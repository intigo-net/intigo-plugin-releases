<?php
/** Upgrade to 1.3.30 — when the governorate is confirmed but no délégation is named
 *  in the address, auto-fill the best délégation INSIDE that governorate (search-engine
 *  top hit → chef-lieu → first) as REVIEW, instead of leaving the order unsendable;
 *  plus a precise "Ville détectée" message. No cross-governorate guess. No schema change. */
if (!defined('_PS_VERSION_')) { exit; }
function upgrade_module_1_3_30($module)
{
    if (!(include dirname(__FILE__) . '/../sql/install.php')) { return false; }
    if (method_exists($module, 'ensureTabs')) { $module->ensureTabs(); }
    return true;
}
