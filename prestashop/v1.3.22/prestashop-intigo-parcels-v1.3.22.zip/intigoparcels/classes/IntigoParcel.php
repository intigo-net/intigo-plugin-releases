<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * One row per PrestaShop order that has interacted with Intigo.
 *
 * Primary key is `id_order` (1:1 with ps_orders). Created on first push attempt,
 * regardless of whether the API call succeeded — we need somewhere to record
 * `last_error` and `last_attempt_at` even when no NID came back yet.
 */
class IntigoParcel extends ObjectModel
{
    public $id_order;
    public $nid = '';
    public $status_code = 0;
    public $package_size = 1;
    public $recipient_name = '';
    public $recipient_phone = '';
    public $reference_id = '';
    public $destination_address = '';
    public $destination_city_id = 0;
    public $destination_district_id = 0;
    public $destination_neighborhood_id = 0;
    public $destination_city_name = '';
    public $destination_district_name = '';
    public $pickup_index = -1;
    public $pickup_override_index = null;
    public $resolution_status = 'pending';
    public $resolution_confidence = '';
    public $resolved_from = '';
    public $auto_resolved = 0;
    public $resolution_source = '';
    public $last_resolution_at;
    public $bordereau_url = '';
    public $idempotency_hash = '';
    public $api_target_used = '';
    public $sync_locked = 0;
    public $send_lock = 0;
    public $send_lock_at;
    public $last_error;
    public $last_attempt_at;
    public $last_sync_at;
    public $created_at;
    public $updated_at;

    public static $definition = [
        'table' => 'intigo_parcel',
        'primary' => 'id_order',
        'fields' => [
            'id_order' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true],
            'nid' => ['type' => self::TYPE_STRING, 'size' => 64],
            'status_code' => ['type' => self::TYPE_INT],
            'package_size' => ['type' => self::TYPE_INT],
            'recipient_name' => ['type' => self::TYPE_STRING, 'size' => 190],
            'recipient_phone' => ['type' => self::TYPE_STRING, 'size' => 32],
            // Merchant-facing reference shown in the UI as "Référence"; sent to
            // Intigo as the parcel `additional_info` field (the v3 API has no
            // `note` field on create — verified against partner2-api).
            'reference_id' => ['type' => self::TYPE_STRING, 'size' => 190],
            'destination_address' => ['type' => self::TYPE_HTML],
            'destination_city_id' => ['type' => self::TYPE_INT],
            'destination_district_id' => ['type' => self::TYPE_INT],
            'destination_neighborhood_id' => ['type' => self::TYPE_INT],
            'destination_city_name' => ['type' => self::TYPE_STRING, 'size' => 190],
            'destination_district_name' => ['type' => self::TYPE_STRING, 'size' => 190],
            'pickup_index' => ['type' => self::TYPE_INT],
            // Sticky merchant override; NULL = no override (fall back to status map).
            'pickup_override_index' => ['type' => self::TYPE_INT, 'allow_null' => true],
            'resolution_status' => ['type' => self::TYPE_STRING, 'size' => 16],
            'resolution_confidence' => ['type' => self::TYPE_STRING, 'size' => 8],
            'resolved_from' => ['type' => self::TYPE_STRING, 'size' => 255],
            'auto_resolved' => ['type' => self::TYPE_BOOL],
            'resolution_source' => ['type' => self::TYPE_STRING, 'size' => 16],
            'last_resolution_at' => ['type' => self::TYPE_DATE, 'allow_null' => true],
            'bordereau_url' => ['type' => self::TYPE_STRING, 'size' => 512],
            'idempotency_hash' => ['type' => self::TYPE_STRING, 'size' => 32],
            'api_target_used' => ['type' => self::TYPE_STRING, 'size' => 16],
            'sync_locked' => ['type' => self::TYPE_BOOL],
            'send_lock' => ['type' => self::TYPE_BOOL],
            'send_lock_at' => ['type' => self::TYPE_DATE, 'allow_null' => true],
            'last_error' => ['type' => self::TYPE_HTML, 'allow_null' => true],
            'last_attempt_at' => ['type' => self::TYPE_DATE, 'allow_null' => true],
            'last_sync_at' => ['type' => self::TYPE_DATE, 'allow_null' => true],
            'created_at' => ['type' => self::TYPE_DATE],
            'updated_at' => ['type' => self::TYPE_DATE],
        ],
    ];

    /**
     * ObjectModel's default flow uses an auto-increment `id_intigo_parcel` PK.
     * Our PK is `id_order` (1:1 with ps_orders) — so we override save() to do
     * an upsert keyed on id_order instead.
     */
    public function save($null_values = false, $auto_date = true)
    {
        $now = date('Y-m-d H:i:s');
        if (empty($this->created_at)) {
            $this->created_at = $now;
        }
        $this->updated_at = $now;

        $existing = self::findByOrderId((int) $this->id_order);
        if ($existing) {
            $data = $this->toRow();
            unset($data['id_order']);
            return Db::getInstance()->update(
                self::$definition['table'],
                $data,
                'id_order = ' . (int) $this->id_order,
                1
            );
        }
        return Db::getInstance()->insert(self::$definition['table'], $this->toRow());
    }

    public static function findByOrderId($id_order)
    {
        $id_order = (int) $id_order;
        if ($id_order <= 0) {
            return null;
        }
        $row = Db::getInstance()->getRow(
            'SELECT * FROM `' . _DB_PREFIX_ . self::$definition['table'] . '` WHERE id_order = ' . $id_order
        );
        if (!$row) {
            return null;
        }
        $instance = new self();
        foreach ($row as $key => $value) {
            if (property_exists($instance, $key)) {
                $instance->{$key} = $value;
            }
        }
        return $instance;
    }

    public static function findByNid($nid)
    {
        $nid = pSQL((string) $nid);
        if ($nid === '') {
            return null;
        }
        // Db::getRow auto-appends LIMIT 1, so we don't add one ourselves.
        $row = Db::getInstance()->getRow(
            'SELECT * FROM `' . _DB_PREFIX_ . self::$definition['table'] . '` WHERE nid = "' . $nid . '"'
        );
        if (!$row) {
            return null;
        }
        $instance = new self();
        foreach ($row as $key => $value) {
            if (property_exists($instance, $key)) {
                $instance->{$key} = $value;
            }
        }
        return $instance;
    }

    /**
     * Returns the N most recent parcels (any status) for sync sweep / dashboard.
     */
    public static function recent($limit = 50)
    {
        $limit = max(1, (int) $limit);
        $rows = Db::getInstance()->executeS(
            'SELECT * FROM `' . _DB_PREFIX_ . self::$definition['table'] . '`
            WHERE nid <> ""
            ORDER BY COALESCE(last_sync_at, last_attempt_at, created_at) DESC
            LIMIT ' . $limit
        );
        return is_array($rows) ? $rows : [];
    }

    /**
     * Atomically claim an order for sending, so concurrent pushes (bulk run,
     * double-click, cron overlapping a manual send) can NEVER create duplicate
     * parcels at Intigo — the v3 API has no client idempotency key, so this
     * client-side lock is the only guard. Ensures a row exists, then a single
     * UPDATE wins the claim. A lock older than $stale_seconds is reclaimable in
     * case a previous push died mid-flight.
     *
     * @return bool true only for the caller that acquired the claim.
     */
    public static function claimForSend($id_order, $force = false, $stale_seconds = 180)
    {
        $id_order = (int) $id_order;
        if ($id_order <= 0) {
            return false;
        }
        $db = Db::getInstance();
        $table = _DB_PREFIX_ . self::$definition['table'];
        $now = date('Y-m-d H:i:s');

        // Ensure a row exists (no-op if present) so the claim UPDATE has a target.
        $db->execute(
            'INSERT IGNORE INTO `' . $table . '` (id_order, destination_address, created_at, updated_at)
             VALUES (' . $id_order . ', "", "' . pSQL($now) . '", "' . pSQL($now) . '")'
        );

        $stale = date('Y-m-d H:i:s', time() - (int) $stale_seconds);
        // Non-force: only claim orders not already pushed (nid empty). Force still
        // serializes (so two forced pushes can't race) but ignores the nid guard.
        $nidGuard = $force ? '' : ' AND nid = ""';
        $db->execute(
            'UPDATE `' . $table . '`
             SET send_lock = 1, send_lock_at = "' . pSQL($now) . '"
             WHERE id_order = ' . $id_order . $nidGuard . '
               AND (send_lock = 0 OR send_lock_at IS NULL OR send_lock_at < "' . pSQL($stale) . '")'
        );
        return (int) $db->Affected_Rows() === 1;
    }

    public static function releaseSendLock($id_order)
    {
        $id_order = (int) $id_order;
        if ($id_order <= 0) {
            return;
        }
        Db::getInstance()->execute(
            'UPDATE `' . _DB_PREFIX_ . self::$definition['table'] . '` SET send_lock = 0 WHERE id_order = ' . $id_order
        );
    }

    private function toRow()
    {
        $row = [];
        foreach (self::$definition['fields'] as $key => $def) {
            $value = $this->{$key};
            if ($value === null && empty($def['allow_null'])) {
                continue;
            }
            // Build the escaped, quoted SQL literal ourselves and pass it as a raw
            // ('sql') value. Db::update() does NOT escape scalar values (only
            // Db::insert() does), so a name like "Salma B'chir" would otherwise
            // break the UPDATE on an existing parcel. type=>'sql' is used verbatim
            // by BOTH insert and update, so there's no risk of double-escaping.
            if ($value === null) {
                $row[$key] = ['type' => 'sql', 'value' => 'NULL'];
                continue;
            }
            $allow_html = (isset($def['type']) && $def['type'] === self::TYPE_HTML);
            $row[$key] = ['type' => 'sql', 'value' => "'" . pSQL((string) $value, $allow_html) . "'"];
        }
        return $row;
    }
}
