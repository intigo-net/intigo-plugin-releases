<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Maps a PrestaShop order status to an Intigo pickup address.
 *
 * "The system is based on status": when an order reaches a mapped status, the
 * module knows which pickup address the courier should collect from and sends
 * its `index` as `parcel.pickup_index` at push time (see IntigoOrderService).
 *
 * Storage is keyed by status — UNIQUE(id_shop, id_order_state) — so resolution
 * is deterministic (one status maps to at most one address). The admin UI
 * presents it the other way round (one row per address, a status selector),
 * but the table is indexed by status for fast push-time lookup.
 *
 * Defensive design (PICKUP_STATUS_SPEC §3/§9): we persist BOTH the API `index`
 * (the value we send) AND the internal `id`, plus a frozen `pickup_label`, so
 * the mapping survives even if the address later disappears from Intigo.
 */
class IntigoPickupMap extends ObjectModel
{
    public $id_map;
    public $id_shop = 1;
    public $id_order_state = 0;
    public $pickup_index = 0;
    public $pickup_id = 0;
    public $pickup_label = '';
    public $date_upd;

    public static $definition = [
        'table' => 'intigo_pickup_map',
        'primary' => 'id_map',
        'fields' => [
            'id_shop' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId'],
            'id_order_state' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true],
            'pickup_index' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'],
            'pickup_id' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedInt'],
            'pickup_label' => ['type' => self::TYPE_STRING, 'size' => 255],
            'date_upd' => ['type' => self::TYPE_DATE, 'allow_null' => true],
        ],
    ];

    /**
     * Upsert the address mapped to a status (keyed on the unique pair).
     * The UNIQUE(id_shop, id_order_state) constraint is the source of truth that
     * a status maps to at most one address — JS only mirrors it for UX.
     */
    public static function set($id_shop, $id_order_state, $pickup_index, $pickup_id, $label)
    {
        $id_shop = (int) $id_shop ?: 1;
        $id_order_state = (int) $id_order_state;
        if ($id_order_state <= 0) {
            return false;
        }
        $data = [
            'id_shop' => $id_shop,
            'id_order_state' => $id_order_state,
            'pickup_index' => (int) $pickup_index,
            'pickup_id' => (int) $pickup_id,
            'pickup_label' => pSQL((string) $label),
            'date_upd' => date('Y-m-d H:i:s'),
        ];
        $existing = (int) Db::getInstance()->getValue(
            'SELECT id_map FROM `' . _DB_PREFIX_ . self::$definition['table'] . '`
             WHERE id_shop = ' . $id_shop . ' AND id_order_state = ' . $id_order_state
        );
        if ($existing > 0) {
            return Db::getInstance()->update(self::$definition['table'], $data, 'id_map = ' . $existing, 1);
        }
        return Db::getInstance()->insert(self::$definition['table'], $data);
    }

    /**
     * Detach a status from any address.
     */
    public static function clearForState($id_shop, $id_order_state)
    {
        $id_shop = (int) $id_shop ?: 1;
        $id_order_state = (int) $id_order_state;
        if ($id_order_state <= 0) {
            return false;
        }
        return Db::getInstance()->delete(
            self::$definition['table'],
            'id_shop = ' . $id_shop . ' AND id_order_state = ' . $id_order_state
        );
    }

    /**
     * Fast push-time lookup: the pickup index for a (shop, status), or null when
     * the status isn't mapped. Never throws — a missing table returns null.
     */
    public static function resolvePickupIndex($id_shop, $id_order_state)
    {
        $id_shop = (int) $id_shop ?: 1;
        $id_order_state = (int) $id_order_state;
        if ($id_order_state <= 0) {
            return null;
        }
        try {
            $val = Db::getInstance()->getValue(
                'SELECT pickup_index FROM `' . _DB_PREFIX_ . self::$definition['table'] . '`
                 WHERE id_shop = ' . $id_shop . ' AND id_order_state = ' . $id_order_state
            );
        } catch (\Throwable $e) {
            return null;
        }
        return ($val === false || $val === null) ? null : (int) $val;
    }

    /**
     * All order-state IDs mapped to a pickup address for this shop — i.e. the
     * statuses the merchant designated as "Intigo" orders. Used to scope the
     * Intigo Orders list (they ship different statuses with different couriers,
     * so only these belong to Intigo).
     */
    public static function mappedStates($id_shop)
    {
        return array_map('intval', array_keys(self::getMap($id_shop)));
    }

    /**
     * Order-state IDs mapped to a pickup address that STILL EXISTS in the current
     * Intigo pickup cache — a stale mapping to a removed address is ignored. This
     * is the canonical "Intigo orders" status scope, shared by the Orders list and
     * the dashboard coverage metric. If the pickup cache isn't populated yet, every
     * mapped status is kept so scoping still works.
     */
    public static function mappedStatesForExistingPickups($id_shop)
    {
        $map = self::getMap($id_shop);
        if (empty($map)) {
            return [];
        }
        $valid = [];
        $pc = Configuration::get('INTIGO_PICKUP_CACHE');
        if ($pc !== false && trim((string) $pc) !== '') {
            $list = json_decode((string) $pc, true);
            if (is_array($list)) {
                foreach ($list as $it) {
                    if (is_array($it) && isset($it['index']) && $it['index'] !== null) {
                        $valid[(int) $it['index']] = true;
                    }
                }
            }
        }
        $states = [];
        foreach ($map as $state => $mm) {
            if (empty($valid) || isset($valid[(int) $mm['pickup_index']])) {
                $states[] = (int) $state;
            }
        }
        return $states;
    }

    /**
     * The full mapping for a shop, keyed by status for the admin UI:
     *   [id_order_state => ['pickup_index'=>int,'pickup_id'=>int,'label'=>string]]
     */
    public static function getMap($id_shop)
    {
        $id_shop = (int) $id_shop ?: 1;
        $out = [];
        try {
            $rows = Db::getInstance()->executeS(
                'SELECT id_order_state, pickup_index, pickup_id, pickup_label
                 FROM `' . _DB_PREFIX_ . self::$definition['table'] . '`
                 WHERE id_shop = ' . $id_shop
            );
        } catch (\Throwable $e) {
            return $out;
        }
        if (is_array($rows)) {
            foreach ($rows as $r) {
                $out[(int) $r['id_order_state']] = [
                    'pickup_index' => (int) $r['pickup_index'],
                    'pickup_id' => (int) $r['pickup_id'],
                    'label' => (string) $r['pickup_label'],
                ];
            }
        }
        return $out;
    }
}
