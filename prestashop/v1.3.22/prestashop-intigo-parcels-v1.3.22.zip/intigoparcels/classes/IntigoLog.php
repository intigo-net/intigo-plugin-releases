<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Activity log — circular buffer whose size is configurable via the
 * INTIGO_LOG_MAX_ROWS setting (default 2000). Oldest rows are trimmed on insert
 * so storage stays bounded.
 */
class IntigoLog
{
    const TABLE = 'intigo_log';
    const DEFAULT_MAX_ROWS = 2000;

    /**
     * Row cap, from the INTIGO_LOG_MAX_ROWS config (clamped to a sane range).
     * Falls back to DEFAULT_MAX_ROWS when unset/invalid.
     */
    public static function maxRows()
    {
        $n = (int) Configuration::get('INTIGO_LOG_MAX_ROWS');
        if ($n <= 0) {
            $n = self::DEFAULT_MAX_ROWS;
        }
        return max(100, min(50000, $n));
    }

    /**
     * @param int|null $id_order Related PS order id (searchable), or null for
     *                           global/config events with no order in scope.
     */
    public static function add($action, $context = '', $actor = null, $id_order = null)
    {
        $action = trim((string) $action);
        if ($action === '') {
            return false;
        }

        if ($actor === null) {
            $actor = 'system';
            if (class_exists('Context')) {
                $ctx = Context::getContext();
                if ($ctx && isset($ctx->employee) && is_object($ctx->employee) && !empty($ctx->employee->id)) {
                    $actor = (string) ($ctx->employee->email ?: ('employee#' . $ctx->employee->id));
                }
            }
        }

        if (is_array($context)) {
            $context = json_encode($context);
        }

        $ok = Db::getInstance()->insert(self::TABLE, [
            'created_at' => date('Y-m-d H:i:s'),
            'actor' => substr((string) $actor, 0, 64),
            'action' => substr((string) $action, 0, 64),
            // NULL when no order is in scope; int otherwise (searchable column).
            'id_order' => ((int) $id_order > 0)
                ? (int) $id_order
                : ['type' => 'sql', 'value' => 'NULL'],
            'context' => (string) $context,
        ]);

        self::trim();
        return $ok;
    }

    /**
     * Keeps only the most recent MAX_ROWS entries. Runs after every insert.
     * Cheap because the table is bounded; one DELETE keyed on id range.
     *
     * Db::getValue/getRow auto-appends `LIMIT 1` to the query, which collides
     * with our manual `LIMIT 1 OFFSET MAX_ROWS`. Use executeS to bypass that.
     */
    public static function trim()
    {
        $rows = Db::getInstance()->executeS(
            'SELECT id_intigo_log FROM `' . _DB_PREFIX_ . self::TABLE . '`
            ORDER BY id_intigo_log DESC LIMIT 1 OFFSET ' . (int) self::maxRows()
        );
        if (is_array($rows) && !empty($rows) && isset($rows[0]['id_intigo_log'])) {
            $cutoff_id = (int) $rows[0]['id_intigo_log'];
            Db::getInstance()->execute(
                'DELETE FROM `' . _DB_PREFIX_ . self::TABLE . '` WHERE id_intigo_log <= ' . $cutoff_id
            );
        }
    }

    /**
     * Page through recent log entries.
     *
     * @param int $page  1-indexed
     * @param int $per_page
     * @return array{rows: array, total: int}
     */
    public static function paginate($page = 1, $per_page = 25, $id_order = null)
    {
        $page = max(1, (int) $page);
        $per_page = max(1, min(200, (int) $per_page));
        $offset = ($page - 1) * $per_page;

        // Optional order-id filter (int-cast, so it's injection-safe).
        $where = ((int) $id_order > 0) ? ' WHERE id_order = ' . (int) $id_order : '';

        $rows = Db::getInstance()->executeS(
            'SELECT * FROM `' . _DB_PREFIX_ . self::TABLE . '`' . $where . '
            ORDER BY id_intigo_log DESC
            LIMIT ' . (int) $per_page . ' OFFSET ' . (int) $offset
        );
        $total = (int) Db::getInstance()->getValue(
            'SELECT COUNT(*) FROM `' . _DB_PREFIX_ . self::TABLE . '`' . $where
        );
        return ['rows' => is_array($rows) ? $rows : [], 'total' => $total];
    }
}
