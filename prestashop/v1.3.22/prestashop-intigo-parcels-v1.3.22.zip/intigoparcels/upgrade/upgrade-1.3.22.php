<?php
/** Upgrade to 1.3.22 — recipient name completes a missing surname from the
 *  customer when the delivery address has only a first name. No schema change. */
if (!defined('_PS_VERSION_')) { exit; }
function upgrade_module_1_3_22($module)
{
    if (!(include dirname(__FILE__) . '/../sql/install.php')) { return false; }
    if (method_exists($module, 'ensureTabs')) { $module->ensureTabs(); }
    return true;
}
