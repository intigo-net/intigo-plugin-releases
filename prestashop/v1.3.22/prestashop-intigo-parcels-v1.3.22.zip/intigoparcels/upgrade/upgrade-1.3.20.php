<?php
/** Upgrade to 1.3.20 — pickup integrity + searchable logs.
 *  - Adds intigo_parcel.pickup_override_index (sticky per-order pickup override).
 *  - Adds intigo_log.id_order (logs become searchable/filterable by order).
 *  Both are healed idempotently by sql/install.php's column guards. No global
 *  default pickup anymore: a parcel is sent only when a pickup is explicitly
 *  resolved (override or status map), otherwise the send is blocked. */
if (!defined('_PS_VERSION_')) { exit; }
function upgrade_module_1_3_20($module)
{
    if (!(include dirname(__FILE__) . '/../sql/install.php')) { return false; }
    // Remove the retired global default pickup — sends no longer fall back to it.
    Configuration::deleteByName('INTIGO_DEFAULT_PICKUP_INDEX');
    if (method_exists($module, 'ensureTabs')) { $module->ensureTabs(); }
    return true;
}
