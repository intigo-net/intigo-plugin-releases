<?php
/** Upgrade to 1.3.21 — dashboard polish + fixes (no schema change):
 *  - "Couverture Intigo" now divides by Intigo-relevant orders, not all orders.
 *  - Personalized dashboard greeting; friendly widgets (top villes donut,
 *    petits faits, stats par adresse de ramassage).
 *  The idempotent install heal is kept for safety. */
if (!defined('_PS_VERSION_')) { exit; }
function upgrade_module_1_3_21($module)
{
    if (!(include dirname(__FILE__) . '/../sql/install.php')) { return false; }
    if (method_exists($module, 'ensureTabs')) { $module->ensureTabs(); }
    return true;
}
