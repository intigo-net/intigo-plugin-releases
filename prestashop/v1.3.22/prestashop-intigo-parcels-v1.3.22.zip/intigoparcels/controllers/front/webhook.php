<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Webhook receiver — Intigo → PrestaShop status sync.
 *
 *   POST /module/intigoparcels/webhook
 *
 * Intigo's logistics backend POSTs here whenever a parcel status changes (see
 * WEBHOOK_STATUS_SYNC_SPEC.md). We verify the HMAC-SHA256 signature against the
 * shared token, find the order by NID, update the stored status, and (for mapped
 * milestones) transition the native PrestaShop order state.
 *
 * Security: a token MUST be configured for any side effect — an unsigned/forged
 * request can never flip an order. Always fast, always answers, never throws.
 */
class IntigoparcelsWebhookModuleFrontController extends ModuleFrontController
{
    public $ssl = true;
    public $auth = false;
    public $ajax = true;

    public function postProcess()
    {
        @ob_end_clean();
        header('Content-Type: application/json; charset=utf-8');

        $raw = Tools::file_get_contents('php://input');
        if ($raw === false || $raw === null) {
            $raw = '';
        }

        try {
            require_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoParcel.php';
            require_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoLog.php';
            list($code, $body) = $this->handle((string) $raw);
        } catch (\Throwable $e) {
            // Accepted but failed internally — return 200 so Intigo doesn't retry a
            // parcel we already received; the dashboard status-pull reconciles.
            if (class_exists('IntigoLog')) {
                IntigoLog::add('webhook_error', $e->getMessage());
            }
            $code = 200;
            $body = ['ok' => false, 'message' => 'internal error (accepted)'];
        }

        http_response_code($code);
        echo json_encode($body);
        exit;
    }

    /**
     * @return array [http_code, body]
     */
    private function handle($raw)
    {
        $token = trim((string) Configuration::get('INTIGO_WEBHOOK_TOKEN'));
        if ($token === '') {
            IntigoLog::add('webhook_no_token', 'rejected — configure a token in Settings');
            return [401, ['ok' => false, 'message' => 'webhook not configured']];
        }

        // Verify authenticity: HMAC signature over the RAW body (primary), Bearer
        // token (fallback identity). Either must match.
        $sig = isset($_SERVER['HTTP_X_WEBHOOK_SIGNATURE']) ? (string) $_SERVER['HTTP_X_WEBHOOK_SIGNATURE'] : '';
        $bearer = isset($_SERVER['HTTP_AUTHORIZATION']) ? (string) $_SERVER['HTTP_AUTHORIZATION'] : '';
        $expected = 'sha256=' . hash_hmac('sha256', $raw, $token);
        $sig_ok = ($sig !== '' && hash_equals($expected, $sig));
        $bearer_ok = ($bearer !== '' && hash_equals('Bearer ' . $token, $bearer));
        if (!$sig_ok && !$bearer_ok) {
            IntigoLog::add('webhook_bad_signature', 'sig=' . substr($sig, 0, 20));
            return [401, ['ok' => false, 'message' => 'invalid signature']];
        }

        $data = json_decode($raw, true);
        if (!is_array($data) || (isset($data['event']) ? $data['event'] : '') !== 'parcel.status_changed'
            || empty($data['data']['nid'])) {
            return [400, ['ok' => false, 'message' => 'bad payload']];
        }

        // Record that the webhook is alive (surfaced on Settings / Dashboard).
        Configuration::updateValue('INTIGO_WEBHOOK_LAST_TS', (string) time());

        $nid = (string) $data['data']['nid'];
        $new_status = isset($data['data']['new_status']) ? (int) $data['data']['new_status'] : 0;
        $old_status = isset($data['data']['old_status']) ? (int) $data['data']['old_status'] : 0;
        $label = isset($data['data']['status_label']) ? (string) $data['data']['status_label'] : '';

        $parcel = IntigoParcel::findByNid($nid);
        if (!$parcel) {
            IntigoLog::add('webhook_unknown_nid', $nid);
            return [200, ['ok' => true, 'message' => 'unknown nid (ignored)']];
        }

        // Out-of-order guard: ignore an event that doesn't advance state (a late/
        // replayed delivery can't move a parcel backwards out of a terminal state).
        $current = (int) $parcel->status_code;
        if ($current >= 5000 && $new_status > 0 && $new_status < $current) {
            IntigoLog::add('webhook_stale', 'nid=' . $nid . ' ' . $current . ' -> ' . $new_status . ' ignored');
            return [200, ['ok' => true, 'message' => 'stale event ignored']];
        }

        $parcel->status_code = $new_status;
        $parcel->last_sync_at = date('Y-m-d H:i:s');
        if ($new_status >= 5000) {
            // Delivered / returned → locked at Intigo, no more BO updates.
            $parcel->sync_locked = 1;
        }
        $parcel->save();

        // The parcel's Intigo status is ALWAYS recorded (shown on the orders/order
        // screens). The native PS order status is only moved when the merchant has
        // enabled it in Settings (toggle) — otherwise we leave their order workflow
        // untouched and just surface the new Intigo status.
        if ((string) Configuration::get('INTIGO_WH_UPDATE_ORDERS') !== '0') {
            $this->transitionOrderState((int) $parcel->id_order, $new_status);
        }

        IntigoLog::add('webhook_status', 'nid=' . $nid . ' ' . $old_status . ' -> ' . $new_status . ' (' . $label . ')',
            null, (int) $parcel->id_order);
        return [200, ['ok' => true, 'message' => 'updated']];
    }

    /**
     * Transition the native PS order state for a mapped milestone, idempotently.
     * Only acts when the merchant has chosen a target state; never overrides a
     * cancelled/refunded order.
     */
    private function transitionOrderState($id_order, $new_status)
    {
        try {
            require_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoStatus.php';
            // Merchant-configured Intigo-status → PS-state map (many-to-many).
            $target = (int) IntigoStatus::psStateFor($new_status);
            if ($target <= 0) {
                return;
            }
            $order = new Order($id_order);
            if (!Validate::isLoadedObject($order)) {
                return;
            }
            $current = (int) $order->getCurrentState();
            if ($current === $target) {
                return; // idempotent — already there
            }
            // Don't drag a cancelled/refunded/error order to "delivered".
            $cur_state = new OrderState($current);
            if (Validate::isLoadedObject($cur_state) && ((int) $cur_state->paid === 0 && ((int) $cur_state->shipped === 0))
                && ($current === (int) Configuration::get('PS_OS_CANCELED') || $current === (int) Configuration::get('PS_OS_ERROR'))) {
                return;
            }
            $history = new OrderHistory();
            $history->id_order = (int) $order->id;
            $history->changeIdOrderState($target, $order, true);
            $history->add();

            // Log the transition WITH the pickup detected for the new status, so a
            // wrong-pickup situation is visible in the searchable per-order log.
            IntigoLog::add('order_state_changed',
                'src=webhook ' . $this->stateName($current) . ' -> ' . $this->stateName($target)
                . ' | ramassage: ' . $this->detectedPickupLabel((int) $order->id_shop ?: 1, $target),
                null, (int) $order->id);
        } catch (\Throwable $e) {
            IntigoLog::add('webhook_state_error', $e->getMessage(), null, (int) $id_order);
        }
    }

    /** Human PS order-state name in the default language (or "#id" fallback). */
    private function stateName($id_state)
    {
        $lang = (int) Configuration::get('PS_LANG_DEFAULT') ?: 1;
        $os = new OrderState((int) $id_state, $lang);
        return Validate::isLoadedObject($os) ? (string) $os->name : ('#' . (int) $id_state);
    }

    /**
     * The pickup address mapped to a PS order state, for the log — label if the
     * status maps to one, else a "blocked" note (no default fallback exists).
     */
    private function detectedPickupLabel($id_shop, $id_state)
    {
        $row = Db::getInstance()->getRow(
            'SELECT pickup_index, pickup_label FROM `' . _DB_PREFIX_ . 'intigo_pickup_map`
             WHERE id_shop = ' . (int) $id_shop . ' AND id_order_state = ' . (int) $id_state
        );
        if ($row && (int) $row['pickup_index'] >= 1) {
            $lbl = trim((string) $row['pickup_label']);
            return ($lbl !== '' ? $lbl : ('#' . (int) $row['pickup_index']));
        }
        return 'aucune (envoi bloqué — à définir dans la commande)';
    }
}
