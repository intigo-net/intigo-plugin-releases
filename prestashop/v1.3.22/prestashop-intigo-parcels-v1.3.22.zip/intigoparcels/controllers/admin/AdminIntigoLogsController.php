<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

require_once dirname(__FILE__) . '/../../classes/IntigoAutoload.php';

class AdminIntigoLogsController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        $this->display = 'view';
        parent::__construct();
        $this->meta_title = $this->trans('Intigo — Logs', [], 'Modules.Intigoparcels.Admin');
        $this->show_page_header_toolbar = false;
    }

    public function initContent()
    {
        $page = max(1, (int) Tools::getValue('p', 1));
        // Optional order-id filter, so a merchant can pull one order's full history.
        $oid = (int) Tools::getValue('oid', 0);
        $data = IntigoLog::paginate($page, 25, $oid > 0 ? $oid : null);
        $rows = $data['rows'];
        $total = (int) $data['total'];
        $pages = max(1, (int) ceil($total / 25));

        $base_url = self::$currentIndex . '&token=' . $this->token;
        $oid_qs = $oid > 0 ? '&oid=' . $oid : '';

        $html = '<div class="intigo-screen">' . IntigoAdminUi::navHtml($this->context->link, 'logs');
        $html .= '<div class="panel"><div class="panel-heading"><i class="material-icons">receipt</i> Intigo — Logs (' . $total . ')</div>';

        // Filter by order id — single GET form (same Appliquer/Réinitialiser
        // pattern as the Orders list) so logs are searchable per order.
        $html .= '<form method="get" class="intigo-filters" style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;margin-bottom:12px;">'
            . '<input type="hidden" name="controller" value="AdminIntigoLogs">'
            . '<input type="hidden" name="token" value="' . htmlspecialchars($this->token) . '">'
            . '<span style="font-size:12px;color:#667085;">Commande n°</span>'
            . '<input type="number" name="oid" min="1" value="' . ($oid > 0 ? (int) $oid : '') . '" placeholder="ex : 2599" class="form-control input-sm" style="width:150px;height:31px;">'
            . '<button type="submit" class="btn btn-sm btn-primary"><i class="material-icons" style="font-size:15px;vertical-align:middle;">filter_alt</i> Appliquer</button>';
        if ($oid > 0) {
            $html .= '<a href="' . htmlspecialchars($base_url) . '" class="btn btn-sm btn-default">✕ Réinitialiser</a>';
        }
        $html .= '</form>';

        // Friendly French label + colour per event. Webhooks RECEIVED from the
        // Intigo system are highlighted so they're easy to spot in the journal.
        $labels = [
            'webhook_status' => ['Webhook reçu — statut mis à jour', 'success'],
            'webhook_bad_signature' => ['Webhook — signature invalide', 'danger'],
            'webhook_unknown_nid' => ['Webhook reçu — colis inconnu', 'warning'],
            'webhook_no_token' => ['Webhook — non configuré (jeton manquant)', 'warning'],
            'webhook_error' => ['Webhook — erreur de traitement', 'danger'],
            'webhook_stale' => ['Webhook — événement ignoré (obsolète)', 'default'],
            'webhook_state_error' => ['Webhook — erreur de changement d\'état', 'danger'],
            'webhook_settings_save' => ['Webhook — configuration enregistrée', 'info'],
            'order_state_changed' => ['Changement de statut (ramassage détecté)', 'info'],
            'pickup_required' => ['Envoi bloqué — adresse de ramassage requise', 'warning'],
            'auto_push_pickup_required' => ['Auto-envoi bloqué — ramassage requis', 'warning'],
            'order_push_ok' => ['Colis créé chez Intigo', 'success'],
            'order_push_failed' => ['Échec de l\'envoi du colis', 'danger'],
            'order_resend_ok' => ['Colis renvoyé (bon ramassage)', 'success'],
            'order_cancel_ok' => ['Colis annulé', 'default'],
            'order_bordereau_ok' => ['Bordereau généré', 'info'],
            'address_resolved' => ['Adresse Intigo détectée', 'info'],
            'settings_save' => ['Réglages enregistrés', 'default'],
        ];
        $fg = ['success' => '#12805c', 'danger' => '#b42318', 'warning' => '#b54708', 'info' => '#175cd3', 'default' => '#475467'];
        $bg = ['success' => '#ecfdf3', 'danger' => '#fef3f2', 'warning' => '#fffaeb', 'info' => '#eff8ff', 'default' => '#f2f4f7'];

        if (empty($rows)) {
            $html .= '<p>' . ($oid > 0
                ? 'Aucune activité pour la commande n°' . (int) $oid . '.'
                : 'Aucune activité pour l\'instant.') . '</p>';
        } else {
            $html .= '<table class="table"><thead><tr><th>Heure</th><th>Commande</th><th>Acteur</th><th>Événement</th><th>Détails</th></tr></thead><tbody>';
            foreach ($rows as $r) {
                $action = (string) $r['action'];
                $is_wh = strpos($action, 'webhook') === 0;
                $lbl = isset($labels[$action]) ? $labels[$action][0] : $action;
                $kind = isset($labels[$action]) ? $labels[$action][1] : 'default';
                $badge = '<span style="display:inline-block;padding:2px 9px;border-radius:11px;font-size:12px;font-weight:600;color:'
                    . $fg[$kind] . ';background:' . $bg[$kind] . ';">' . htmlspecialchars($lbl) . '</span>';
                $rowStyle = $is_wh ? ' style="background:#fbf9ff;"' : '';
                $oid_cell = ((int) $r['id_order'] > 0)
                    ? '<code>#' . (int) $r['id_order'] . '</code>'
                    : '<span style="color:#98a2b3;">—</span>';
                $html .= '<tr' . $rowStyle . '>'
                    . '<td style="white-space:nowrap;">' . htmlspecialchars($r['created_at']) . '</td>'
                    . '<td style="white-space:nowrap;">' . $oid_cell . '</td>'
                    . '<td>' . htmlspecialchars($r['actor']) . '</td>'
                    . '<td>' . $badge . ' <code style="font-size:11px;color:#98a2b3;">' . htmlspecialchars($action) . '</code></td>'
                    . '<td>' . htmlspecialchars((string) $r['context']) . '</td>'
                    . '</tr>';
            }
            $html .= '</tbody></table>';
            if ($pages > 1) {
                $html .= '<ul class="pagination">';
                for ($i = 1; $i <= $pages; $i++) {
                    $url = $base_url . $oid_qs . '&p=' . $i;
                    $cls = $i === $page ? ' class="active"' : '';
                    $html .= '<li' . $cls . '><a href="' . htmlspecialchars($url) . '">' . $i . '</a></li>';
                }
                $html .= '</ul>';
            }
        }
        $html .= '</div>';
        $html .= '</div>'; // .intigo-screen
        $this->content = $html;
        parent::initContent();
    }
}
