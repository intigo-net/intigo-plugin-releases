<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

$sql = [];

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'intigo_parcel` (
    `id_order` INT UNSIGNED NOT NULL,
    `nid` VARCHAR(64) NOT NULL DEFAULT \'\',
    `status_code` INT NOT NULL DEFAULT 0,
    `package_size` TINYINT UNSIGNED NOT NULL DEFAULT 1,
    `recipient_name` VARCHAR(190) NOT NULL DEFAULT \'\',
    `recipient_phone` VARCHAR(32) NOT NULL DEFAULT \'\',
    `reference_id` VARCHAR(190) NOT NULL DEFAULT \'\',
    `destination_address` TEXT NOT NULL,
    `destination_city_id` INT UNSIGNED NOT NULL DEFAULT 0,
    `destination_district_id` INT UNSIGNED NOT NULL DEFAULT 0,
    `destination_neighborhood_id` INT UNSIGNED NOT NULL DEFAULT 0,
    `destination_city_name` VARCHAR(190) NOT NULL DEFAULT \'\',
    `destination_district_name` VARCHAR(190) NOT NULL DEFAULT \'\',
    `pickup_index` INT NOT NULL DEFAULT -1,
    `pickup_override_index` INT NULL DEFAULT NULL,
    `resolution_status` VARCHAR(16) NOT NULL DEFAULT \'pending\',
    `resolution_confidence` VARCHAR(8) NOT NULL DEFAULT \'\',
    `resolved_from` VARCHAR(255) NOT NULL DEFAULT \'\',
    `auto_resolved` TINYINT(1) NOT NULL DEFAULT 0,
    `resolution_source` VARCHAR(16) NOT NULL DEFAULT \'\',
    `last_resolution_at` DATETIME NULL,
    `bordereau_url` VARCHAR(512) NOT NULL DEFAULT \'\',
    `idempotency_hash` CHAR(32) NOT NULL DEFAULT \'\',
    `api_target_used` VARCHAR(16) NOT NULL DEFAULT \'\',
    `sync_locked` TINYINT(1) NOT NULL DEFAULT 0,
    `send_lock` TINYINT(1) NOT NULL DEFAULT 0,
    `send_lock_at` DATETIME NULL,
    `last_error` TEXT NULL,
    `last_attempt_at` DATETIME NULL,
    `last_sync_at` DATETIME NULL,
    `created_at` DATETIME NOT NULL,
    `updated_at` DATETIME NOT NULL,
    PRIMARY KEY (`id_order`),
    KEY `nid` (`nid`),
    KEY `status_code` (`status_code`),
    KEY `resolution_status` (`resolution_status`),
    KEY `last_sync_at` (`last_sync_at`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'intigo_product_size` (
    `id_product` INT UNSIGNED NOT NULL,
    `size` ENUM(\'S\',\'M\',\'L\',\'XL\') NOT NULL,
    PRIMARY KEY (`id_product`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'intigo_log` (
    `id_intigo_log` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `created_at` DATETIME NOT NULL,
    `actor` VARCHAR(64) NOT NULL DEFAULT \'system\',
    `action` VARCHAR(64) NOT NULL DEFAULT \'\',
    `id_order` INT UNSIGNED NULL DEFAULT NULL,
    `context` TEXT NULL,
    PRIMARY KEY (`id_intigo_log`),
    KEY `created_at` (`created_at`),
    KEY `id_order` (`id_order`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'intigo_pickup_map` (
    `id_map` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `id_shop` INT UNSIGNED NOT NULL DEFAULT 1,
    `id_order_state` INT UNSIGNED NOT NULL,
    `pickup_index` INT UNSIGNED NOT NULL DEFAULT 0,
    `pickup_id` INT UNSIGNED NOT NULL DEFAULT 0,
    `pickup_label` VARCHAR(255) NOT NULL DEFAULT \'\',
    `date_upd` DATETIME NULL,
    PRIMARY KEY (`id_map`),
    UNIQUE KEY `uniq_shop_state` (`id_shop`, `id_order_state`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

foreach ($sql as $query) {
    if (Db::getInstance()->execute($query) == false) {
        return false;
    }
}

// Idempotent column additions for tables that already exist from an earlier
// install (CREATE TABLE IF NOT EXISTS above won't add new columns). Each guard
// checks information_schema so a re-run is a no-op.
$pt = "`" . _DB_PREFIX_ . "intigo_parcel`";
$columns = [
    'intigo_parcel' => [
        'reference_id' => "ALTER TABLE $pt ADD COLUMN `reference_id` VARCHAR(190) NOT NULL DEFAULT '' AFTER `recipient_phone`",
        // Auto-resolution + bulk-send support (ADDRESS_AUTODETECT_BULK_SPEC).
        'destination_city_name' => "ALTER TABLE $pt ADD COLUMN `destination_city_name` VARCHAR(190) NOT NULL DEFAULT '' AFTER `destination_neighborhood_id`",
        'destination_district_name' => "ALTER TABLE $pt ADD COLUMN `destination_district_name` VARCHAR(190) NOT NULL DEFAULT '' AFTER `destination_city_name`",
        'pickup_index' => "ALTER TABLE $pt ADD COLUMN `pickup_index` INT NOT NULL DEFAULT -1 AFTER `destination_district_name`",
        // Merchant's explicit per-order pickup override (sticky). NULL = no override,
        // resolve pickup from the status→pickup map instead. Kept separate from
        // pickup_index (which records the pickup actually detected/sent).
        'pickup_override_index' => "ALTER TABLE $pt ADD COLUMN `pickup_override_index` INT NULL DEFAULT NULL AFTER `pickup_index`",
        'resolution_status' => "ALTER TABLE $pt ADD COLUMN `resolution_status` VARCHAR(16) NOT NULL DEFAULT 'pending' AFTER `destination_district_name`",
        'resolution_confidence' => "ALTER TABLE $pt ADD COLUMN `resolution_confidence` VARCHAR(8) NOT NULL DEFAULT '' AFTER `resolution_status`",
        'resolved_from' => "ALTER TABLE $pt ADD COLUMN `resolved_from` VARCHAR(255) NOT NULL DEFAULT '' AFTER `resolution_confidence`",
        'auto_resolved' => "ALTER TABLE $pt ADD COLUMN `auto_resolved` TINYINT(1) NOT NULL DEFAULT 0 AFTER `resolved_from`",
        'resolution_source' => "ALTER TABLE $pt ADD COLUMN `resolution_source` VARCHAR(16) NOT NULL DEFAULT '' AFTER `auto_resolved`",
        'last_resolution_at' => "ALTER TABLE $pt ADD COLUMN `last_resolution_at` DATETIME NULL AFTER `resolution_source`",
        'send_lock' => "ALTER TABLE $pt ADD COLUMN `send_lock` TINYINT(1) NOT NULL DEFAULT 0 AFTER `sync_locked`",
        'send_lock_at' => "ALTER TABLE $pt ADD COLUMN `send_lock_at` DATETIME NULL AFTER `send_lock`",
        // Complete the heal for EVERY remaining column. ObjectModel::save() writes
        // all defined fields in one statement — a single missing column makes every
        // save silently fail (returns false, no throw) while SELECTs that don't
        // read that column still work. So a table left stale by an incomplete
        // earlier upgrade must be brought fully up to definition here. Nullable /
        // defaulted so ADD COLUMN never fails on a table that already has rows.
        'nid' => "ALTER TABLE $pt ADD COLUMN `nid` VARCHAR(64) NOT NULL DEFAULT ''",
        'status_code' => "ALTER TABLE $pt ADD COLUMN `status_code` INT NOT NULL DEFAULT 0",
        'package_size' => "ALTER TABLE $pt ADD COLUMN `package_size` TINYINT UNSIGNED NOT NULL DEFAULT 1",
        'recipient_name' => "ALTER TABLE $pt ADD COLUMN `recipient_name` VARCHAR(190) NOT NULL DEFAULT ''",
        'recipient_phone' => "ALTER TABLE $pt ADD COLUMN `recipient_phone` VARCHAR(32) NOT NULL DEFAULT ''",
        'destination_address' => "ALTER TABLE $pt ADD COLUMN `destination_address` TEXT NULL",
        'destination_city_id' => "ALTER TABLE $pt ADD COLUMN `destination_city_id` INT UNSIGNED NOT NULL DEFAULT 0",
        'destination_district_id' => "ALTER TABLE $pt ADD COLUMN `destination_district_id` INT UNSIGNED NOT NULL DEFAULT 0",
        'destination_neighborhood_id' => "ALTER TABLE $pt ADD COLUMN `destination_neighborhood_id` INT UNSIGNED NOT NULL DEFAULT 0",
        'bordereau_url' => "ALTER TABLE $pt ADD COLUMN `bordereau_url` VARCHAR(512) NOT NULL DEFAULT ''",
        'idempotency_hash' => "ALTER TABLE $pt ADD COLUMN `idempotency_hash` CHAR(32) NOT NULL DEFAULT ''",
        'api_target_used' => "ALTER TABLE $pt ADD COLUMN `api_target_used` VARCHAR(16) NOT NULL DEFAULT ''",
        'sync_locked' => "ALTER TABLE $pt ADD COLUMN `sync_locked` TINYINT(1) NOT NULL DEFAULT 0",
        'last_error' => "ALTER TABLE $pt ADD COLUMN `last_error` TEXT NULL",
        'last_attempt_at' => "ALTER TABLE $pt ADD COLUMN `last_attempt_at` DATETIME NULL",
        'last_sync_at' => "ALTER TABLE $pt ADD COLUMN `last_sync_at` DATETIME NULL",
        'created_at' => "ALTER TABLE $pt ADD COLUMN `created_at` DATETIME NULL",
        'updated_at' => "ALTER TABLE $pt ADD COLUMN `updated_at` DATETIME NULL",
    ],
    'intigo_log' => [
        // Related PrestaShop order id, so logs are searchable/filterable by order.
        // Nullable: some events (global/config) have no order in scope.
        'id_order' => "ALTER TABLE `" . _DB_PREFIX_ . "intigo_log` ADD COLUMN `id_order` INT UNSIGNED NULL DEFAULT NULL AFTER `action`",
    ],
];
foreach ($columns as $table => $adds) {
    foreach ($adds as $column => $alter) {
        $exists = Db::getInstance()->getValue(
            'SELECT COUNT(*) FROM information_schema.COLUMNS
             WHERE TABLE_SCHEMA = DATABASE()
               AND TABLE_NAME = "' . _DB_PREFIX_ . pSQL($table) . '"
               AND COLUMN_NAME = "' . pSQL($column) . '"'
        );
        if ((int) $exists === 0) {
            // Strip any "AFTER `col`" — the referenced column may itself still be
            // missing (they're added in array order), which would abort the ADD and
            // leave a gap. Column position is irrelevant to correctness.
            $alter = preg_replace('/\s+AFTER\s+`[^`]+`/i', '', $alter);
            Db::getInstance()->execute($alter);
        }
    }
}

return true;
