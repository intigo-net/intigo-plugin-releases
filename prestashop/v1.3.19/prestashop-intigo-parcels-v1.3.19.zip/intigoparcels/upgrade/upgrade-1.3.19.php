<?php
/** Upgrade to 1.3.19 — the Orders list now has ONE unified filter form: category,
 * order status and date range apply together (AND) on a single "Appliquer" click,
 * with a "Réinitialiser" clear. UI-only change, no schema change; the idempotent
 * install heal is kept for safety. */
if (!defined('_PS_VERSION_')) { exit; }
function upgrade_module_1_3_19($module)
{
    if (!(include dirname(__FILE__) . '/../sql/install.php')) { return false; }
    if (method_exists($module, 'ensureTabs')) { $module->ensureTabs(); }
    return true;
}
