<?php
/** Upgrade to 1.3.18 — the webhook status-map now recognizes Intigo's real
 * delivered/return/cancel status codes (6001, 6500, 6900, 9000, 9001, 9004) that
 * were previously unmappable. No schema change; the new codes are picked up from
 * IntigoStatus::webhookStatuses(). This upgrade rewrites the map to a single clean
 * row so the new codes can be mapped from Settings. */
if (!defined('_PS_VERSION_')) { exit; }
function upgrade_module_1_3_18($module)
{
    require_once dirname(__FILE__) . '/../classes/IntigoStatus.php';
    IntigoStatus::setMap(IntigoStatus::getMap()); // read latest, rewrite single row
    if (method_exists($module, 'ensureTabs')) { $module->ensureTabs(); }
    return true;
}
