<?php
/** Upgrade to 1.3.16 — sent orders (parcel has a NID) stay in the Intigo Orders
 * list even after the webhook moves their PrestaShop status to a delivery status
 * that isn't pickup-mapped. Prevents shipped orders from vanishing. */
if (!defined('_PS_VERSION_')) { exit; }
function upgrade_module_1_3_16($module)
{
    if (!(include dirname(__FILE__) . '/../sql/install.php')) { return false; }
    if (method_exists($module, 'ensureTabs')) { $module->ensureTabs(); }
    return true;
}
