<?php
/** Upgrade to 1.3.17 — the webhook status-map (Intigo status -> PS status) could be
 * stored as several conflicting id_shop=NULL rows, so the webhook sometimes mapped
 * to the WRONG status. getMap() now reads the freshest row, setMap() collapses
 * duplicates. This upgrade collapses any existing duplicates to one clean row. */
if (!defined('_PS_VERSION_')) { exit; }
function upgrade_module_1_3_17($module)
{
    if (!(include dirname(__FILE__) . '/../sql/install.php')) { return false; }
    require_once dirname(__FILE__) . '/../classes/IntigoStatus.php';
    IntigoStatus::setMap(IntigoStatus::getMap()); // read latest, rewrite single row
    if (method_exists($module, 'ensureTabs')) { $module->ensureTabs(); }
    return true;
}
