<?php
/**
 * Upgrade to 1.3.1 — access management.
 *
 *  - The new "Accès" admin page (AdminIntigoAccess) under the Intigo parent.
 *  - Grant every employee profile access to the Intigo pages (PrestaShop only
 *    auto-grants SuperAdmin when a tab is added, so custom profiles were locked
 *    out). The "Accès" page itself stays SuperAdmin-only.
 *
 * No schema change since 1.3.0. Everything here is idempotent.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_3_1($module)
{
    // Schema safety net (idempotent CREATE/ALTER) in case an older column is missing.
    if (!(include dirname(__FILE__) . '/../sql/install.php')) {
        return false;
    }

    // Create the "Accès" tab (SuperAdmin-only) and grant the other pages to all
    // profiles. Both are public + idempotent on the module instance.
    if (method_exists($module, 'ensureAccessTab')) {
        $module->ensureAccessTab();
    }
    if (method_exists($module, 'grantTabAccess')) {
        $module->grantTabAccess();
    }
    Configuration::updateValue('INTIGO_TAB_ACCESS_V1', '1');

    return true;
}
