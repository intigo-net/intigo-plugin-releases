<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Auto-detects the Intigo delivery zone (city_id / district_id / neighborhood_id)
 * from a customer's free-text PrestaShop shipping address, using the OpenSearch
 * location guesser — so the merchant never edits orders by hand.
 *
 * Detection model: the resolver ALWAYS surfaces at least the NEAREST zone when
 * the guesser returns anything — it never leaves an order "Sans correspondance"
 * over a low-confidence match. The confidence TIER tells the merchant how much to
 * trust it; only auto-send (GREEN) is gated, never the display.
 *
 *   GREEN   single city across top hits · city resolved by EXACT match ·
 *           district present · coherent · agrees with the order's city
 *           → auto-send-eligible
 *   REVIEW  the nearest match, but fuzzy / ambiguous / city-only / unverified
 *           IDs → auto-filled with the nearest zone, needs one human glance
 *   BLOCKED only when there is genuinely nothing to match: empty address AND
 *           city, or the guesser is unavailable / returns zero results
 */
class IntigoAddressResolver
{
    const TIER_GREEN = 'green';
    const TIER_REVIEW = 'review';
    const TIER_BLOCKED = 'blocked';

    /** @var IntigoApiClient */
    private $api;

    public function __construct(IntigoApiClient $api = null)
    {
        $this->api = $api ?: new IntigoApiClient();
    }

    /**
     * Build the guesser query: cleaned address locality + the order's city
     * (always appended to anchor the governorate). Building noise pulls the
     * search toward spurious matches, so strip it.
     */
    public function buildQuery($address1, $city)
    {
        $addr = $this->cleanAddress($address1);
        $city = trim((string) $city);
        $q = trim($addr . ' ' . $city);
        return $q !== '' ? $q : $city;
    }

    /**
     * Strip building-reference *pairs* — the keyword AND its following token
     * ("immeuble X", "appt 3", "bloc B", "n° 12", "étage 2"). Deliberately does
     * NOT strip bare numbers: Tunisian place names embed them ("Charguia 2",
     * "El Menzah 6"), and removing the number changes the destination.
     */
    private function cleanAddress($address1)
    {
        $addr = (string) $address1;
        // "n° 12", "no 12", "n 12", "n°12" (apartment/door numbers).
        $addr = preg_replace('/\bn[\x{00b0}o]?\.?\s*\d+\b/iu', ' ', $addr);
        // Building keyword + its following token: "immeuble X", "appt 3", "bloc B".
        $addr = preg_replace(
            '/\b(immeuble|imm|appartement|appart|appt|apt|bloc|block|etage|etg|esc|escalier|residence|res)\b\.?\s*[\w\x{00b0}]+/iu',
            ' ',
            $addr
        );
        $addr = preg_replace('/[,;]+/', ' ', (string) $addr);   // leftover separators
        return trim(preg_replace('/\s+/', ' ', (string) $addr));
    }

    /**
     * Resolve free-text → zone + confidence tier. Pure (no persistence).
     */
    public function resolve($address1, $city)
    {
        $query = $this->buildQuery($address1, $city);
        if ($query === '') {
            return $this->blocked('empty_address', '');
        }

        $res = $this->api->searchLocations($query);
        if (empty($res['ok'])) {                       // fail closed
            return $this->blocked('guesser_unavailable:' . (isset($res['error']) ? $res['error'] : ''), $query);
        }
        $items = $res['items'];
        if (empty($items)) {
            return $this->blocked('no_match', $query);
        }

        $psCity = IntigoApiClient::normalizeName($city);
        $hasLocality = ($this->cleanAddress($address1) !== '');

        // Dispersion: how many distinct cities across the top hits.
        $topN = array_slice($items, 0, 5);
        $cities = [];
        foreach ($topN as $it) {
            $cn = IntigoApiClient::normalizeName($it['city_name']);
            if ($cn !== '') {
                $cities[$cn] = true;
            }
        }
        $dispersion = count($cities);

        // Choose the NEAREST candidate. The guesser ranks by relevance, so
        // items[0] is the nearest. With several candidate cities we PREFER the one
        // matching the order's city (right governorate) — but we never discard the
        // match: if none matches, the nearest result stands. The resolver must
        // ALWAYS surface at least the nearest zone, never "no match".
        $chosen = $items[0];
        if ($dispersion > 1 && $psCity !== '') {
            foreach ($items as $it) {
                if (IntigoApiClient::normalizeName($it['city_name']) === $psCity) {
                    $chosen = $it;
                    break;
                }
            }
        }

        // city_name → city_id (the fuzzy step; may fail to resolve).
        $district_id = (int) $chosen['district_id'];
        $cityRes = $this->api->resolveCityNameToId($chosen['city_name']);
        $city_id = (int) $cityRes['id'];

        // Coherence decides only whether the IDs are SAFE TO SEND on the standard
        // path — NOT whether we surface the match. We keep the IDs only when the
        // city resolved AND the district belongs to it; otherwise we still return
        // the nearest NAMES (so the merchant sees the detected zone) with null IDs,
        // and the postal-code path or a manual confirm handles the actual send.
        $coherent = ($city_id > 0
            && ($district_id <= 0 || $this->api->districtBelongsToCity($district_id, $city_id)));

        // City cross-check as a BOOSTER (only meaningful with a usable city_id).
        // A garbage/unknown city field ("tunisia", a postcode, empty) is neutral.
        $psCityId = 0;
        if ($psCity !== '') {
            $cmap = $this->api->cityNameToIdMap();
            $psCityId = isset($cmap[$psCity]) ? (int) $cmap[$psCity] : 0;
        }
        $cityConflict = ($coherent && $psCityId > 0 && $psCityId !== $city_id);
        $cityAgrees = ($coherent && $psCityId > 0 && $psCityId === $city_id);

        // GREEN (auto-send eligible): coherent IDs + a single city + an exact city
        // match + a real district + an address locality + no city conflict. Every
        // other result that still has a candidate is REVIEW — auto-filled with the
        // nearest zone, flagged for a human glance (never silently shipped).
        $tier = self::TIER_REVIEW;
        if ($coherent && $dispersion === 1 && !empty($cityRes['exact']) && $district_id > 0
            && $hasLocality && !$cityConflict) {
            $tier = self::TIER_GREEN;
        }

        return [
            'ok' => true,
            'tier' => $tier,
            'city_id' => $coherent ? $city_id : 0,
            'city_name' => (string) $chosen['city_name'],
            'district_id' => $coherent ? $district_id : 0,
            'district_name' => (string) $chosen['district_name'],
            'neighborhood_id' => $coherent ? (int) $chosen['neighborhood_id'] : 0,
            'neighborhood_name' => (string) $chosen['neighborhood_name'],
            'query' => $query,
            'dispersion' => $dispersion,
            'city_agrees' => $cityAgrees,
            'reason' => $coherent ? '' : 'nearest_unverified',
        ];
    }

    /**
     * Resolve from a PS Order and persist onto its parcel row. Never clobbers a
     * merchant's manual entry. Returns the resolution result array.
     */
    public function resolveAndStore(Order $order)
    {
        $parcel = IntigoParcel::findByOrderId((int) $order->id);

        // Respect a manual override — don't auto-overwrite what a human entered.
        if ($parcel && ($parcel->resolution_source === 'manual' || (int) $parcel->auto_resolved === 0)
            && (int) $parcel->destination_city_id > 0 && (int) $parcel->destination_district_id > 0) {
            return ['ok' => true, 'tier' => 'manual', 'skipped' => true];
        }
        // Already pushed — freeze it.
        if ($parcel && trim((string) $parcel->nid) !== '') {
            return ['ok' => true, 'tier' => 'sent', 'skipped' => true];
        }

        $address1 = '';
        $city = '';
        if ((int) $order->id_address_delivery > 0) {
            $address = new Address((int) $order->id_address_delivery);
            if (Validate::isLoadedObject($address)) {
                $address1 = trim((string) $address->address1 . ' ' . (string) $address->address2);
                $city = (string) $address->city;
            }
        }

        $result = $this->resolve($address1, $city);

        $parcel = $parcel ?: new IntigoParcel();
        $parcel->id_order = (int) $order->id;
        $parcel->pickup_index = $this->computePickupIndex($order);
        $parcel->resolved_from = substr(trim($address1 . ' | ' . $city), 0, 255);
        $parcel->resolution_source = 'guesser';
        $parcel->auto_resolved = 1;
        $parcel->last_resolution_at = date('Y-m-d H:i:s');
        $parcel->resolution_confidence = $result['tier'];
        if (!empty($result['ok'])) {
            $parcel->destination_city_id = (int) $result['city_id'];
            $parcel->destination_district_id = (int) $result['district_id'];
            $parcel->destination_neighborhood_id = (int) $result['neighborhood_id'];
            $parcel->destination_city_name = (string) $result['city_name'];
            $parcel->destination_district_name = (string) $result['district_name'];
            $parcel->resolution_status = ($result['tier'] === self::TIER_GREEN) ? 'resolved' : 'review';
        } else {
            $parcel->resolution_status = 'blocked';
        }
        $parcel->save();

        if (class_exists('IntigoLog')) {
            IntigoLog::add('address_resolved', 'id_order=' . (int) $order->id
                . ' tier=' . $result['tier']
                . ' city=' . (isset($result['city_name']) ? $result['city_name'] : '')
                . ' district=' . (isset($result['district_name']) ? $result['district_name'] : '')
                . ' q=' . (isset($result['query']) ? $result['query'] : '')
                . (empty($result['ok']) ? ' reason=' . $result['reason'] : ''));
        }
        return $result;
    }

    /**
     * The pickup index this order would ship from — same cascade as the push:
     * status-mapped address → configured default → cached is_primary → -1 (none).
     * Stored on the parcel so the Orders "Adresse de ramassage" filter works
     * directly, without depending on a status mapping existing.
     */
    private function computePickupIndex(Order $order)
    {
        if (!class_exists('IntigoPickupMap')) {
            @include_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoPickupMap.php';
        }
        $shop = (int) $order->id_shop ?: 1;
        if (class_exists('IntigoPickupMap')) {
            $idx = IntigoPickupMap::resolvePickupIndex($shop, (int) $order->getCurrentState());
            if ($idx !== null) {
                return (int) $idx;
            }
        }
        $cfg = Configuration::get('INTIGO_DEFAULT_PICKUP_INDEX');
        if ($cfg !== false && trim((string) $cfg) !== '' && (int) $cfg >= 0) {
            return (int) $cfg;
        }
        $cache = Configuration::get('INTIGO_PICKUP_CACHE');
        if ($cache !== false && trim((string) $cache) !== '') {
            $list = json_decode((string) $cache, true);
            if (is_array($list)) {
                foreach ($list as $it) {
                    if (is_array($it) && !empty($it['is_primary']) && isset($it['index']) && $it['index'] !== null) {
                        return (int) $it['index'];
                    }
                }
            }
        }
        return -1;
    }

    private function blocked($reason, $query)
    {
        return [
            'ok' => false,
            'tier' => self::TIER_BLOCKED,
            'city_id' => 0, 'city_name' => '',
            'district_id' => 0, 'district_name' => '',
            'neighborhood_id' => 0, 'neighborhood_name' => '',
            'query' => $query,
            'dispersion' => 0,
            'city_agrees' => false,
            'reason' => $reason,
        ];
    }
}
