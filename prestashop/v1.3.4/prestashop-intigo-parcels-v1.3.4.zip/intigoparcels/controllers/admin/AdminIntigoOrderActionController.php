<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

require_once dirname(__FILE__) . '/../../classes/IntigoAutoload.php';

/**
 * Receives action submissions from the BO order-side panel:
 *   save / save_push / save_update / push_force / cancel / bordereau
 *
 * For the save-prefixed actions, persists the form fields to ps_intigo_parcel
 * BEFORE invoking the API. Other actions just dispatch.
 *
 * Redirects back to the order edit page with a success/error notice.
 */
class AdminIntigoOrderActionController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        parent::__construct();
    }

    public function postProcess()
    {
        $action = (string) Tools::getValue('intigo_action');

        // Bulk send (multi-select on the Orders list) — no single id_order.
        if ($action === 'bulk_push') {
            $this->handleBulkPush();
            return;
        }
        // Bulk bordereau — one combined PDF for all selected, already-sent orders.
        if ($action === 'bulk_bordereau') {
            $this->handleBulkBordereau();
            return;
        }

        $id_order = (int) Tools::getValue('id_order');
        if ($id_order <= 0 || $action === '') {
            $this->redirectToOrder($id_order, 'Paramètres manquants', 'error');
        }

        $order = new Order($id_order);
        if (!Validate::isLoadedObject($order)) {
            $this->redirectToOrder($id_order, 'Commande introuvable', 'error');
        }

        require_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoOrderService.php';

        // Save submitted form fields first (for any save-prefixed action)
        if (strpos($action, 'save') === 0) {
            $this->saveParcelFromForm($order);
        }

        $svc = new IntigoOrderService();
        $res = null;

        switch ($action) {
            case 'save':
                $res = ['ok' => true, 'message' => 'Informations enregistrées'];
                break;
            case 'push':         // From Intigo Orders list — push without touching parcel fields
            case 'save_push':    // From order edit form — save form THEN push
                $res = $svc->pushParcel($order, false);
                break;
            case 'push_force':
                $res = $svc->pushParcel($order, true);
                break;
            case 'update':
            case 'save_update':
                $res = $svc->updateParcel($order);
                break;
            case 'cancel':
                $res = $svc->cancelParcel($order);
                break;
            case 'bordereau':
                $res = $svc->generateBordereau($order);
                break;
            default:
                $this->redirectToOrder($id_order, 'Action inconnue', 'error');
                return;
        }

        $type = !empty($res['ok']) ? 'success' : 'error';
        $msg = isset($res['message']) ? (string) $res['message'] : ($type === 'success' ? 'OK' : 'Échec');
        if (!empty($res['nid'])) {
            $msg .= ' (suivi : ' . $res['nid'] . ')';
        }
        // The bordereau URL travels as its own param so the Orders screen can
        // render a clickable "Open" + "Copy link" instead of a raw URL in text.
        $bordereau_url = !empty($res['url']) ? (string) $res['url'] : '';
        if ($bordereau_url !== '') {
            $msg = 'Bordereau prêt.';
        }
        $this->redirectToOrder($id_order, $msg, $type, $bordereau_url);
    }

    /**
     * Bulk-send the selected orders to Intigo (one batch request). Always
     * returns to the Orders list with a count summary.
     */
    private function handleBulkPush()
    {
        require_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoOrderService.php';
        @set_time_limit(120);

        $ids = Tools::getValue('id_orders');
        $ids = is_array($ids) ? array_filter(array_map('intval', $ids)) : [];
        if (empty($ids)) {
            $this->redirectToOrdersList('Aucune commande sélectionnée', 'warning');
        }

        $svc = new IntigoOrderService();
        $res = $svc->pushParcelsBulk($ids);

        $parts = [$res['created'] . ' colis créé(s)'];
        if ($res['failed'] > 0) {
            $parts[] = $res['failed'] . ' échec(s)';
        }
        if ($res['skipped'] > 0) {
            $parts[] = $res['skipped'] . ' ignorée(s)';
        }
        $msg = implode(', ', $parts);
        $type = $res['created'] > 0 ? ($res['failed'] > 0 ? 'warning' : 'success') : ($res['failed'] > 0 ? 'error' : 'warning');
        $this->redirectToOrdersList($msg, $type);
    }

    /**
     * Bulk bordereau: collect the NIDs of the selected, already-sent orders and
     * ask Intigo for ONE combined bordereau PDF (the /bordereau endpoint accepts
     * many NIDs). Returns to the Orders list with the bordereau link banner.
     */
    private function handleBulkBordereau()
    {
        require_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoParcel.php';
        require_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoApiClient.php';
        @set_time_limit(120);

        $ids = Tools::getValue('id_orders');
        $ids = is_array($ids) ? array_filter(array_map('intval', $ids)) : [];
        if (empty($ids)) {
            $this->redirectToOrdersList('Aucune commande sélectionnée', 'warning');
        }

        $nids = [];
        foreach ($ids as $oid) {
            $p = IntigoParcel::findByOrderId((int) $oid);
            if ($p && trim((string) $p->nid) !== '') {
                $nids[] = trim((string) $p->nid);
            }
        }
        if (empty($nids)) {
            $this->redirectToOrdersList(
                'Aucun colis envoyé dans la sélection — envoyez les commandes à Intigo avant de générer le bordereau.',
                'warning'
            );
        }

        $api = new IntigoApiClient();
        $res = $api->generateBordereau($nids);
        $url = !empty($res['ok'])
            ? (string) (isset($res['data']['url']) ? $res['data']['url'] : (isset($res['data']['bordereau_url']) ? $res['data']['bordereau_url'] : ''))
            : '';
        if ($url === '') {
            $this->redirectToOrdersList('Échec de la génération du bordereau groupé.', 'error');
        }

        if (class_exists('IntigoLog')) {
            IntigoLog::add('bulk_bordereau', 'count=' . count($nids));
        }
        $redirect = $this->context->link->getAdminLink('AdminIntigoOrders', true, [], [
            'intigo_notice' => 'Bordereau groupé prêt — ' . count($nids) . ' colis.',
            'intigo_notice_type' => 'success',
            'intigo_bordereau_url' => $url,
        ]);
        Tools::redirectAdmin($redirect);
        exit;
    }

    private function redirectToOrdersList($message, $type = 'info')
    {
        $url = $this->context->link->getAdminLink('AdminIntigoOrders', true, [], [
            'intigo_notice' => $message,
            'intigo_notice_type' => $type,
        ]);
        Tools::redirectAdmin($url);
        exit;
    }

    private function saveParcelFromForm(Order $order)
    {
        require_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoParcel.php';

        $parcel = IntigoParcel::findByOrderId((int) $order->id) ?: new IntigoParcel();
        $parcel->id_order = (int) $order->id;
        $parcel->recipient_name = trim((string) Tools::getValue('recipient_name'));
        $parcel->recipient_phone = self::normalizePhone((string) Tools::getValue('recipient_phone'));
        $parcel->reference_id = trim((string) Tools::getValue('reference_id'));
        $parcel->destination_address = trim((string) Tools::getValue('destination_address'));
        $parcel->destination_city_id = (int) Tools::getValue('destination_city_id');
        $parcel->destination_district_id = (int) Tools::getValue('destination_district_id');
        $parcel->destination_neighborhood_id = (int) Tools::getValue('destination_neighborhood_id');
        $size = (int) Tools::getValue('package_size');
        if (in_array($size, [1, 2, 4, 5], true)) {
            $parcel->package_size = $size;
        }
        // Mark as a manual entry so auto-resolution never overwrites what the
        // merchant just typed/picked here.
        $parcel->resolution_source = 'manual';
        $parcel->auto_resolved = 0;
        if ((int) $parcel->destination_city_id > 0 && (int) $parcel->destination_district_id > 0) {
            $parcel->resolution_status = 'resolved';
            $parcel->resolution_confidence = 'manual';
        }
        $parcel->save();
    }

    private static function normalizePhone($phone)
    {
        $digits = preg_replace('/\D+/', '', (string) $phone);
        if ($digits === null) {
            return '';
        }
        if (strpos($digits, '00') === 0) {
            $digits = substr($digits, 2);
        }
        return $digits;
    }

    private function redirectToOrder($id_order, $message, $type = 'info', $bordereau_url = '')
    {
        $params = [
            'intigo_notice' => $message,
            'intigo_notice_type' => $type,
        ];
        if ($bordereau_url !== '') {
            $params['intigo_bordereau_url'] = $bordereau_url;
        }
        $return_to = (string) Tools::getValue('intigo_return');
        if ($return_to === 'orders') {
            $url = $this->context->link->getAdminLink('AdminIntigoOrders', true, [], $params);
        } else {
            $params['id_order'] = (int) $id_order;
            $params['vieworder'] = 1;
            $url = $this->context->link->getAdminLink('AdminOrders', true, [], $params);
        }
        Tools::redirectAdmin($url);
        exit;
    }
}
