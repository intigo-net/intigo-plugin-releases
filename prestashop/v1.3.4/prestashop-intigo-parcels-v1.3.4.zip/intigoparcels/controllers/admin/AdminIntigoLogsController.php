<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

require_once dirname(__FILE__) . '/../../classes/IntigoAutoload.php';

class AdminIntigoLogsController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        $this->display = 'view';
        parent::__construct();
        $this->meta_title = $this->trans('Intigo — Logs', [], 'Modules.Intigoparcels.Admin');
        $this->show_page_header_toolbar = false;
    }

    public function initContent()
    {
        $page = max(1, (int) Tools::getValue('p', 1));
        $data = IntigoLog::paginate($page, 25);
        $rows = $data['rows'];
        $total = (int) $data['total'];
        $pages = max(1, (int) ceil($total / 25));

        $html = '<div class="intigo-screen">' . IntigoAdminUi::navHtml($this->context->link, 'logs');
        $html .= '<div class="panel"><div class="panel-heading"><i class="material-icons">receipt</i> Intigo — Logs (' . $total . ')</div>';
        if (empty($rows)) {
            $html .= '<p>No activity yet.</p>';
        } else {
            $html .= '<table class="table"><thead><tr><th>Time</th><th>Actor</th><th>Action</th><th>Context</th></tr></thead><tbody>';
            foreach ($rows as $r) {
                $html .= '<tr>'
                    . '<td>' . htmlspecialchars($r['created_at']) . '</td>'
                    . '<td>' . htmlspecialchars($r['actor']) . '</td>'
                    . '<td><code>' . htmlspecialchars($r['action']) . '</code></td>'
                    . '<td>' . htmlspecialchars((string) $r['context']) . '</td>'
                    . '</tr>';
            }
            $html .= '</tbody></table>';
            if ($pages > 1) {
                $html .= '<ul class="pagination">';
                for ($i = 1; $i <= $pages; $i++) {
                    $url = self::$currentIndex . '&token=' . $this->token . '&p=' . $i;
                    $cls = $i === $page ? ' class="active"' : '';
                    $html .= '<li' . $cls . '><a href="' . htmlspecialchars($url) . '">' . $i . '</a></li>';
                }
                $html .= '</ul>';
            }
        }
        $html .= '</div>';
        $html .= '</div>'; // .intigo-screen
        $this->content = $html;
        parent::initContent();
    }
}
