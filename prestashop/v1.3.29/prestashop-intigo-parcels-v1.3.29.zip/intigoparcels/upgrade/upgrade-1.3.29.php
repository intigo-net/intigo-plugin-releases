<?php
/** Upgrade to 1.3.29 — the postal-code send path is removed: a parcel is only ever
 *  created with the ville + délégation we verified. No schema change. */
if (!defined('_PS_VERSION_')) { exit; }
function upgrade_module_1_3_29($module)
{
    if (!(include dirname(__FILE__) . '/../sql/install.php')) { return false; }
    if (method_exists($module, 'ensureTabs')) { $module->ensureTabs(); }
    return true;
}
