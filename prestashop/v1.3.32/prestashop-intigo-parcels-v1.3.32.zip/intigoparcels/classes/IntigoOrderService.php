<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Push/update/cancel parcels at Intigo. Direct port of class-intigo-order-service.php
 * from the WP plugin, adapted to PrestaShop's Order / Address / Customer model.
 *
 *   pushParcel($order)   — POST /v3/parcels/  (idempotent by md5(ps:shop:order:event:v1))
 *   updateParcel($order) — PATCH /v3/parcels/{nid}, with phone/address/price fallback
 *                          if PATCH 4xxs (mirrors the WP plugin's lock-aware logic)
 *   cancelParcel($order) — POST /v3/parcels/{nid}/cancel
 */
class IntigoOrderService
{
    /** @var IntigoApiClient */
    private $api;

    public function __construct()
    {
        $this->api = new IntigoApiClient();
    }

    /**
     * The COMPLETE postal address on one line — street, then postcode + city, then
     * country — the way PrestaShop displays it. The street alone left the driver
     * (and the zone detection) without the postcode or city, which is exactly how a
     * Tunis parcel could look plausible while being routed elsewhere.
     */
    public static function fullAddressLine($address)
    {
        if (!$address || !Validate::isLoadedObject($address)) {
            return '';
        }
        $parts = [];
        $street = trim((string) $address->address1 . ' ' . (string) $address->address2);
        if ($street !== '') {
            $parts[] = $street;
        }
        $locality = trim(trim((string) $address->postcode) . ' ' . trim((string) $address->city));
        if ($locality !== '') {
            $parts[] = $locality;
        }
        // Shops that use the État field instead of Ville would otherwise send an
        // address with no locality at all — the governorate belongs on the label.
        // Skipped when the Ville already says the same thing.
        $state = IntigoAddressResolver::stateName($address);
        if ($state !== '' && IntigoApiClient::normalizeName($state) !== IntigoApiClient::normalizeName((string) $address->city)) {
            $parts[] = $state;
        }
        if ((int) $address->id_country > 0) {
            $id_lang = (int) Context::getContext()->language->id;
            $country = trim((string) Country::getNameById($id_lang, (int) $address->id_country));
            if ($country !== '') {
                $parts[] = $country;
            }
        }
        return implode(', ', $parts);
    }

    /**
     * The address to use for a parcel: the stored one, EXCEPT when it is still the
     * old street-only value we derived automatically — that gets upgraded to the
     * complete line. A merchant's hand-edited address is never overwritten, because
     * it no longer equals the derivation it would have come from.
     */
    public static function preferredAddress($stored, $address)
    {
        $stored = trim((string) $stored);
        if (!$address || !Validate::isLoadedObject($address)) {
            return $stored;
        }
        $legacy = trim((string) $address->address1 . ' ' . (string) $address->address2);
        if ($stored === '' || $stored === $legacy) {
            return self::fullAddressLine($address);
        }
        return $stored;
    }

    /**
     * Full recipient name for a delivery. Uses the address firstname + lastname,
     * but when the address has NO lastname (common in guest COD checkout) it
     * completes the surname from the order's customer — ONLY when it's clearly the
     * same person (address firstname empty or matches the customer's), so we never
     * overwrite a genuinely different recipient. Returns '' when nothing usable.
     */
    public static function fullRecipientName(Order $order, $address)
    {
        $af = $address ? trim((string) $address->firstname) : '';
        $al = $address ? trim((string) $address->lastname) : '';
        $name = trim($af . ' ' . $al);
        if ($al === '' && (int) $order->id_customer > 0) {
            $c = new Customer((int) $order->id_customer);
            if (Validate::isLoadedObject($c)) {
                $cf = trim((string) $c->firstname);
                $cl = trim((string) $c->lastname);
                if ($cl !== '' && ($af === '' || strcasecmp($af, $cf) === 0)) {
                    $name = trim($cf . ' ' . $cl);
                }
            }
        }
        return $name;
    }

    public function pushParcel(Order $order, $force = false, $autoTriggered = false)
    {
        $parcel = IntigoParcel::findByOrderId((int) $order->id);

        // HARD RULE: an order is NEVER sent to Intigo without a Référence — manual
        // OR automatic. The reference becomes the parcel `cid`, so it's mandatory.
        if (!$parcel || trim((string) $parcel->reference_id) === '') {
            if (class_exists('IntigoLog')) {
                IntigoLog::add($autoTriggered ? 'auto_push_skipped_no_reference' : 'push_blocked_no_reference',
                    'id_order=' . (int) $order->id);
            }
            return ['ok' => false, 'skipped' => true,
                'message' => 'Référence obligatoire : renseignez la référence de la commande avant l\'envoi à Intigo.'];
        }

        // Idempotency: only skip when we already have a successful NID.
        // Failed attempts (no NID) are always retryable so the merchant can
        // fix missing fields (district, etc.) and click Send again.
        if (!$force && $parcel && trim((string) $parcel->nid) !== '') {
            return [
                'ok' => true,
                'skipped' => true,
                'message' => 'Colis déjà envoyé (numéro de suivi ' . $parcel->nid . ')',
                'nid' => $parcel->nid,
            ];
        }

        // Pickup gate: never send with a guessed pickup. If neither a per-order
        // override nor a status→pickup mapping resolves a pickup, refuse the send
        // and tell the merchant to set it from the order edit modal.
        $pickupMsg = $this->pickupBlockMessage($order);
        if ($pickupMsg !== null) {
            $this->flagPickupRequired($order, $pickupMsg, $autoTriggered);
            return ['ok' => false, 'skipped' => true, 'pickup_required' => true, 'message' => $pickupMsg];
        }

        // Build the ordered send plan BEFORE claiming (the standard payload may
        // resolve the city via API) so we never hold the send-lock during a slow
        // resolve, and never lock for nothing. The plan carries up to two methods
        // — the free-text-guesser zone and the postal-code path — in confidence
        // order; if the first fails we fall through to the second.
        $plan = $this->buildSendPlan($order, $parcel);
        if (empty($plan)) {
            $std = $this->orderToPayload($order);
            $msg = $this->validatePayload($std);
            $msg = $msg !== null ? $msg : 'Adresse incomplète : renseignez la ville et la délégation, ou un code postal valide.';
            $this->savePushFailure($order, $std, 'validation: ' . $msg);
            return ['ok' => false, 'message' => $msg];
        }

        // Atomically claim the order — only ONE concurrent push reaches the API.
        // The v3 API has no idempotency key, so this is the only thing preventing
        // duplicate parcels under bulk send / double-click / cron-overlap.
        if (!IntigoParcel::claimForSend((int) $order->id, $force)) {
            $existing = IntigoParcel::findByOrderId((int) $order->id);
            if ($existing && trim((string) $existing->nid) !== '') {
                return ['ok' => true, 'skipped' => true, 'nid' => $existing->nid,
                    'message' => 'Colis déjà envoyé (numéro de suivi ' . $existing->nid . ')'];
            }
            return ['ok' => false, 'skipped' => true, 'message' => 'Un envoi est déjà en cours pour cette commande'];
        }

        try {
            $errors = [];
            foreach ($plan as $attempt) {
                $res = ($attempt['method'] === 'postal')
                    ? $this->api->createParcelByPostalCode($attempt['payload'])
                    : $this->api->createParcel($attempt['payload']);
                if (!empty($res['ok']) && !empty($res['data']['nid'])) {
                    $nid = (string) $res['data']['nid'];
                    $this->savePushSuccess($order, $attempt['payload'], $nid, (string) ($res['adapter'] ?? 'primary'));
                    IntigoLog::add('order_push_ok', 'id_order=' . (int) $order->id . ' nid=' . $nid . ' via=' . $attempt['method']);
                    return ['ok' => true, 'nid' => $nid, 'message' => 'Colis créé avec succès (suivi : ' . $nid . ')'];
                }
                $errors[] = $attempt['method'] . ' → ' . $this->formatApiError($res);
                IntigoLog::add('order_push_attempt_failed', 'id_order=' . (int) $order->id . ' via=' . $attempt['method']);
            }
            $err = implode(' | ', $errors);
            $this->savePushFailure($order, $plan[count($plan) - 1]['payload'], $err);
            IntigoLog::add('order_push_failed', 'id_order=' . (int) $order->id . ' err=' . $err);
            return ['ok' => false, 'message' => 'Échec de l\'envoi à Intigo. ' . $err];
        } finally {
            IntigoParcel::releaseSendLock((int) $order->id);
        }
    }

    public function updateParcel(Order $order)
    {
        $parcel = IntigoParcel::findByOrderId((int) $order->id);
        if (!$parcel || trim((string) $parcel->nid) === '') {
            return ['ok' => false, 'message' => 'Aucun colis pour cette commande — envoyez-le d\'abord'];
        }
        if ((int) $parcel->sync_locked === 1) {
            return ['ok' => false, 'message' => 'Colis verrouillé chez Intigo (livré/en retour) — modification impossible'];
        }

        $payload = $this->orderToPayload($order);
        $validation = $this->validatePayload($payload);
        if ($validation !== null) {
            return ['ok' => false, 'message' => 'validation: ' . $validation];
        }

        $res = $this->api->updateParcel($parcel->nid, $payload);
        if (!empty($res['ok'])) {
            $this->recordSynced($parcel, $order);
            IntigoLog::add('order_update_ok', 'id_order=' . (int) $order->id . ' nid=' . $parcel->nid);
            return ['ok' => true, 'message' => 'Colis mis à jour'];
        }
        if ($this->isParcelLockedError($res)) {
            $parcel->sync_locked = 1;
            $parcel->save();
            return ['ok' => false, 'locked' => true, 'message' => 'Colis verrouillé chez Intigo (livré/en retour)'];
        }

        // Fallback: try the per-field change endpoints
        $errs = [];
        $phone_res = $this->api->changePhone($parcel->nid, $payload['phone1'] ?? '');
        if (empty($phone_res['ok'])) {
            $errs[] = 'phone=' . $this->formatApiError($phone_res);
        }
        $addr_res = $this->api->changeAddress($parcel->nid, [
            'address' => $payload['destination_address'] ?? '',
            'city_id' => (int) ($payload['destination_city_id'] ?? 0),
            'district_id' => (int) ($payload['destination_district_id'] ?? 0),
            'neighborhood_id' => (int) ($payload['destination_neighborhood_id'] ?? 0),
        ]);
        if (empty($addr_res['ok'])) {
            $errs[] = 'address=' . $this->formatApiError($addr_res);
        }
        $price_res = $this->api->changePrice($parcel->nid, (float) ($payload['price'] ?? 0));
        if (empty($price_res['ok'])) {
            $errs[] = 'price=' . $this->formatApiError($price_res);
        }
        // "Mis à jour" only when every part went through: reporting success on
        // one call out of three left the merchant believing the address had changed.
        if (count($errs) === 0) {
            $this->recordSynced($parcel, $order);
            IntigoLog::add('order_update_fallback_ok', 'id_order=' . (int) $order->id . ' nid=' . $parcel->nid);
            return ['ok' => true, 'message' => 'Colis mis à jour'];
        }
        $err = $this->formatApiError($res) . ' | fallback: ' . implode(' ', $errs);
        IntigoLog::add('order_update_failed', 'id_order=' . (int) $order->id . ' err=' . $err);
        return ['ok' => false, 'message' => $err];
    }

    public function cancelParcel(Order $order)
    {
        $parcel = IntigoParcel::findByOrderId((int) $order->id);
        if (!$parcel || trim((string) $parcel->nid) === '') {
            return ['ok' => false, 'message' => 'Aucun colis pour cette commande'];
        }
        $res = $this->api->cancelParcel($parcel->nid);
        if (!empty($res['ok'])) {
            IntigoLog::add('order_cancel_ok', 'id_order=' . (int) $order->id . ' nid=' . $parcel->nid);
            return ['ok' => true, 'message' => 'Colis annulé'];
        }
        $err = $this->formatApiError($res);
        IntigoLog::add('order_cancel_failed', 'id_order=' . (int) $order->id . ' err=' . $err);
        return ['ok' => false, 'message' => $err];
    }

    /**
     * Re-send a parcel so it ships from the pickup mapped to the order's CURRENT
     * status. Intigo has no "change pickup" on an existing parcel, so the only way
     * to correct a parcel already created from the wrong pickup is to cancel it and
     * create a new one. We PRE-VALIDATE the recreate first, so we never cancel a
     * good parcel and then fail to recreate it (which would leave the order with no
     * parcel).
     */
    public function resendParcel(Order $order)
    {
        $parcel = IntigoParcel::findByOrderId((int) $order->id);
        // Nothing sent yet → this is just a normal send.
        if (!$parcel || trim((string) $parcel->nid) === '') {
            return $this->pushParcel($order, false);
        }
        $old_nid = (string) $parcel->nid;

        // Pickup gate FIRST: never cancel a good parcel if we can't even resolve a
        // pickup to recreate it with (would leave the order with no parcel).
        $pickupMsg = $this->pickupBlockMessage($order);
        if ($pickupMsg !== null) {
            return ['ok' => false, 'message' => 'Renvoi impossible — ' . $pickupMsg
                . ' Le colis existant (' . $old_nid . ') n\'a pas été annulé.'];
        }

        // Guard: make sure we CAN recreate before we cancel anything.
        $plan = $this->buildSendPlan($order, $parcel);
        if (empty($plan)) {
            $msg = $this->validatePayload($this->orderToPayload($order));
            return ['ok' => false, 'message' => 'Renvoi impossible — '
                . ($msg !== null ? $msg : 'adresse incomplète')
                . '. Le colis existant (' . $old_nid . ') n\'a pas été annulé.'];
        }

        // 1. Cancel the existing parcel.
        $cancel = $this->api->cancelParcel($old_nid);
        if (empty($cancel['ok'])) {
            $err = $this->formatApiError($cancel);
            IntigoLog::add('order_resend_cancel_failed', 'id_order=' . (int) $order->id . ' nid=' . $old_nid . ' err=' . $err);
            return ['ok' => false, 'message' => 'Impossible d\'annuler le colis existant (' . $old_nid . ') : ' . $err];
        }

        // 2. Clear the NID (and stale bordereau) so a fresh parcel is created with
        //    the pickup mapped to the order's current status.
        $parcel->nid = '';
        $parcel->bordereau_url = '';
        $parcel->sync_locked = 0;
        $parcel->save();

        // 3. Recreate (force, so nothing skips it).
        $res = $this->pushParcel($order, true);
        if (!empty($res['ok']) && !empty($res['nid'])) {
            IntigoLog::add('order_resend_ok', 'id_order=' . (int) $order->id . ' old=' . $old_nid . ' new=' . $res['nid']);
            $res['message'] = 'Colis renvoyé avec le bon ramassage (ancien ' . $old_nid . ' annulé ; nouveau suivi : ' . $res['nid'] . ')';
        } else {
            IntigoLog::add('order_resend_recreate_failed', 'id_order=' . (int) $order->id . ' old=' . $old_nid);
            $res['message'] = 'Ancien colis (' . $old_nid . ') annulé, mais la recréation a échoué : '
                . (isset($res['message']) ? $res['message'] : '') . ' Cliquez sur « Envoyer à Intigo » pour réessayer.';
        }
        return $res;
    }

    public function generateBordereau(Order $order)
    {
        $parcel = IntigoParcel::findByOrderId((int) $order->id);
        if (!$parcel || trim((string) $parcel->nid) === '') {
            return ['ok' => false, 'message' => 'Aucun colis pour cette commande'];
        }
        $res = $this->api->generateBordereau([$parcel->nid]);
        if (!empty($res['ok']) && !empty($res['data']['url'])) {
            $parcel->bordereau_url = (string) $res['data']['url'];
            $parcel->save();
            IntigoLog::add('order_bordereau_ok', 'id_order=' . (int) $order->id . ' nid=' . $parcel->nid);
            return ['ok' => true, 'url' => $parcel->bordereau_url];
        }
        $err = $this->formatApiError($res);
        IntigoLog::add('order_bordereau_failed', 'id_order=' . (int) $order->id . ' err=' . $err);
        return ['ok' => false, 'message' => $err];
    }

    /**
     * Bulk-create parcels for many orders in ONE request via /v3/parcels/batch
     * (max 100; returns per-item results mapped by index). Each order is atomically
     * claimed first so a concurrent/duplicate bulk can't double-create. Orders that
     * are already pushed, incomplete, or locked are skipped (not failed).
     *
     * @return array ['total','created','failed','skipped','skip_detail'=>[id=>reason]]
     */
    public function pushParcelsBulk(array $order_ids)
    {
        $order_ids = array_values(array_unique(array_map('intval', $order_ids)));
        $jobs = [];   // ['order'=>, 'plan'=>[], 'done'=>bool, 'err'=>str, 'payload'=>last-tried]
        $skipped = [];

        foreach ($order_ids as $oid) {
            if ($oid <= 0) {
                continue;
            }
            $order = new Order($oid);
            if (!Validate::isLoadedObject($order)) {
                $skipped[$oid] = 'not_found';
                continue;
            }
            $existing = IntigoParcel::findByOrderId($oid);
            if ($existing && trim((string) $existing->nid) !== '') {
                $skipped[$oid] = 'already';
                continue;
            }
            // HARD RULE: never bulk-send an order without a Référence.
            if (!$existing || trim((string) $existing->reference_id) === '') {
                $skipped[$oid] = 'no_reference';
                continue;
            }
            // Pickup gate: skip (never guess) when no pickup resolves; flag it so the
            // merchant sees why and can fix it in the order edit modal.
            $pickupMsg = $this->pickupBlockMessage($order);
            if ($pickupMsg !== null) {
                $this->flagPickupRequired($order, $pickupMsg);
                $skipped[$oid] = 'pickup_required';
                continue;
            }
            $plan = $this->buildSendPlan($order, $existing);
            if (empty($plan)) {
                // No usable zone AND no usable postal code — skip WITHOUT marking a
                // failure (already flagged by its resolution status). Only a real
                // API rejection is a failure.
                $skipped[$oid] = 'incomplete';
                continue;
            }
            if (!IntigoParcel::claimForSend($oid, false)) {
                $skipped[$oid] = 'locked';
                continue;
            }
            $jobs[] = ['order' => $order, 'plan' => $plan, 'done' => false, 'err' => '', 'payload' => $plan[0]['payload']];
        }

        // Up to two rounds: round 0 = each job's primary method, round 1 = its
        // fallback. Within a round, jobs are grouped by method and sent in ONE
        // batch call per method (standard → /batch, postal → /batch-by-postal-code).
        $created = 0;
        $failed = 0;
        for ($round = 0; $round < 2; $round++) {
            $byMethod = ['standard' => [], 'postal' => []];
            foreach ($jobs as $ji => $job) {
                if ($job['done'] || !isset($job['plan'][$round])) {
                    continue;
                }
                $m = $job['plan'][$round]['method'];
                $byMethod[$m][] = ['ji' => $ji, 'payload' => $job['plan'][$round]['payload']];
            }
            foreach (['standard', 'postal'] as $m) {
                if (empty($byMethod[$m])) {
                    continue;
                }
                $batch = $byMethod[$m];
                $payloads = array_map(function ($b) { return $b['payload']; }, $batch);
                $res = ($m === 'postal')
                    ? $this->api->createParcelsBatchByPostalCode(['parcels' => $payloads])
                    : $this->api->createParcelsBatch(['parcels' => $payloads]);
                $results = (!empty($res['ok']) && isset($res['data']['results']) && is_array($res['data']['results']))
                    ? $res['data']['results'] : null;
                if ($results === null) {
                    // Whole batch failed — record the error on each job so the next
                    // round (or finalize) can fall back / report it.
                    $err = $m . ' → ' . $this->formatApiError($res);
                    foreach ($batch as $b) {
                        $jobs[$b['ji']]['err'] = $err;
                        $jobs[$b['ji']]['payload'] = $b['payload'];
                    }
                    continue;
                }
                foreach ($results as $item) {
                    $bidx = isset($item['index']) ? (int) $item['index'] : -1;
                    if (!isset($batch[$bidx])) {
                        continue;
                    }
                    $ji = $batch[$bidx]['ji'];
                    if (!empty($item['success']) && !empty($item['nid'])) {
                        $this->savePushSuccess($jobs[$ji]['order'], $batch[$bidx]['payload'], (string) $item['nid'], (string) ($res['adapter'] ?? 'primary'));
                        $jobs[$ji]['done'] = true;
                        $created++;
                    } else {
                        $jobs[$ji]['err'] = $m . ' → ' . (string) (isset($item['error']) ? $item['error'] : 'échec');
                        $jobs[$ji]['payload'] = $batch[$bidx]['payload'];
                    }
                }
            }
        }

        foreach ($jobs as $job) {
            if (!$job['done']) {
                $this->savePushFailure($job['order'], $job['payload'], $job['err'] !== '' ? $job['err'] : 'échec de l\'envoi');
                $failed++;
            }
            IntigoParcel::releaseSendLock((int) $job['order']->id);
        }

        IntigoLog::add('bulk_push', 'created=' . $created . ' failed=' . $failed . ' skipped=' . count($skipped));
        return [
            'total' => count($order_ids),
            'created' => $created,
            'failed' => $failed,
            'skipped' => count($skipped),
            'skip_detail' => $skipped,
        ];
    }

    /* -------------------- Send plan (guesser zone + postal code) -------------------- */

    /**
     * Build the ordered list of send attempts for an order. Each attempt is
     * ['method' => 'standard'|'postal', 'payload' => array]. Our OWN resolved zone
     * always leads when the payload is valid — it is verified locally (the city
     * matches the order's city and the district belongs to it), whereas the postal
     * path DELETES those ids and lets Intigo re-derive the zone from its own
     * core_neighborhood.postal_code table, which we cannot check before sending and
     * which is demonstrably wrong for at least one code (1082, a Tunis code, resolves
     * to Kef — it misrouted order #2796 by ~200 km). Postal therefore never leads any
     * more; it is only a fallback for an unresolvable zone or a rejected send. Empty
     * array = nothing to send (neither a valid zone nor a usable postal code).
     *
     * HARD RULE (v1.3.29): the postal-code path is GONE. Without a Ville AND a
     * Délégation there is no send plan at all, and there is no second attempt that
     * could quietly substitute a zone Intigo derives on its own.
     *
     * The fallback was kept in 1.3.28 as a retry behind a valid zone, but that left
     * one live hazard: if Intigo rejected our (correct) payload for any reason, the
     * retry stripped the zone ids and sent `postal_code` — and Intigo resolves 1082,
     * a Tunis code, to Kef. A retry that can silently change the governorate is worse
     * than a failed send the merchant can see. If the standard send fails now, it
     * fails loudly and the error is shown.
     *
     * Single choke point for every entry point — manual send, bulk send, order-side
     * panel and the automatic status triggers.
     */
    private function buildSendPlan(Order $order, $parcel)
    {
        $std = $this->orderToPayload($order);
        if ($this->validatePayload($std) !== null) {
            return [];
        }
        return [['method' => 'standard', 'payload' => $std]];
    }

    /** The delivery postal code if it's a usable Tunisian 4-digit code, else ''. */
    public function usablePostalCode(Order $order)
    {
        $pc = '';
        if ((int) $order->id_address_delivery > 0) {
            $address = new Address((int) $order->id_address_delivery);
            if (Validate::isLoadedObject($address)) {
                $pc = (string) $address->postcode;
            }
        }
        $digits = preg_replace('/\D+/', '', $pc);
        return (is_string($digits) && strlen($digits) === 4) ? $digits : '';
    }

    // orderToPostalPayload() was removed in v1.3.29. It stripped the destination
    // zone ids and let Intigo re-derive them from `postal_code`, which is how a
    // Tunis parcel (1082) was created in Kef. Nothing may send a parcel without the
    // zone we verified; the postcode is now only ever a display hint in the BO.

    /**
     * Order line items as [['name','qty','total'], ...]. Used both for the parcel
     * `description` (so contents print on the bordereau) and for the read-only
     * product summary on the Intigo order edit page.
     */
    public function getOrderProducts(Order $order)
    {
        $out = [];
        try {
            $products = (array) $order->getProducts();
        } catch (\Throwable $e) {
            return $out; // never let a product-fetch hiccup break the payload/send
        }
        foreach ($products as $p) {
            $name = isset($p['product_name']) ? trim((string) $p['product_name']) : '';
            if ($name === '') {
                continue;
            }
            $out[] = [
                'name' => $name,
                'qty' => isset($p['product_quantity']) ? (int) $p['product_quantity'] : 0,
                'total' => isset($p['total_price_tax_incl']) ? (float) $p['total_price_tax_incl'] : 0.0,
            ];
        }
        return $out;
    }

    /** The product list as one line for the parcel description (≤250 chars). */
    public function buildProductDescription(Order $order)
    {
        $items = [];
        foreach ($this->getOrderProducts($order) as $p) {
            $items[] = ($p['qty'] > 1 ? $p['qty'] . '× ' : '') . $p['name'];
        }
        $desc = implode(', ', $items);
        if ($desc === '') {
            $desc = 'Commande #' . (int) $order->id;
        }
        return function_exists('mb_substr') ? mb_substr($desc, 0, 250) : substr($desc, 0, 250);
    }

    /** The parcel description as sent: « Réf : X — products », capped at 250. */
    public function buildDescription(Order $order, $reference_id = '')
    {
        $products = $this->buildProductDescription($order);
        $desc = $reference_id !== '' ? ('Réf : ' . $reference_id . ' — ' . $products) : $products;
        return function_exists('mb_substr') ? mb_substr($desc, 0, 250) : substr($desc, 0, 250);
    }

    /* -------------------- Order edits → parcel -------------------- */

    /**
     * What an order edit can change on the parcel, as it stands now.
     * Compared with the parcel's `sync_snapshot` (the same shape, as last sent).
     */
    public function orderSyncSnapshot(Order $order, $parcel = null)
    {
        $reference_id = $parcel ? trim((string) $parcel->reference_id) : '';
        return [
            // A string, so the stored and the live value compare exactly (a float
            // round-trips through JSON as 169.90000000000001).
            'price' => number_format((float) $this->computeCodAmount($order), 3, '.', ''),
            'description' => $this->buildDescription($order, $reference_id),
        ];
    }

    /**
     * Pass an order edit on to its parcel — only what changed, only while the
     * parcel still awaits pickup.
     *
     * The automatic update used to re-send the WHOLE creation payload on every
     * Order::update(), including a status change saved by our own webhook: the
     * zone, name and phone stored here flattened whatever Intigo had corrected,
     * and the price went out again unchanged. Now the order's price and product
     * list are compared with what was last sent and only the difference is
     * PATCHed. Past pickup Intigo refuses every change, so the edit is recorded
     * on the parcel (`sync_error`) and shown in the order panel instead.
     *
     * @return array{ok:bool, changed:string[], message:string}
     */
    public function syncOrderEdits(Order $order, $force = false)
    {
        $parcel = IntigoParcel::findByOrderId((int) $order->id);
        if (!$parcel || trim((string) $parcel->nid) === '') {
            return ['ok' => false, 'changed' => [], 'message' => 'Aucun colis pour cette commande'];
        }
        if ((int) $parcel->sync_locked === 1) {
            return ['ok' => false, 'changed' => [], 'message' => 'Colis verrouillé chez Intigo (livré/en retour)'];
        }

        $now = $this->orderSyncSnapshot($order, $parcel);
        $before = null;
        if (trim((string) $parcel->sync_snapshot) !== '') {
            $decoded = json_decode((string) $parcel->sync_snapshot, true);
            if (is_array($decoded)) { $before = $decoded; }
        }

        $changed = [];
        if ($force) {
            $changed = ['price', 'description'];
        } elseif ($before !== null) {
            foreach (['price', 'description'] as $k) {
                if (!array_key_exists($k, $before) || $before[$k] != $now[$k]) { $changed[] = $k; }
            }
        }
        if (!$changed) {
            // Nothing moved — or, for a parcel sent before 1.3.32, nothing known
            // to compare with: record the baseline so the next edit is caught.
            if ($before === null) {
                $parcel->sync_snapshot = json_encode($now, JSON_UNESCAPED_UNICODE);
                $parcel->save();
            }
            return ['ok' => true, 'changed' => [], 'message' => 'Colis déjà à jour'];
        }

        // Intigo only accepts changes while the parcel awaits pickup (status < 2000).
        if ((int) $parcel->status_code >= 2000) {
            $parcel->sync_snapshot = json_encode($now, JSON_UNESCAPED_UNICODE);
            $parcel->sync_error = 'Commande modifiée après le ramassage du colis (' . implode(', ', $changed)
                . ') — non répercutée chez Intigo. Prix du colis : ' . number_format((float) ($before['price'] ?? 0), 3, '.', '')
                . ' ; commande : ' . $now['price'] . '.';
            $parcel->save();
            IntigoLog::add('order_edit_not_synced', 'id_order=' . (int) $order->id . ' nid=' . $parcel->nid . ' status=' . (int) $parcel->status_code, null, (int) $order->id);
            return ['ok' => false, 'changed' => $changed, 'message' => $parcel->sync_error];
        }

        $body = [];
        if (in_array('price', $changed, true)) { $body['price'] = (float) $now['price']; }
        if (in_array('description', $changed, true)) { $body['description'] = $now['description']; }
        $res = $this->api->updateParcel($parcel->nid, $body);
        if (!empty($res['ok'])) {
            $parcel->sync_snapshot = json_encode($now, JSON_UNESCAPED_UNICODE);
            $parcel->sync_error = null;
            $parcel->last_sync_at = date('Y-m-d H:i:s');
            $parcel->save();
            IntigoLog::add('order_edit_synced', 'id_order=' . (int) $order->id . ' nid=' . $parcel->nid . ' ' . implode(',', $changed), null, (int) $order->id);
            return ['ok' => true, 'changed' => $changed, 'message' => 'Colis mis à jour (' . implode(', ', $changed) . ')'];
        }
        if ($this->isParcelLockedError($res)) {
            $parcel->sync_locked = 1;
            $parcel->sync_snapshot = json_encode($now, JSON_UNESCAPED_UNICODE);
            $parcel->sync_error = 'Colis verrouillé chez Intigo (livré/en retour) — modification non répercutée.';
            $parcel->save();
            return ['ok' => false, 'locked' => true, 'changed' => $changed, 'message' => $parcel->sync_error];
        }
        $err = $this->formatApiError($res);
        // Recorded as the new state all the same: the edit was seen, and asking
        // again on every later save would only repeat the refusal.
        $parcel->sync_snapshot = json_encode($now, JSON_UNESCAPED_UNICODE);
        $parcel->sync_error = 'Commande modifiée (' . implode(', ', $changed) . ') — non répercutée chez Intigo : ' . $err;
        $parcel->save();
        IntigoLog::add('order_edit_sync_failed', 'id_order=' . (int) $order->id . ' nid=' . $parcel->nid . ' err=' . $err, null, (int) $order->id);
        return ['ok' => false, 'changed' => $changed, 'message' => $parcel->sync_error];
    }

    /* -------------------- Payload building -------------------- */

    /**
     * Build the parcel-creation payload from a PrestaShop Order.
     *
     * Precedence:
     *   - Intigo cart meta (city/district/etc captured at checkout) wins
     *   - Falls back to ps_intigo_parcel row (if order was edited)
     *   - Falls back to PrestaShop shipping address (best-effort)
     */
    public function orderToPayload(Order $order, $resolveViaApi = true)
    {
        $address = new Address((int) $order->id_address_delivery);
        $address_loaded = Validate::isLoadedObject($address);

        // Invoice address is a useful fallback — customers often put phone on
        // the billing address only, leaving the shipping address phone empty.
        $invoice = (int) $order->id_address_invoice > 0 && (int) $order->id_address_invoice !== (int) $order->id_address_delivery
            ? new Address((int) $order->id_address_invoice)
            : null;
        $invoice_loaded = $invoice && Validate::isLoadedObject($invoice);

        // All Intigo data lives in ps_intigo_parcel (admin fills it in BO).
        // Fall back to PS shipping address for any field the admin hasn't set.
        $parcel = IntigoParcel::findByOrderId((int) $order->id);

        $recipient_name = '';
        $phone = '';
        $destination_address = '';
        $city_id = 0;
        $district_id = 0;
        $neighborhood_id = 0;

        if ($parcel) {
            $recipient_name = (string) $parcel->recipient_name;
            $phone = (string) $parcel->recipient_phone;
            $destination_address = (string) $parcel->destination_address;
            $city_id = (int) $parcel->destination_city_id;
            $district_id = (int) $parcel->destination_district_id;
            $neighborhood_id = (int) $parcel->destination_neighborhood_id;
        }

        // Last-resort fallback: PrestaShop addresses (delivery first, then invoice).
        // Complete a missing surname from the customer so the recipient is never
        // just a first name (client-reported: guest COD checkout saved the address
        // with only a first name while the customer record had the full name).
        if ($recipient_name === '' && $address_loaded) {
            $recipient_name = self::fullRecipientName($order, $address);
        }
        if ($recipient_name === '' && $invoice_loaded) {
            $recipient_name = self::fullRecipientName($order, $invoice);
        }
        if ($phone === '' && $address_loaded) {
            $phone = (string) ($address->phone_mobile ?: $address->phone);
        }
        if ($phone === '' && $invoice_loaded) {
            $phone = (string) ($invoice->phone_mobile ?: $invoice->phone);
        }
        if ($address_loaded) {
            $destination_address = self::preferredAddress($destination_address, $address);
        }
        if ($destination_address === '' && $invoice_loaded) {
            $destination_address = self::fullAddressLine($invoice);
        }

        // Resolve city by name from address.city when we still don't have a
        // city_id. This makes a network call, so it is SKIPPED during checkout
        // (resolveViaApi=false) to never block order creation.
        if ($resolveViaApi && $city_id <= 0 && $address_loaded && trim((string) $address->city) !== '') {
            $resolved = $this->resolveCityIdByName((string) $address->city);
            if ($resolved > 0) {
                $city_id = $resolved;
            }
        }

        // Resolve size: per-order parcel.package_size > cart-based waterfall
        $size_letter = 'S';
        if ($parcel && (int) $parcel->package_size > 0) {
            $letter = IntigoSizeResolver::codeToLetter((int) $parcel->package_size);
            if ($letter !== '') {
                $size_letter = $letter;
            }
        } else {
            $size_letter = IntigoSizeResolver::resolveForOrder($order);
        }
        $package_size_code = IntigoApiClient::sizeLetterToCode($size_letter);

        $payload = [
            'recipient_name' => $recipient_name,
            'phone1' => $this->normalizePhone($phone),
            'destination_address' => $destination_address,
            'destination_city_id' => $city_id,
            'destination_district_id' => $district_id,
            'price' => $this->computeCodAmount($order),
            'package_size' => $package_size_code,
            'can_open' => false,
        ];
        if ($neighborhood_id > 0) {
            $payload['destination_neighborhood_id'] = $neighborhood_id;
        }

        // cid = the merchant's Référence (per Intigo: "the referenceID is the cid").
        // It's required before any send, so it's always set; fall back to a stable
        // per-order key only as a last resort so Intigo always gets a correlation id.
        $reference_id = $parcel ? trim((string) $parcel->reference_id) : '';
        $payload['cid'] = $reference_id !== ''
            ? $reference_id
            : ('ps-' . ((int) $order->id_shop ?: 1) . '-' . (int) $order->id);

        // `description` prints on the bordereau as the "Commentaire" section —
        // verified against partner2-api/services/bordereau_service.py, where
        // `additional_info` is NOT printed. So we put BOTH the Référence AND the
        // product list here, so the reference is VISIBLE on the bordereau next to
        // the contents (capped to keep within the API's description limit).
        $payload['description'] = $this->buildDescription($order, $reference_id);

        // Also carry the Référence in additional_info (courier-app note / future
        // proofing). Not printed on the current bordereau, but the merchant asked
        // for it to live in the note field too.
        if ($reference_id !== '') {
            $payload['additional_info'] = $reference_id;
        }

        // Pickup address according to the order's current status. This is purely
        // local (status map + cached pickup list) — NO network call — so it is
        // safe during checkout too. The pickup_index is frozen at parcel creation;
        // the API exposes no way to change it afterward, so resolution only
        // matters at push time.
        $pickup = $this->resolvePickupIndex($order);
        if ($pickup !== null && $pickup >= 1) {
            $payload['pickup_index'] = (int) $pickup;
        }

        return $payload;
    }

    /**
     * The COD (cash-on-delivery) amount Intigo should collect from the recipient.
     *
     * Rule — purely by the payment method (INTIGO_COD_METHODS = the merchant's
     * cash-on-delivery methods):
     *   - payment method IS a COD method → collect the FULL amount on delivery.
     *   - any OTHER method               → collect 0 (handled outside COD).
     * Matching is case-insensitive, against the order's payment name + module.
     * An empty list means "no COD methods configured" → every order collects full.
     */
    private function computeCodAmount(Order $order)
    {
        $total = (float) $order->total_paid_tax_incl;
        $raw = trim((string) Configuration::get('INTIGO_COD_METHODS'));
        if ($raw === '') {
            return $total; // nothing configured → collect full
        }
        $haystack = Tools::strtolower(trim((string) $order->payment . ' ' . (string) $order->module));
        foreach (preg_split('/[\r\n,;]+/', $raw) as $kw) {
            $kw = Tools::strtolower(trim($kw));
            if ($kw !== '' && strpos($haystack, $kw) !== false) {
                return $total; // COD method → collect the exact amount on delivery
            }
        }
        // Not a COD method → the amount is settled outside cash-on-delivery
        // (paid online, cheque, bank transfer, …) → Intigo collects nothing.
        return 0.0;
    }

    /**
     * Resolve the pickup index for this order — STRICT, no guessing:
     *   1. the merchant's sticky per-order override (pickup_override_index), else
     *   2. the pickup mapped to the order's current status, else
     *   3. null → UNRESOLVED.
     * There is deliberately NO default/primary/GPS fallback: when nothing resolves,
     * the caller MUST refuse to send (see pickupBlockMessage()) so a parcel is never
     * created with a guessed pickup. This is the fix for the Sousse↔Sfax mismatch —
     * a wrong-by-guess pickup can no longer reach Intigo.
     */
    private function resolvePickupIndex(Order $order)
    {
        // 1. Sticky per-order override wins over everything.
        $parcel = IntigoParcel::findByOrderId((int) $order->id);
        if ($parcel && $parcel->pickup_override_index !== null && (int) $parcel->pickup_override_index >= 1) {
            return (int) $parcel->pickup_override_index;
        }
        // 2. Status → pickup mapping the merchant configured.
        if (!class_exists('IntigoPickupMap')) {
            @include_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoPickupMap.php';
        }
        if (class_exists('IntigoPickupMap')) {
            $idx = IntigoPickupMap::resolvePickupIndex((int) $order->id_shop ?: 1, (int) $order->getCurrentState());
            if ($idx !== null && (int) $idx >= 1) {
                return (int) $idx;
            }
        }
        // 3. Unresolved — never guess a default.
        return null;
    }

    /**
     * The pickup index that WOULD be used for this order (override or status map),
     * for display in the BO. Null when unresolved.
     */
    public function effectivePickupIndex(Order $order)
    {
        return $this->resolvePickupIndex($order);
    }

    /**
     * Null when a pickup is resolvable (override or status map), otherwise a
     * merchant-facing message. When non-null the order MUST NOT be sent to Intigo
     * until the merchant sets the pickup from the order edit modal.
     */
    public function pickupBlockMessage(Order $order)
    {
        if ($this->resolvePickupIndex($order) !== null) {
            return null;
        }
        return 'Adresse de ramassage requise : aucun statut mappé et aucun choix manuel. '
            . 'Ouvrez la commande, cliquez « Modifier », choisissez l’adresse de ramassage, puis envoyez.';
    }

    /** Flag a parcel as blocked for a missing pickup (shows in the "Échec" filter). */
    private function flagPickupRequired(Order $order, $message, $autoTriggered = false)
    {
        $parcel = IntigoParcel::findByOrderId((int) $order->id) ?: new IntigoParcel();
        $parcel->id_order = (int) $order->id;
        if ($parcel->nid === null) {
            $parcel->nid = '';
        }
        $parcel->last_error = substr((string) $message, 0, 4000);
        $parcel->last_attempt_at = date('Y-m-d H:i:s');
        $parcel->save();
        if (class_exists('IntigoLog')) {
            IntigoLog::add($autoTriggered ? 'auto_push_pickup_required' : 'pickup_required',
                'status=' . (int) $order->getCurrentState(), null, (int) $order->id);
        }
    }

    /* -------------------- Persistence helpers -------------------- */

    /** The parcel now matches the order: remember what was sent. */
    private function recordSynced(IntigoParcel $parcel, Order $order)
    {
        $parcel->sync_snapshot = json_encode($this->orderSyncSnapshot($order, $parcel), JSON_UNESCAPED_UNICODE);
        $parcel->sync_error = null;
        $parcel->last_sync_at = date('Y-m-d H:i:s');
        $parcel->save();
    }

    private function savePushSuccess(Order $order, array $payload, $nid, $adapter)
    {
        $parcel = IntigoParcel::findByOrderId((int) $order->id) ?: new IntigoParcel();
        $parcel->id_order = (int) $order->id;
        $parcel->nid = (string) $nid;
        $parcel->api_target_used = (string) $adapter;
        $parcel->status_code = 1000; // "Pending pickup" — Intigo's initial state
        $parcel->sync_error = null;
        $parcel->package_size = (int) $payload['package_size'];
        $parcel->recipient_name = (string) $payload['recipient_name'];
        $parcel->recipient_phone = (string) $payload['phone1'];
        $parcel->destination_address = (string) $payload['destination_address'];
        // Postal-code sends carry no zone IDs (Intigo resolves them server-side) —
        // only overwrite when the payload actually has them, else keep what's stored.
        if (isset($payload['destination_city_id'])) {
            $parcel->destination_city_id = (int) $payload['destination_city_id'];
        }
        if (isset($payload['destination_district_id'])) {
            $parcel->destination_district_id = (int) $payload['destination_district_id'];
        }
        if (isset($payload['destination_neighborhood_id'])) {
            $parcel->destination_neighborhood_id = (int) $payload['destination_neighborhood_id'];
        }
        // Persist the pickup ACTUALLY sent to Intigo, so the stored value is the
        // truth of what the parcel was created with (used for the divergence
        // warning + the Orders-list pickup filter). The gate guarantees it's set.
        if (isset($payload['pickup_index'])) {
            $parcel->pickup_index = (int) $payload['pickup_index'];
        }
        $parcel->idempotency_hash = md5($this->idempotencyKey($order, 'manual_create'));
        $parcel->sync_locked = 0;
        $parcel->last_error = null;
        $parcel->last_attempt_at = date('Y-m-d H:i:s');
        // The baseline later order edits are compared against (syncOrderEdits).
        $parcel->sync_snapshot = json_encode($this->orderSyncSnapshot($order, $parcel), JSON_UNESCAPED_UNICODE);
        $parcel->save();
    }

    private function savePushFailure(Order $order, array $payload, $error_message)
    {
        $parcel = IntigoParcel::findByOrderId((int) $order->id) ?: new IntigoParcel();
        $parcel->id_order = (int) $order->id;
        if ($parcel->nid === null) { $parcel->nid = ''; }
        $parcel->package_size = (int) $payload['package_size'];
        $parcel->recipient_name = (string) $payload['recipient_name'];
        $parcel->recipient_phone = (string) $payload['phone1'];
        $parcel->destination_address = (string) $payload['destination_address'];
        // Postal-code payloads carry no zone IDs — keep whatever's stored.
        if (isset($payload['destination_city_id'])) {
            $parcel->destination_city_id = (int) $payload['destination_city_id'];
        }
        if (isset($payload['destination_district_id'])) {
            $parcel->destination_district_id = (int) $payload['destination_district_id'];
        }
        if (isset($payload['destination_neighborhood_id'])) {
            $parcel->destination_neighborhood_id = (int) $payload['destination_neighborhood_id'];
        }
        // NOTE: do NOT set idempotency_hash on failure — that's reserved for
        // successful pushes so future retries aren't blocked by it.
        $parcel->last_error = substr((string) $error_message, 0, 4000);
        $parcel->last_attempt_at = date('Y-m-d H:i:s');
        $parcel->save();
    }

    /* -------------------- Validation / errors -------------------- */

    /**
     * Returns null when the parcel can be sent, or a human-friendly message
     * naming exactly what the merchant still needs to fill in (never raw API
     * field names like "destination_city_id").
     */
    private function validatePayload(array $payload)
    {
        $missing = [];
        if (trim((string) $payload['recipient_name']) === '') {
            $missing[] = 'le nom du destinataire';
        }
        if (trim((string) $payload['phone1']) === '') {
            $missing[] = 'le téléphone';
        }
        if (trim((string) $payload['destination_address']) === '') {
            $missing[] = 'l\'adresse de livraison';
        }
        if ((int) $payload['destination_city_id'] <= 0) {
            $missing[] = 'la ville';
        }
        if ((int) $payload['destination_district_id'] <= 0) {
            $missing[] = 'la délégation';
        }
        if (empty($missing)) {
            return null;
        }
        $last = array_pop($missing);
        $list = $missing ? implode(', ', $missing) . ' et ' . $last : $last;

        return 'Ce colis ne peut pas encore être envoyé — veuillez renseigner ' . $list
            . '. Cliquez sur « Modifier » pour compléter les informations, puis envoyez.';
    }

    private function formatApiError($res)
    {
        if (!is_array($res)) { return 'unknown error'; }
        $parts = [];
        if (isset($res['adapter'])) { $parts[] = 'adapter=' . $res['adapter']; }
        if (isset($res['code'])) { $parts[] = 'http=' . $res['code']; }
        if (!empty($res['url'])) { $parts[] = 'url=' . $res['url']; }
        if (!empty($res['error'])) {
            $parts[] = 'error=' . $res['error'];
        } elseif (!empty($res['data'])) {
            $parts[] = 'response=' . json_encode($res['data']);
        }
        if (!empty($res['legacy_attempt'])) {
            $la = $res['legacy_attempt'];
            $sub = [];
            if (!empty($la['code'])) { $sub[] = 'http=' . $la['code']; }
            if (!empty($la['url'])) { $sub[] = 'url=' . $la['url']; }
            if (!empty($la['error'])) { $sub[] = 'error=' . $la['error']; }
            elseif (!empty($la['data'])) { $sub[] = 'response=' . json_encode($la['data']); }
            if ($sub) { $parts[] = 'legacy(' . implode(' ', $sub) . ')'; }
        }
        return $parts ? implode(' | ', $parts) : 'unknown error';
    }

    /**
     * Detect "parcel is locked at Intigo" errors — same heuristics as the WP plugin.
     */
    private function isParcelLockedError($res)
    {
        if (!is_array($res)) { return false; }
        $status = (int) ($res['code'] ?? 0);
        if ($status !== 400 && $status !== 409) { return false; }
        $detail = '';
        if (isset($res['data']['detail'])) {
            $detail = strtolower((string) $res['data']['detail']);
        } elseif (isset($res['error'])) {
            $detail = strtolower((string) $res['error']);
        }
        if ($detail === '') { return false; }
        return strpos($detail, 'deja livre') !== false
            || strpos($detail, 'déjà livré') !== false
            || strpos($detail, 'en retour') !== false
            || strpos($detail, 'ne peut plus être modifié') !== false
            || strpos($detail, 'ne peut plus etre modifie') !== false;
    }

    private function idempotencyKey(Order $order, $event)
    {
        $shop_id = (int) $order->id_shop ?: 1;
        return sprintf('ps:%d:%d:%s:v1', $shop_id, (int) $order->id, $event);
    }

    private function normalizePhone($phone)
    {
        $digits = preg_replace('/\D+/', '', (string) $phone);
        if ($digits === null) {
            return '';
        }
        if (strpos($digits, '00') === 0) {
            $digits = substr($digits, 2);
        }
        return $digits;
    }

    private function resolveCityIdByName($city_name)
    {
        $res = $this->api->fetchCities($city_name);
        if (!empty($res['ok']) && !empty($res['items'])) {
            // Exact match first, else first hit
            $lower = strtolower(trim($city_name));
            foreach ($res['items'] as $item) {
                if (strtolower((string) $item['name']) === $lower) {
                    return (int) $item['id'];
                }
            }
            return (int) $res['items'][0]['id'];
        }
        return 0;
    }
}
