<?php
/** Upgrade to 1.3.32 — an order edited after its parcel was sent (quantity, product,
 *  price) is passed on to Intigo: only what changed, only while the parcel awaits
 *  pickup. Adds `sync_snapshot` (what was last sent) and `sync_error` (why an edit
 *  could not be passed on) to ps_intigo_parcel. */
if (!defined('_PS_VERSION_')) { exit; }
function upgrade_module_1_3_32($module)
{
    if (!(include dirname(__FILE__) . '/../sql/install.php')) { return false; }
    if (method_exists($module, 'ensureTabs')) { $module->ensureTabs(); }
    return true;
}
