<?php
/**
 * Intigo Parcels for PrestaShop — main module class.
 *
 * Port of the WordPress Intigo Parcels for WooCommerce plugin.
 * Compatible with PrestaShop 1.7.x and 8.x; PHP 7.2+.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

require_once __DIR__ . '/classes/IntigoAutoload.php';
require_once __DIR__ . '/classes/IntigoAdminUi.php';
require_once __DIR__ . '/classes/IntigoApiClient.php';
require_once __DIR__ . '/classes/IntigoParcel.php';
require_once __DIR__ . '/classes/IntigoPickupMap.php';
require_once __DIR__ . '/classes/IntigoProductSize.php';
require_once __DIR__ . '/classes/IntigoLog.php';
require_once __DIR__ . '/classes/IntigoSizeResolver.php';
require_once __DIR__ . '/classes/IntigoAddressResolver.php';
require_once __DIR__ . '/classes/IntigoOrderService.php';

class Intigoparcels extends Module
{
    /**
     * Configuration keys for module behavior. Shipping price is NOT one of them —
     * PrestaShop's native carrier ranges (Shipping → Carriers → Intigo Delivery)
     * handle that. See feedback memory feedback-prestashop-no-shipping-pricing.
     */
    const CONFIG_KEYS = [
        'INTIGO_ENVIRONMENT',
        'INTIGO_API_KEY',
        'INTIGO_FALLBACK_ENABLED',
        'INTIGO_AUTO_CREATE',
        'INTIGO_DEFAULT_SIZE',
        'INTIGO_CARRIER_ID',
        'INTIGO_CRON_TOKEN',
        'INTIGO_TRACKING_URL',
        // Per-size shipping prices — the carrier charges by resolved package size
        // (S/M/L/XL), matching the Shopify app. Merchant-configurable in Settings.
        'INTIGO_PRICE_S',
        'INTIGO_PRICE_M',
        'INTIGO_PRICE_L',
        'INTIGO_PRICE_XL',
        // The shop's CASH-ON-DELIVERY payment methods. An order paid with one of
        // these is sent to Intigo with the FULL amount to collect; every OTHER
        // method (already paid online) is sent with 0. Comma-separated, matched
        // against the order's payment name + module.
        'INTIGO_COD_METHODS',
        // Pickup addresses ↔ order-status mapping (v1.1.0). The status map drives
        // which pickup address (pickup_index) is sent at parcel creation.
        'INTIGO_DEFAULT_PICKUP_INDEX',
        'INTIGO_PICKUP_AS_TRIGGER',
        'INTIGO_PICKUP_CACHE',
        'INTIGO_PICKUP_CACHE_TS',
        // Cached city-name → city_id map for free-text address auto-resolution.
        'INTIGO_CITIES_CACHE',
        'INTIGO_CITIES_CACHE_TS',
        // Cached live parcel-status snapshot powering the dashboard KPIs.
        'INTIGO_DASH_STATUS',
        'INTIGO_DASH_STATUS_TS',
        // Webhook status-sync (Intigo → PrestaShop): shared secret + the PS order
        // states to set on milestone statuses + last-received timestamp.
        'INTIGO_WEBHOOK_TOKEN',
        'INTIGO_STATE_DELIVERED',
        'INTIGO_STATE_RETURNED',
        'INTIGO_STATE_IN_DELIVERY',
        'INTIGO_WH_STATUS_MAP',
        'INTIGO_WH_UPDATE_ORDERS',
        'INTIGO_WEBHOOK_LAST_TS',
        'INTIGO_TAB_ACCESS_V1',
        'INTIGO_TAB_ACCESS_V2',
    ];

    /**
     * Hooks registered at install time.
     *
     * NOTE: no customer-facing checkout hooks (displayCarrierExtraContent,
     * actionValidateStepComplete, displayHeader). All Intigo data is captured
     * in the BO order page after checkout — see feedback memory
     * feedback-prestashop-no-checkout-injection.
     */
    const HOOKS = [
        'displayBackOfficeHeader',
        'actionAdminControllerSetMedia',
        'actionValidateOrder',
        'actionOrderStatusPostUpdate',
        'actionObjectOrderUpdateAfter',
        'displayAdminOrder',
        'displayAdminOrderSide',
        // Tab hooks — these render reliably in PS 8.x's Symfony order view,
        // unlike displayAdminOrderSide which can drop output silently.
        'displayAdminOrderTabLink',
        'displayAdminOrderTabContent',
    ];

    public function __construct()
    {
        $this->name = 'intigoparcels';
        $this->tab = 'shipping_logistics';
        $this->version = '1.3.18';
        $this->author = 'Intigo';
        $this->need_instance = 0;
        $this->bootstrap = true;
        $this->ps_versions_compliancy = ['min' => '1.7.0.0', 'max' => _PS_VERSION_];

        parent::__construct();

        $this->displayName = $this->l('Intigo Parcels');
        $this->description = $this->l('Sell on PrestaShop, ship via Intigo. Checkout flow with Intigo zone selection, automatic or manual push of orders to Intigo, bordereau generation, and status sync.');
        $this->confirmUninstall = $this->l('Are you sure? Order-to-parcel mapping, product size assignments and activity logs will be deleted.');
    }

    public function install()
    {
        if (!parent::install()) {
            return false;
        }
        if (!$this->installSql()) {
            return false;
        }
        if (!$this->installDefaults()) {
            return false;
        }
        if (!$this->installCarrier()) {
            return false;
        }
        if (!$this->installTabs()) {
            return false;
        }
        foreach (self::HOOKS as $hook) {
            if (!$this->registerHook($hook)) {
                return false;
            }
        }
        return true;
    }

    public function uninstall()
    {
        // Deliberately PRESERVE configuration (API key, per-size prices, tracking
        // URL) and data tables (order↔parcel mapping, product sizes, logs) on
        // uninstall, so a reinstall/upgrade never loses the merchant's setup or
        // the link to parcels already created in the Intigo system. We only
        // remove the UI (tabs) and soft-delete the carrier; install() revives both.
        // A full data purge is intentionally NOT done here (would orphan parcels
        // that still exist in Intigo). Use sql/uninstall.php manually if ever needed.
        $this->uninstallTabs();
        $this->uninstallCarrier();
        return parent::uninstall();
    }

    /* -------------------- Install helpers -------------------- */

    private function installSql()
    {
        return include __DIR__ . '/sql/install.php';
    }

    private function uninstallSql()
    {
        return include __DIR__ . '/sql/uninstall.php';
    }

    private function installDefaults()
    {
        $defaults = [
            'INTIGO_ENVIRONMENT' => 'sandbox',
            'INTIGO_API_KEY' => '',
            'INTIGO_FALLBACK_ENABLED' => '1',
            'INTIGO_AUTO_CREATE' => '0',
            'INTIGO_DEFAULT_SIZE' => 'S',
            'INTIGO_CRON_TOKEN' => bin2hex(random_bytes(16)),
            // Customer-facing tracking URL on the carrier — points to the Intigo
            // client app on Google Play (the official tracking destination).
            'INTIGO_TRACKING_URL' => 'https://play.google.com/store/apps/details?id=net.intigo.client',
            // Per-size shipping prices (placeholders — merchant sets real rates).
            'INTIGO_PRICE_S' => '7',
            'INTIGO_PRICE_M' => '8',
            'INTIGO_PRICE_L' => '10',
            'INTIGO_PRICE_XL' => '12',
            // Cash-on-delivery payment methods → send the exact amount to collect;
            // every other (paid-online) method → 0. Empty by default (no hardcoded
            // list): the merchant ticks their COD solution(s) in Settings, chosen
            // dynamically from the shop's active payment modules. Empty = collect
            // full on every order (safe until configured).
            'INTIGO_COD_METHODS' => '',
            // Pickup mapping defaults: no forced default index, trigger OFF (opt-in),
            // empty cache. These keep current behavior unchanged until configured.
            'INTIGO_DEFAULT_PICKUP_INDEX' => '',
            'INTIGO_PICKUP_AS_TRIGGER' => '0',
            'INTIGO_PICKUP_CACHE' => '',
            'INTIGO_PICKUP_CACHE_TS' => '0',
            // Webhook status-sync: no token (disabled) + no state mapping until the
            // merchant configures it. A pre-filled token makes setup one click.
            'INTIGO_WEBHOOK_TOKEN' => bin2hex(random_bytes(16)),
            'INTIGO_STATE_DELIVERED' => '0',
            'INTIGO_STATE_RETURNED' => '0',
            'INTIGO_STATE_IN_DELIVERY' => '0',
            'INTIGO_WH_STATUS_MAP' => '',
            'INTIGO_WH_UPDATE_ORDERS' => '1',
            'INTIGO_WEBHOOK_LAST_TS' => '0',
        ];
        foreach ($defaults as $k => $v) {
            if (Configuration::get($k) === false) {
                Configuration::updateValue($k, $v);
            }
        }
        return true;
    }

    /**
     * Registers the "Intigo Delivery" carrier as a standard carrier (NOT a
     * CarrierModule). Pricing is handled entirely by PrestaShop's native
     * Shipping → Carriers UI (price ranges, weight ranges). The merchant
     * configures the price grid there; the module never overrides it.
     *
     * We seed one price range at 0 TND covering all zones/groups so the
     * carrier shows up in checkout even before the merchant tweaks pricing —
     * but the merchant is expected to set real prices in Shipping → Carriers.
     */
    private function installCarrier()
    {
        // Reinstall path: config is preserved, so the carrier id still points at
        // the (soft-deleted) carrier. Revive it instead of creating a duplicate —
        // this keeps every existing order's carrier link intact and avoids the
        // zombie-carrier pile-up.
        $existing_id = (int) Configuration::get('INTIGO_CARRIER_ID');
        if ($existing_id > 0) {
            $carrier = new Carrier($existing_id);
            if (Validate::isLoadedObject($carrier)) {
                $carrier->deleted = 0;
                $carrier->active = 1;
                $carrier->is_module = true;
                $carrier->shipping_external = true;
                $carrier->external_module_name = $this->name;
                $carrier->update();
                $logo = __DIR__ . '/views/img/carrier.jpg';
                if (file_exists($logo) && defined('_PS_SHIP_IMG_DIR_')) {
                    @copy($logo, _PS_SHIP_IMG_DIR_ . (int) $carrier->id . '.jpg');
                }
                return true;
            }
            // Stored id no longer resolves → fall through and create a fresh one.
        }
        $carrier = new Carrier();
        $carrier->name = 'Intigo Delivery';
        $carrier->active = 1;
        $carrier->deleted = 0;
        $carrier->shipping_handling = false;
        $carrier->range_behavior = 0;
        // Module-priced carrier: the module computes the price per resolved
        // package size (S/M/L/XL) in getPackageShippingCost(). Verified against
        // Cart::getPackageShippingCostFromModule (PS 9.1.3): the module is called
        // only when is_module=1 AND shipping_external=1; with need_range=1 PS calls
        // getPackageShippingCost(). The seed price range below keeps the carrier
        // valid in every zone (so it shows at checkout).
        $carrier->is_module = true;
        $carrier->shipping_external = true;
        $carrier->external_module_name = $this->name;
        $carrier->shipping_method = Carrier::SHIPPING_METHOD_PRICE;
        $carrier->need_range = 1;
        // Customer-facing tracking URL (@ = tracking number placeholder).
        $carrier->url = (string) Configuration::get('INTIGO_TRACKING_URL');
        foreach (Language::getLanguages() as $lang) {
            $carrier->delay[$lang['id_lang']] = '24-72h livraison via Intigo';
        }
        if (!$carrier->add()) {
            return false;
        }
        // Carrier logo (shown in checkout + the BO Carriers list).
        $logo = __DIR__ . '/views/img/carrier.jpg';
        if (file_exists($logo) && defined('_PS_SHIP_IMG_DIR_')) {
            @copy($logo, _PS_SHIP_IMG_DIR_ . (int) $carrier->id . '.jpg');
        }
        $range_price = new RangePrice();
        $range_price->id_carrier = (int) $carrier->id;
        $range_price->delimiter1 = 0;
        $range_price->delimiter2 = 100000;
        $range_price->add();
        foreach (Zone::getZones(true) as $zone) {
            Db::getInstance()->insert('carrier_zone', [
                'id_carrier' => (int) $carrier->id,
                'id_zone' => (int) $zone['id_zone'],
            ]);
            Db::getInstance()->insert('delivery', [
                'id_carrier' => (int) $carrier->id,
                'id_range_price' => (int) $range_price->id,
                'id_range_weight' => null,
                'id_zone' => (int) $zone['id_zone'],
                'price' => 0,
            ], false, true, Db::INSERT_IGNORE);
        }
        foreach (Group::getGroups(true) as $group) {
            Db::getInstance()->insert('carrier_group', [
                'id_carrier' => (int) $carrier->id,
                'id_group' => (int) $group['id_group'],
            ]);
        }
        Configuration::updateValue('INTIGO_CARRIER_ID', (int) $carrier->id);
        return true;
    }

    private function uninstallCarrier()
    {
        $id_carrier = (int) Configuration::get('INTIGO_CARRIER_ID');
        if ($id_carrier > 0) {
            $carrier = new Carrier($id_carrier);
            if (Validate::isLoadedObject($carrier)) {
                $carrier->deleted = 1;
                $carrier->update();
            }
        }
        return true;
    }

    /**
     * Creates one parent tab "Intigo" plus 5 child tabs. Stub controllers exist
     * for tabs whose features land in later phases — they render "Coming soon"
     * so the navigation is complete from day 1.
     */
    private function installTabs()
    {
        // Parent
        $parent = new Tab();
        foreach (Language::getLanguages(true) as $lang) {
            $parent->name[$lang['id_lang']] = 'Intigo';
        }
        $parent->class_name = 'AdminIntigoParent';
        $parent->module = $this->name;
        // Nest under the "SELL" section so PrestaShop renders Intigo as an
        // expandable dropdown group (like Orders/Customers) with our screens as
        // its submenu — NOT an orphan flat item. 'SELL' exists on 1.7/8/9.
        $id_sell = (int) Tab::getIdFromClassName('SELL');
        $parent->id_parent = $id_sell > 0 ? $id_sell : 0;
        $parent->icon = 'local_shipping';
        $parent->add();

        // All screens are legacy ModuleAdminControllers (class_name only) so the
        // single codebase runs on PrestaShop 1.7 / 8 / 9. NO Symfony route_name —
        // PrestaShopAdminController is 9.0+ only and 500s the whole BO on 1.7/8.
        $children = [
            ['AdminIntigoDashboard', 'Dashboard', true],
            ['AdminIntigoOrders', 'Orders', true],
            ['AdminIntigoPickup', 'Pickup addresses', true],
            ['AdminIntigoProductSizes', 'Product Sizes', true],
            ['AdminIntigoLogs', 'Logs', true],
            ['AdminIntigoSettings', 'Settings', true],
            ['AdminIntigoAccess', 'Accès', true],
            ['AdminIntigoDocs', 'Docs', true],
            ['AdminIntigoOrderAction', '', false], // hidden — only reachable via form action
        ];
        foreach ($children as $row) {
            $tab = new Tab();
            $tab->class_name = $row[0];
            $tab->module = $this->name;
            $tab->id_parent = (int) $parent->id;
            $tab->active = (bool) $row[2] ? 1 : 0;
            foreach (Language::getLanguages(true) as $lang) {
                $tab->name[$lang['id_lang']] = $row[1] !== '' ? $row[1] : $row[0];
            }
            $tab->add();
        }

        // Make every Intigo page accessible to every employee profile (not just
        // SuperAdmin) — see grantTabAccess.
        $this->grantTabAccess();
        $this->grantModuleAccess();
        Configuration::updateValue('INTIGO_TAB_ACCESS_V1', '1');
        Configuration::updateValue('INTIGO_TAB_ACCESS_V2', '1');
        return true;
    }

    /**
     * Grant every employee profile full access (view/add/edit/delete) to all
     * Intigo admin tabs. PrestaShop only auto-grants the SuperAdmin profile when a
     * module tab is added, so on shops with custom profiles (Logisticien, etc.)
     * the staff hit "access denied" on our pages. Idempotent — INSERT IGNORE on
     * the access PK, so re-running never duplicates or clobbers.
     */
    public function grantTabAccess()
    {
        try {
            $db = Db::getInstance();
            $classes = [
                'AdminIntigoParent', 'AdminIntigoDashboard', 'AdminIntigoOrders',
                'AdminIntigoPickup', 'AdminIntigoProductSizes', 'AdminIntigoLogs',
                'AdminIntigoSettings', 'AdminIntigoDocs', 'AdminIntigoOrderAction',
            ];
            $profiles = $db->executeS('SELECT id_profile FROM `' . _DB_PREFIX_ . 'profile`');
            if (!is_array($profiles) || empty($profiles)) {
                return;
            }
            foreach ($classes as $class) {
                foreach (['CREATE', 'READ', 'UPDATE', 'DELETE'] as $action) {
                    $slug = 'ROLE_MOD_TAB_' . strtoupper($class) . '_' . $action;
                    $id_role = (int) $db->getValue(
                        'SELECT id_authorization_role FROM `' . _DB_PREFIX_ . 'authorization_role` WHERE slug = "' . pSQL($slug) . '"'
                    );
                    if ($id_role <= 0) {
                        continue;
                    }
                    foreach ($profiles as $p) {
                        $db->execute(
                            'INSERT IGNORE INTO `' . _DB_PREFIX_ . 'access` (id_profile, id_authorization_role) VALUES ('
                            . (int) $p['id_profile'] . ', ' . $id_role . ')'
                        );
                    }
                }
            }

        } catch (\Throwable $e) {
            if (class_exists('IntigoLog')) {
                IntigoLog::add('grant_tab_access_error', $e->getMessage());
            }
        }
    }

    /**
     * Grant MODULE access (ROLE_MOD_MODULE_INTIGOPARCELS_*) to every profile.
     * PrestaShop SKIPS a module's hooks (incl. actionAdminControllerSetMedia +
     * displayBackOfficeHeader — see Hook.php) for any profile without module "view"
     * access, so our CSS/JS never load and the pages render unstyled. This is a
     * COARSE permission (use the module at all) and is SAFE to re-run on existing
     * installs — it does NOT touch per-page tab access, so it never undoes the
     * merchant's "Accès" restrictions. Lives in ps_module_access (NOT ps_access).
     */
    public function grantModuleAccess()
    {
        try {
            $db = Db::getInstance();
            $profiles = $db->executeS('SELECT id_profile FROM `' . _DB_PREFIX_ . 'profile`');
            if (!is_array($profiles) || empty($profiles)) {
                return;
            }
            foreach (['CREATE', 'READ', 'UPDATE', 'DELETE'] as $action) {
                $slug = 'ROLE_MOD_MODULE_' . strtoupper($this->name) . '_' . $action;
                $id_role = (int) $db->getValue(
                    'SELECT id_authorization_role FROM `' . _DB_PREFIX_ . 'authorization_role` WHERE slug = "' . pSQL($slug) . '"'
                );
                if ($id_role <= 0) {
                    continue;
                }
                foreach ($profiles as $p) {
                    $db->execute(
                        'INSERT IGNORE INTO `' . _DB_PREFIX_ . 'module_access` (id_profile, id_authorization_role) VALUES ('
                        . (int) $p['id_profile'] . ', ' . $id_role . ')'
                    );
                }
            }
        } catch (\Throwable $e) {
            if (class_exists('IntigoLog')) {
                IntigoLog::add('grant_module_access_error', $e->getMessage());
            }
        }
    }

    /**
     * Create the "Accès" admin tab if it's missing (installs from before this
     * page existed). PrestaShop auto-grants the SuperAdmin profile on add(), and
     * we deliberately do NOT grant it to other profiles — managing permissions
     * stays admin-only.
     */
    public function ensureAccessTab()
    {
        try {
            if ((int) Tab::getIdFromClassName('AdminIntigoAccess') > 0) {
                return;
            }
            $id_parent = (int) Tab::getIdFromClassName('AdminIntigoParent');
            if ($id_parent <= 0) {
                return;
            }
            $tab = new Tab();
            $tab->class_name = 'AdminIntigoAccess';
            $tab->module = $this->name;
            $tab->id_parent = $id_parent;
            $tab->active = 1;
            foreach (Language::getLanguages(true) as $lang) {
                $tab->name[$lang['id_lang']] = 'Accès';
            }
            $tab->add();
        } catch (\Throwable $e) {
            if (class_exists('IntigoLog')) {
                IntigoLog::add('ensure_access_tab_error', $e->getMessage());
            }
        }
    }

    /**
     * Ensure EVERY Intigo submenu tab exists. Critical for installs upgraded in
     * place: when a new page (e.g. "Adresses de ramassage" / AdminIntigoPickup)
     * ships in a release whose version the shop already has, PrestaShop runs no
     * upgrade script, so the tab is never created — and a legacy controller with
     * no tab has no authorization role, so the page is inaccessible *even to
     * SuperAdmin* and the module surfaces only under "Configure". This self-heals
     * that: cheap existence checks, and only when a tab is genuinely missing does
     * it create it and (re)grant access (a new tab's roles otherwise reach only
     * SuperAdmin). Idempotent and fully guarded — never breaks a BO page.
     */
    public function ensureTabs()
    {
        try {
            $id_parent = (int) Tab::getIdFromClassName('AdminIntigoParent');
            if ($id_parent <= 0) {
                // The whole Intigo tab tree is missing — rebuild it (also grants).
                $this->installTabs();
                return;
            }
            $children = [
                ['AdminIntigoDashboard', 'Dashboard', true],
                ['AdminIntigoOrders', 'Orders', true],
                ['AdminIntigoPickup', 'Pickup addresses', true],
                ['AdminIntigoProductSizes', 'Product Sizes', true],
                ['AdminIntigoLogs', 'Logs', true],
                ['AdminIntigoSettings', 'Settings', true],
                ['AdminIntigoAccess', 'Accès', true],
                ['AdminIntigoDocs', 'Docs', true],
                ['AdminIntigoOrderAction', '', false],
            ];
            $created = false;
            foreach ($children as $row) {
                if ((int) Tab::getIdFromClassName($row[0]) > 0) {
                    continue;
                }
                $tab = new Tab();
                $tab->class_name = $row[0];
                $tab->module = $this->name;
                $tab->id_parent = $id_parent;
                $tab->active = (bool) $row[2] ? 1 : 0;
                foreach (Language::getLanguages(true) as $lang) {
                    $tab->name[$lang['id_lang']] = $row[1] !== '' ? $row[1] : $row[0];
                }
                $tab->add();
                $created = true;
            }
            if ($created) {
                // A freshly added tab grants only SuperAdmin by default — re-grant
                // so every profile reaches it, exactly like a clean install.
                $this->grantTabAccess();
                $this->grantModuleAccess();
            }
        } catch (\Throwable $e) {
            if (class_exists('IntigoLog')) {
                IntigoLog::add('ensure_tabs_error', $e->getMessage());
            }
        }
    }

    private function uninstallTabs()
    {
        $class_names = [
            'AdminIntigoDashboard',
            'AdminIntigoOrders',
            'AdminIntigoPickup',
            'AdminIntigoProductSizes',
            'AdminIntigoLogs',
            'AdminIntigoSettings',
            'AdminIntigoAccess',
            'AdminIntigoDocs',
            'AdminIntigoOrderAction',
            'AdminIntigoParent',
        ];
        foreach ($class_names as $cn) {
            $id = (int) Tab::getIdFromClassName($cn);
            if ($id) {
                $tab = new Tab($id);
                $tab->delete();
            }
        }
        return true;
    }

    /* -------------------- Configuration entry point -------------------- */

    /**
     * Module Manager "Configure" button lands here. We redirect into the proper
     * AdminIntigoSettings controller so the URL is bookmark-friendly and matches
     * the tab the user can reach from the menu.
     */
    public function getContent()
    {
        $url = $this->context->link->getAdminLink('AdminIntigoSettings');
        Tools::redirectAdmin($url);
        return ''; // unreachable
    }

    /**
     * The module is "configured" once it has an API key. Until then, every hook
     * must do nothing rather than attempt API calls or risky rendering. (We
     * derive the API base URL from INTIGO_ENVIRONMENT, so the key is the single
     * meaningful readiness signal.)
     */
    private function isConfigured()
    {
        return trim((string) Configuration::get('INTIGO_API_KEY')) !== '';
    }

    /* -------------------- Carrier pricing (size-based) -------------------- */
    // PrestaShop calls one of these on the module for the Intigo carrier (which
    // branch depends on need_range — see Cart::getPackageShippingCostFromModule).
    // We implement all three; each returns the price for the cart's resolved
    // package size. They must ALWAYS return a number — never throw — or checkout
    // breaks. The cost is tax-excluded; PrestaShop applies the carrier tax group.

    public function getPackageShippingCost($cart, $shipping_cost = 0, $products = [])
    {
        return $this->computeShippingCost($cart);
    }

    public function getOrderShippingCost($cart, $shipping_cost = 0)
    {
        return $this->computeShippingCost($cart);
    }

    public function getOrderShippingCostExternal($cart)
    {
        return $this->computeShippingCost($cart);
    }

    /**
     * Resolve the cart's package size (per-product size → max across the cart →
     * default from Settings) and return the merchant's configured price for it.
     */
    private function computeShippingCost($cart)
    {
        try {
            $size = ($cart instanceof Cart)
                ? IntigoSizeResolver::resolveForCart($cart)
                : IntigoSizeResolver::pluginDefault();
            $map = [
                'S' => (float) Configuration::get('INTIGO_PRICE_S'),
                'M' => (float) Configuration::get('INTIGO_PRICE_M'),
                'L' => (float) Configuration::get('INTIGO_PRICE_L'),
                'XL' => (float) Configuration::get('INTIGO_PRICE_XL'),
            ];
            return isset($map[$size]) ? $map[$size] : (float) Configuration::get('INTIGO_PRICE_S');
        } catch (\Throwable $e) {
            if (class_exists('IntigoLog')) {
                IntigoLog::add('shipping_cost_error', $e->getMessage());
            }
            // Safe fallback so checkout never breaks; merchant can fix prices.
            return (float) Configuration::get('INTIGO_PRICE_S');
        }
    }

    /* -------------------- Phase 1 hook stubs -------------------- */
    // Real hook bodies land in their respective phases. Defined here so install
    // succeeds and PrestaShop doesn't whine about missing hook handlers.

    public function hookActionAdminControllerSetMedia()
    {
        try {
            // Enqueue admin order JS/CSS on the order detail page so the editable
            // Intigo side panel has cascading-dropdown behavior.
            $ctrl = isset($this->context->controller) ? $this->context->controller : null;
            $ctrl_name = is_object($ctrl) ? get_class($ctrl) : '';
            if (strpos($ctrl_name, 'AdminOrders') !== false || $ctrl_name === 'AdminOrdersController') {
                $this->context->controller->addCSS($this->_path . 'views/css/admin-order.css?v=' . $this->assetVersion('views/css/admin-order.css'), 'all', null, false);
                $this->context->controller->addJS($this->_path . 'views/js/admin-order.js?v=' . $this->assetVersion('views/js/admin-order.js'), false);
            }
            // Our own legacy admin screens reuse the Shopify-style cosmetic layer.
            if (strpos($ctrl_name, 'AdminIntigo') !== false) {
                $this->context->controller->addCSS($this->_path . 'views/css/intigo-admin.css?v=' . $this->assetVersion('views/css/intigo-admin.css'), 'all', null, false);
            }
        } catch (\Throwable $e) {
            // Asset registration must never break an admin page.
        }
    }

    /**
     * Injects a red "new orders" badge onto the Intigo parent menu item — the
     * count of Intigo-carrier orders not yet sent (no parcel NID). Done via a
     * tiny script so it works on every PS version's BO menu, and never touches
     * a core page if anything is off (try/catch + isConfigured gate).
     */
    public function hookDisplayBackOfficeHeader()
    {
        try {
            // Self-heal: grant all profiles access to the Intigo pages once (covers
            // installs that pre-date this fix, where only SuperAdmin had access).
            // Guarded by a flag so it runs a single time and never overrides a
            // merchant's later permission edits.
            // V1: first-time tab-access grant (only when never run — never re-grants,
            // so it can't undo the merchant's "Accès" restrictions).
            if (Configuration::get('INTIGO_TAB_ACCESS_V1') !== '1') {
                $this->grantTabAccess();
                Configuration::updateValue('INTIGO_TAB_ACCESS_V1', '1');
            }
            // V2: grant MODULE access (the piece V1 missed → hooks/CSS were skipped
            // for non-SuperAdmin profiles). Coarse + idempotent; does NOT touch tab
            // access, so restrictions stay intact. Re-runs once for everyone.
            if (Configuration::get('INTIGO_TAB_ACCESS_V2') !== '1') {
                $this->grantModuleAccess();
                Configuration::updateValue('INTIGO_TAB_ACCESS_V2', '1');
            }
            // Ensure the "Accès" page exists on installs that pre-date it (one
            // cheap lookup; only inserts when truly missing). SuperAdmin-only.
            $this->ensureAccessTab();
            // Ensure ALL Intigo submenu tabs exist — covers in-place upgrades where
            // a new page (e.g. "Adresses de ramassage") shipped under a version the
            // shop already had, so no upgrade script ran and the tab/role were never
            // created (page inaccessible even to SuperAdmin). Cheap + idempotent.
            $this->ensureTabs();
            // One-time: create the pickup-map table + seed its config defaults for
            // installs that jumped past the 1.1.0 upgrade. Guarded so it runs once.
            if (Configuration::get('INTIGO_TABS_V3') !== '1') {
                @include dirname(__FILE__) . '/sql/install.php';
                $pickup_defaults = [
                    'INTIGO_DEFAULT_PICKUP_INDEX' => '',
                    'INTIGO_PICKUP_AS_TRIGGER' => '0',
                    'INTIGO_PICKUP_CACHE' => '',
                    'INTIGO_PICKUP_CACHE_TS' => '0',
                ];
                foreach ($pickup_defaults as $k => $v) {
                    if (Configuration::get($k) === false) {
                        Configuration::updateValue($k, $v);
                    }
                }
                Configuration::updateValue('INTIGO_TABS_V3', '1');
            }

            // Material icon per Intigo submenu item (the BO sidebar theme doesn't
            // render level-two tab icons, so we inject them — same approach as the
            // badge). Keyed by the menu <li> id.
            $icons = json_encode([
                'subtab-AdminIntigoDashboard' => 'dashboard',
                'subtab-AdminIntigoOrders' => 'local_shipping',
                'subtab-AdminIntigoPickup' => 'place',
                'subtab-AdminIntigoProductSizes' => 'straighten',
                'subtab-AdminIntigoLogs' => 'receipt',
                'subtab-AdminIntigoSettings' => 'settings',
                'subtab-AdminIntigoAccess' => 'admin_panel_settings',
                'subtab-AdminIntigoDocs' => 'menu_book',
            ]);
            // Single digit, capped at 9 — keeps the badge a perfect circle.
            $count = $this->isConfigured() ? $this->countNewOrders() : 0;
            $badge = $count > 0 ? json_encode((string) min($count, 9)) : 'null';

            return
                // Self-contained Material Icons font, loaded on EVERY BO page so our
                // icons + sidebar icons render even on PrestaShop versions (1.7.8.0)
                // whose BO doesn't provide the font on legacy module pages.
                '<link rel="stylesheet" href="' . $this->_path . 'views/css/intigo-icons.css?v='
                . $this->assetVersion('views/css/intigo-icons.css') . '">'
                . '<style>'
                // width/height + padding forced (PrestaShop's sidebar adds a
                // padding-left to menu spans, which turned the circle into an oval).
                . '.intigo-menu-badge{display:inline-flex!important;align-items:center;'
                . 'justify-content:center;box-sizing:border-box!important;width:18px!important;'
                . 'height:18px!important;min-width:18px!important;padding:0!important;margin-left:6px;'
                . 'border-radius:50%!important;background:#ef4444;color:#fff;font-size:11px;'
                . 'font-weight:700;line-height:1;flex:0 0 auto;box-shadow:0 1px 2px rgba(0,0,0,.2);}'
                . '.intigo-side-icon{font-size:18px;vertical-align:middle;margin-right:9px;opacity:.9;}'
                . '</style>'
                . '<script>(function(){var ICONS=' . $icons . ',BADGE=' . $badge . ','
                . 'BT=["subtab-AdminIntigoParent","subtab-AdminIntigoOrders"];function build(){'
                . 'Object.keys(ICONS).forEach(function(id){var li=document.getElementById(id);if(!li)return;'
                . 'var a=li.querySelector("a");if(!a||a.querySelector(".intigo-side-icon"))return;'
                . 'var i=document.createElement("i");i.className="material-icons intigo-side-icon";'
                . 'i.textContent=ICONS[id];a.insertBefore(i,a.firstChild);});'
                . 'if(BADGE!==null){BT.forEach(function(id){var li=document.getElementById(id);if(!li)return;'
                . 'var a=li.querySelector("a");if(!a||a.querySelector(".intigo-menu-badge"))return;'
                . 'var b=document.createElement("span");b.className="intigo-menu-badge";'
                . 'b.textContent=BADGE;b.title="Commandes à envoyer à Intigo";a.appendChild(b);});}}'
                . 'if(document.readyState==="loading"){document.addEventListener("DOMContentLoaded",build);}'
                . 'else{build();}})();</script>';
        } catch (\Throwable $e) {
            return '';
        }
    }

    /**
     * Cache-busting version for an asset = its file mtime (falls back to the
     * module version). Ensures the browser always picks up CSS/JS edits without
     * relying on PrestaShop's media cache, and busts on every deploy.
     */
    private function assetVersion($relative_path)
    {
        $mtime = @filemtime(__DIR__ . '/' . ltrim($relative_path, '/'));
        return $mtime ? (string) $mtime : $this->version;
    }

    /**
     * Count of orders on the Intigo carrier that still have no parcel NID — the
     * "to send" backlog surfaced as the menu badge. Never throws.
     */
    private function countNewOrders()
    {
        try {
            $pfx = _DB_PREFIX_;
            // Carrier-AGNOSTIC: merchants ship ANY order via Intigo, not only
            // Intigo-carrier ones (that filter made the badge always 0 for shops
            // that don't use the Intigo carrier). Match the Intigo Orders list
            // scope — orders whose status is mapped to an Intigo pickup (their
            // "Intigo orders"), or all orders if nothing is mapped yet — and count
            // those not yet sent (no NID).
            $id_shop = 1;
            if (class_exists('Context')) {
                $ctx = Context::getContext();
                if ($ctx && isset($ctx->shop) && (int) $ctx->shop->id > 0) {
                    $id_shop = (int) $ctx->shop->id;
                }
            }
            $states = class_exists('IntigoPickupMap')
                ? array_filter(array_map('intval', (array) IntigoPickupMap::mappedStates($id_shop)))
                : [];
            $scope = !empty($states) ? 'o.current_state IN (' . implode(',', $states) . ')' : '1';
            return (int) Db::getInstance()->getValue(
                'SELECT COUNT(*) FROM `' . $pfx . 'orders` o
                 LEFT JOIN `' . $pfx . 'intigo_parcel` p ON p.id_order = o.id_order
                 WHERE (' . $scope . ')
                   AND (p.id_order IS NULL OR p.nid = "" OR p.nid IS NULL)'
            );
        } catch (\Throwable $e) {
            return 0;
        }
    }

    /**
     * Fires once when an order is created. We:
     *   1. Snapshot the PS shipping address onto a new ps_intigo_parcel row
     *      (best-effort: try to resolve city_id from address.city via API).
     *   2. If auto mode is ON, attempt to push. Push will fail if required
     *      fields can't be resolved — the merchant fixes those in the BO and
     *      clicks "Send to Intigo" manually.
     */
    public function hookActionValidateOrder($params)
    {
        // This hook runs during customer checkout — it must NEVER throw (that
        // would break order creation) and must NEVER make a blocking network
        // call. Everything is wrapped and the API is only touched when the
        // merchant has configured the module.
        try {
            if (!$this->isConfigured()) {
                return;
            }
            $order = isset($params['order']) ? $params['order'] : null;
            if (!($order instanceof Order)) {
                return;
            }
            $intigo_carrier_id = (int) Configuration::get('INTIGO_CARRIER_ID');
            if ((int) $order->id_carrier !== $intigo_carrier_id) {
                return;
            }

            // Snapshot PS address onto a parcel row (no NID yet). Pass
            // resolveViaApi=false so we do NOT call the Intigo API synchronously
            // during checkout — the merchant resolves city/district in the BO.
            $svc = new IntigoOrderService();
            $payload = $svc->orderToPayload($order, false);
            $parcel = IntigoParcel::findByOrderId((int) $order->id) ?: new IntigoParcel();
            $parcel->id_order = (int) $order->id;
            $parcel->recipient_name = (string) $payload['recipient_name'];
            $parcel->recipient_phone = (string) $payload['phone1'];
            $parcel->destination_address = (string) $payload['destination_address'];
            $parcel->destination_city_id = (int) $payload['destination_city_id'];
            $parcel->destination_district_id = (int) $payload['destination_district_id'];
            $parcel->destination_neighborhood_id = isset($payload['destination_neighborhood_id'])
                ? (int) $payload['destination_neighborhood_id'] : 0;
            if (empty($parcel->package_size)) {
                $parcel->package_size = (int) $payload['package_size'];
            }
            $parcel->save();

            // Auto-push if enabled (pushParcel is itself idempotent + swallows
            // its own network errors — see IntigoOrderService). autoTriggered=true
            // → never ships without a Référence.
            if ((string) Configuration::get('INTIGO_AUTO_CREATE') === '1') {
                $svc->pushParcel($order, false, true);
            }
        } catch (\Throwable $e) {
            if (class_exists('IntigoLog')) {
                IntigoLog::add('validate_order_error', $e->getMessage());
            }
        }
    }

    public function hookActionOrderStatusPostUpdate($params)
    {
        try {
            if (!$this->isConfigured()) {
                return;
            }
            $auto_create = (string) Configuration::get('INTIGO_AUTO_CREATE') === '1';
            $pickup_trigger = (string) Configuration::get('INTIGO_PICKUP_AS_TRIGGER') === '1';
            // Neither push trigger is enabled → nothing to do.
            if (!$auto_create && !$pickup_trigger) {
                return;
            }
            $id_order = isset($params['id_order']) ? (int) $params['id_order'] : 0;
            $order = $id_order > 0 ? new Order($id_order) : null;
            if (!$order || !Validate::isLoadedObject($order)) {
                return;
            }
            if ((int) $order->id_carrier !== (int) Configuration::get('INTIGO_CARRIER_ID')) {
                return;
            }
            $parcel = IntigoParcel::findByOrderId((int) $order->id);
            if ($parcel && trim((string) $parcel->nid) !== '') {
                return; // already pushed — never duplicate
            }

            // "Status = push trigger" (opt-in): when the order reaches a status
            // that's mapped to a pickup address, push the parcel now. The matching
            // pickup_index is selected automatically by orderToPayload (§7), which
            // literally realizes "when I change the status, I know which pickup to
            // use". Gated to mapped statuses so unmapped transitions don't push.
            if ($pickup_trigger) {
                $id_shop = (int) $order->id_shop ?: 1;
                $new_state = isset($params['newOrderStatus']) && is_object($params['newOrderStatus'])
                    ? (int) $params['newOrderStatus']->id
                    : (int) $order->getCurrentState();
                if (IntigoPickupMap::resolvePickupIndex($id_shop, $new_state) !== null) {
                    $svc = new IntigoOrderService();
                    $svc->pushParcel($order, false, true);
                    return;
                }
            }

            // Safety-net: if auto mode is ON and the parcel still has no NID, try
            // once more. This handles flows where actionValidateOrder didn't fire
            // (e.g. manual order creation).
            if ($auto_create) {
                $svc = new IntigoOrderService();
                $svc->pushParcel($order, false, true);
            }
        } catch (\Throwable $e) {
            if (class_exists('IntigoLog')) {
                IntigoLog::add('order_status_update_error', $e->getMessage());
            }
        }
    }

    public function hookActionObjectOrderUpdateAfter($params)
    {
        try {
            if (!$this->isConfigured()) {
                return;
            }
            $order = isset($params['object']) ? $params['object'] : null;
            if (!($order instanceof Order)) {
                return;
            }
            $parcel = IntigoParcel::findByOrderId((int) $order->id);
            if (!$parcel || trim((string) $parcel->nid) === '' || (int) $parcel->sync_locked === 1) {
                return;
            }
            $svc = new IntigoOrderService();
            $svc->updateParcel($order); // best-effort, swallows result
        } catch (\Throwable $e) {
            if (class_exists('IntigoLog')) {
                IntigoLog::add('order_update_after_error', $e->getMessage());
            }
        }
    }

    public function hookDisplayAdminOrder($params)
    {
        // PS 1.7 fallback path — same content as the 8.x side hook.
        return $this->renderAdminOrderSide($params);
    }

    public function hookDisplayAdminOrderSide($params)
    {
        return $this->renderAdminOrderSide($params);
    }

    /**
     * Adds an "Intigo Parcel" tab to the order view's tab bar (next to
     * Status/Documents/Carriers). Only shown when the order's carrier is
     * Intigo Delivery.
     */
    public function hookDisplayAdminOrderTabLink($params)
    {
        // Retired: the parcel panel renders once in the order's left column via
        // hookDisplayAdminOrderSide. Keeping this as a no-op avoids a duplicate
        // tab and the old debug scaffolding. (See REBUILD_SPEC §5.3 / §10.)
        return '';
    }

    public function hookDisplayAdminOrderTabContent($params)
    {
        return '';
    }

    private function renderAdminOrderSide($params)
    {
        // Render the panel only once per request, even if several order-view
        // hooks fire (displayAdminOrder on 1.7, displayAdminOrderSide on 8/9).
        static $alreadyRendered = false;
        if ($alreadyRendered) {
            return '';
        }
        $alreadyRendered = true;

        // HARD GUARANTEE: this hook must NEVER break a core admin page. Any
        // failure is logged and swallowed; the order page renders without us.
        try {
            return $this->buildAdminOrderSide($params);
        } catch (\Throwable $e) {
            if (class_exists('IntigoLog')) {
                IntigoLog::add('side_hook_error', $e->getMessage());
            }
            return '';
        }
    }

    private function buildAdminOrderSide($params)
    {
        // Not configured yet → render a tiny, safe note and touch nothing else
        // (no Order/Address loads, no API). Matches "do nothing until configured".
        if (!$this->isConfigured()) {
            return '<div class="card mb-3"><div class="card-body"><p class="text-muted" style="margin:0;">'
                . 'Intigo isn\'t configured yet — add your API key in <strong>Intigo &rsaquo; Settings</strong> to manage parcels here.'
                . '</p></div></div>';
        }

        $id_order = isset($params['id_order']) ? (int) $params['id_order'] : 0;
        // PS 8.x sometimes passes the order object directly instead of id
        if ($id_order <= 0 && isset($params['order']) && is_object($params['order'])) {
            $id_order = (int) $params['order']->id;
        }
        if ($id_order <= 0) {
            return '<div class="alert alert-warning">Intigo: hook fired but no id_order in params</div>';
        }
        $order = new Order($id_order);
        if (!Validate::isLoadedObject($order)) {
            return '<div class="alert alert-warning">Intigo: hook fired but Order #' . $id_order . ' not loaded</div>';
        }
        $intigo_carrier_id = (int) Configuration::get('INTIGO_CARRIER_ID');
        $is_intigo = (int) $order->id_carrier === $intigo_carrier_id;

        $parcel = IntigoParcel::findByOrderId($id_order);

        // Build form values: parcel row > PS shipping address fallback.
        $form = [
            'recipient_name' => '',
            'recipient_phone' => '',
            'reference_id' => '',
            'destination_address' => '',
            'destination_city_id' => 0,
            'destination_district_id' => 0,
            'destination_neighborhood_id' => 0,
            'package_size' => 1,
        ];
        if ($parcel) {
            $form['recipient_name'] = (string) $parcel->recipient_name;
            $form['recipient_phone'] = (string) $parcel->recipient_phone;
            $form['reference_id'] = (string) $parcel->reference_id;
            $form['destination_address'] = (string) $parcel->destination_address;
            $form['destination_city_id'] = (int) $parcel->destination_city_id;
            $form['destination_district_id'] = (int) $parcel->destination_district_id;
            $form['destination_neighborhood_id'] = (int) $parcel->destination_neighborhood_id;
            $form['package_size'] = (int) $parcel->package_size ?: 1;
        }
        // Fallback to PS shipping address for empty fields — for ANY order, since
        // a merchant can ship any order via Intigo (not only Intigo-carrier ones).
        if ((int) $order->id_address_delivery > 0) {
            $addr = new Address((int) $order->id_address_delivery);
            if (Validate::isLoadedObject($addr)) {
                if ($form['recipient_name'] === '') {
                    $form['recipient_name'] = trim((string) $addr->firstname . ' ' . (string) $addr->lastname);
                }
                if ($form['recipient_phone'] === '') {
                    $form['recipient_phone'] = (string) ($addr->phone_mobile ?: $addr->phone);
                }
                if ($form['destination_address'] === '') {
                    $form['destination_address'] = trim((string) $addr->address1 . ' ' . (string) $addr->address2);
                }
            }
        }

        // Auto-detect the Intigo zone for orders that have an address but no
        // resolved city yet — typically PRE-EXISTING orders placed before Intigo
        // was set up (the merchant opens the native order page and the Ville /
        // Délégation are empty). The Intigo Orders list already does this; the
        // native order panel did not, so old orders showed "— choisir une ville —".
        // Best-effort + persisted by resolveAndStore(), so it runs once per order
        // (next view reads the stored ids), respects manual overrides, and is fully
        // guarded — a guesser hiccup never blocks the order page.
        // Run ONCE per order: skip if pushed, or if auto-detection already ran
        // (even if it found nothing). Without this, an unmatchable address — or an
        // unreachable guesser — would re-query (and possibly hang ~10s) on every
        // order view. A merchant can still re-detect from the Intigo Orders list.
        $already_pushed = $parcel && trim((string) $parcel->nid) !== '';
        $already_autodetected = $parcel && (int) $parcel->auto_resolved === 1;
        if (!$already_pushed
            && !$already_autodetected
            && (int) $form['destination_city_id'] <= 0
            && trim((string) $form['destination_address']) !== '') {
            try {
                $res = (new IntigoAddressResolver())->resolveAndStore($order);
                if (!empty($res['ok'])) {
                    if ((int) $form['destination_city_id'] <= 0 && (int) $res['city_id'] > 0) {
                        $form['destination_city_id'] = (int) $res['city_id'];
                    }
                    if ((int) $form['destination_district_id'] <= 0 && (int) $res['district_id'] > 0) {
                        $form['destination_district_id'] = (int) $res['district_id'];
                    }
                    if ((int) $form['destination_neighborhood_id'] <= 0 && (int) $res['neighborhood_id'] > 0) {
                        $form['destination_neighborhood_id'] = (int) $res['neighborhood_id'];
                    }
                }
            } catch (\Throwable $e) {
                if (class_exists('IntigoLog')) {
                    IntigoLog::add('order_side_autodetect_error', $e->getMessage());
                }
            }
        }

        // Push-gating: the merchant can always Save partial data, but "Send to
        // Intigo" is disabled until everything required by the API is present.
        $missing = [];
        if (trim((string) (isset($form['reference_id']) ? $form['reference_id'] : '')) === '') { $missing[] = 'référence'; }
        if (trim((string) $form['recipient_name']) === '') { $missing[] = 'recipient name'; }
        if (trim((string) $form['recipient_phone']) === '') { $missing[] = 'phone'; }
        if (trim((string) $form['destination_address']) === '') { $missing[] = 'address'; }
        if ((int) $form['destination_city_id'] <= 0) { $missing[] = 'city'; }
        if ((int) $form['destination_district_id'] <= 0) { $missing[] = 'district'; }

        $has_nid = $parcel && trim((string) $parcel->nid) !== '';

        $this->context->smarty->assign([
            'intigo_is_intigo_carrier' => $is_intigo,
            'intigo_order_id' => $id_order,
            'intigo_parcel' => $parcel,
            'intigo_has_nid' => $has_nid,
            // The order view is a Symfony controller on PS 8/9 (and 1.7.8), where
            // hookActionAdminControllerSetMedia doesn't match "AdminOrders" — so
            // we embed the panel's CSS/JS straight from the template to guarantee
            // they load on every version. Bumped query string busts the cache.
            'intigo_module_uri' => $this->_path,
            'intigo_asset_v' => max(
                (int) $this->assetVersion('views/css/admin-order.css'),
                (int) $this->assetVersion('views/js/admin-order.js')
            ),
            // Flash notice after a panel action (save/send/update) — rendered as a
            // toast inside the panel since the native order view doesn't run our
            // IntigoAdminUi::noticeToast.
            'intigo_notice' => (string) Tools::getValue('intigo_notice'),
            'intigo_notice_type' => (string) Tools::getValue('intigo_notice_type'),
            'intigo_status_label' => $has_nid ? $this->intigoStatusLabel((int) $parcel->status_code) : '',
            'intigo_form' => $form,
            'intigo_sizes' => [1 => 'S', 2 => 'M', 4 => 'L', 5 => 'XL'],
            'intigo_missing' => implode(', ', $missing),
            'intigo_can_push' => empty($missing),
            'intigo_action_url' => $this->context->link->getAdminLink('AdminIntigoOrderAction'),
            'intigo_regions_url' => $this->context->link->getModuleLink(
                $this->name,
                'regions',
                ['action' => 'cities'],
                true
            ),
        ]);

        // Never let a template/render error take down the whole BO order page.
        try {
            $rendered = $this->display(__FILE__, 'displayAdminOrderSide.tpl');
        } catch (\Throwable $e) {
            IntigoLog::add('side_hook_render_error', $e->getMessage());
            return '<div class="card mb-3"><div class="card-body"><div class="alert alert-warning" style="margin:0;">'
                . '<strong>Intigo:</strong> the parcel panel couldn\'t render here. '
                . 'Manage this order from <strong>Intigo → Orders</strong> instead.</div></div></div>';
        }
        return $rendered;
    }

    /**
     * Human, French status label for an Intigo numeric status code (ranges from
     * the adapter contract — see REBUILD_SPEC §8). Kept simple and non-technical
     * so merchants read "Livré", not a code.
     */
    private function intigoStatusLabel($code)
    {
        $code = (int) $code;
        if ($code <= 0) {
            return 'Créé';
        }
        if ($code >= 1000 && $code < 2000) {
            return 'En attente de ramassage';
        }
        if ($code >= 2000 && $code < 4000) {
            return 'En transit';
        }
        if ($code === 4000) {
            return 'En cours de livraison';
        }
        if ($code === 5000) {
            return 'Livré';
        }
        if ($code >= 6000 && $code < 7000) {
            return 'Retour';
        }
        if ($code >= 9000) {
            return 'Annulé';
        }
        return 'En cours';
    }
}
