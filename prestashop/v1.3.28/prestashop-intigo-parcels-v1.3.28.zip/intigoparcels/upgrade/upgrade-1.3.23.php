<?php
/** Upgrade to 1.3.23 — dashboard "Petits faits" gains the busiest-day record and
 *  two daily averages (per active day, and overall pace). No schema change. */
if (!defined('_PS_VERSION_')) { exit; }
function upgrade_module_1_3_23($module)
{
    if (!(include dirname(__FILE__) . '/../sql/install.php')) { return false; }
    if (method_exists($module, 'ensureTabs')) { $module->ensureTabs(); }
    return true;
}
