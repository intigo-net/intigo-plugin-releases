<?php
/** Upgrade to 1.3.25 — the delivery address sent to Intigo now carries the postal
 *  code, city and country. Addresses still holding the old street-only value are
 *  upgraded on the fly; hand-edited addresses are left exactly as typed.
 *  No schema change. */
if (!defined('_PS_VERSION_')) { exit; }
function upgrade_module_1_3_25($module)
{
    if (!(include dirname(__FILE__) . '/../sql/install.php')) { return false; }
    if (method_exists($module, 'ensureTabs')) { $module->ensureTabs(); }
    return true;
}
