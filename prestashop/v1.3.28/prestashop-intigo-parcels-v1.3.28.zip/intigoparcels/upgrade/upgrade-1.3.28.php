<?php
/** Upgrade to 1.3.28 — the État (state) field is accepted as the governorate, zones
 *  are matched exactly against Intigo's own place list, and no parcel can be sent
 *  without a Ville AND a Délégation. No schema change. */
if (!defined('_PS_VERSION_')) { exit; }
function upgrade_module_1_3_28($module)
{
    if (!(include dirname(__FILE__) . '/../sql/install.php')) { return false; }
    if (method_exists($module, 'ensureTabs')) { $module->ensureTabs(); }

    // Unsent parcels that were auto-resolved keep a zone the OLD rules produced —
    // possibly one the fuzzy guesser invented outside the order's own governorate.
    // Clear those so the new exact matcher re-runs and either confirms the zone or
    // hands it to the merchant. Manual entries and already-sent parcels untouched.
    Db::getInstance()->execute(
        'UPDATE `' . _DB_PREFIX_ . 'intigo_parcel`
            SET destination_city_id = 0, destination_district_id = 0,
                destination_neighborhood_id = 0, destination_city_name = "",
                destination_district_name = "", auto_resolved = 0,
                resolution_status = "blocked"
          WHERE (nid IS NULL OR nid = "") AND resolution_source = "guesser"'
    );

    return true;
}
