<?php
/** Upgrade to 1.3.24 — the address guesser no longer invents a destination when
 *  nothing in the address corroborates a candidate. Clears the zones a previous
 *  (guessing) resolution stored on parcels NOT yet sent, so they are re-detected
 *  under the new rules instead of keeping a possibly wrong zone. Sent parcels and
 *  merchant-entered zones are left untouched. No schema change. */
if (!defined('_PS_VERSION_')) { exit; }
function upgrade_module_1_3_24($module)
{
    if (!(include dirname(__FILE__) . '/../sql/install.php')) { return false; }

    // Only guesser-owned, unsent, never-confirmed rows. `auto_resolved = 0` makes
    // the next order view re-run detection; cleared ids stop the old guess from
    // being sent in the meantime.
    Db::getInstance()->execute(
        'UPDATE `' . _DB_PREFIX_ . 'intigo_parcel`
            SET destination_city_id = 0,
                destination_district_id = 0,
                destination_neighborhood_id = 0,
                destination_city_name = "",
                destination_district_name = "",
                auto_resolved = 0,
                resolution_status = "blocked"
          WHERE (nid IS NULL OR nid = "")
            AND resolution_source = "guesser"
            AND resolution_status = "review"'
    );

    if (method_exists($module, 'ensureTabs')) { $module->ensureTabs(); }
    return true;
}
