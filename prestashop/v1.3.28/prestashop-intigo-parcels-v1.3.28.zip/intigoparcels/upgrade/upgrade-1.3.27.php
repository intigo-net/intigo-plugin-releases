<?php
/** Upgrade to 1.3.27 — "Re-détecter" now reports the truth: the detected zone, or
 *  that the zone is NOT confirmed. No schema change. */
if (!defined('_PS_VERSION_')) { exit; }
function upgrade_module_1_3_27($module)
{
    if (!(include dirname(__FILE__) . '/../sql/install.php')) { return false; }
    if (method_exists($module, 'ensureTabs')) { $module->ensureTabs(); }
    return true;
}
