<?php
/** Upgrade to 1.3.26 — a delivery address saved without a city no longer blocks:
 *  the city is taken from the order's invoice address. No schema change. */
if (!defined('_PS_VERSION_')) { exit; }
function upgrade_module_1_3_26($module)
{
    if (!(include dirname(__FILE__) . '/../sql/install.php')) { return false; }
    if (method_exists($module, 'ensureTabs')) { $module->ensureTabs(); }
    return true;
}
