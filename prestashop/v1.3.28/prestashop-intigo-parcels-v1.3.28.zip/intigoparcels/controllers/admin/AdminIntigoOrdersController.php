<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

require_once dirname(__FILE__) . '/../../classes/IntigoAutoload.php';

/**
 * Intigo Orders — central list of every order that used the Intigo Delivery
 * carrier, with parcel status and inline actions, PLUS a dedicated edit page
 * (?a=edit&id_order=X) for setting city/district/neighborhood/phone/etc.
 *
 * Lives entirely inside our own controller so it renders 100% reliably,
 * unlike the BO order view's side/tab hooks which PS 8.x sometimes drops.
 */
class AdminIntigoOrdersController extends ModuleAdminController
{
    const PER_PAGE = 25;

    public function __construct()
    {
        $this->bootstrap = true;
        $this->display = 'view';
        parent::__construct();
        $this->meta_title = 'Intigo — Manage Orders';
        $this->show_page_header_toolbar = false;
    }

    const RESOLVE_BATCH = 20;
    const AUTO_RESOLVE_ON_VIEW = 4;

    public function initContent()
    {
        $action = (string) Tools::getValue('a');
        if ($action === 'edit') {
            $this->renderEditPage();
        } elseif ($action === 'resolve') {
            $this->handleResolveBatch(); // auto-detect addresses, then redirect
        } elseif ($action === 'redetect') {
            $this->handleRedetect(); // force re-detect ONE order's address, then back to edit
        } else {
            $this->renderListPage();
        }
        parent::initContent();
    }

    /**
     * Force a fresh address auto-detection for a single order (merchant clicked
     * "Re-détecter" on the edit page — e.g. to re-run detection after an accuracy
     * improvement, or because the first guess was off), then return to the edit
     * page showing the new zone. Never touches an already-sent parcel.
     */
    private function handleRedetect()
    {
        require_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoZoneIndex.php';
        require_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoAddressResolver.php';
        $id_order = (int) Tools::getValue('id_order');
        $order = new Order($id_order);
        $msg = 'Adresse re-détectée.';
        $type = 'success';
        if (!Validate::isLoadedObject($order)) {
            $msg = 'Commande introuvable';
            $type = 'error';
        } else {
            try {
                $res = (new IntigoAddressResolver())->resolveAndStore($order, true);
                $tier = isset($res['tier']) ? $res['tier'] : '';
                if (!empty($res['skipped']) && $tier === 'sent') {
                    $msg = 'Colis déjà envoyé — l\'adresse ne peut plus être re-détectée.';
                    $type = 'warning';
                } elseif ($tier === 'blocked' || empty($res['ok'])) {
                    // Never say "re-détectée" when detection REFUSED — that reads as
                    // success and leaves the merchant staring at an empty Ville.
                    $msg = 'Zone non confirmée — choisissez la ville et la délégation '
                        . 'ci-dessous, puis enregistrez. L\'envoi reste bloqué tant que '
                        . 'la zone n\'est pas renseignée.';
                    $type = 'warning';
                } else {
                    $msg = 'Zone détectée : ' . (string) $res['city_name']
                        . ' / ' . (string) $res['district_name']
                        . '. Vérifiez-la avant d\'envoyer.';
                }
            } catch (\Throwable $e) {
                $msg = 'Échec de la re-détection';
                $type = 'error';
            }
        }
        Tools::redirectAdmin(self::$currentIndex . '&token=' . $this->token
            . '&a=edit&id_order=' . $id_order
            . '&intigo_notice=' . urlencode($msg) . '&intigo_notice_type=' . $type);
    }

    /**
     * Auto-detect Intigo zones for a bounded batch of not-yet-resolved, not-yet-
     * sent orders (free-text → city/district via the guesser), then redirect back.
     * Bounded so the request never runs away; the merchant re-clicks to clear more.
     */
    private function handleResolveBatch()
    {
        @set_time_limit(120);
        $resolver = new IntigoAddressResolver();
        $rows = Db::getInstance()->executeS(
            'SELECT o.id_order FROM `' . _DB_PREFIX_ . 'orders` o
             LEFT JOIN `' . _DB_PREFIX_ . 'intigo_parcel` p ON o.id_order = p.id_order
             WHERE (p.nid IS NULL OR p.nid = "")
               AND (p.resolution_status IS NULL OR p.resolution_status IN ("", "pending"))
             ORDER BY o.id_order DESC
             LIMIT ' . self::RESOLVE_BATCH
        );
        $n = 0;
        foreach ((array) $rows as $r) {
            try {
                $order = new Order((int) $r['id_order']);
                if (Validate::isLoadedObject($order)) {
                    $resolver->resolveAndStore($order);
                    $n++;
                }
            } catch (Exception $e) {
                IntigoLog::add('resolve_batch_error', $e->getMessage());
            } catch (\Throwable $e) {
                IntigoLog::add('resolve_batch_error', $e->getMessage());
            }
        }
        $f = (string) Tools::getValue('f');
        Tools::redirectAdmin(
            self::$currentIndex . '&token=' . $this->token
            . ($f !== '' ? '&f=' . $f : '')
            . '&intigo_notice=' . rawurlencode($n . ' adresse(s) analysée(s)')
            . '&intigo_notice_type=success'
        );
    }

    /**
     * Silently auto-detect addresses for a small bounded batch of not-yet-resolved
     * orders when the list is viewed — makes resolution feel automatic without a
     * "Détecter" click. Soft time budget so a slow guesser never hangs the page.
     */
    private function autoResolveLazy($limit)
    {
        if (trim((string) Configuration::get('INTIGO_API_KEY')) === '') {
            return;
        }
        try {
            $rows = Db::getInstance()->executeS(
                'SELECT o.id_order FROM `' . _DB_PREFIX_ . 'orders` o
                 LEFT JOIN `' . _DB_PREFIX_ . 'intigo_parcel` p ON o.id_order = p.id_order
                 WHERE (p.nid IS NULL OR p.nid = "")
                   AND (p.resolution_status IS NULL OR p.resolution_status IN ("", "pending"))
                 ORDER BY o.id_order DESC LIMIT ' . (int) $limit
            );
            if (empty($rows)) {
                return;
            }
            $resolver = new IntigoAddressResolver();
            $start = microtime(true);
            foreach ($rows as $r) {
                if (microtime(true) - $start > 6.0) {
                    break; // soft budget — remaining ones resolve on the next visit
                }
                $order = new Order((int) $r['id_order']);
                if (Validate::isLoadedObject($order)) {
                    $resolver->resolveAndStore($order);
                }
            }
        } catch (\Throwable $e) {
            IntigoLog::add('auto_resolve_error', $e->getMessage());
        }
    }

    /* ---------------- LIST view ---------------- */

    private function renderListPage()
    {
        require_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoStatus.php';
        $intigo_carrier_id = (int) Configuration::get('INTIGO_CARRIER_ID');
        $has_api_key = trim((string) Configuration::get('INTIGO_API_KEY')) !== '';
        $page = max(1, (int) Tools::getValue('p', 1));
        // Whitelist the filter: it's interpolated into tab/link hrefs and the
        // pickup-select base URL, so an unknown value would be a reflected-XSS
        // vector. Anything off-list falls back to "all".
        $filter = (string) Tools::getValue('f', '');
        if (!in_array($filter, ['', 'ready', 'review', 'pending', 'synced', 'failed', 'intigo'], true)) {
            $filter = '';
        }

        // Auto-detect addresses for the few most-recent not-yet-analysed orders on
        // each visit, so a new order already shows its Intigo zone without the
        // merchant clicking "Détecter". Bounded + time-budgeted (never hangs); the
        // network call lives here in the BO, never in customer checkout.
        $this->autoResolveLazy(self::AUTO_RESOLVE_ON_VIEW);

        // Scope to "Intigo" orders only. The merchant works with several couriers
        // and assigns each a different set of order statuses; the statuses they
        // mapped to an Intigo pickup address ARE their Intigo orders. So this list
        // shows ONLY orders whose current status is one of those mapped statuses.
        // When nothing is mapped yet, fall back to all (so initial setup isn't a
        // blank page).
        // ...PLUS any order already sent to Intigo (parcel has a NID). Once shipped,
        // an order stays an Intigo order forever — even after the webhook moves its
        // PrestaShop status to a delivery status that ISN'T pickup-mapped (e.g.
        // "en cours de livraison"). Without this, the webhook status-sync would make
        // sent orders vanish from the list and the merchant would lose track of them.
        // The pickup-status mapping still governs which NEW (unsent) orders appear.
        $id_shop = (int) $this->context->shop->id ?: 1;
        $mapped_states = $this->mappedStatesForExistingPickups($id_shop);
        $state_restrict = !empty($mapped_states)
            ? '(o.current_state IN (' . implode(',', array_map('intval', $mapped_states)) . ')'
                . ' OR (p.nid IS NOT NULL AND p.nid <> ""))'
            : '1';

        $where = '1';
        if ($filter === 'ready') {
            // Address auto-resolved with high confidence, not yet sent → bulk lane.
            $where = '(p.nid IS NULL OR p.nid = "") AND p.resolution_status = "resolved"';
        } elseif ($filter === 'review') {
            // Resolved-but-unsure or no match → needs a human glance / fix.
            $where = '(p.nid IS NULL OR p.nid = "") AND p.resolution_status IN ("review", "blocked")';
        } elseif ($filter === 'pending') {
            $where = '(p.nid IS NULL OR p.nid = "")';
        } elseif ($filter === 'synced') {
            $where = 'p.nid IS NOT NULL AND p.nid <> ""';
        } elseif ($filter === 'failed') {
            $where = 'p.last_error IS NOT NULL AND p.last_error <> "" AND (p.nid IS NULL OR p.nid = "")';
        } elseif ($filter === 'intigo') {
            $where = 'o.id_carrier = ' . $intigo_carrier_id;
        }

        // Status filter: the merchant filters by the configured ORDER STATUS (each
        // courier uses different statuses). Only the mapped "Intigo" statuses are
        // accepted — an off-scope value is ignored (also blocks SQL injection).
        $st = (string) Tools::getValue('st', '');
        if ($st !== '' && in_array((int) $st, $mapped_states, true)) {
            $where .= ' AND o.current_state = ' . (int) $st;
        } else {
            $st = '';
        }

        // Date-range filter on the order date — applied only when the merchant
        // submits the "Appliquer" form (it's a plain GET, nothing runs until then).
        // Strict Y-m-d validation also blocks SQL injection.
        $date_from = (string) Tools::getValue('date_from', '');
        $date_to = (string) Tools::getValue('date_to', '');
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date_from)) {
            $date_from = '';
        }
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date_to)) {
            $date_to = '';
        }
        $date_sql = '';
        if ($date_from !== '') {
            $date_sql .= ' AND o.date_add >= "' . pSQL($date_from) . ' 00:00:00"';
        }
        if ($date_to !== '') {
            $date_sql .= ' AND o.date_add <= "' . pSQL($date_to) . ' 23:59:59"';
        }
        $where .= $date_sql;
        // Query-string suffix so tabs / status / pagination keep the date filter.
        $date_qs = ($date_from !== '' ? '&date_from=' . $date_from : '')
            . ($date_to !== '' ? '&date_to=' . $date_to : '');

        // Apply the Intigo-status scope on top of whatever the tabs/pickup built.
        $where = '(' . $where . ') AND (' . $state_restrict . ')';

        // Counts for the tabs — scoped to the same Intigo statuses AND date range.
        $cnt = function ($w) use ($state_restrict, $date_sql) {
            return (int) Db::getInstance()->getValue(
                'SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'orders` o
                 LEFT JOIN `' . _DB_PREFIX_ . 'intigo_parcel` p ON o.id_order = p.id_order
                 WHERE (' . $w . ') AND (' . $state_restrict . ')' . $date_sql
            );
        };
        $count_ready = $cnt('(p.nid IS NULL OR p.nid = "") AND p.resolution_status = "resolved"');
        $count_review = $cnt('(p.nid IS NULL OR p.nid = "") AND p.resolution_status IN ("review", "blocked")');
        $count_unresolved = $cnt('(p.nid IS NULL OR p.nid = "") AND (p.resolution_status IS NULL OR p.resolution_status IN ("", "pending"))');

        $orders_in_shop = (int) Db::getInstance()->getValue(
            'SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'orders`'
        );
        $total = (int) Db::getInstance()->getValue(
            'SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'orders` o
            LEFT JOIN `' . _DB_PREFIX_ . 'intigo_parcel` p ON o.id_order = p.id_order
            WHERE ' . $where
        );
        $pages = max(1, (int) ceil($total / self::PER_PAGE));
        $offset = ($page - 1) * self::PER_PAGE;

        $rows = Db::getInstance()->executeS(
            'SELECT o.id_order, o.reference, o.total_paid_tax_incl, o.date_add, o.id_carrier,
                    a.firstname, a.lastname, a.city, a.postcode,
                    c.name AS carrier_name,
                    p.nid, p.status_code, p.last_attempt_at, p.last_error, p.bordereau_url,
                    p.destination_city_id, p.destination_district_id,
                    p.destination_city_name, p.destination_district_name,
                    p.resolution_status, p.resolution_confidence, p.reference_id
             FROM `' . _DB_PREFIX_ . 'orders` o
             LEFT JOIN `' . _DB_PREFIX_ . 'intigo_parcel` p ON o.id_order = p.id_order
             LEFT JOIN `' . _DB_PREFIX_ . 'address` a ON o.id_address_delivery = a.id_address
             LEFT JOIN `' . _DB_PREFIX_ . 'carrier` c ON o.id_carrier = c.id_carrier
             WHERE ' . $where . '
             ORDER BY o.id_order DESC
             LIMIT ' . self::PER_PAGE . ' OFFSET ' . $offset
        );
        $rows = is_array($rows) ? $rows : [];

        $base_url = self::$currentIndex . '&token=' . $this->token;
        $action_url = $this->context->link->getAdminLink('AdminIntigoOrderAction');
        $settings_url = $this->context->link->getAdminLink('AdminIntigoSettings');

        $notice = (string) Tools::getValue('intigo_notice');
        $notice_type = (string) Tools::getValue('intigo_notice_type');
        $alert_class = $notice_type === 'success' ? 'success'
            : ($notice_type === 'error' ? 'danger'
            : ($notice_type === 'warning' ? 'warning' : 'info'));

        $h = '<div class="intigo-screen">';
        $h .= IntigoAdminUi::navHtml($this->context->link, 'orders');

        $h .= IntigoAdminUi::noticeToast();
        // Only render the bordereau link when it's a real http(s) URL — htmlspecialchars
        // alone wouldn't stop a "javascript:" scheme injected via the query string.
        $notice_bordereau = (string) Tools::getValue('intigo_bordereau_url');
        if ($notice_bordereau !== '' && preg_match('#^https?://#i', $notice_bordereau)) {
            $h .= '<div class="alert alert-success" style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">'
                . '<i class="material-icons">picture_as_pdf</i><strong>' . IntigoAdminUi::t('Bordereau ready.') . '</strong>'
                . '<a href="' . htmlspecialchars($notice_bordereau) . '" target="_blank" rel="noopener" class="btn btn-primary btn-sm">' . IntigoAdminUi::t('Open bordereau') . '</a>'
                . '<button type="button" class="btn btn-default btn-sm intigo-copy" data-copy="' . htmlspecialchars($notice_bordereau) . '">' . IntigoAdminUi::t('Copy link') . '</button>'
                . '<span class="text-muted" style="word-break:break-all;font-size:12px;">' . htmlspecialchars($notice_bordereau) . '</span>'
                . '</div>';
        }
        if (!$has_api_key) {
            $h .= '<div class="alert alert-warning"><strong>' . IntigoAdminUi::t('API key required.') . '</strong> '
                . IntigoAdminUi::t('Add your Intigo API key before pushing parcels.') . ' '
                . '<a href="' . htmlspecialchars($settings_url) . '">' . IntigoAdminUi::t('Go to Settings') . '</a></div>';
        }

        // No orders in the whole shop yet → guide the merchant.
        if ($orders_in_shop === 0) {
            $h .= '<div class="card"><div class="card-body">';
            $h .= IntigoAdminUi::emptyState(
                'inbox',
                'No orders yet',
                'When customers place orders in your shop, they appear here so you can ship them with Intigo. '
                . 'Start by adding your API key, then create your first parcel from an order.',
                'Go to Settings',
                $settings_url
            );
            $h .= '</div></div></div>';
            $this->content = $h;
            return;
        }

        $h .= '<div class="card">';
        $h .= '<div class="card-header"><h3 class="card-header-title">'
            . '<i class="material-icons">local_shipping</i> ' . IntigoAdminUi::t('Orders') . ' (' . $total . ')</h3></div>';
        $h .= '<div class="card-body">';

        $tabs = [
            ['', 'Toutes', null],
            ['ready', 'Prêtes à envoyer', $count_ready],
            ['review', 'À vérifier', $count_review],
            ['pending', 'En attente', $count_unresolved],
            ['synced', 'Synchronisées', null],
            ['failed', 'Échec', null],
            ['intigo', 'Transporteur Intigo', null],
        ];
        // Mapped order statuses (the "Intigo" statuses) + their names, for the
        // inline status filter.
        $state_names = [];
        foreach ((array) OrderState::getOrderStates((int) $this->context->language->id) as $os) {
            $state_names[(int) $os['id_order_state']] = (string) $os['name'];
        }
        $base_qs = $base_url . ($filter !== '' ? '&f=' . $filter : '');

        $h .= '<div class="intigo-filterbar">';
        // One unified GET form: category (f) + status (st) + date range all apply
        // together (AND) only when the merchant clicks "Appliquer" — no control
        // navigates on its own anymore. Same GET param names as before, so old
        // bookmarks and pagination links still resolve identically.
        $h .= '<form method="get" class="intigo-filters" style="display:flex;gap:6px;flex-wrap:wrap;align-items:center;">';
        $h .= '<input type="hidden" name="controller" value="AdminIntigoOrders">';
        $h .= '<input type="hidden" name="token" value="' . htmlspecialchars($this->token) . '">';
        // Category filter — was tab links, now a <select> (live pill counts folded
        // into the option labels, e.g. "À vérifier (12)").
        $h .= '<select name="f" class="form-control input-sm" style="width:auto;height:31px;">';
        foreach ($tabs as $t) {
            $label = IntigoAdminUi::t($t[1]);
            if ($t[2] !== null && $t[2] > 0) {
                $label .= ' (' . (int) $t[2] . ')';
            }
            $sel = ($filter === $t[0]) ? ' selected' : '';
            $h .= '<option value="' . htmlspecialchars($t[0]) . '"' . $sel . '>' . $label . '</option>';
        }
        $h .= '</select>';
        // Status filter — plain state-id values, no auto-navigation. Server
        // whitelists st against $mapped_states, so the integer value is exactly
        // what it expects.
        if (!empty($mapped_states)) {
            $h .= '<select name="st" class="form-control input-sm" style="width:auto;height:31px;">'
                . '<option value="">🏷️ Tous les statuts</option>';
            foreach ($mapped_states as $sid) {
                $sid = (int) $sid;
                $name = isset($state_names[$sid]) ? $state_names[$sid] : ('Statut #' . $sid);
                $sel = ((string) $st === (string) $sid) ? ' selected' : '';
                $h .= '<option value="' . $sid . '"' . $sel . '>' . htmlspecialchars($name) . '</option>';
            }
            $h .= '</select>';
        }
        // Date range — part of the same form, so it applies together with f/st.
        $h .= '<span style="font-size:12px;color:#667085;">📅 Du</span>'
            . '<input type="date" name="date_from" value="' . htmlspecialchars($date_from) . '" class="form-control input-sm" style="width:auto;height:31px;">'
            . '<span style="font-size:12px;color:#667085;">au</span>'
            . '<input type="date" name="date_to" value="' . htmlspecialchars($date_to) . '" class="form-control input-sm" style="width:auto;height:31px;">';
        // Single apply + reset. Réinitialiser is an <a> (navigates to the unfiltered
        // list) not type="reset" (which would only clear inputs client-side).
        $h .= '<button type="submit" class="btn btn-sm btn-primary"><i class="material-icons" style="font-size:15px;vertical-align:middle;">filter_alt</i> Appliquer</button>';
        if ($filter !== '' || $st !== '' || $date_from !== '' || $date_to !== '') {
            $h .= '<a href="' . htmlspecialchars($base_url) . '" class="btn btn-sm btn-default">✕ Réinitialiser</a>';
        }
        $h .= '</form>';
        // Auto-detect button — OUTSIDE the filter form so it isn't swept into the GET
        // submit. Carries the active filters (f via $base_qs, plus st + dates) so
        // post-resolve returns to the same view.
        if ($has_api_key && $count_unresolved > 0) {
            $h .= '<a href="' . $base_qs . ($st !== '' ? '&st=' . $st : '') . $date_qs . '&a=resolve" class="btn btn-sm btn-default intigo-filterbar-right" '
                . 'title="Détecter automatiquement la ville/délégation depuis l\'adresse client">'
                . '<i class="material-icons" style="font-size:16px;vertical-align:middle;">auto_fix_high</i> '
                . 'Détecter les adresses (' . (int) $count_unresolved . ')</a>';
        }
        $h .= '</div>';

        // Bulk action bar (uses the HTML5 form= attribute so per-row forms below
        // don't need to nest). Submits the checked id_orders to a single batch.
        $h .= '<form id="intigobulk" method="post" action="' . htmlspecialchars($action_url) . '"></form>';
        $h .= '<div class="intigo-bulkbar" id="intigo-bulkbar" style="display:none;">'
            . '<span id="intigo-bulkcount">0</span> ' . 'commande(s) sélectionnée(s)'
            . ' <button type="submit" form="intigobulk" name="intigo_action" value="bulk_push" class="btn btn-success btn-sm" '
            . 'onclick="return intigoBulkConfirm(\'send\');">'
            . '<i class="material-icons" style="font-size:16px;vertical-align:middle;">send</i> Envoyer la sélection à Intigo</button>'
            . ' <button type="submit" form="intigobulk" name="intigo_action" value="bulk_bordereau" class="btn btn-default btn-sm" '
            . 'onclick="return intigoBulkConfirm(\'bordereau\');">'
            . '<i class="material-icons" style="font-size:16px;vertical-align:middle;">receipt_long</i> Générer les bordereaux</button>'
            . '</div>';

        // Orders exist but none match the active filter.
        if (empty($rows)) {
            $h .= IntigoAdminUi::emptyState(
                'filter_list',
                'No orders match this filter',
                'Essayez l\'onglet <strong>Toutes</strong> pour voir toutes les commandes.'
            );
            $h .= '</div></div></div>';
            $this->content = $h;
            return;
        }

        $h .= '<table class="table">';
        $h .= '<thead><tr>'
            . '<th style="width:28px;"><input type="checkbox" id="intigo-selall" title="Tout sélectionner"></th>'
            . '<th>#</th><th>' . IntigoAdminUi::t('Reference') . '</th><th>' . IntigoAdminUi::t('Customer') . '</th><th>' . IntigoAdminUi::t('City') . '</th>'
            . '<th>Zone Intigo détectée</th>'
            . '<th>' . IntigoAdminUi::t('Total') . '</th>'
            . '<th>' . IntigoAdminUi::t('Intigo status') . '</th><th>NID</th>'
            . '<th style="white-space:nowrap;">' . IntigoAdminUi::t('Actions') . '</th>'
            . '</tr></thead><tbody>';

        foreach ($rows as $r) {
            $id_order = (int) $r['id_order'];
            $nid = trim((string) $r['nid']);
            $has_nid = $nid !== '';
            $has_bordereau = $has_nid && trim((string) $r['bordereau_url']) !== '';
            $has_error = !$has_nid && trim((string) $r['last_error']) !== '';
            $is_intigo_carrier = (int) $r['id_carrier'] === $intigo_carrier_id;

            // Status badge — for a sent parcel, show the LIVE Intigo status (kept
            // current by the webhook), so the merchant always sees where Intigo has
            // the parcel even when PS order-status auto-update is off.
            if ($has_nid) {
                $sc = (int) $r['status_code'];
                $status = '<span class="intigo-badge ' . IntigoStatus::badgeClass($sc) . '">'
                    . htmlspecialchars(IntigoStatus::label($sc)) . '</span>';
                if ($has_bordereau) {
                    $status .= '<div class="intigo-zone" style="margin-top:3px;">Bordereau prêt</div>';
                }
            } elseif ($has_error) {
                $status = '<span class="intigo-badge intigo-badge--danger" title="' . htmlspecialchars((string) $r['last_error']) . '">' . IntigoAdminUi::t('Failed') . '</span>';
            } else {
                $status = '<span class="intigo-badge intigo-badge--muted">' . IntigoAdminUi::t('Not synced') . '</span>';
            }

            // Detected Intigo zone + confidence (from auto-resolution).
            $city_name = trim((string) $r['destination_city_name']);
            $district_name = trim((string) $r['destination_district_name']);
            $zone = $city_name !== ''
                ? htmlspecialchars($city_name . ($district_name !== '' ? ' / ' . $district_name : ''))
                : '';
            $rstatus = (string) $r['resolution_status'];
            $conf = (string) $r['resolution_confidence'];
            // Postal-code fallback: a valid 4-digit Tunisian postcode makes the
            // order sendable even when the free-text guesser couldn't match a zone
            // (Intigo resolves the zone from the postcode at send time).
            $pc_digits = preg_replace('/\D+/', '', (string) $r['postcode']);
            $has_postcode = (is_string($pc_digits) && strlen($pc_digits) === 4);
            $zone_line = $zone !== '' ? '<div class="intigo-zone">' . $zone . '</div>' : '';
            $pc_note = $has_postcode
                ? '<div class="intigo-zone">Code postal ' . htmlspecialchars($pc_digits) . ' — zone résolue par Intigo</div>'
                : '';
            if ($has_nid) {
                // Sent order: show the detected Intigo zone if we stored it; else
                // fall back to the postal code it shipped with, then the PS city —
                // so a synced order is never blank under "Zone Intigo détectée".
                if ($zone !== '') {
                    $zone_cell = '<span class="text-muted">' . $zone . '</span>';
                } elseif ($has_postcode) {
                    $zone_cell = '<span class="text-muted">Code postal ' . htmlspecialchars($pc_digits) . '</span>';
                } elseif (trim((string) $r['city']) !== '') {
                    $zone_cell = '<span class="text-muted">' . htmlspecialchars((string) $r['city']) . '</span>';
                } else {
                    $zone_cell = '<span class="text-muted">—</span>';
                }
            } elseif ($rstatus === 'resolved') {
                $zone_cell = '<span class="intigo-badge intigo-badge--success">' . ($conf === 'manual' ? 'Manuelle' : 'Prête') . '</span>' . $zone_line;
            } elseif ($rstatus === 'review') {
                $zone_cell = '<span class="intigo-badge intigo-badge--warning">À vérifier</span>' . $zone_line;
            } elseif ($rstatus === 'blocked' && $has_postcode) {
                // Guesser couldn't match, but the postcode can — sendable.
                $zone_cell = '<span class="intigo-badge intigo-badge--info">Prête · code postal</span>' . $pc_note
                    . '<div class="intigo-zone"><a href="' . $base_url . '&a=edit&id_order=' . $id_order . '">Préciser la zone</a></div>';
            } elseif ($rstatus === 'blocked') {
                $zone_cell = '<span class="intigo-badge intigo-badge--danger">Sans correspondance</span>'
                    . '<div class="intigo-zone"><a href="' . $base_url . '&a=edit&id_order=' . $id_order . '">Corriger l\'adresse</a></div>';
            } elseif ($has_postcode) {
                $zone_cell = '<span class="intigo-badge intigo-badge--info">Prête · code postal</span>' . $pc_note;
            } else {
                $zone_cell = '<span class="text-muted" style="font-size:12px;">Non analysée</span>';
            }
            // Selectable in both bulk lanes: unsent → bulk send, sent → bulk bordereau.
            $checkbox = '<input type="checkbox" form="intigobulk" name="id_orders[]" value="' . $id_order
                . '" class="intigo-rowcb"' . ($has_nid ? ' data-sent="1"' : ' data-unsent="1"') . '>';

            $h .= '<tr>';
            $h .= '<td>' . $checkbox . '</td>';
            $h .= '<td>' . $id_order . '</td>';
            $ref_intigo = trim((string) $r['reference_id']);
            $h .= '<td><code>' . htmlspecialchars((string) $r['reference']) . '</code>'
                . ($ref_intigo !== ''
                    ? '<div class="intigo-zone" style="margin-top:3px;">Réf : <strong>' . htmlspecialchars($ref_intigo) . '</strong></div>'
                    : '<div class="intigo-zone" style="margin-top:3px;color:#94a3b8;">Réf : —</div>')
                . '</td>';
            $h .= '<td>' . htmlspecialchars(trim((string) $r['firstname'] . ' ' . $r['lastname'])) . '</td>';
            $h .= '<td>' . htmlspecialchars((string) $r['city']) . '</td>';
            $h .= '<td>' . $zone_cell . '</td>';
            $h .= '<td style="white-space:nowrap;">' . number_format((float) $r['total_paid_tax_incl'], 3, ',', ' ') . ' DT</td>';
            $h .= '<td>' . $status . '</td>';
            $h .= '<td>' . ($has_nid
                ? '<code style="font-size:11px;">' . htmlspecialchars($nid) . '</code>'
                : '<span class="text-muted">—</span>') . '</td>';

            // HARD RULE: a parcel is sendable ONLY with a Ville AND a Délégation.
            // A postal code used to be accepted on its own, and that is exactly how
            // parcels with no confirmed zone reached Intigo and were re-derived to
            // the wrong governorate (1082, a Tunis code, resolves to Kef there).
            $ready = ((int) $r['destination_city_id'] > 0 && (int) $r['destination_district_id'] > 0);
            // Same rule for the Référence — never sendable without one.
            $has_ref = trim((string) $r['reference_id']) !== '';
            $can_send = $ready && $has_ref;
            $h .= '<td style="white-space:nowrap;">';
            $edit_url = $base_url . '&a=edit&id_order=' . $id_order;
            // Highlight Edit as the next step when the order still needs data.
            $edit_class = (!$has_nid && !$can_send) ? 'btn-primary' : 'btn-default';
            $h .= '<a href="' . $edit_url . '" class="btn ' . $edit_class . ' btn-sm" title="' . IntigoAdminUi::t('Edit Intigo delivery details') . '"><i class="material-icons intigo-bi">edit</i>' . IntigoAdminUi::t('Edit') . '</a> ';

            // Already-generated bordereau → open it directly + copy link (no re-POST).
            if ($has_bordereau) {
                $burl = htmlspecialchars((string) $r['bordereau_url']);
                $h .= '<a href="' . $burl . '" target="_blank" rel="noopener" class="btn btn-default btn-sm"><i class="material-icons intigo-bi">receipt</i>' . IntigoAdminUi::t('Open bordereau') . '</a> ';
                $h .= '<button type="button" class="btn btn-default btn-sm intigo-copy" data-copy="' . $burl . '" title="' . IntigoAdminUi::t('Copy link') . '"><i class="material-icons intigo-bi">content_copy</i>' . IntigoAdminUi::t('Copy') . '</button> ';
            }

            $h .= '<form method="post" action="' . htmlspecialchars($action_url) . '" style="display:inline;">';
            $h .= '<input type="hidden" name="id_order" value="' . $id_order . '">';
            $h .= '<input type="hidden" name="intigo_return" value="orders">';
            if (!$has_nid) {
                if ($can_send) {
                    $h .= '<button type="submit" name="intigo_action" value="push" class="btn btn-success btn-sm" '
                        . 'onclick="return confirm(\'Envoyer la commande #' . $id_order . ' à Intigo ?\');">'
                        . '<i class="material-icons intigo-bi">send</i>' . IntigoAdminUi::t('Send to Intigo') . '</button>';
                } else {
                    // Disabled — name the exact missing field(s) and steer to Edit.
                    $need = [];
                    if (!$has_ref) {
                        $need[] = 'la référence';
                    }
                    if ((int) $r['destination_city_id'] <= 0) {
                        $need[] = 'la ville';
                    }
                    if ((int) $r['destination_district_id'] <= 0) {
                        $need[] = 'la délégation';
                    }
                    $last = array_pop($need);
                    $tip = 'Envoi bloqué — renseignez ' . ($need ? implode(', ', $need) . ' et ' . $last : $last)
                        . ' via Modifier. Le code postal seul ne suffit pas : Intigo le ré-interprète et peut changer de gouvernorat.';
                    $h .= '<span class="intigo-tip" title="' . htmlspecialchars($tip) . '">'
                        . '<button type="button" class="btn btn-default btn-sm" disabled style="pointer-events:none;">' . IntigoAdminUi::t('Send to Intigo') . '</button></span>';
                }
            } else {
                if (!$has_bordereau) {
                    $h .= '<button type="submit" name="intigo_action" value="bordereau" class="btn btn-default btn-sm"><i class="material-icons intigo-bi">receipt_long</i>' . IntigoAdminUi::t('Generate bordereau') . '</button> ';
                }
                $h .= '<button type="submit" name="intigo_action" value="cancel" class="btn btn-danger btn-sm" '
                    . 'onclick="return confirm(\'Annuler le colis ' . htmlspecialchars($nid) . ' ?\');"><i class="material-icons intigo-bi">cancel</i>' . IntigoAdminUi::t('Cancel') . '</button>';
            }
            $h .= '</form>';
            $h .= '</td>';
            $h .= '</tr>';
        }
        $h .= '</tbody></table>';

        if ($pages > 1) {
            $h .= '<ul class="pagination">';
            for ($i = 1; $i <= $pages; $i++) {
                $url = $base_url . ($filter !== '' ? '&f=' . $filter : '') . ($st !== '' ? '&st=' . $st : '') . $date_qs . '&p=' . $i;
                $cls = $i === $page ? ' class="active"' : '';
                $h .= '<li' . $cls . '><a href="' . $url . '">' . $i . '</a></li>';
            }
            $h .= '</ul>';
        }

        $h .= '<p class="text-muted" style="margin-top:12px;"><small>'
            . '<strong>Astuce :</strong> cliquez sur <em>Modifier</em> sur une commande pour renseigner la ville, le district, le quartier et le destinataire avant l\'envoi à Intigo.'
            . '</small></p>';

        $h .= '</div></div></div>';

        // Copy-to-clipboard for bordereau links (delegated; works for the notice
        // banner and per-row Copy buttons).
        $h .= '<script>document.addEventListener("click",function(e){'
            . 'var b=e.target.closest(".intigo-copy");if(!b){return;}e.preventDefault();'
            . 'var t=b.getAttribute("data-copy")||"";'
            . 'var done=function(){var o=b.textContent;b.textContent="Copié !";setTimeout(function(){b.textContent=o;},1200);};'
            . 'if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(t).then(done,done);}'
            . 'else{var i=document.createElement("input");i.value=t;document.body.appendChild(i);i.select();try{document.execCommand("copy");}catch(err){}i.remove();done();}'
            . '});</script>';

        // Multi-select + bulk-send wiring (select-all, live count, confirm gate).
        $h .= '<script>(function(){'
            . 'var selall=document.getElementById("intigo-selall");'
            . 'var bar=document.getElementById("intigo-bulkbar");'
            . 'var countEl=document.getElementById("intigo-bulkcount");'
            . 'function cbs(){return Array.prototype.slice.call(document.querySelectorAll(".intigo-rowcb"));}'
            . 'function update(){var c=cbs();var n=c.filter(function(x){return x.checked;}).length;'
            . 'if(countEl)countEl.textContent=n;if(bar)bar.style.display=n>0?"":"none";'
            . 'if(selall){selall.checked=c.length>0&&n===c.length;selall.indeterminate=n>0&&n<c.length;}}'
            . 'if(selall){selall.addEventListener("change",function(){cbs().forEach(function(x){x.checked=selall.checked;});update();});}'
            . 'document.addEventListener("change",function(e){if(e.target&&e.target.classList&&e.target.classList.contains("intigo-rowcb"))update();});'
            . 'window.intigoBulkConfirm=function(mode){var c=cbs().filter(function(x){return x.checked;});var n=c.length;'
            . 'if(n===0){alert("Sélectionnez au moins une commande.");return false;}'
            . 'if(mode==="bordereau"){var sent=c.filter(function(x){return x.getAttribute("data-sent")==="1";}).length;'
            . 'if(sent===0){alert("Aucun colis envoyé dans la sélection. Envoyez d\'abord les commandes à Intigo.");return false;}'
            . 'return confirm("Générer le bordereau groupé pour "+sent+" colis envoyé(s) ?");}'
            . 'return confirm("Envoyer "+n+" commande(s) à Intigo ? Les colis seront créés chez Intigo.");};'
            . 'update();'
            . '})();</script>';

        $this->content = $h;
    }

    /* ---------------- EDIT view ---------------- */

    /**
     * Order-state IDs linked to a pickup address — and only to one that STILL
     * EXISTS in the current Intigo pickup list. This is the "only those linked to
     * pickup addresses" scope used for the orders list and the status filter; a
     * stale mapping to a removed address is ignored. If the pickup list isn't
     * cached yet, every mapped status is kept so the filter still works.
     */
    private function mappedStatesForExistingPickups($id_shop)
    {
        // Shared with the dashboard coverage metric (single source of truth).
        return IntigoPickupMap::mappedStatesForExistingPickups($id_shop);
    }

    private function renderEditPage()
    {
        require_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoParcel.php';
        require_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoOrderService.php';

        $id_order = (int) Tools::getValue('id_order');
        $order = new Order($id_order);
        if (!Validate::isLoadedObject($order)) {
            $this->content = '<div class="alert alert-danger">Commande #' . $id_order . ' introuvable</div>'
                . '<a href="' . self::$currentIndex . '&token=' . $this->token . '" class="btn btn-default">← Retour à la liste</a>';
            return;
        }

        $parcel = IntigoParcel::findByOrderId($id_order);
        $svc = new IntigoOrderService();
        // resolveViaApi=false: just prefill the form from the parcel/PS address —
        // do NOT make a network call (city is chosen from the dropdown).
        $preview = $svc->orderToPayload($order, false);

        // Form values: parcel row (if set) > preview from PS address fallback
        $f = [
            'reference_id' => $parcel ? (string) $parcel->reference_id : '',
            'recipient_name' => ($parcel && trim((string) $parcel->recipient_name) !== '')
                ? $parcel->recipient_name : ($preview['recipient_name'] ?? ''),
            'recipient_phone' => ($parcel && trim((string) $parcel->recipient_phone) !== '')
                ? $parcel->recipient_phone : ($preview['phone1'] ?? ''),
            // $preview already routes the stored address through preferredAddress(),
            // so a street-only legacy value shows as the complete line while a
            // hand-edited one is kept verbatim.
            'destination_address' => trim((string) ($preview['destination_address'] ?? '')) !== ''
                ? $preview['destination_address']
                : ($parcel ? (string) $parcel->destination_address : ''),
            'city_id' => $parcel ? (int) $parcel->destination_city_id : (int) ($preview['destination_city_id'] ?? 0),
            'district_id' => $parcel ? (int) $parcel->destination_district_id : 0,
            'neighborhood_id' => $parcel ? (int) $parcel->destination_neighborhood_id : 0,
            'package_size' => $parcel ? ((int) $parcel->package_size ?: 1) : 1,
        ];

        // Pickup switcher (same as the native order panel): local cache options +
        // the effective pickup (per-order override → status map). No network call.
        require_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoPickupMap.php';
        $pickup_options = [];
        $cache = Configuration::get('INTIGO_PICKUP_CACHE');
        if ($cache !== false && trim((string) $cache) !== '') {
            $list = json_decode((string) $cache, true);
            if (is_array($list)) {
                foreach ($list as $it) {
                    if (!is_array($it) || !isset($it['index']) || $it['index'] === null) {
                        continue;
                    }
                    $lbl = trim((string) (isset($it['street_address']) ? $it['street_address'] : '')
                        . ' ' . (isset($it['city_name']) ? $it['city_name'] : ''));
                    if ($lbl === '') {
                        $lbl = 'Ramassage #' . (int) $it['index'];
                    }
                    $pickup_options[] = ['index' => (int) $it['index'], 'label' => $lbl, 'has_gps' => !empty($it['has_gps'])];
                }
            }
        }
        $pickup_override = ($parcel && $parcel->pickup_override_index !== null) ? (int) $parcel->pickup_override_index : 0;
        $sp = IntigoPickupMap::resolvePickupIndex((int) $order->id_shop ?: 1, (int) $order->getCurrentState());
        $status_pickup = ($sp !== null) ? (int) $sp : 0;
        $pickup_label_by_index = [];
        foreach ($pickup_options as $po) {
            $pickup_label_by_index[$po['index']] = $po['label'];
        }
        $status_pickup_label = ($status_pickup >= 1 && isset($pickup_label_by_index[$status_pickup]))
            ? $pickup_label_by_index[$status_pickup] : '';

        // Auto-detect the Intigo zone (city/district) for an unpushed order that
        // has none yet — SAME as the native order panel. Without this the edit page
        // (reached from the Orders list "Préciser la zone") was blank while the
        // native order view detected the zone. Best-effort, persisted, one-time.
        $already_pushed = $parcel && trim((string) $parcel->nid) !== '';
        if (!$already_pushed && (int) $f['city_id'] <= 0 && trim((string) $f['destination_address']) !== '') {
            try {
                require_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoZoneIndex.php';
        require_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoAddressResolver.php';
                $res = (new IntigoAddressResolver())->resolveAndStore($order);
                if (!empty($res['ok'])) {
                    if ((int) $res['city_id'] > 0) {
                        $f['city_id'] = (int) $res['city_id'];
                    }
                    if ((int) $res['district_id'] > 0) {
                        $f['district_id'] = (int) $res['district_id'];
                    }
                    if ((int) $res['neighborhood_id'] > 0) {
                        $f['neighborhood_id'] = (int) $res['neighborhood_id'];
                    }
                }
            } catch (\Throwable $e) {
                if (class_exists('IntigoLog')) {
                    IntigoLog::add('edit_autodetect_error', $e->getMessage());
                }
            }
        }

        $action_url = $this->context->link->getAdminLink('AdminIntigoOrderAction');
        $list_url = self::$currentIndex . '&token=' . $this->token;
        $regions_url = $this->context->link->getModuleLink('intigoparcels', 'regions', ['action' => 'cities'], true);

        $notice = (string) Tools::getValue('intigo_notice');
        $notice_type = (string) Tools::getValue('intigo_notice_type');
        $alert_class = $notice_type === 'success' ? 'success'
            : ($notice_type === 'error' ? 'danger'
            : ($notice_type === 'warning' ? 'warning' : 'info'));

        $h = '<div class="intigo-screen">';
        $h .= IntigoAdminUi::navHtml($this->context->link, 'orders');
        $h .= '<div class="panel">';
        $h .= '<div class="panel-heading">'
            . '<i class="material-icons">local_shipping</i> '
            . 'Colis Intigo — Commande #' . $id_order . ' (' . htmlspecialchars((string) $order->reference) . ')'
            . '</div>';

        if ($notice !== '') {
            $h .= '<div class="alert alert-' . $alert_class . '">' . htmlspecialchars($notice) . '</div>';
        }

        // Current parcel state banner
        if ($parcel && trim((string) $parcel->nid) !== '') {
            $h .= '<div class="alert alert-success">'
                . '<strong>Numéro de suivi :</strong> <code>' . htmlspecialchars($parcel->nid) . '</code> &nbsp; '
                . '<strong>Statut :</strong> ' . (int) $parcel->status_code . ' &nbsp; '
                . '<small>Envoyé le ' . htmlspecialchars((string) $parcel->last_attempt_at) . '</small>'
                . '</div>';
        } elseif ($parcel && trim((string) $parcel->last_error) !== '') {
            $h .= '<div class="alert alert-warning">'
                . '<strong>Le dernier envoi a échoué :</strong><br>'
                . '<small><code>' . htmlspecialchars((string) $parcel->last_error) . '</code></small>'
                . '</div>';
        } else {
            $h .= '<div class="alert alert-info">Aucun colis créé pour l\'instant. Complétez les champs puis cliquez sur <strong>Enregistrer &amp; Envoyer à Intigo</strong>.</div>';
        }

        // Read-only order context (client + products + original address) so the
        // merchant SEES who/what the order is for. Not editable — the Intigo fields
        // are the editable form below.
        $customer = new Customer((int) $order->id_customer);
        $cust_name = trim((string) $customer->firstname . ' ' . (string) $customer->lastname);
        $dadr = new Address((int) $order->id_address_delivery);
        $orig_addr = Validate::isLoadedObject($dadr)
            ? trim(trim((string) $dadr->address1 . ' ' . (string) $dadr->address2) . ', ' . trim((string) $dadr->postcode . ' ' . (string) $dadr->city))
            : '';
        $orig_phone = Validate::isLoadedObject($dadr) ? trim((string) ($dadr->phone ? $dadr->phone : $dadr->phone_mobile)) : '';
        $products = $svc->getOrderProducts($order);

        $h .= '<div class="card" style="margin:0 0 16px;"><div class="card-body">';
        $h .= '<h3 style="margin:0 0 12px;font-size:15px;color:#0f172a;"><i class="material-icons" style="vertical-align:-5px;color:#4F46E5;">receipt_long</i> Récapitulatif de la commande <span class="text-muted" style="font-size:12px;font-weight:400;">(lecture seule)</span></h3>';
        $h .= '<div style="display:grid;grid-template-columns:1fr 1fr;gap:6px 24px;font-size:13px;color:#334155;">';
        $h .= '<div><span class="text-muted">Client :</span> <strong>' . htmlspecialchars($cust_name !== '' ? $cust_name : '—') . '</strong></div>';
        $h .= '<div><span class="text-muted">Total :</span> <strong>' . number_format((float) $order->total_paid_tax_incl, 3, ',', ' ') . ' DT</strong></div>';
        if ($orig_phone !== '') {
            $h .= '<div><span class="text-muted">Téléphone :</span> ' . htmlspecialchars($orig_phone) . '</div>';
        }
        if ($orig_addr !== '') {
            $h .= '<div style="grid-column:1/-1;"><span class="text-muted">Adresse client :</span> ' . htmlspecialchars($orig_addr) . '</div>';
        }
        $h .= '</div>';
        if (!empty($products)) {
            $h .= '<div style="margin-top:12px;"><span class="text-muted" style="font-size:13px;">Produits :</span>'
                . '<ul style="margin:6px 0 0;padding-left:18px;font-size:13px;color:#334155;">';
            foreach ($products as $p) {
                $h .= '<li>' . htmlspecialchars(($p['qty'] > 1 ? $p['qty'] . '× ' : '') . $p['name'])
                    . ' <span class="text-muted">— ' . number_format((float) $p['total'], 3, ',', ' ') . ' DT</span></li>';
            }
            $h .= '</ul></div>';
        }
        $h .= '<p class="text-muted" style="margin:10px 0 0;font-size:12px;">La liste des produits est envoyée à Intigo et apparaît sur le bordereau.</p>';
        $h .= '</div></div>';

        // Form
        $h .= '<form method="post" action="' . htmlspecialchars($action_url) . '" class="form-horizontal" id="intigo-edit-form" '
            . 'data-regions-url="' . htmlspecialchars($regions_url) . '">';
        $h .= '<input type="hidden" name="id_order" value="' . $id_order . '">';
        $h .= '<input type="hidden" name="intigo_return" value="orders">';

        $h .= '<div class="form-group">'
            . '<label class="control-label col-lg-3">Référence <span style="color:#d92d20;">*</span></label>'
            . '<div class="col-lg-6">'
            . '<input type="text" name="reference_id" id="intigo-ref-input" value="' . htmlspecialchars((string) $f['reference_id']) . '" class="form-control" placeholder="Ex : CMD-1024">'
            . '<p class="help-block">Obligatoire — identifiant Intigo (cid) et imprimée sur le bordereau (Commentaire). Sans référence, l\'envoi est bloqué.</p>'
            . '</div></div>';
        $h .= $this->formGroup('Nom du destinataire *', 'recipient_name', 'text', $f['recipient_name'], 'required');
        $h .= $this->formGroup('Téléphone *', 'recipient_phone', 'tel', $f['recipient_phone'], 'required');
        $h .= $this->formGroupTextarea('Adresse de livraison *', 'destination_address', $f['destination_address']);

        // Re-detect the zone from the address on demand (e.g. the first guess was
        // off). Available even AFTER sending: the merchant needs to see the corrected
        // zone before deciding to recreate the parcel with "Renvoyer".
        $redetect_url = self::$currentIndex . '&token=' . $this->token . '&a=redetect&id_order=' . (int) $id_order;
        $h .= '<div class="form-group"><div class="col-lg-offset-3 col-lg-6">'
            . '<a href="' . htmlspecialchars($redetect_url) . '" class="btn btn-default btn-sm">'
            . '<i class="material-icons" style="font-size:16px;vertical-align:middle;">my_location</i> '
            . 'Re-détecter la ville / délégation</a>'
            . '<p class="help-block" style="margin-top:4px;">Relance la détection automatique depuis l\'adresse ci-dessus '
            . '(utile si la zone détectée est incorrecte).'
            . ($already_pushed
                ? ' Ce colis est déjà chez Intigo : la re-détection met à jour la zone <strong>ici seulement</strong>. '
                    . 'Utilisez <strong>Renvoyer</strong> pour recréer le colis avec la zone corrigée.'
                : '')
            . '</p>'
            . '</div></div>';

        // Zone gate banner — the send button below stays locked until BOTH selects
        // are set, so say so up front rather than leaving a greyed-out button.
        if (!$already_pushed && ((int) $f['city_id'] <= 0 || (int) $f['district_id'] <= 0)) {
            $h .= '<div class="alert alert-warning" id="intigo-zone-alert" style="margin:0 0 16px;">'
                . '<strong>Zone de livraison non confirmée.</strong> '
                . 'Choisissez la <strong>Ville</strong> et la <strong>Délégation</strong> ci-dessous pour activer l\'envoi à Intigo.'
                . '<br><small>Le code postal seul ne suffit pas : Intigo le ré-interprète de son côté et peut expédier '
                . 'vers un autre gouvernorat.</small></div>';
        }

        $city_missing = ((int) $f['city_id'] <= 0);
        $dist_missing = ((int) $f['district_id'] <= 0);
        $req_style = 'border-color:#d92d20;box-shadow:0 0 0 2px rgba(217,45,32,.12);';

        $h .= '<div class="form-group">';
        $h .= '<label class="control-label col-lg-3">Ville <span style="color:#d92d20;">*</span></label>';
        $h .= '<div class="col-lg-6">';
        $h .= '<select name="destination_city_id" id="intigo-city" class="form-control intigo-zone-req" data-selected="' . (int) $f['city_id'] . '" required'
            . ($city_missing ? ' style="' . $req_style . '"' : '') . '>';
        $h .= '<option value="">— choisir une ville —</option>';
        $h .= '</select>';
        $h .= '<p class="help-block">Obligatoire — sans ville, l\'envoi à Intigo est bloqué.</p>';
        $h .= '</div></div>';

        $h .= '<div class="form-group">';
        $h .= '<label class="control-label col-lg-3">Délégation <span style="color:#d92d20;">*</span></label>';
        $h .= '<div class="col-lg-6">';
        $h .= '<select name="destination_district_id" id="intigo-district" class="form-control intigo-zone-req" data-selected="' . (int) $f['district_id'] . '" required disabled'
            . ($dist_missing ? ' style="' . $req_style . '"' : '') . '>';
        $h .= '<option value="">— choisir d\'abord une ville —</option>';
        $h .= '</select>';
        $h .= '<p class="help-block">Obligatoire — sans délégation, l\'envoi à Intigo est bloqué.</p>';
        $h .= '</div></div>';

        $h .= '<div class="form-group">';
        $h .= '<label class="control-label col-lg-3">Cité</label>';
        $h .= '<div class="col-lg-6">';
        $h .= '<select name="destination_neighborhood_id" id="intigo-neighborhood" class="form-control" data-selected="' . (int) $f['neighborhood_id'] . '" disabled>';
        $h .= '<option value="">— facultatif —</option>';
        $h .= '</select>';
        $h .= '</div></div>';

        $h .= '<div class="form-group">';
        $h .= '<label class="control-label col-lg-3">Taille du colis</label>';
        $h .= '<div class="col-lg-3">';
        $h .= '<select name="package_size" class="form-control">';
        $size_map = [1 => 'S', 2 => 'M', 4 => 'L', 5 => 'XL'];
        foreach ($size_map as $code => $label) {
            $sel = (int) $f['package_size'] === $code ? ' selected' : '';
            $h .= '<option value="' . $code . '"' . $sel . '>' . $label . '</option>';
        }
        $h .= '</select>';
        $h .= '</div></div>';

        $h .= '<div class="form-group">';
        $h .= '<label class="control-label col-lg-3">Adresse de ramassage <span style="color:#dc2626;">*</span></label>';
        $h .= '<div class="col-lg-6">';
        $h .= '<select name="pickup_override_index" class="form-control">';
        $auto_lbl = ($status_pickup_label !== '')
            ? ' — ' . htmlspecialchars($status_pickup_label)
            : ($status_pickup >= 1 ? ' — #' . (int) $status_pickup : ' — aucune adresse mappée');
        $h .= '<option value="">Auto (selon le statut)' . $auto_lbl . '</option>';
        foreach ($pickup_options as $po) {
            $sel = ($pickup_override === (int) $po['index']) ? ' selected' : '';
            $gps = $po['has_gps'] ? '' : ' (GPS manquant)';
            $h .= '<option value="' . (int) $po['index'] . '"' . $sel . '>' . htmlspecialchars($po['label'] . $gps) . '</option>';
        }
        $h .= '</select>';
        $h .= '<p class="help-block">Par défaut, l\'adresse liée au statut de la commande. Sans adresse résolue, l\'envoi est bloqué — jamais d\'adresse par défaut.</p>';
        $h .= '</div></div>';

        // Buttons
        $h .= '<div class="panel-footer" style="margin-top:24px;">';
        $h .= '<a href="' . $list_url . '" class="btn btn-default">← Retour à la liste</a> ';
        // formnovalidate: "Enregistrer" is a SAVE-AS-DRAFT — it must always go
        // through even with an empty Ville/Délégation (a required <select> would
        // otherwise make the browser silently block the whole form, so the
        // reference never saves). Completeness is enforced server-side before an
        // actual send. Same for the send buttons — an empty city_id can still ship
        // via the postal-code path, and the server returns a clear message if not.
        $h .= '<button type="submit" name="intigo_action" value="save" formnovalidate class="btn btn-default">Enregistrer</button> ';
        if (!$parcel || trim((string) $parcel->nid) === '') {
            $h .= '<button type="submit" name="intigo_action" value="save_push" id="intigo-savepush-btn" formnovalidate class="btn btn-success"><i class="material-icons intigo-bi">send</i> Enregistrer &amp; Envoyer à Intigo</button>';
        } else {
            $h .= '<button type="submit" name="intigo_action" value="save_update" formnovalidate class="btn btn-primary"><i class="material-icons intigo-bi">sync</i> Enregistrer &amp; Mettre à jour</button>';
        }
        $h .= '</div>';

        $h .= '</form>';
        $h .= '</div>';

        // Inline cascading-dropdown JS (no external file dependency — self-contained)
        $h .= $this->cascadingJs();

        // Référence + Ville + Délégation are all mandatory before an envoi. Keep
        // "Enregistrer & Envoyer" disabled until the three are set, name what is
        // still missing in the tooltip, and outline the offending select in red.
        // The server refuses the same combination, so this is a courtesy, not the
        // guard: IntigoOrderService::buildSendPlan() returns no plan at all without
        // a ville and a délégation.
        $h .= '<script>(function(){'
            . 'var r=document.getElementById("intigo-ref-input"),b=document.getElementById("intigo-savepush-btn"),'
            . 'c=document.getElementById("intigo-city"),d=document.getElementById("intigo-district"),'
            . 'a=document.getElementById("intigo-zone-alert");'
            . 'if(!b)return;'
            . 'function mark(el,bad){if(!el)return;el.style.borderColor=bad?"#d92d20":"";'
            . 'el.style.boxShadow=bad?"0 0 0 2px rgba(217,45,32,.12)":"";}'
            . 'function t(){var m=[];'
            . 'if(r&&r.value.trim()==="")m.push("la référence");'
            . 'var cb=!c||!c.value,db=!d||!d.value;'
            . 'if(cb)m.push("la ville");if(db)m.push("la délégation");'
            . 'mark(c,cb);mark(d,db);'
            . 'if(a)a.style.display=(cb||db)?"":"none";'
            . 'b.disabled=m.length>0;b.style.opacity=m.length?"0.55":"";'
            . 'b.title=m.length?("Envoi bloqué — renseignez "+m.join(", ")):"";}'
            . 'if(r)r.addEventListener("input",t);'
            . 'if(c)c.addEventListener("change",function(){setTimeout(t,0);});'
            . 'if(d)d.addEventListener("change",t);'
            // The Ville/Délégation selects are filled asynchronously by the
            // cascading-dropdown JS, so re-check until they have settled.
            . 'var n=0,iv=setInterval(function(){t();if(++n>40)clearInterval(iv);},250);'
            . 't();})();</script>';
        $h .= '</div>'; // .intigo-screen

        $this->content = $h;
    }

    private function formGroup($label, $name, $type, $value, $extra = '')
    {
        return '<div class="form-group">'
            . '<label class="control-label col-lg-3">' . htmlspecialchars($label) . '</label>'
            . '<div class="col-lg-6">'
            . '<input type="' . $type . '" name="' . $name . '" value="' . htmlspecialchars((string) $value) . '" class="form-control" ' . $extra . '>'
            . '</div></div>';
    }

    private function formGroupTextarea($label, $name, $value)
    {
        return '<div class="form-group">'
            . '<label class="control-label col-lg-3">' . htmlspecialchars($label) . '</label>'
            . '<div class="col-lg-6">'
            . '<textarea name="' . $name . '" class="form-control" rows="2" required>' . htmlspecialchars((string) $value) . '</textarea>'
            . '</div></div>';
    }

    private function cascadingJs()
    {
        return <<<'JS'
<script>
(function () {
    var form = document.getElementById('intigo-edit-form');
    if (!form) { return; }
    var regionsUrl = form.getAttribute('data-regions-url');
    var cityEl = document.getElementById('intigo-city');
    var districtEl = document.getElementById('intigo-district');
    var neighborhoodEl = document.getElementById('intigo-neighborhood');
    var preCity = parseInt(cityEl.dataset.selected || '0', 10);
    var preDistrict = parseInt(districtEl.dataset.selected || '0', 10);
    var preNeighborhood = parseInt(neighborhoodEl.dataset.selected || '0', 10);

    function fetchJson(url) {
        return fetch(url, { credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .catch(function () { return null; });
    }

    function fill(sel, items, selectId) {
        while (sel.options.length > 1) { sel.remove(1); }
        (items || []).forEach(function (it) {
            var o = document.createElement('option');
            o.value = it.id;
            o.textContent = it.name;
            if (parseInt(selectId, 10) === parseInt(it.id, 10)) { o.selected = true; }
            sel.appendChild(o);
        });
    }

    function loadCities(selectId) {
        fetchJson(regionsUrl + '&action=cities').then(function (data) {
            if (!data || !data.ok) { return; }
            fill(cityEl, data.items, selectId);
            if (selectId > 0) { loadDistricts(selectId, preDistrict); }
        });
    }
    function loadDistricts(cityId, selectId) {
        fetchJson(regionsUrl + '&action=districts&city_id=' + cityId).then(function (data) {
            if (!data || !data.ok) { return; }
            fill(districtEl, data.items, selectId);
            districtEl.disabled = false;
            if (selectId > 0) { loadNeighborhoods(selectId, preNeighborhood); }
        });
    }
    function loadNeighborhoods(districtId, selectId) {
        fetchJson(regionsUrl + '&action=neighborhoods&district_id=' + districtId).then(function (data) {
            if (!data || !data.ok) { return; }
            fill(neighborhoodEl, data.items, selectId);
            neighborhoodEl.disabled = false;
        });
    }

    cityEl.addEventListener('change', function () {
        districtEl.innerHTML = '<option value="">— choisir une délégation —</option>';
        districtEl.disabled = !cityEl.value;
        neighborhoodEl.innerHTML = '<option value="">— facultatif —</option>';
        neighborhoodEl.disabled = true;
        if (cityEl.value) { loadDistricts(parseInt(cityEl.value, 10), 0); }
    });
    districtEl.addEventListener('change', function () {
        neighborhoodEl.innerHTML = '<option value="">— facultatif —</option>';
        neighborhoodEl.disabled = !districtEl.value;
        if (districtEl.value) { loadNeighborhoods(parseInt(districtEl.value, 10), 0); }
    });

    loadCities(preCity);
})();
</script>
JS;
    }
}
