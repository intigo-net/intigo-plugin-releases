<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Deterministic, offline matcher for Tunisian delivery zones.
 *
 * The free-text guesser (OpenSearch) ranks by fuzzy similarity, so it happily
 * answers "Cité 1er Mai / Le Kef Est / Kef" for a Tunis address whose only
 * common token is "1er" — that misrouted a real parcel by ~200 km. This class
 * replaces guessing with EXACT matching against Intigo's own place names (the
 * very list behind the Ville / Délégation / Cité dropdowns, in
 * data/intigo-zones.php).
 *
 * Two ideas make it work where the guesser fails:
 *
 *  1. SQUASHED comparison — normalise, then remove every non-alphanumeric.
 *     Intigo stores "Mutuelle Ville"; the customer writes "Mutuelleville".
 *     Squashed, both are `mutuelleville`, an exact hit. No fuzziness, so it can
 *     never wander into another governorate.
 *  2. The governorate comes from a FIELD, never from the street text — the
 *     PrestaShop État (state) or Ville. Both are accepted: merchants who use
 *     one leave the other empty. Street text is only ever searched for the
 *     délégation/cité, and only inside the governorate already established.
 *
 * The names here are stable reference data. The IDs sent to Intigo are NEVER
 * taken from this file — IntigoAddressResolver re-resolves every matched name
 * to a live id through IntigoApiClient, so a server-side renumbering cannot
 * make us ship a wrong zone.
 */
class IntigoZoneIndex
{
    /** Shortest squashed name we will look for inside free text. */
    const MIN_MATCH_LEN = 6;

    /** @var array|null */
    private static $data = null;

    public static function data()
    {
        if (self::$data === null) {
            $file = _PS_MODULE_DIR_ . 'intigoparcels/data/intigo-zones.php';
            $d = is_readable($file) ? include $file : null;
            self::$data = is_array($d) ? $d : [];
        }
        return self::$data;
    }

    /**
     * Normalise then strip everything that isn't a letter or digit:
     * "Mutuelle-Ville " → "mutuelleville", "El Menzah 6" → "elmenzah6".
     */
    public static function squash($text)
    {
        return str_replace(' ', '', IntigoApiClient::normalizeName($text));
    }

    /**
     * Match a governorate from ONE address field (État or Ville). Tolerates the
     * spelling variants merchants actually have in their PrestaShop state list
     * ("Manouba"/"Mannouba", "Le Kef"/"Kef") via a leading-article strip and a
     * single-edit distance — safe because no two of the 24 governorate names are
     * within two edits of each other, and an ambiguous result is rejected.
     *
     * Returns the canonical squashed city key, or '' when the field doesn't name
     * a governorate (empty, "Tunisia", a postcode, a neighbourhood…).
     */
    public static function matchCityField($value)
    {
        $key = self::squash($value);
        if ($key === '') {
            return '';
        }
        $data = self::data();
        if (isset($data[$key])) {
            return $key;
        }
        // "Le Kef" / "El Kef" → "kef"; "Grand Tunis" → "tunis".
        $stripped = preg_replace('/^(le|la|el|grand|gouvernoratde|gouvernorat)/', '', $key);
        if ($stripped !== $key && $stripped !== '' && isset($data[$stripped])) {
            return $stripped;
        }
        // One typo/letter-doubling away, and only if exactly one city qualifies.
        if (strlen($key) >= 4) {
            $hit = '';
            foreach (array_keys($data) as $ck) {
                if (abs(strlen($ck) - strlen($key)) <= 1 && levenshtein($ck, $key) <= 1) {
                    if ($hit !== '') {
                        return '';
                    }
                    $hit = $ck;
                }
            }
            if ($hit !== '') {
                return $hit;
            }
        }
        return '';
    }

    /**
     * Find the governorate named as a WHOLE WORD inside free address text. Only
     * used when neither État nor Ville gave one — a street may legitimately be
     * "Rue de Tunis" in Sousse, so a hit here is weaker evidence and the caller
     * treats it as such. Ambiguous (two governorates named) → ''.
     */
    public static function findCityInText($text)
    {
        $words = explode(' ', IntigoApiClient::normalizeName($text));
        $data = self::data();
        $hit = '';
        foreach ($data as $ck => $row) {
            // Multi-word governorates ("Ben Arous", "Sidi Bouzid") must be matched
            // on the squashed run of consecutive words, not a single word.
            $joined = implode('', $words);
            $found = in_array($ck, $words, true) || strpos($joined, $ck) !== false;
            if ($found && strlen($ck) >= 4) {
                if ($hit !== '' && $hit !== $ck) {
                    return '';
                }
                $hit = $ck;
            }
        }
        return $hit;
    }

    /**
     * Look for a délégation or cité named verbatim in the customer's text.
     *
     * $city_key scopes the search to one governorate — strongly preferred: 374 of
     * the 3647 place names in Tunisia are reused across governorates ("Erriadh",
     * "Cité Ennasr"…), so an unscoped search is only trusted when every match
     * agrees on a single governorate.
     *
     * The LONGEST match wins: "elmenzah6" beats "elmenzah", and a cité beats the
     * délégation that contains it, because a longer name is more specific.
     *
     * @return array|null ['city','district','neighborhood','matched','scoped']
     */
    public static function matchZone($text, $city_key = '')
    {
        $hay = self::squash($text);
        if ($hay === '') {
            return null;
        }
        $data = self::data();
        $scope = ($city_key !== '' && isset($data[$city_key])) ? [$city_key => $data[$city_key]] : $data;

        $best = null;
        $cities_hit = [];
        foreach ($scope as $ck => $crow) {
            foreach ($crow[1] as $dkey => $drow) {
                if (strlen($dkey) >= self::MIN_MATCH_LEN && strpos($hay, $dkey) !== false) {
                    $cities_hit[$ck] = true;
                    if ($best === null || strlen($dkey) > $best['len']) {
                        $best = ['city' => $crow[0], 'district' => $drow[0], 'neighborhood' => '',
                                 'matched' => $dkey, 'len' => strlen($dkey)];
                    }
                }
                foreach ($drow[1] as $nkey) {
                    if (strlen($nkey) >= self::MIN_MATCH_LEN && strpos($hay, $nkey) !== false) {
                        $cities_hit[$ck] = true;
                        if ($best === null || strlen($nkey) > $best['len']) {
                            $best = ['city' => $crow[0], 'district' => $drow[0], 'neighborhood' => $nkey,
                                     'matched' => $nkey, 'len' => strlen($nkey)];
                        }
                    }
                }
            }
        }
        if ($best === null) {
            return null;
        }
        // Unscoped and the text names places in two different governorates — we
        // cannot tell which one the customer means. Refuse rather than pick.
        if ($city_key === '' && count($cities_hit) > 1) {
            return null;
        }
        $best['scoped'] = ($city_key !== '');
        unset($best['len']);
        return $best;
    }
}
