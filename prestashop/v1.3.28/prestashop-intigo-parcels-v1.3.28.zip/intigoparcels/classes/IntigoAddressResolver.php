<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Auto-detects the Intigo delivery zone (city_id / district_id / neighborhood_id)
 * from a customer's free-text PrestaShop shipping address, using the OpenSearch
 * location guesser — so the merchant never edits orders by hand.
 *
 * Detection model: the resolver ALWAYS surfaces at least the NEAREST zone when
 * the guesser returns anything — it never leaves an order "Sans correspondance"
 * over a low-confidence match. The confidence TIER tells the merchant how much to
 * trust it; only auto-send (GREEN) is gated, never the display.
 *
 *   GREEN   single city across top hits · city resolved by EXACT match ·
 *           district present · coherent · agrees with the order's city
 *           → auto-send-eligible
 *   REVIEW  the nearest match, but fuzzy / ambiguous / city-only / unverified
 *           IDs → auto-filled with the nearest zone, needs one human glance
 *   BLOCKED only when there is genuinely nothing to match: empty address AND
 *           city, or the guesser is unavailable / returns zero results
 */
class IntigoAddressResolver
{
    const TIER_GREEN = 'green';
    const TIER_REVIEW = 'review';
    const TIER_BLOCKED = 'blocked';

    /** @var IntigoApiClient */
    private $api;

    public function __construct(IntigoApiClient $api = null)
    {
        $this->api = $api ?: new IntigoApiClient();
    }

    /**
     * Build the guesser query: cleaned address locality + the order's city
     * (always appended to anchor the governorate). Building noise pulls the
     * search toward spurious matches, so strip it.
     */
    public function buildQuery($address1, $city)
    {
        $addr = $this->cleanAddress($address1);
        $city = trim((string) $city);
        $q = trim($addr . ' ' . $city);
        return $q !== '' ? $q : $city;
    }

    /**
     * Strip building-reference *pairs* — the keyword AND its following token
     * ("immeuble X", "appt 3", "bloc B", "n° 12", "étage 2"). Deliberately does
     * NOT strip bare numbers: Tunisian place names embed them ("Charguia 2",
     * "El Menzah 6"), and removing the number changes the destination.
     */
    private function cleanAddress($address1)
    {
        $addr = (string) $address1;
        // "n° 12", "no 12", "n 12", "n°12" (apartment/door numbers).
        $addr = preg_replace('/\bn[\x{00b0}o]?\.?\s*\d+\b/iu', ' ', $addr);
        // Building keyword + its following token: "immeuble X", "appt 3", "bloc B".
        $addr = preg_replace(
            '/\b(immeuble|imm|appartement|appart|appt|apt|bloc|block|etage|etg|esc|escalier|residence|res)\b\.?\s*[\w\x{00b0}]+/iu',
            ' ',
            $addr
        );
        // Standalone 4-digit numbers are postal codes (Tunisian place-numbers are
        // 1-2 digits, e.g. "El Menzah 6") — they add noise the guesser can't use.
        $addr = preg_replace('/\b\d{4}\b/u', ' ', (string) $addr);
        $addr = preg_replace('/[,;]+/', ' ', (string) $addr);   // leftover separators
        return trim(preg_replace('/\s+/', ' ', (string) $addr));
    }

    /**
     * The locality text that FOLLOWS a 4-digit postal code in a Tunisian address
     * ("… 2091 Jardins d'el menzah 2" → "Jardins d'el menzah 2"). The postal code
     * isn't searchable, but it reliably marks where the street ends and the place
     * name begins — querying just that part resolves far better than the full line
     * (street + building words drag the guesser to spurious "Cité des Jardins"
     * matches). Returns '' when there's no postal code.
     */
    private function localityAfterPostal($text)
    {
        if (!preg_match('/\b\d{4}\b(.+)$/u', (string) $text, $m)) {
            return '';
        }
        $after = preg_split('/[,;]/', trim($m[1]));
        return $this->cleanAddress($after[0]);
    }

    /**
     * EXACT local match against Intigo's own place names, tried BEFORE the fuzzy
     * guesser. See IntigoZoneIndex for why (the guesser answers "Kef" for a Tunis
     * address). The governorate comes from the État or the Ville field — either
     * one, since merchants use one or the other — and the délégation/cité is then
     * looked for inside that governorate only.
     *
     * Returns a full resolve() result, or null when nothing matched exactly (the
     * caller then falls back to the guesser).
     */
    private function resolveLocally($address1, $city, $state, $postcode)
    {
        if (!class_exists('IntigoZoneIndex')) {
            return null;
        }
        // The governorate comes from a FIELD only — État first, then Ville. Both
        // are accepted, since a shop fills in one or the other.
        $city_key = IntigoZoneIndex::matchCityField($state);
        $city_from = 'etat';
        if ($city_key === '') {
            $city_key = IntigoZoneIndex::matchCityField($city);
            $city_from = 'ville';
        }

        // The délégation/cité is looked for in the STREET TEXT ONLY. Feeding the
        // Ville/État back in would let the governorate name match a same-named
        // place inside itself — "Avenue Habib Bourguiba" + Ville "Sousse" would
        // "match" the cité Sousse in Sousse Medina, which is a guess wearing a
        // match's clothes. The fields decide the governorate, the street decides
        // the délégation, and neither does the other's job.
        $text = (string) $address1;
        $m = IntigoZoneIndex::matchZone($text, $city_key);
        if ($m === null) {
            // No délégation/cité named verbatim. Let the guesser try (it is now
            // fenced inside this governorate and so cannot wander to Kef); resolve()
            // comes back for governorateOnly() only if that fails too.
            return null;
        }

        // Names matched locally; every ID below comes from the LIVE API so a
        // server-side renumbering can never make us ship a stale zone.
        $cityRes = $this->api->resolveCityNameToId($m['city']);
        $city_id = (int) $cityRes['id'];
        if ($city_id <= 0) {
            return null;
        }
        $district_id = 0;
        $dres = $this->api->fetchDistricts($city_id, '');
        if (!empty($dres['ok'])) {
            foreach ($dres['items'] as $d) {
                if (IntigoZoneIndex::squash($d['name']) === IntigoZoneIndex::squash($m['district'])) {
                    $district_id = (int) $d['id'];
                    break;
                }
            }
        }
        if ($district_id <= 0) {
            return null;
        }
        $neighborhood_id = 0;
        $neighborhood_name = '';
        if ($m['neighborhood'] !== '') {
            $nres = $this->api->fetchNeighborhoods($district_id);
            if (!empty($nres['ok'])) {
                foreach ($nres['items'] as $n) {
                    if (IntigoZoneIndex::squash($n['name']) === $m['neighborhood']) {
                        $neighborhood_id = (int) $n['id'];
                        $neighborhood_name = (string) $n['name'];
                        break;
                    }
                }
            }
        }

        // GREEN only when the governorate came from a real field AND a place name
        // inside it was written verbatim by the customer. That is corroboration,
        // not ranking — it replaces the old `dispersion === 1` gate, which measured
        // the search index's noise and was almost never true for a real address.
        // An unscoped match (no État, no Ville) stays REVIEW: it rests on the whole
        // country agreeing, which is good evidence but not a stated governorate.
        $green = $m['scoped'];

        return [
            'ok' => true,
            'tier' => $green ? self::TIER_GREEN : self::TIER_REVIEW,
            'city_id' => $city_id,
            'city_name' => (string) $m['city'],
            'district_id' => $district_id,
            'district_name' => (string) $m['district'],
            'neighborhood_id' => $neighborhood_id,
            'neighborhood_name' => $neighborhood_name,
            'query' => $text,
            'dispersion' => 1,
            'city_agrees' => true,
            'match_rule' => 'exact_local_' . $city_from,
            'reason' => '',
        ];
    }

    /**
     * The governorate alone, when the État or Ville field names one but nothing
     * identifies the délégation. Deliberately NOT sendable (district stays 0) —
     * but the merchant then picks the délégation from a 9-23 entry dropdown
     * instead of retyping the whole zone. Returns null when there is no such
     * field, so a blank order still blocks outright.
     */
    private function governorateOnly($city, $state)
    {
        if (!class_exists('IntigoZoneIndex')) {
            return null;
        }
        $city_key = IntigoZoneIndex::matchCityField($state);
        $from = 'etat';
        if ($city_key === '') {
            $city_key = IntigoZoneIndex::matchCityField($city);
            $from = 'ville';
        }
        if ($city_key === '') {
            return null;
        }
        $name = (string) IntigoZoneIndex::data()[$city_key][0];
        $cityRes = $this->api->resolveCityNameToId($name);
        if ((int) $cityRes['id'] <= 0) {
            return null;
        }
        $r = $this->blocked('district_not_named', trim($city . ' ' . $state));
        $r['city_id'] = (int) $cityRes['id'];
        $r['city_name'] = $name;
        $r['city_agrees'] = true;
        $r['match_rule'] = 'city_field_' . $from;
        return $r;
    }

    /**
     * Resolve free-text → zone + confidence tier. Pure (no persistence).
     *
     * $state is the PrestaShop État (id_state) name. Merchants fill in either the
     * Ville or the État — both are accepted as the governorate.
     *
     * Order of attempts, strongest evidence first:
     *   1. EXACT match of a délégation/cité name in the street text, inside the
     *      governorate the État/Ville field states;
     *   2. the fuzzy guesser, fenced inside that same governorate;
     *   3. the governorate alone — not sendable, but the merchant only picks the
     *      délégation.
     * Anything else blocks. No step may invent a governorate.
     */
    public function resolve($address1, $city, $postcode = '', $state = '')
    {
        // Exact match against Intigo's own place list first — deterministic, and
        // it cannot invent a governorate the way the fuzzy guesser can.
        $local = $this->resolveLocally($address1, $city, $state, $postcode);
        if ($local !== null) {
            return $local;
        }

        // The État stands in for the Ville everywhere below, so an address with an
        // empty Ville still has a governorate to anchor and cross-check against.
        if (trim((string) $city) === '') {
            $city = (string) $state;
        }
        if ($this->buildQuery($address1, $city) === '') {
            return $this->refuse('empty_address', '', $city, $state);
        }

        $psCity = IntigoApiClient::normalizeName($city);
        $hasLocality = ($this->cleanAddress($address1) !== '');

        // Everything the customer wrote, normalised — used to confirm a candidate's
        // delegation is actually named in the address.
        $haystack = IntigoApiClient::normalizeName($this->cleanAddress($address1) . ' ' . $city);

        // Query list, CLEANEST first: the locality after the postal code, then the
        // full cleaned line, then the bare city. Gathering candidates from all of
        // them means the right delegation surfaces even when the noisy full line
        // alone would bury it.
        // In PrestaShop the postal code lives in its OWN field, not inside the
        // address line — so inject it as a delimiter ("<street> <postcode> <city>")
        // to let localityAfterPostal isolate the real locality (the city), which the
        // guesser resolves far better than the noisy street ("des jasmins" → wrongly
        // "des jardins / Jendouba").
        $postalText = trim($address1 . ' ' . trim((string) $postcode) . ' ' . $city);
        $queries = [];
        foreach ([$this->localityAfterPostal($postalText),
                  $this->buildQuery($address1, $city),
                  trim((string) $city)] as $q) {
            $q = trim((string) $q);
            if ($q !== '' && !in_array($q, $queries, true)) {
                $queries[] = $q;
            }
        }

        $candidates = [];
        $seen = [];
        foreach ($queries as $q) {
            $r = $this->api->searchLocations($q);
            if (empty($r['ok'])) {
                continue;
            }
            foreach ((array) $r['items'] as $it) {
                $key = (int) $it['neighborhood_id'] . '|' . IntigoApiClient::normalizeName($it['district_name']);
                if (!isset($seen[$key])) {
                    $seen[$key] = true;
                    $candidates[] = $it;
                }
            }
        }
        if (empty($candidates)) {
            return $this->refuse('no_match', implode(' | ', $queries), $city, $state);
        }

        // When the order states a governorate (État or Ville), the guesser is not
        // allowed to leave it. This is what makes the Kef/Kasserine class of
        // misroute impossible on the fallback path too: a Tunis address can only
        // ever resolve to a Tunis delegation, whatever the search index ranks.
        if (class_exists('IntigoZoneIndex')) {
            $ck = IntigoZoneIndex::matchCityField($state);
            if ($ck === '') {
                $ck = IntigoZoneIndex::matchCityField($city);
            }
            if ($ck !== '') {
                $canon = IntigoApiClient::normalizeName(IntigoZoneIndex::data()[$ck][0]);
                $inside = [];
                foreach ($candidates as $it) {
                    if (IntigoApiClient::normalizeName($it['city_name']) === $canon) {
                        $inside[] = $it;
                    }
                }
                if (empty($inside)) {
                    return $this->refuse('outside_stated_city', implode(' | ', $queries), $city, $state);
                }
                $candidates = $inside;
            }
        }
        $query = $queries[0];

        // Dispersion across the leading candidates (kept for the GREEN tier gate).
        $cities = [];
        foreach (array_slice($candidates, 0, 5) as $it) {
            $cn = IntigoApiClient::normalizeName($it['city_name']);
            if ($cn !== '') {
                $cities[$cn] = true;
            }
        }
        $dispersion = count($cities);

        // Selection, strongest signal first:
        //   1. a candidate whose DELEGATION is named in the address (address says
        //      "el menzah" and the delegation is "El Menzah") — decisive, and what
        //      rejects far-away "Cité des Jardins / Ghardimaou" mismatches;
        //   2. a candidate whose NEIGHBOURHOOD is named in the address;
        //   3. a candidate in the governorate the order's city resolves to;
        //   4. the nearest (first) candidate.
        $chosen = null;
        $match_rule = '';
        foreach ($candidates as $it) {
            $d = IntigoApiClient::normalizeName($it['district_name']);
            if ($d !== '' && strlen($d) >= 4 && strpos($haystack, $d) !== false) {
                $chosen = $it;
                $match_rule = 'district_text';
                break;
            }
        }
        if ($chosen === null) {
            foreach ($candidates as $it) {
                $n = IntigoApiClient::normalizeName($it['neighborhood_name']);
                if ($n !== '' && strlen($n) >= 5 && strpos($haystack, $n) !== false) {
                    $chosen = $it;
                    $match_rule = 'neighborhood_text';
                    break;
                }
            }
        }
        if ($chosen === null && $psCity !== '') {
            foreach ($candidates as $it) {
                if (IntigoApiClient::normalizeName($it['city_name']) === $psCity) {
                    $chosen = $it;
                    $match_rule = 'city_equal';
                    break;
                }
            }
        }
        if ($chosen === null) {
            // Nothing the customer wrote corroborates ANY candidate — the guesser's
            // top hit is then a pure fuzzy guess and is routinely far away
            // ("55 rue du 1er juin, Mutuelleville" → "Cité 1er Mai / Le Kef Est /
            // Kef", because Mutuelleville is absent from the index and "1er"
            // matches "1er Mai"). Never guess a destination: refuse, and let the
            // deterministic postal-code path or the merchant decide.
            return $this->refuse('no_confident_match', $query, $city, $state);
        }

        // city_name → city_id (the fuzzy step; may fail to resolve).
        $district_id = (int) $chosen['district_id'];
        $cityRes = $this->api->resolveCityNameToId($chosen['city_name']);
        $city_id = (int) $cityRes['id'];

        // Coherence decides only whether the IDs are SAFE TO SEND on the standard
        // path — NOT whether we surface the match. We keep the IDs only when the
        // city resolved AND the district belongs to it; otherwise we still return
        // the nearest NAMES (so the merchant sees the detected zone) with null IDs,
        // and the postal-code path or a manual confirm handles the actual send.
        $coherent = ($city_id > 0
            && ($district_id <= 0 || $this->api->districtBelongsToCity($district_id, $city_id)));

        // City cross-check as a BOOSTER (only meaningful with a usable city_id).
        // A garbage/unknown city field ("tunisia", a postcode, empty) is neutral.
        $psCityId = 0;
        if ($psCity !== '') {
            $cmap = $this->api->cityNameToIdMap();
            $psCityId = isset($cmap[$psCity]) ? (int) $cmap[$psCity] : 0;
        }
        $cityConflict = ($coherent && $psCityId > 0 && $psCityId !== $city_id);
        $cityAgrees = ($coherent && $psCityId > 0 && $psCityId === $city_id);

        // GREEN (auto-send eligible): coherent IDs + a single city + an exact city
        // match + a real district + an address locality + no city conflict. Every
        // other result that still has a candidate is REVIEW — auto-filled with the
        // nearest zone, flagged for a human glance (never silently shipped).
        // GREEN needs CORROBORATION, not ranking: the customer must have written the
        // delegation or the neighbourhood themselves. `dispersion` used to stand in
        // for this, but it counts distinct cities among the top hits — a property of
        // the search index, not of our answer (q=Tunis ranks Sfax first), and since
        // candidates are now fenced to the stated governorate it would be 1 almost
        // always. `city_equal` proves only the governorate, so it stays REVIEW.
        $tier = self::TIER_REVIEW;
        if ($coherent && $district_id > 0 && $hasLocality && !$cityConflict
            && !empty($cityRes['exact'])
            && in_array($match_rule, ['district_text', 'neighborhood_text'], true)) {
            $tier = self::TIER_GREEN;
        }

        return [
            'ok' => true,
            'tier' => $tier,
            'city_id' => $coherent ? $city_id : 0,
            'city_name' => (string) $chosen['city_name'],
            'district_id' => $coherent ? $district_id : 0,
            'district_name' => (string) $chosen['district_name'],
            'neighborhood_id' => $coherent ? (int) $chosen['neighborhood_id'] : 0,
            'neighborhood_name' => (string) $chosen['neighborhood_name'],
            'query' => $query,
            'dispersion' => $dispersion,
            'city_agrees' => $cityAgrees,
            'match_rule' => 'guesser_' . $match_rule,
            'reason' => $coherent ? '' : 'nearest_unverified',
        ];
    }

    /**
     * Resolve from a PS Order and persist onto its parcel row. Never clobbers a
     * merchant's manual entry. Returns the resolution result array.
     */
    public function resolveAndStore(Order $order, $force = false)
    {
        $parcel = IntigoParcel::findByOrderId((int) $order->id);

        // Already sent: a PASSIVE re-detect changes nothing, since the zone is frozen
        // at Intigo. An EXPLICIT one (the merchant clicked "Re-détecter") is allowed
        // so a wrongly-zoned parcel can be corrected locally and then recreated with
        // "Renvoyer" — the merchant asked for this to stay available after sending.
        $already_sent = $parcel && trim((string) $parcel->nid) !== '';
        if (!$force && $already_sent) {
            return ['ok' => true, 'tier' => 'sent', 'skipped' => true];
        }
        // Respect a manual override — don't auto-overwrite what a human entered.
        // A forced re-detect (merchant clicked "Re-détecter") bypasses this.
        if (!$force && $parcel && ($parcel->resolution_source === 'manual' || (int) $parcel->auto_resolved === 0)
            && (int) $parcel->destination_city_id > 0 && (int) $parcel->destination_district_id > 0) {
            return ['ok' => true, 'tier' => 'manual', 'skipped' => true];
        }

        $address1 = '';
        $city = '';
        $state = '';
        $postcode = '';
        if ((int) $order->id_address_delivery > 0) {
            $address = new Address((int) $order->id_address_delivery);
            if (Validate::isLoadedObject($address)) {
                $address1 = trim((string) $address->address1 . ' ' . (string) $address->address2);
                $city = (string) $address->city;
                $state = self::stateName($address);
                $postcode = (string) $address->postcode;
            }
        }

        // A delivery address saved without a Ville leaves nothing to verify against
        // (real client case: "55, rue du 1er juin. Mutuelleville, 1082" with an
        // empty Ville and the governorate in the État field instead). Fall back to
        // the invoice address of the SAME order for whichever field is blank —
        // never a guess, always the customer's own data.
        if ((int) $order->id_address_invoice > 0
            && (trim($city) === '' || trim($state) === '' || trim($postcode) === '')) {
            $inv = new Address((int) $order->id_address_invoice);
            if (Validate::isLoadedObject($inv)) {
                if (trim($city) === '') {
                    $city = (string) $inv->city;
                }
                if (trim($state) === '') {
                    $state = self::stateName($inv);
                }
                if (trim($postcode) === '') {
                    $postcode = (string) $inv->postcode;
                }
            }
        }

        $result = $this->resolve($address1, $city, $postcode, $state);

        $parcel = $parcel ?: new IntigoParcel();
        $parcel->id_order = (int) $order->id;
        $parcel->pickup_index = $this->computePickupIndex($order);
        $parcel->resolved_from = substr(trim($address1 . ' | ' . $city), 0, 255);
        $parcel->resolution_source = 'guesser';
        $parcel->auto_resolved = 1;
        $parcel->last_resolution_at = date('Y-m-d H:i:s');
        $parcel->resolution_confidence = $result['tier'];
        if (!empty($result['ok'])) {
            $parcel->destination_city_id = (int) $result['city_id'];
            $parcel->destination_district_id = (int) $result['district_id'];
            $parcel->destination_neighborhood_id = (int) $result['neighborhood_id'];
            $parcel->destination_city_name = (string) $result['city_name'];
            $parcel->destination_district_name = (string) $result['district_name'];
            $parcel->resolution_status = ($result['tier'] === self::TIER_GREEN) ? 'resolved' : 'review';
        } elseif ($already_sent) {
            // Keep the zone actually sent to Intigo on record — never blank the
            // history of a parcel that already exists there.
            $parcel->resolution_status = 'blocked';
        } else {
            // Clear any zone a previous (guessing) resolution left behind, so a
            // stale wrong zone can never be sent once we've refused to confirm it.
            // Manual entries never reach here — they returned early above.
            // EXCEPTION: a governorate confirmed from the État/Ville field is kept
            // (city_id set, district still 0). The order stays unsendable, but the
            // merchant only has to pick the délégation instead of the whole zone.
            $parcel->destination_city_id = (int) $result['city_id'];
            $parcel->destination_district_id = 0;
            $parcel->destination_neighborhood_id = 0;
            $parcel->destination_city_name = (string) $result['city_name'];
            $parcel->destination_district_name = '';
            $parcel->resolution_status = 'blocked';
        }
        $parcel->save();

        if (class_exists('IntigoLog')) {
            IntigoLog::add('address_resolved', 'id_order=' . (int) $order->id
                . ' tier=' . $result['tier']
                . ' city=' . (isset($result['city_name']) ? $result['city_name'] : '')
                . ' district=' . (isset($result['district_name']) ? $result['district_name'] : '')
                . ' q=' . (isset($result['query']) ? $result['query'] : '')
                . (empty($result['ok']) ? ' reason=' . $result['reason'] : ''));
        }
        return $result;
    }

    /**
     * The pickup index this order would ship from — same STRICT resolution as the
     * push: per-order override → status-mapped address → -1 (none). No default/
     * primary fallback (removed with INTIGO_DEFAULT_PICKUP_INDEX). Stored on the
     * parcel so the Orders "Adresse de ramassage" filter works.
     */
    private function computePickupIndex(Order $order)
    {
        $parcel = IntigoParcel::findByOrderId((int) $order->id);
        if ($parcel && $parcel->pickup_override_index !== null && (int) $parcel->pickup_override_index >= 1) {
            return (int) $parcel->pickup_override_index;
        }
        if (!class_exists('IntigoPickupMap')) {
            @include_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoPickupMap.php';
        }
        if (class_exists('IntigoPickupMap')) {
            $idx = IntigoPickupMap::resolvePickupIndex((int) $order->id_shop ?: 1, (int) $order->getCurrentState());
            if ($idx !== null && (int) $idx >= 1) {
                return (int) $idx;
            }
        }
        return -1;
    }

    /**
     * The État (state) of a PrestaShop address, '' when the country has no states
     * or none was picked. Tunisian shops that enable states list the governorates
     * there — the same 24 names Intigo uses for its cities.
     */
    public static function stateName($address)
    {
        if (!$address || (int) $address->id_state <= 0) {
            return '';
        }
        $state = new State((int) $address->id_state);
        return Validate::isLoadedObject($state) ? trim((string) $state->name) : '';
    }

    /**
     * Refuse a send, but hand back the governorate when the État or Ville field
     * names one — a blocked order with the Ville already filled costs the merchant
     * one dropdown, not a whole zone lookup.
     */
    private function refuse($reason, $query, $city, $state)
    {
        $partial = $this->governorateOnly($city, $state);
        if ($partial !== null) {
            $partial['query'] = $query;
            return $partial;
        }
        return $this->blocked($reason, $query);
    }

    private function blocked($reason, $query)
    {
        return [
            'ok' => false,
            'tier' => self::TIER_BLOCKED,
            'city_id' => 0, 'city_name' => '',
            'district_id' => 0, 'district_name' => '',
            'neighborhood_id' => 0, 'neighborhood_name' => '',
            'query' => $query,
            'dispersion' => 0,
            'city_agrees' => false,
            'reason' => $reason,
        ];
    }
}
