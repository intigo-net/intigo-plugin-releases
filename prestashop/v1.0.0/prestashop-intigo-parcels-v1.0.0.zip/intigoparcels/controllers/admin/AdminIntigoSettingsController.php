<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Intigo → Settings (legacy ModuleAdminController — portable across PS 1.7/8/9).
 * Connection, order-processing mode, default size, cron token + a connection test.
 */
class AdminIntigoSettingsController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        $this->display = 'view';
        parent::__construct();
        $this->meta_title = 'Intigo — Settings';
        // Hide PrestaShop's default "Afficher" page-header toolbar; our in-page
        // nav bar + breadcrumb already identify the screen (cleaner header).
        $this->show_page_header_toolbar = false;
    }

    public function initContent()
    {
        parent::initContent();
        try {
            if (Tools::isSubmit('submitIntigoSettings')) {
                $this->handleSave();
            } elseif (Tools::isSubmit('intigo_test_connection')) {
                $this->handleTest();
            }
            $this->content = $this->render();
        } catch (Exception $e) {
            IntigoLog::add('settings_error', $e->getMessage());
            $this->content = '<div class="alert alert-warning">Intigo settings are temporarily unavailable.</div>';
        }
        $this->context->smarty->assign('content', $this->content);
    }

    private function handleSave()
    {
        $env = Tools::getValue('INTIGO_ENVIRONMENT') === 'production' ? 'production' : 'sandbox';
        Configuration::updateValue('INTIGO_ENVIRONMENT', $env);
        Configuration::updateValue('INTIGO_API_KEY', trim((string) Tools::getValue('INTIGO_API_KEY')));
        Configuration::updateValue('INTIGO_FALLBACK_ENABLED', Tools::getValue('INTIGO_FALLBACK_ENABLED') ? '1' : '0');
        Configuration::updateValue('INTIGO_AUTO_CREATE', Tools::getValue('INTIGO_AUTO_CREATE') ? '1' : '0');
        Configuration::updateValue('INTIGO_DEFAULT_SIZE', IntigoApiClient::normalizeSizeLetter(Tools::getValue('INTIGO_DEFAULT_SIZE'), 'S'));

        // Tracking URL → applied to the live carrier so customers see it.
        $tracking = trim((string) Tools::getValue('INTIGO_TRACKING_URL'));
        Configuration::updateValue('INTIGO_TRACKING_URL', $tracking);
        $cid = (int) Configuration::get('INTIGO_CARRIER_ID');
        if ($cid > 0) {
            $carrier = new Carrier($cid);
            if (Validate::isLoadedObject($carrier)) {
                $carrier->url = $tracking;
                $carrier->update();
            }
        }

        // Per-size shipping prices (the carrier charges by resolved package size).
        foreach (['S', 'M', 'L', 'XL'] as $s) {
            $v = (float) str_replace(',', '.', (string) Tools::getValue('INTIGO_PRICE_' . $s));
            Configuration::updateValue('INTIGO_PRICE_' . $s, $v < 0 ? 0 : $v);
        }

        IntigoLog::add('settings_save', 'env=' . $env);
        $this->redirectWithNotice('Settings saved.', 'success');
    }

    private function handleTest()
    {
        $api = new IntigoApiClient();
        $res = $api->healthCheck();
        IntigoLog::add($res['ok'] ? 'health_ok' : 'health_failed', (string) $res['message']);
        $this->redirectWithNotice(
            ($res['ok'] ? 'Connection OK — ' : 'Connection failed — ') . (string) $res['message'],
            $res['ok'] ? 'success' : 'error'
        );
    }

    private function redirectWithNotice($message, $type)
    {
        Tools::redirectAdmin(
            self::$currentIndex . '&token=' . $this->token
            . '&intigo_notice=' . rawurlencode($message)
            . '&intigo_notice_type=' . rawurlencode($type)
        );
    }

    private function render()
    {
        $env = Configuration::get('INTIGO_ENVIRONMENT') === 'production' ? 'production' : 'sandbox';
        $api_key = (string) Configuration::get('INTIGO_API_KEY');
        $fallback = (string) Configuration::get('INTIGO_FALLBACK_ENABLED') === '1';
        $auto = (string) Configuration::get('INTIGO_AUTO_CREATE') === '1';
        $size = IntigoApiClient::normalizeSizeLetter(Configuration::get('INTIGO_DEFAULT_SIZE'), 'S');
        $tracking = (string) Configuration::get('INTIGO_TRACKING_URL');
        $cron_token = (string) Configuration::get('INTIGO_CRON_TOKEN');
        $price = function ($k) {
            $v = (float) Configuration::get('INTIGO_PRICE_' . $k);
            return rtrim(rtrim(number_format($v, 3, '.', ''), '0'), '.');
        };
        $currency = 'TND';
        $cur = Currency::getDefaultCurrency();
        if (Validate::isLoadedObject($cur)) {
            $currency = $cur->sign ? $cur->sign : $cur->iso_code;
        }
        $action = self::$currentIndex . '&token=' . $this->token;

        $notice = (string) Tools::getValue('intigo_notice');
        $ntype = (string) Tools::getValue('intigo_notice_type');
        $alert = $ntype === 'success' ? 'success' : ($ntype === 'error' ? 'danger' : 'info');

        $checked = function ($cond) {
            return $cond ? ' checked' : '';
        };
        $sel = function ($cond) {
            return $cond ? ' selected' : '';
        };

        $h = '<div class="intigo-screen intigo-form">';
        $h .= IntigoAdminUi::navHtml($this->context->link, 'settings');
        $h .= IntigoAdminUi::noticeToast();

        $h .= '<form method="post" action="' . htmlspecialchars($action) . '" class="form-horizontal">';

        // Connection
        $h .= '<div class="card"><div class="card-header"><h3 class="card-header-title">' . IntigoAdminUi::t('Connection') . '</h3></div><div class="card-body">';
        $h .= '<div class="form-group"><label class="control-label col-lg-3">' . IntigoAdminUi::t('Environment') . '</label><div class="col-lg-7">'
            . '<label class="radio-inline"><input type="radio" name="INTIGO_ENVIRONMENT" value="sandbox"' . $checked($env === 'sandbox') . '> Sandbox <small>(dev-api.intigo.net)</small></label> '
            . '<label class="radio-inline"><input type="radio" name="INTIGO_ENVIRONMENT" value="production"' . $checked($env === 'production') . '> Production <small>(api.intigo.net)</small></label>'
            . '<p class="help-block">En <strong>Sandbox</strong>, les colis sont créés dans le tableau de bord partenaire de test '
            . '<a href="https://partner-staging.intigo.net/" target="_blank" rel="noopener">partner-staging.intigo.net</a> — pas en production.</p>'
            . '</div></div>';
        $h .= '<div class="form-group"><label class="control-label col-lg-3">' . IntigoAdminUi::t('API key') . '</label><div class="col-lg-7">'
            . '<input type="text" name="INTIGO_API_KEY" class="form-control" autocomplete="off" value="' . htmlspecialchars($api_key) . '">'
            . '<p class="help-block">Envoyé dans l\'en-tête X-API-KEY à chaque appel à l\'API.</p></div></div>';
        $h .= '<div class="form-group"><label class="control-label col-lg-3">' . IntigoAdminUi::t('Tracking URL') . '</label><div class="col-lg-7">'
            . '<input type="text" name="INTIGO_TRACKING_URL" class="form-control" value="' . htmlspecialchars($tracking) . '" placeholder="https://play.google.com/store/apps/details?id=net.intigo.client">'
            . '<p class="help-block">Affiché aux clients sur le transporteur Intigo. Par défaut, pointe vers l\'application Intigo sur Google Play.</p></div></div>';
        $h .= '<div class="form-group"><label class="control-label col-lg-3">' . IntigoAdminUi::t('Legacy fallback') . '</label><div class="col-lg-7">'
            . '<label class="checkbox-inline"><input type="checkbox" name="INTIGO_FALLBACK_ENABLED" value="1"' . $checked($fallback) . '> Réessayer les anciens points d\'accès en cas d\'échec (hors authentification)</label></div></div>';
        $h .= '<div class="form-group"><div class="col-lg-offset-3 col-lg-7">'
            . '<button type="submit" name="intigo_test_connection" value="1" class="btn btn-outline-secondary btn-sm"><i class="icon-flash"></i> ' . IntigoAdminUi::t('Test connection') . '</button></div></div>';
        $h .= '</div></div>';

        // Order processing
        $h .= '<div class="card"><div class="card-header"><h3 class="card-header-title">' . IntigoAdminUi::t('Order processing') . '</h3></div><div class="card-body">';
        $h .= '<div class="form-group"><label class="control-label col-lg-3">' . IntigoAdminUi::t('Mode') . '</label><div class="col-lg-7">'
            . '<label class="radio-inline"><input type="radio" name="INTIGO_AUTO_CREATE" value="0"' . $checked(!$auto) . '> Manuel — envoyer chaque commande depuis l\'écran Commandes</label><br>'
            . '<label class="radio-inline"><input type="radio" name="INTIGO_AUTO_CREATE" value="1"' . $checked($auto) . '> Automatique — envoyer à Intigo dès que la commande est payée</label>'
            . '</div></div></div></div>';

        // Defaults
        $h .= '<div class="card"><div class="card-header"><h3 class="card-header-title">' . IntigoAdminUi::t('Defaults') . '</h3></div><div class="card-body">';
        $h .= '<div class="form-group"><label class="control-label col-lg-3">' . IntigoAdminUi::t('Default package size') . '</label><div class="col-lg-3"><select name="INTIGO_DEFAULT_SIZE" class="form-control">';
        foreach (['S', 'M', 'L', 'XL'] as $s) {
            $h .= '<option value="' . $s . '"' . $sel($size === $s) . '>' . $s . '</option>';
        }
        $h .= '</select><p class="help-block">Utilisé lorsqu\'un produit n\'a pas de taille spécifique.</p></div></div>';

        // Per-size shipping prices — the carrier charges by the order's resolved size.
        $h .= '<hr><div class="form-group"><label class="control-label col-lg-3">' . IntigoAdminUi::t('Shipping price per size') . '</label><div class="col-lg-9">';
        $h .= '<p class="help-block">Le transporteur Intigo facture selon la taille du colis — déterminée par la taille Intigo de chaque produit (définie dans <strong>Tailles produits</strong>), agrégée au plus grand article, avec repli sur la taille par défaut ci-dessus. Saisissez vos tarifs Intigo négociés.</p>';
        foreach (['S', 'M', 'L', 'XL'] as $s) {
            $h .= '<div class="row" style="margin-bottom:6px;"><div class="col-lg-2"><label style="font-weight:600;padding-top:7px;">Taille ' . $s . '</label></div>'
                . '<div class="col-lg-4"><div class="input-group">'
                . '<input type="text" name="INTIGO_PRICE_' . $s . '" class="form-control" value="' . htmlspecialchars($price($s)) . '">'
                . '<span class="input-group-addon">' . htmlspecialchars($currency) . '</span></div></div></div>';
        }
        $h .= '</div></div>';
        $h .= '</div><div class="card-footer text-right"><button type="submit" name="submitIntigoSettings" value="1" class="btn btn-primary">' . IntigoAdminUi::t('Save') . '</button></div></div>';

        $h .= '</form>';

        // Cron
        $h .= '<div class="card"><div class="card-header"><h3 class="card-header-title">' . IntigoAdminUi::t('Cron / status sync') . '</h3></div><div class="card-body">'
            . '<p class="text-muted mb-1">Jeton cron</p><pre><code>' . htmlspecialchars($cron_token) . '</code></pre>'
            . '<p class="text-muted"><small>Le point d\'accès de synchronisation arrive avec le moteur de synchro des statuts.</small></p></div></div>';

        $h .= '</div>'; // .intigo-screen

        return $h;
    }
}
