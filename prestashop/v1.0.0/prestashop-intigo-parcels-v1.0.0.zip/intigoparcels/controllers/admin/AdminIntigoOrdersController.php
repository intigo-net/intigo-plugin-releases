<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Intigo Orders — central list of every order that used the Intigo Delivery
 * carrier, with parcel status and inline actions, PLUS a dedicated edit page
 * (?a=edit&id_order=X) for setting city/district/neighborhood/phone/etc.
 *
 * Lives entirely inside our own controller so it renders 100% reliably,
 * unlike the BO order view's side/tab hooks which PS 8.x sometimes drops.
 */
class AdminIntigoOrdersController extends ModuleAdminController
{
    const PER_PAGE = 25;

    public function __construct()
    {
        $this->bootstrap = true;
        $this->display = 'view';
        parent::__construct();
        $this->meta_title = 'Intigo — Manage Orders';
        $this->show_page_header_toolbar = false;
    }

    public function initContent()
    {
        $action = (string) Tools::getValue('a');
        if ($action === 'edit') {
            $this->renderEditPage();
        } else {
            $this->renderListPage();
        }
        parent::initContent();
    }

    /* ---------------- LIST view ---------------- */

    private function renderListPage()
    {
        $intigo_carrier_id = (int) Configuration::get('INTIGO_CARRIER_ID');
        $has_api_key = trim((string) Configuration::get('INTIGO_API_KEY')) !== '';
        $page = max(1, (int) Tools::getValue('p', 1));
        $filter = (string) Tools::getValue('f', '');

        // Show ALL recent orders (like the Shopify app) — a merchant can ship any
        // order via Intigo, not only ones where the customer happened to pick the
        // Intigo carrier at checkout. The carrier filter is now an opt-in tab.
        $where = '1';
        if ($filter === 'pending') {
            $where = '(p.nid IS NULL OR p.nid = "")';
        } elseif ($filter === 'synced') {
            $where = 'p.nid IS NOT NULL AND p.nid <> ""';
        } elseif ($filter === 'failed') {
            $where = 'p.last_error IS NOT NULL AND p.last_error <> "" AND (p.nid IS NULL OR p.nid = "")';
        } elseif ($filter === 'intigo') {
            $where = 'o.id_carrier = ' . $intigo_carrier_id;
        }

        $orders_in_shop = (int) Db::getInstance()->getValue(
            'SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'orders`'
        );
        $total = (int) Db::getInstance()->getValue(
            'SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'orders` o
            LEFT JOIN `' . _DB_PREFIX_ . 'intigo_parcel` p ON o.id_order = p.id_order
            WHERE ' . $where
        );
        $pages = max(1, (int) ceil($total / self::PER_PAGE));
        $offset = ($page - 1) * self::PER_PAGE;

        $rows = Db::getInstance()->executeS(
            'SELECT o.id_order, o.reference, o.total_paid_tax_incl, o.date_add, o.id_carrier,
                    a.firstname, a.lastname, a.city,
                    c.name AS carrier_name,
                    p.nid, p.status_code, p.last_attempt_at, p.last_error, p.bordereau_url,
                    p.destination_city_id, p.destination_district_id
             FROM `' . _DB_PREFIX_ . 'orders` o
             LEFT JOIN `' . _DB_PREFIX_ . 'intigo_parcel` p ON o.id_order = p.id_order
             LEFT JOIN `' . _DB_PREFIX_ . 'address` a ON o.id_address_delivery = a.id_address
             LEFT JOIN `' . _DB_PREFIX_ . 'carrier` c ON o.id_carrier = c.id_carrier
             WHERE ' . $where . '
             ORDER BY o.id_order DESC
             LIMIT ' . self::PER_PAGE . ' OFFSET ' . $offset
        );
        $rows = is_array($rows) ? $rows : [];

        $base_url = self::$currentIndex . '&token=' . $this->token;
        $action_url = $this->context->link->getAdminLink('AdminIntigoOrderAction');
        $settings_url = $this->context->link->getAdminLink('AdminIntigoSettings');

        $notice = (string) Tools::getValue('intigo_notice');
        $notice_type = (string) Tools::getValue('intigo_notice_type');
        $alert_class = $notice_type === 'success' ? 'success'
            : ($notice_type === 'error' ? 'danger'
            : ($notice_type === 'warning' ? 'warning' : 'info'));

        $h = '<div class="intigo-screen">';
        $h .= IntigoAdminUi::navHtml($this->context->link, 'orders');

        $h .= IntigoAdminUi::noticeToast();
        $notice_bordereau = (string) Tools::getValue('intigo_bordereau_url');
        if ($notice_bordereau !== '') {
            $h .= '<div class="alert alert-success" style="display:flex;align-items:center;gap:10px;flex-wrap:wrap;">'
                . '<i class="material-icons">picture_as_pdf</i><strong>' . IntigoAdminUi::t('Bordereau ready.') . '</strong>'
                . '<a href="' . htmlspecialchars($notice_bordereau) . '" target="_blank" rel="noopener" class="btn btn-primary btn-sm">' . IntigoAdminUi::t('Open bordereau') . '</a>'
                . '<button type="button" class="btn btn-default btn-sm intigo-copy" data-copy="' . htmlspecialchars($notice_bordereau) . '">' . IntigoAdminUi::t('Copy link') . '</button>'
                . '<span class="text-muted" style="word-break:break-all;font-size:12px;">' . htmlspecialchars($notice_bordereau) . '</span>'
                . '</div>';
        }
        if (!$has_api_key) {
            $h .= '<div class="alert alert-warning"><strong>' . IntigoAdminUi::t('API key required.') . '</strong> '
                . IntigoAdminUi::t('Add your Intigo API key before pushing parcels.') . ' '
                . '<a href="' . htmlspecialchars($settings_url) . '">' . IntigoAdminUi::t('Go to Settings') . '</a></div>';
        }

        // No orders in the whole shop yet → guide the merchant.
        if ($orders_in_shop === 0) {
            $h .= '<div class="card"><div class="card-body">';
            $h .= IntigoAdminUi::emptyState(
                'inbox',
                'No orders yet',
                'When customers place orders in your shop, they appear here so you can ship them with Intigo. '
                . 'Start by adding your API key, then create your first parcel from an order.',
                'Go to Settings',
                $settings_url
            );
            $h .= '</div></div></div>';
            $this->content = $h;
            return;
        }

        $h .= '<div class="card">';
        $h .= '<div class="card-header"><h3 class="card-header-title">'
            . '<i class="material-icons">local_shipping</i> ' . IntigoAdminUi::t('Orders') . ' (' . $total . ')</h3></div>';
        $h .= '<div class="card-body">';

        $tabs = [['', 'All'], ['pending', 'Not synced'], ['synced', 'Synced'], ['failed', 'Failed'], ['intigo', 'Intigo carrier']];
        $h .= '<div style="margin-bottom:12px;">';
        foreach ($tabs as $t) {
            $active = $filter === $t[0] ? ' btn-primary' : ' btn-default';
            $url = $base_url . ($t[0] !== '' ? '&f=' . $t[0] : '');
            $h .= '<a href="' . $url . '" class="btn btn-sm' . $active . '" style="margin-right:4px;">' . IntigoAdminUi::t($t[1]) . '</a>';
        }
        $h .= '</div>';

        // Orders exist but none match the active filter.
        if (empty($rows)) {
            $h .= IntigoAdminUi::emptyState(
                'filter_list',
                'No orders match this filter',
                'Try the <strong>All</strong> tab to see every order.'
            );
            $h .= '</div></div></div>';
            $this->content = $h;
            return;
        }

        $h .= '<table class="table">';
        $h .= '<thead><tr>'
            . '<th>#</th><th>' . IntigoAdminUi::t('Reference') . '</th><th>' . IntigoAdminUi::t('Customer') . '</th><th>' . IntigoAdminUi::t('City') . '</th><th>' . IntigoAdminUi::t('Carrier') . '</th><th>' . IntigoAdminUi::t('Total') . '</th>'
            . '<th>' . IntigoAdminUi::t('Intigo status') . '</th><th>NID</th>'
            . '<th style="white-space:nowrap;">' . IntigoAdminUi::t('Actions') . '</th>'
            . '</tr></thead><tbody>';

        foreach ($rows as $r) {
            $id_order = (int) $r['id_order'];
            $nid = trim((string) $r['nid']);
            $has_nid = $nid !== '';
            $has_bordereau = $has_nid && trim((string) $r['bordereau_url']) !== '';
            $has_error = !$has_nid && trim((string) $r['last_error']) !== '';
            $is_intigo_carrier = (int) $r['id_carrier'] === $intigo_carrier_id;

            // Status badge (Shopify-style state).
            if ($has_bordereau) {
                $status = '<span class="intigo-badge intigo-badge--success">' . IntigoAdminUi::t('Bordereau ready') . '</span>';
            } elseif ($has_nid) {
                $status = '<span class="intigo-badge intigo-badge--info">' . IntigoAdminUi::t('Synced') . '</span>';
            } elseif ($has_error) {
                $status = '<span class="intigo-badge intigo-badge--danger" title="' . htmlspecialchars((string) $r['last_error']) . '">' . IntigoAdminUi::t('Failed') . '</span>';
            } else {
                $status = '<span class="intigo-badge intigo-badge--muted">' . IntigoAdminUi::t('Not synced') . '</span>';
            }

            $carrier_cell = htmlspecialchars((string) $r['carrier_name']);
            if ($is_intigo_carrier) {
                $carrier_cell = '<span class="intigo-badge intigo-badge--info">Intigo</span>';
            }

            $h .= '<tr>';
            $h .= '<td>' . $id_order . '</td>';
            $h .= '<td><code>' . htmlspecialchars((string) $r['reference']) . '</code></td>';
            $h .= '<td>' . htmlspecialchars(trim((string) $r['firstname'] . ' ' . $r['lastname'])) . '</td>';
            $h .= '<td>' . htmlspecialchars((string) $r['city']) . '</td>';
            $h .= '<td>' . $carrier_cell . '</td>';
            $h .= '<td>' . number_format((float) $r['total_paid_tax_incl'], 2) . '</td>';
            $h .= '<td>' . $status . '</td>';
            $h .= '<td>' . ($has_nid
                ? '<code style="font-size:11px;">' . htmlspecialchars($nid) . '</code>'
                : '<span class="text-muted">—</span>') . '</td>';

            $ready = (int) $r['destination_city_id'] > 0 && (int) $r['destination_district_id'] > 0;
            $h .= '<td style="white-space:nowrap;">';
            $edit_url = $base_url . '&a=edit&id_order=' . $id_order;
            // Highlight Edit as the next step when the order still needs data.
            $edit_class = (!$has_nid && !$ready) ? 'btn-primary' : 'btn-default';
            $h .= '<a href="' . $edit_url . '" class="btn ' . $edit_class . ' btn-sm" title="' . IntigoAdminUi::t('Edit Intigo delivery details') . '">' . IntigoAdminUi::t('Edit') . '</a> ';

            // Already-generated bordereau → open it directly + copy link (no re-POST).
            if ($has_bordereau) {
                $burl = htmlspecialchars((string) $r['bordereau_url']);
                $h .= '<a href="' . $burl . '" target="_blank" rel="noopener" class="btn btn-default btn-sm">' . IntigoAdminUi::t('Open bordereau') . '</a> ';
                $h .= '<button type="button" class="btn btn-default btn-sm intigo-copy" data-copy="' . $burl . '" title="' . IntigoAdminUi::t('Copy link') . '">' . IntigoAdminUi::t('Copy') . '</button> ';
            }

            $h .= '<form method="post" action="' . htmlspecialchars($action_url) . '" style="display:inline;">';
            $h .= '<input type="hidden" name="id_order" value="' . $id_order . '">';
            $h .= '<input type="hidden" name="intigo_return" value="orders">';
            if (!$has_nid) {
                if ($ready) {
                    $h .= '<button type="submit" name="intigo_action" value="push" class="btn btn-primary btn-sm" '
                        . 'onclick="return confirm(\'Send order #' . $id_order . ' to Intigo?\');">'
                        . IntigoAdminUi::t('Send to Intigo') . '</button>';
                } else {
                    // Not enough data — explain via tooltip and steer to Edit (the
                    // span carries the title so it shows even though the btn is disabled).
                    $h .= '<span class="intigo-tip" title="' . IntigoAdminUi::t('Add city & district first — click Edit to complete, then Send.') . '">'
                        . '<button type="button" class="btn btn-default btn-sm" disabled style="pointer-events:none;">' . IntigoAdminUi::t('Send to Intigo') . '</button></span>';
                }
            } else {
                if (!$has_bordereau) {
                    $h .= '<button type="submit" name="intigo_action" value="bordereau" class="btn btn-default btn-sm">' . IntigoAdminUi::t('Generate bordereau') . '</button> ';
                }
                $h .= '<button type="submit" name="intigo_action" value="cancel" class="btn btn-danger btn-sm" '
                    . 'onclick="return confirm(\'Cancel parcel ' . htmlspecialchars($nid) . '?\');">' . IntigoAdminUi::t('Cancel') . '</button>';
            }
            $h .= '</form>';
            $h .= '</td>';
            $h .= '</tr>';
        }
        $h .= '</tbody></table>';

        if ($pages > 1) {
            $h .= '<ul class="pagination">';
            for ($i = 1; $i <= $pages; $i++) {
                $url = $base_url . ($filter !== '' ? '&f=' . $filter : '') . '&p=' . $i;
                $cls = $i === $page ? ' class="active"' : '';
                $h .= '<li' . $cls . '><a href="' . $url . '">' . $i . '</a></li>';
            }
            $h .= '</ul>';
        }

        $h .= '<p class="text-muted" style="margin-top:12px;"><small>'
            . '<strong>Astuce :</strong> cliquez sur <em>Modifier</em> sur une commande pour renseigner la ville, le district, le quartier et le destinataire avant l\'envoi à Intigo.'
            . '</small></p>';

        $h .= '</div></div></div>';

        // Copy-to-clipboard for bordereau links (delegated; works for the notice
        // banner and per-row Copy buttons).
        $h .= '<script>document.addEventListener("click",function(e){'
            . 'var b=e.target.closest(".intigo-copy");if(!b){return;}e.preventDefault();'
            . 'var t=b.getAttribute("data-copy")||"";'
            . 'var done=function(){var o=b.textContent;b.textContent="Copied!";setTimeout(function(){b.textContent=o;},1200);};'
            . 'if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(t).then(done,done);}'
            . 'else{var i=document.createElement("input");i.value=t;document.body.appendChild(i);i.select();try{document.execCommand("copy");}catch(err){}i.remove();done();}'
            . '});</script>';

        $this->content = $h;
    }

    /* ---------------- EDIT view ---------------- */

    private function renderEditPage()
    {
        require_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoParcel.php';
        require_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoOrderService.php';

        $id_order = (int) Tools::getValue('id_order');
        $order = new Order($id_order);
        if (!Validate::isLoadedObject($order)) {
            $this->content = '<div class="alert alert-danger">Order #' . $id_order . ' not found</div>'
                . '<a href="' . self::$currentIndex . '&token=' . $this->token . '" class="btn btn-default">← Back to list</a>';
            return;
        }

        $parcel = IntigoParcel::findByOrderId($id_order);
        $svc = new IntigoOrderService();
        // resolveViaApi=false: just prefill the form from the parcel/PS address —
        // do NOT make a network call (city is chosen from the dropdown).
        $preview = $svc->orderToPayload($order, false);

        // Form values: parcel row (if set) > preview from PS address fallback
        $f = [
            'recipient_name' => ($parcel && trim((string) $parcel->recipient_name) !== '')
                ? $parcel->recipient_name : ($preview['recipient_name'] ?? ''),
            'recipient_phone' => ($parcel && trim((string) $parcel->recipient_phone) !== '')
                ? $parcel->recipient_phone : ($preview['phone1'] ?? ''),
            'destination_address' => ($parcel && trim((string) $parcel->destination_address) !== '')
                ? $parcel->destination_address : ($preview['destination_address'] ?? ''),
            'city_id' => $parcel ? (int) $parcel->destination_city_id : (int) ($preview['destination_city_id'] ?? 0),
            'district_id' => $parcel ? (int) $parcel->destination_district_id : 0,
            'neighborhood_id' => $parcel ? (int) $parcel->destination_neighborhood_id : 0,
            'package_size' => $parcel ? ((int) $parcel->package_size ?: 1) : 1,
        ];

        $action_url = $this->context->link->getAdminLink('AdminIntigoOrderAction');
        $list_url = self::$currentIndex . '&token=' . $this->token;
        $regions_url = $this->context->link->getModuleLink('intigoparcels', 'regions', ['action' => 'cities'], true);

        $notice = (string) Tools::getValue('intigo_notice');
        $notice_type = (string) Tools::getValue('intigo_notice_type');
        $alert_class = $notice_type === 'success' ? 'success'
            : ($notice_type === 'error' ? 'danger'
            : ($notice_type === 'warning' ? 'warning' : 'info'));

        $h = '<div class="intigo-screen">';
        $h .= IntigoAdminUi::navHtml($this->context->link, 'orders');
        $h .= '<div class="panel">';
        $h .= '<div class="panel-heading">'
            . '<i class="material-icons">local_shipping</i> '
            . 'Edit Intigo Parcel — Order #' . $id_order . ' (' . htmlspecialchars((string) $order->reference) . ')'
            . '</div>';

        if ($notice !== '') {
            $h .= '<div class="alert alert-' . $alert_class . '">' . htmlspecialchars($notice) . '</div>';
        }

        // Current parcel state banner
        if ($parcel && trim((string) $parcel->nid) !== '') {
            $h .= '<div class="alert alert-success">'
                . '<strong>NID:</strong> <code>' . htmlspecialchars($parcel->nid) . '</code> &nbsp; '
                . '<strong>Status:</strong> ' . (int) $parcel->status_code . ' &nbsp; '
                . '<small>Pushed ' . htmlspecialchars((string) $parcel->last_attempt_at) . ' via ' . htmlspecialchars((string) $parcel->api_target_used) . '</small>'
                . '</div>';
        } elseif ($parcel && trim((string) $parcel->last_error) !== '') {
            $h .= '<div class="alert alert-warning">'
                . '<strong>Last push failed:</strong><br>'
                . '<small><code>' . htmlspecialchars((string) $parcel->last_error) . '</code></small>'
                . '</div>';
        } else {
            $h .= '<div class="alert alert-info">No parcel created yet. Fill the fields and click <strong>Save &amp; Send to Intigo</strong>.</div>';
        }

        // Form
        $h .= '<form method="post" action="' . htmlspecialchars($action_url) . '" class="form-horizontal" id="intigo-edit-form" '
            . 'data-regions-url="' . htmlspecialchars($regions_url) . '">';
        $h .= '<input type="hidden" name="id_order" value="' . $id_order . '">';
        $h .= '<input type="hidden" name="intigo_return" value="orders">';

        $h .= $this->formGroup('Recipient name *', 'recipient_name', 'text', $f['recipient_name'], 'required');
        $h .= $this->formGroup('Phone *', 'recipient_phone', 'tel', $f['recipient_phone'], 'required');
        $h .= $this->formGroupTextarea('Delivery address *', 'destination_address', $f['destination_address']);

        $h .= '<div class="form-group">';
        $h .= '<label class="control-label col-lg-3">City *</label>';
        $h .= '<div class="col-lg-6">';
        $h .= '<select name="destination_city_id" id="intigo-city" class="form-control" data-selected="' . (int) $f['city_id'] . '" required>';
        $h .= '<option value="">— pick a city —</option>';
        $h .= '</select>';
        $h .= '</div></div>';

        $h .= '<div class="form-group">';
        $h .= '<label class="control-label col-lg-3">District *</label>';
        $h .= '<div class="col-lg-6">';
        $h .= '<select name="destination_district_id" id="intigo-district" class="form-control" data-selected="' . (int) $f['district_id'] . '" required disabled>';
        $h .= '<option value="">— pick a city first —</option>';
        $h .= '</select>';
        $h .= '</div></div>';

        $h .= '<div class="form-group">';
        $h .= '<label class="control-label col-lg-3">Neighborhood</label>';
        $h .= '<div class="col-lg-6">';
        $h .= '<select name="destination_neighborhood_id" id="intigo-neighborhood" class="form-control" data-selected="' . (int) $f['neighborhood_id'] . '" disabled>';
        $h .= '<option value="">— optional —</option>';
        $h .= '</select>';
        $h .= '</div></div>';

        $h .= '<div class="form-group">';
        $h .= '<label class="control-label col-lg-3">Package size</label>';
        $h .= '<div class="col-lg-3">';
        $h .= '<select name="package_size" class="form-control">';
        $size_map = [1 => 'S', 2 => 'M', 4 => 'L', 5 => 'XL'];
        foreach ($size_map as $code => $label) {
            $sel = (int) $f['package_size'] === $code ? ' selected' : '';
            $h .= '<option value="' . $code . '"' . $sel . '>' . $label . '</option>';
        }
        $h .= '</select>';
        $h .= '</div></div>';

        // Buttons
        $h .= '<div class="panel-footer" style="margin-top:24px;">';
        $h .= '<a href="' . $list_url . '" class="btn btn-default">← Back to list</a> ';
        $h .= '<button type="submit" name="intigo_action" value="save" class="btn btn-default">Save</button> ';
        if (!$parcel || trim((string) $parcel->nid) === '') {
            $h .= '<button type="submit" name="intigo_action" value="save_push" class="btn btn-primary">Save &amp; Send to Intigo</button>';
        } else {
            $h .= '<button type="submit" name="intigo_action" value="save_update" class="btn btn-primary">Save &amp; Update at Intigo</button>';
        }
        $h .= '</div>';

        $h .= '</form>';
        $h .= '</div>';

        // Inline cascading-dropdown JS (no external file dependency — self-contained)
        $h .= $this->cascadingJs();
        $h .= '</div>'; // .intigo-screen

        $this->content = $h;
    }

    private function formGroup($label, $name, $type, $value, $extra = '')
    {
        return '<div class="form-group">'
            . '<label class="control-label col-lg-3">' . htmlspecialchars($label) . '</label>'
            . '<div class="col-lg-6">'
            . '<input type="' . $type . '" name="' . $name . '" value="' . htmlspecialchars((string) $value) . '" class="form-control" ' . $extra . '>'
            . '</div></div>';
    }

    private function formGroupTextarea($label, $name, $value)
    {
        return '<div class="form-group">'
            . '<label class="control-label col-lg-3">' . htmlspecialchars($label) . '</label>'
            . '<div class="col-lg-6">'
            . '<textarea name="' . $name . '" class="form-control" rows="2" required>' . htmlspecialchars((string) $value) . '</textarea>'
            . '</div></div>';
    }

    private function cascadingJs()
    {
        return <<<'JS'
<script>
(function () {
    var form = document.getElementById('intigo-edit-form');
    if (!form) { return; }
    var regionsUrl = form.getAttribute('data-regions-url');
    var cityEl = document.getElementById('intigo-city');
    var districtEl = document.getElementById('intigo-district');
    var neighborhoodEl = document.getElementById('intigo-neighborhood');
    var preCity = parseInt(cityEl.dataset.selected || '0', 10);
    var preDistrict = parseInt(districtEl.dataset.selected || '0', 10);
    var preNeighborhood = parseInt(neighborhoodEl.dataset.selected || '0', 10);

    function fetchJson(url) {
        return fetch(url, { credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .catch(function () { return null; });
    }

    function fill(sel, items, selectId) {
        while (sel.options.length > 1) { sel.remove(1); }
        (items || []).forEach(function (it) {
            var o = document.createElement('option');
            o.value = it.id;
            o.textContent = it.name;
            if (parseInt(selectId, 10) === parseInt(it.id, 10)) { o.selected = true; }
            sel.appendChild(o);
        });
    }

    function loadCities(selectId) {
        fetchJson(regionsUrl + '&action=cities').then(function (data) {
            if (!data || !data.ok) { return; }
            fill(cityEl, data.items, selectId);
            if (selectId > 0) { loadDistricts(selectId, preDistrict); }
        });
    }
    function loadDistricts(cityId, selectId) {
        fetchJson(regionsUrl + '&action=districts&city_id=' + cityId).then(function (data) {
            if (!data || !data.ok) { return; }
            fill(districtEl, data.items, selectId);
            districtEl.disabled = false;
            if (selectId > 0) { loadNeighborhoods(selectId, preNeighborhood); }
        });
    }
    function loadNeighborhoods(districtId, selectId) {
        fetchJson(regionsUrl + '&action=neighborhoods&district_id=' + districtId).then(function (data) {
            if (!data || !data.ok) { return; }
            fill(neighborhoodEl, data.items, selectId);
            neighborhoodEl.disabled = false;
        });
    }

    cityEl.addEventListener('change', function () {
        districtEl.innerHTML = '<option value="">— pick a district —</option>';
        districtEl.disabled = !cityEl.value;
        neighborhoodEl.innerHTML = '<option value="">— optional —</option>';
        neighborhoodEl.disabled = true;
        if (cityEl.value) { loadDistricts(parseInt(cityEl.value, 10), 0); }
    });
    districtEl.addEventListener('change', function () {
        neighborhoodEl.innerHTML = '<option value="">— optional —</option>';
        neighborhoodEl.disabled = !districtEl.value;
        if (districtEl.value) { loadNeighborhoods(parseInt(districtEl.value, 10), 0); }
    });

    loadCities(preCity);
})();
</script>
JS;
    }
}
