<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Intigo → Dashboard (legacy ModuleAdminController — portable across PS 1.7/8/9).
 * KPI cards + coverage + environment, Shopify-style. Reads only the DB on load
 * (no API call), and degrades gracefully when the module isn't configured.
 */
class AdminIntigoDashboardController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        $this->display = 'view';
        parent::__construct();
        $this->meta_title = 'Intigo — Dashboard';
        $this->show_page_header_toolbar = false;
    }

    public function initContent()
    {
        parent::initContent();
        try {
            $this->content = $this->render();
        } catch (Exception $e) {
            IntigoLog::add('dashboard_error', $e->getMessage());
            $this->content = '<div class="alert alert-warning">Intigo dashboard is temporarily unavailable.</div>';
        }
        $this->context->smarty->assign('content', $this->content);
    }

    private function render()
    {
        $db = Db::getInstance();
        $pfx = _DB_PREFIX_;
        $has_api_key = trim((string) Configuration::get('INTIGO_API_KEY')) !== '';
        $environment = Configuration::get('INTIGO_ENVIRONMENT') === 'production' ? 'production' : 'sandbox';
        $service_url = $environment === 'production' ? 'https://api.intigo.net/api' : 'https://dev-api.intigo.net/api';
        $settings_url = $this->context->link->getAdminLink('AdminIntigoSettings');
        $orders_url = $this->context->link->getAdminLink('AdminIntigoOrders');

        $recent_orders = (int) $db->getValue('SELECT COUNT(*) FROM `' . $pfx . 'orders`');
        $synced = (int) $db->getValue('SELECT COUNT(*) FROM `' . $pfx . 'intigo_parcel` WHERE nid <> ""');
        $bordereaux = (int) $db->getValue('SELECT COUNT(*) FROM `' . $pfx . 'intigo_parcel` WHERE bordereau_url <> ""');
        $calls24 = (int) $db->getValue('SELECT COUNT(*) FROM `' . $pfx . 'intigo_log` WHERE created_at >= (NOW() - INTERVAL 24 HOUR)');
        $failed24 = (int) $db->getValue('SELECT COUNT(*) FROM `' . $pfx . 'intigo_log` WHERE created_at >= (NOW() - INTERVAL 24 HOUR) AND action LIKE "%failed%"');
        $coverage = $recent_orders > 0 ? (int) round($synced / $recent_orders * 100) : 0;

        $h = '<div class="intigo-screen">';
        $h .= IntigoAdminUi::navHtml($this->context->link, 'dashboard');

        $t = function ($s) { return IntigoAdminUi::t($s); };
        if (!$has_api_key) {
            $h .= '<div class="alert alert-warning"><strong>' . $t('API key required.') . '</strong> '
                . $t('Add your Intigo API key to start creating parcels.') . ' '
                . '<a href="' . htmlspecialchars($settings_url) . '">' . $t('Go to Settings') . '</a></div>';
        }

        // KPI cards
        $kpi = function ($label, $value, $hint, $mod = '') {
            return '<div class="col-lg-3 col-md-6"><div class="card intigo-kpi' . $mod . '"><div class="card-body">'
                . '<div class="intigo-kpi-label">' . $label . '</div>'
                . '<div class="intigo-kpi-value">' . (int) $value . '</div>'
                . '<div class="intigo-kpi-hint">' . $hint . '</div>'
                . '</div></div></div>';
        };
        $h .= '<div class="row intigo-kpis">';
        $h .= $kpi($t('Recent orders'), $recent_orders, $t('In your shop'));
        $h .= $kpi($t('Synced to Intigo'), $synced, $coverage . '% ' . $t('of orders'), $synced > 0 ? ' intigo-kpi--success' : '');
        $h .= $kpi($t('Bordereaux ready'), $bordereaux, $t('Of') . ' ' . $synced . ' ' . $t('synced'));
        $h .= $kpi($t('API calls (24h)'), $calls24, $failed24 > 0 ? ($failed24 . ' ' . $t('failed — see Logs')) : $t('All healthy'), $failed24 > 0 ? ' intigo-kpi--danger' : ($calls24 > 0 ? ' intigo-kpi--success' : ''));
        $h .= '</div>';

        // Coverage + environment
        $h .= '<div class="row">';
        $h .= '<div class="col-lg-8"><div class="card"><div class="card-header"><h3 class="card-header-title">' . $t('Sync coverage') . '</h3></div><div class="card-body">'
            . '<p class="text-muted">' . $t('How many of your orders have a matching Intigo parcel.') . '</p>'
            . '<div class="d-flex justify-content-between"><span>' . $t('Coverage') . '</span><strong>' . $coverage . '%</strong></div>'
            . '<div class="progress mt-2"><div class="progress-bar bg-primary" role="progressbar" style="width:' . $coverage . '%"></div></div>'
            . '</div><div class="card-footer text-right"><a href="' . htmlspecialchars($orders_url) . '" class="btn btn-primary">' . $t('Open Orders') . '</a></div></div></div>';

        $env_badge = $environment === 'production'
            ? '<span class="badge badge-success">' . $t('Production') . '</span>'
            : '<span class="badge badge-warning">' . $t('Sandbox') . '</span>';
        $key_badge = $has_api_key
            ? '<span class="badge badge-success">' . $t('API key set') . '</span>'
            : '<span class="badge badge-danger">' . $t('API key missing') . '</span>';
        $h .= '<div class="col-lg-4"><div class="card"><div class="card-header"><h3 class="card-header-title">' . $t('Environment') . '</h3></div><div class="card-body">'
            . '<p>' . $env_badge . ' ' . $key_badge . '</p>'
            . '<p class="text-muted mb-1">' . $t('Service URL') . '</p><p style="word-break:break-all;"><code>' . htmlspecialchars($service_url) . '</code></p>'
            . '</div><div class="card-footer text-right"><a href="' . htmlspecialchars($settings_url) . '" class="btn btn-outline-secondary">' . $t('Change environment') . '</a></div></div></div>';
        $h .= '</div>';

        $h .= '</div>'; // .intigo-screen

        return $h;
    }
}
