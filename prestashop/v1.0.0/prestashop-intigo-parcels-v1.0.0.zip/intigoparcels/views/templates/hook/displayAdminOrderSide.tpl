<div class="card mb-3" id="intigo-order-side"
     data-regions-url="{$intigo_regions_url|escape:'html':'UTF-8'}">
    <div class="card-header">
        <h3 class="card-header-title">
            <i class="material-icons">local_shipping</i> Intigo Parcel
        </h3>
    </div>
    <div class="card-body">
        {if !$intigo_is_intigo_carrier}
            <p class="text-muted small">
                This order isn't on the Intigo Delivery carrier — you can still ship it via Intigo: complete the details below and send.
            </p>
        {/if}
            {if $intigo_parcel && $intigo_parcel->nid}
                <div class="alert alert-success" style="padding:8px 12px;">
                    <strong>NID:</strong> <code>{$intigo_parcel->nid|escape:'html':'UTF-8'}</code><br>
                    <strong>Status:</strong> {$intigo_parcel->status_code|escape:'html':'UTF-8'}<br>
                    <small>Pushed at {$intigo_parcel->last_attempt_at|escape:'html':'UTF-8'} via {$intigo_parcel->api_target_used|escape:'html':'UTF-8'}</small>
                </div>
                {if $intigo_parcel->bordereau_url}
                    <p><a href="{$intigo_parcel->bordereau_url|escape:'html':'UTF-8'}" class="btn btn-outline-secondary btn-sm" target="_blank">Bordereau PDF</a></p>
                {/if}
            {elseif $intigo_parcel && $intigo_parcel->last_error}
                <div class="alert alert-warning" style="padding:8px 12px;">
                    <strong>Last push failed:</strong><br>
                    <small><code>{$intigo_parcel->last_error|escape:'html':'UTF-8'}</code></small>
                </div>
            {else}
                <p class="text-muted small">No parcel created yet. Complete the fields below and click <strong>Send to Intigo</strong>.</p>
            {/if}

            <form method="post" action="{$intigo_action_url|escape:'html':'UTF-8'}" class="intigo-order-form">
                <input type="hidden" name="id_order" value="{$intigo_order_id|intval}">

                <div class="form-group">
                    <label>Recipient name *</label>
                    <input type="text" name="recipient_name" class="form-control"
                           value="{$intigo_form.recipient_name|escape:'html':'UTF-8'}">
                </div>

                <div class="form-group">
                    <label>Phone *</label>
                    <input type="tel" name="recipient_phone" class="form-control"
                           value="{$intigo_form.recipient_phone|escape:'html':'UTF-8'}">
                </div>

                <div class="form-group">
                    <label>Delivery address *</label>
                    <textarea name="destination_address" class="form-control" rows="2">{$intigo_form.destination_address|escape:'html':'UTF-8'}</textarea>
                </div>

                <div class="form-group">
                    <label>City *</label>
                    <select name="destination_city_id" class="form-control intigo-city"
                            data-selected="{$intigo_form.destination_city_id|intval}">
                        <option value="">— pick a city —</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>District *</label>
                    <select name="destination_district_id" class="form-control intigo-district"
                            data-selected="{$intigo_form.destination_district_id|intval}">
                        <option value="">— pick a city first —</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Neighborhood (optional)</label>
                    <select name="destination_neighborhood_id" class="form-control intigo-neighborhood"
                            data-selected="{$intigo_form.destination_neighborhood_id|intval}">
                        <option value="">— optional —</option>
                    </select>
                </div>

                <div class="form-group">
                    <label>Package size</label>
                    <select name="package_size" class="form-control">
                        {foreach from=$intigo_sizes key=code item=letter}
                            <option value="{$code}" {if $intigo_form.package_size == $code}selected{/if}>{$letter}</option>
                        {/foreach}
                    </select>
                </div>

                {if !$intigo_can_push && (!$intigo_parcel || !$intigo_parcel->nid)}
                    <div class="alert alert-warning" style="padding:8px 12px;">
                        <strong>Complete before sending:</strong> {$intigo_missing|escape:'html':'UTF-8'}.
                        You can <em>Save</em> now and finish later.
                    </div>
                {/if}

                <div style="display:flex; gap:6px; flex-wrap:wrap; margin-top:12px;">
                    <button type="submit" name="intigo_action" value="save" class="btn btn-default btn-sm">
                        <i class="material-icons">save</i> Save
                    </button>
                    {if !$intigo_parcel || !$intigo_parcel->nid}
                        <button type="submit" name="intigo_action" value="save_push" class="btn btn-primary btn-sm"{if !$intigo_can_push} disabled{/if}>
                            <i class="material-icons">send</i> Save &amp; Send to Intigo
                        </button>
                    {else}
                        <button type="submit" name="intigo_action" value="save_update" class="btn btn-secondary btn-sm">
                            <i class="material-icons">sync</i> Save & Update Intigo
                        </button>
                        <button type="submit" name="intigo_action" value="bordereau" class="btn btn-outline-secondary btn-sm">
                            <i class="material-icons">picture_as_pdf</i> Bordereau
                        </button>
                        <button type="submit" name="intigo_action" value="cancel" class="btn btn-outline-danger btn-sm"
                                onclick="return confirm('Cancel this parcel at Intigo?');">
                            <i class="material-icons">cancel</i> Cancel
                        </button>
                    {/if}
                </div>
            </form>
    </div>
</div>
