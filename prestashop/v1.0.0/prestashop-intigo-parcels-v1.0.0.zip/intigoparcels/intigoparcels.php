<?php
/**
 * Intigo Parcels for PrestaShop — main module class.
 *
 * Port of the WordPress Intigo Parcels for WooCommerce plugin.
 * Compatible with PrestaShop 1.7.x and 8.x; PHP 7.2+.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

require_once __DIR__ . '/classes/IntigoAdminUi.php';
require_once __DIR__ . '/classes/IntigoApiClient.php';
require_once __DIR__ . '/classes/IntigoParcel.php';
require_once __DIR__ . '/classes/IntigoProductSize.php';
require_once __DIR__ . '/classes/IntigoLog.php';
require_once __DIR__ . '/classes/IntigoSizeResolver.php';
require_once __DIR__ . '/classes/IntigoOrderService.php';

class Intigoparcels extends Module
{
    /**
     * Configuration keys for module behavior. Shipping price is NOT one of them —
     * PrestaShop's native carrier ranges (Shipping → Carriers → Intigo Delivery)
     * handle that. See feedback memory feedback-prestashop-no-shipping-pricing.
     */
    const CONFIG_KEYS = [
        'INTIGO_ENVIRONMENT',
        'INTIGO_API_KEY',
        'INTIGO_FALLBACK_ENABLED',
        'INTIGO_AUTO_CREATE',
        'INTIGO_DEFAULT_SIZE',
        'INTIGO_CARRIER_ID',
        'INTIGO_CRON_TOKEN',
        'INTIGO_TRACKING_URL',
        // Per-size shipping prices — the carrier charges by resolved package size
        // (S/M/L/XL), matching the Shopify app. Merchant-configurable in Settings.
        'INTIGO_PRICE_S',
        'INTIGO_PRICE_M',
        'INTIGO_PRICE_L',
        'INTIGO_PRICE_XL',
    ];

    /**
     * Hooks registered at install time.
     *
     * NOTE: no customer-facing checkout hooks (displayCarrierExtraContent,
     * actionValidateStepComplete, displayHeader). All Intigo data is captured
     * in the BO order page after checkout — see feedback memory
     * feedback-prestashop-no-checkout-injection.
     */
    const HOOKS = [
        'displayBackOfficeHeader',
        'actionAdminControllerSetMedia',
        'actionValidateOrder',
        'actionOrderStatusPostUpdate',
        'actionObjectOrderUpdateAfter',
        'displayAdminOrder',
        'displayAdminOrderSide',
        // Tab hooks — these render reliably in PS 8.x's Symfony order view,
        // unlike displayAdminOrderSide which can drop output silently.
        'displayAdminOrderTabLink',
        'displayAdminOrderTabContent',
    ];

    public function __construct()
    {
        $this->name = 'intigoparcels';
        $this->tab = 'shipping_logistics';
        $this->version = '1.0.0';
        $this->author = 'Intigo';
        $this->need_instance = 0;
        $this->bootstrap = true;
        $this->ps_versions_compliancy = ['min' => '1.7.0.0', 'max' => _PS_VERSION_];

        parent::__construct();

        $this->displayName = $this->l('Intigo Parcels');
        $this->description = $this->l('Sell on PrestaShop, ship via Intigo. Checkout flow with Intigo zone selection, automatic or manual push of orders to Intigo, bordereau generation, and status sync.');
        $this->confirmUninstall = $this->l('Are you sure? Order-to-parcel mapping, product size assignments and activity logs will be deleted.');
    }

    public function install()
    {
        if (!parent::install()) {
            return false;
        }
        if (!$this->installSql()) {
            return false;
        }
        if (!$this->installDefaults()) {
            return false;
        }
        if (!$this->installCarrier()) {
            return false;
        }
        if (!$this->installTabs()) {
            return false;
        }
        foreach (self::HOOKS as $hook) {
            if (!$this->registerHook($hook)) {
                return false;
            }
        }
        return true;
    }

    public function uninstall()
    {
        // Deliberately PRESERVE configuration (API key, per-size prices, tracking
        // URL) and data tables (order↔parcel mapping, product sizes, logs) on
        // uninstall, so a reinstall/upgrade never loses the merchant's setup or
        // the link to parcels already created in the Intigo system. We only
        // remove the UI (tabs) and soft-delete the carrier; install() revives both.
        // A full data purge is intentionally NOT done here (would orphan parcels
        // that still exist in Intigo). Use sql/uninstall.php manually if ever needed.
        $this->uninstallTabs();
        $this->uninstallCarrier();
        return parent::uninstall();
    }

    /* -------------------- Install helpers -------------------- */

    private function installSql()
    {
        return include __DIR__ . '/sql/install.php';
    }

    private function uninstallSql()
    {
        return include __DIR__ . '/sql/uninstall.php';
    }

    private function installDefaults()
    {
        $defaults = [
            'INTIGO_ENVIRONMENT' => 'sandbox',
            'INTIGO_API_KEY' => '',
            'INTIGO_FALLBACK_ENABLED' => '1',
            'INTIGO_AUTO_CREATE' => '0',
            'INTIGO_DEFAULT_SIZE' => 'S',
            'INTIGO_CRON_TOKEN' => bin2hex(random_bytes(16)),
            // Customer-facing tracking URL on the carrier — points to the Intigo
            // client app on Google Play (the official tracking destination).
            'INTIGO_TRACKING_URL' => 'https://play.google.com/store/apps/details?id=net.intigo.client',
            // Per-size shipping prices (placeholders — merchant sets real rates).
            'INTIGO_PRICE_S' => '7',
            'INTIGO_PRICE_M' => '8',
            'INTIGO_PRICE_L' => '10',
            'INTIGO_PRICE_XL' => '12',
        ];
        foreach ($defaults as $k => $v) {
            if (Configuration::get($k) === false) {
                Configuration::updateValue($k, $v);
            }
        }
        return true;
    }

    /**
     * Registers the "Intigo Delivery" carrier as a standard carrier (NOT a
     * CarrierModule). Pricing is handled entirely by PrestaShop's native
     * Shipping → Carriers UI (price ranges, weight ranges). The merchant
     * configures the price grid there; the module never overrides it.
     *
     * We seed one price range at 0 TND covering all zones/groups so the
     * carrier shows up in checkout even before the merchant tweaks pricing —
     * but the merchant is expected to set real prices in Shipping → Carriers.
     */
    private function installCarrier()
    {
        // Reinstall path: config is preserved, so the carrier id still points at
        // the (soft-deleted) carrier. Revive it instead of creating a duplicate —
        // this keeps every existing order's carrier link intact and avoids the
        // zombie-carrier pile-up.
        $existing_id = (int) Configuration::get('INTIGO_CARRIER_ID');
        if ($existing_id > 0) {
            $carrier = new Carrier($existing_id);
            if (Validate::isLoadedObject($carrier)) {
                $carrier->deleted = 0;
                $carrier->active = 1;
                $carrier->is_module = true;
                $carrier->shipping_external = true;
                $carrier->external_module_name = $this->name;
                $carrier->update();
                $logo = __DIR__ . '/views/img/carrier.jpg';
                if (file_exists($logo) && defined('_PS_SHIP_IMG_DIR_')) {
                    @copy($logo, _PS_SHIP_IMG_DIR_ . (int) $carrier->id . '.jpg');
                }
                return true;
            }
            // Stored id no longer resolves → fall through and create a fresh one.
        }
        $carrier = new Carrier();
        $carrier->name = 'Intigo Delivery';
        $carrier->active = 1;
        $carrier->deleted = 0;
        $carrier->shipping_handling = false;
        $carrier->range_behavior = 0;
        // Module-priced carrier: the module computes the price per resolved
        // package size (S/M/L/XL) in getPackageShippingCost(). Verified against
        // Cart::getPackageShippingCostFromModule (PS 9.1.3): the module is called
        // only when is_module=1 AND shipping_external=1; with need_range=1 PS calls
        // getPackageShippingCost(). The seed price range below keeps the carrier
        // valid in every zone (so it shows at checkout).
        $carrier->is_module = true;
        $carrier->shipping_external = true;
        $carrier->external_module_name = $this->name;
        $carrier->shipping_method = Carrier::SHIPPING_METHOD_PRICE;
        $carrier->need_range = 1;
        // Customer-facing tracking URL (@ = tracking number placeholder).
        $carrier->url = (string) Configuration::get('INTIGO_TRACKING_URL');
        foreach (Language::getLanguages() as $lang) {
            $carrier->delay[$lang['id_lang']] = '24-72h livraison via Intigo';
        }
        if (!$carrier->add()) {
            return false;
        }
        // Carrier logo (shown in checkout + the BO Carriers list).
        $logo = __DIR__ . '/views/img/carrier.jpg';
        if (file_exists($logo) && defined('_PS_SHIP_IMG_DIR_')) {
            @copy($logo, _PS_SHIP_IMG_DIR_ . (int) $carrier->id . '.jpg');
        }
        $range_price = new RangePrice();
        $range_price->id_carrier = (int) $carrier->id;
        $range_price->delimiter1 = 0;
        $range_price->delimiter2 = 100000;
        $range_price->add();
        foreach (Zone::getZones(true) as $zone) {
            Db::getInstance()->insert('carrier_zone', [
                'id_carrier' => (int) $carrier->id,
                'id_zone' => (int) $zone['id_zone'],
            ]);
            Db::getInstance()->insert('delivery', [
                'id_carrier' => (int) $carrier->id,
                'id_range_price' => (int) $range_price->id,
                'id_range_weight' => null,
                'id_zone' => (int) $zone['id_zone'],
                'price' => 0,
            ], false, true, Db::INSERT_IGNORE);
        }
        foreach (Group::getGroups(true) as $group) {
            Db::getInstance()->insert('carrier_group', [
                'id_carrier' => (int) $carrier->id,
                'id_group' => (int) $group['id_group'],
            ]);
        }
        Configuration::updateValue('INTIGO_CARRIER_ID', (int) $carrier->id);
        return true;
    }

    private function uninstallCarrier()
    {
        $id_carrier = (int) Configuration::get('INTIGO_CARRIER_ID');
        if ($id_carrier > 0) {
            $carrier = new Carrier($id_carrier);
            if (Validate::isLoadedObject($carrier)) {
                $carrier->deleted = 1;
                $carrier->update();
            }
        }
        return true;
    }

    /**
     * Creates one parent tab "Intigo" plus 5 child tabs. Stub controllers exist
     * for tabs whose features land in later phases — they render "Coming soon"
     * so the navigation is complete from day 1.
     */
    private function installTabs()
    {
        // Parent
        $parent = new Tab();
        foreach (Language::getLanguages(true) as $lang) {
            $parent->name[$lang['id_lang']] = 'Intigo';
        }
        $parent->class_name = 'AdminIntigoParent';
        $parent->module = $this->name;
        // Nest under the "SELL" section so PrestaShop renders Intigo as an
        // expandable dropdown group (like Orders/Customers) with our screens as
        // its submenu — NOT an orphan flat item. 'SELL' exists on 1.7/8/9.
        $id_sell = (int) Tab::getIdFromClassName('SELL');
        $parent->id_parent = $id_sell > 0 ? $id_sell : 0;
        $parent->icon = 'local_shipping';
        $parent->add();

        // All screens are legacy ModuleAdminControllers (class_name only) so the
        // single codebase runs on PrestaShop 1.7 / 8 / 9. NO Symfony route_name —
        // PrestaShopAdminController is 9.0+ only and 500s the whole BO on 1.7/8.
        $children = [
            ['AdminIntigoDashboard', 'Dashboard', true],
            ['AdminIntigoOrders', 'Orders', true],
            ['AdminIntigoProductSizes', 'Product Sizes', true],
            ['AdminIntigoLogs', 'Logs', true],
            ['AdminIntigoSettings', 'Settings', true],
            ['AdminIntigoDocs', 'Docs', true],
            ['AdminIntigoOrderAction', '', false], // hidden — only reachable via form action
        ];
        foreach ($children as $row) {
            $tab = new Tab();
            $tab->class_name = $row[0];
            $tab->module = $this->name;
            $tab->id_parent = (int) $parent->id;
            $tab->active = (bool) $row[2] ? 1 : 0;
            foreach (Language::getLanguages(true) as $lang) {
                $tab->name[$lang['id_lang']] = $row[1] !== '' ? $row[1] : $row[0];
            }
            $tab->add();
        }
        return true;
    }

    private function uninstallTabs()
    {
        $class_names = [
            'AdminIntigoDashboard',
            'AdminIntigoOrders',
            'AdminIntigoProductSizes',
            'AdminIntigoLogs',
            'AdminIntigoSettings',
            'AdminIntigoDocs',
            'AdminIntigoOrderAction',
            'AdminIntigoParent',
        ];
        foreach ($class_names as $cn) {
            $id = (int) Tab::getIdFromClassName($cn);
            if ($id) {
                $tab = new Tab($id);
                $tab->delete();
            }
        }
        return true;
    }

    /* -------------------- Configuration entry point -------------------- */

    /**
     * Module Manager "Configure" button lands here. We redirect into the proper
     * AdminIntigoSettings controller so the URL is bookmark-friendly and matches
     * the tab the user can reach from the menu.
     */
    public function getContent()
    {
        $url = $this->context->link->getAdminLink('AdminIntigoSettings');
        Tools::redirectAdmin($url);
        return ''; // unreachable
    }

    /**
     * The module is "configured" once it has an API key. Until then, every hook
     * must do nothing rather than attempt API calls or risky rendering. (We
     * derive the API base URL from INTIGO_ENVIRONMENT, so the key is the single
     * meaningful readiness signal.)
     */
    private function isConfigured()
    {
        return trim((string) Configuration::get('INTIGO_API_KEY')) !== '';
    }

    /* -------------------- Carrier pricing (size-based) -------------------- */
    // PrestaShop calls one of these on the module for the Intigo carrier (which
    // branch depends on need_range — see Cart::getPackageShippingCostFromModule).
    // We implement all three; each returns the price for the cart's resolved
    // package size. They must ALWAYS return a number — never throw — or checkout
    // breaks. The cost is tax-excluded; PrestaShop applies the carrier tax group.

    public function getPackageShippingCost($cart, $shipping_cost = 0, $products = [])
    {
        return $this->computeShippingCost($cart);
    }

    public function getOrderShippingCost($cart, $shipping_cost = 0)
    {
        return $this->computeShippingCost($cart);
    }

    public function getOrderShippingCostExternal($cart)
    {
        return $this->computeShippingCost($cart);
    }

    /**
     * Resolve the cart's package size (per-product size → max across the cart →
     * default from Settings) and return the merchant's configured price for it.
     */
    private function computeShippingCost($cart)
    {
        try {
            $size = ($cart instanceof Cart)
                ? IntigoSizeResolver::resolveForCart($cart)
                : IntigoSizeResolver::pluginDefault();
            $map = [
                'S' => (float) Configuration::get('INTIGO_PRICE_S'),
                'M' => (float) Configuration::get('INTIGO_PRICE_M'),
                'L' => (float) Configuration::get('INTIGO_PRICE_L'),
                'XL' => (float) Configuration::get('INTIGO_PRICE_XL'),
            ];
            return isset($map[$size]) ? $map[$size] : (float) Configuration::get('INTIGO_PRICE_S');
        } catch (\Throwable $e) {
            if (class_exists('IntigoLog')) {
                IntigoLog::add('shipping_cost_error', $e->getMessage());
            }
            // Safe fallback so checkout never breaks; merchant can fix prices.
            return (float) Configuration::get('INTIGO_PRICE_S');
        }
    }

    /* -------------------- Phase 1 hook stubs -------------------- */
    // Real hook bodies land in their respective phases. Defined here so install
    // succeeds and PrestaShop doesn't whine about missing hook handlers.

    public function hookActionAdminControllerSetMedia()
    {
        try {
            // Enqueue admin order JS/CSS on the order detail page so the editable
            // Intigo side panel has cascading-dropdown behavior.
            $ctrl = isset($this->context->controller) ? $this->context->controller : null;
            $ctrl_name = is_object($ctrl) ? get_class($ctrl) : '';
            if (strpos($ctrl_name, 'AdminOrders') !== false || $ctrl_name === 'AdminOrdersController') {
                $this->context->controller->addCSS($this->_path . 'views/css/admin-order.css');
                $this->context->controller->addJS($this->_path . 'views/js/admin-order.js');
            }
            // Our own legacy admin screens reuse the Shopify-style cosmetic layer.
            if (strpos($ctrl_name, 'AdminIntigo') !== false) {
                $this->context->controller->addCSS($this->_path . 'views/css/intigo-admin.css');
            }
        } catch (\Throwable $e) {
            // Asset registration must never break an admin page.
        }
    }

    public function hookDisplayBackOfficeHeader()
    {
    }

    /**
     * Fires once when an order is created. We:
     *   1. Snapshot the PS shipping address onto a new ps_intigo_parcel row
     *      (best-effort: try to resolve city_id from address.city via API).
     *   2. If auto mode is ON, attempt to push. Push will fail if required
     *      fields can't be resolved — the merchant fixes those in the BO and
     *      clicks "Send to Intigo" manually.
     */
    public function hookActionValidateOrder($params)
    {
        // This hook runs during customer checkout — it must NEVER throw (that
        // would break order creation) and must NEVER make a blocking network
        // call. Everything is wrapped and the API is only touched when the
        // merchant has configured the module.
        try {
            if (!$this->isConfigured()) {
                return;
            }
            $order = isset($params['order']) ? $params['order'] : null;
            if (!($order instanceof Order)) {
                return;
            }
            $intigo_carrier_id = (int) Configuration::get('INTIGO_CARRIER_ID');
            if ((int) $order->id_carrier !== $intigo_carrier_id) {
                return;
            }

            // Snapshot PS address onto a parcel row (no NID yet). Pass
            // resolveViaApi=false so we do NOT call the Intigo API synchronously
            // during checkout — the merchant resolves city/district in the BO.
            $svc = new IntigoOrderService();
            $payload = $svc->orderToPayload($order, false);
            $parcel = IntigoParcel::findByOrderId((int) $order->id) ?: new IntigoParcel();
            $parcel->id_order = (int) $order->id;
            $parcel->recipient_name = (string) $payload['recipient_name'];
            $parcel->recipient_phone = (string) $payload['phone1'];
            $parcel->destination_address = (string) $payload['destination_address'];
            $parcel->destination_city_id = (int) $payload['destination_city_id'];
            $parcel->destination_district_id = (int) $payload['destination_district_id'];
            $parcel->destination_neighborhood_id = isset($payload['destination_neighborhood_id'])
                ? (int) $payload['destination_neighborhood_id'] : 0;
            if (empty($parcel->package_size)) {
                $parcel->package_size = (int) $payload['package_size'];
            }
            $parcel->save();

            // Auto-push if enabled (pushParcel is itself idempotent + swallows
            // its own network errors — see IntigoOrderService).
            if ((string) Configuration::get('INTIGO_AUTO_CREATE') === '1') {
                $svc->pushParcel($order, false);
            }
        } catch (\Throwable $e) {
            if (class_exists('IntigoLog')) {
                IntigoLog::add('validate_order_error', $e->getMessage());
            }
        }
    }

    public function hookActionOrderStatusPostUpdate($params)
    {
        try {
            // Safety-net: if auto mode is ON, the parcel still has no NID, and the
            // order moved to a "paid" state, try once more. This handles flows
            // where actionValidateOrder didn't fire (e.g. manual order creation).
            if (!$this->isConfigured() || (string) Configuration::get('INTIGO_AUTO_CREATE') !== '1') {
                return;
            }
            $id_order = isset($params['id_order']) ? (int) $params['id_order'] : 0;
            $order = $id_order > 0 ? new Order($id_order) : null;
            if (!$order || !Validate::isLoadedObject($order)) {
                return;
            }
            if ((int) $order->id_carrier !== (int) Configuration::get('INTIGO_CARRIER_ID')) {
                return;
            }
            $parcel = IntigoParcel::findByOrderId((int) $order->id);
            if ($parcel && trim((string) $parcel->nid) !== '') {
                return;
            }
            $svc = new IntigoOrderService();
            $svc->pushParcel($order, false);
        } catch (\Throwable $e) {
            if (class_exists('IntigoLog')) {
                IntigoLog::add('order_status_update_error', $e->getMessage());
            }
        }
    }

    public function hookActionObjectOrderUpdateAfter($params)
    {
        try {
            if (!$this->isConfigured()) {
                return;
            }
            $order = isset($params['object']) ? $params['object'] : null;
            if (!($order instanceof Order)) {
                return;
            }
            $parcel = IntigoParcel::findByOrderId((int) $order->id);
            if (!$parcel || trim((string) $parcel->nid) === '' || (int) $parcel->sync_locked === 1) {
                return;
            }
            $svc = new IntigoOrderService();
            $svc->updateParcel($order); // best-effort, swallows result
        } catch (\Throwable $e) {
            if (class_exists('IntigoLog')) {
                IntigoLog::add('order_update_after_error', $e->getMessage());
            }
        }
    }

    public function hookDisplayAdminOrder($params)
    {
        // PS 1.7 fallback path — same content as the 8.x side hook.
        return $this->renderAdminOrderSide($params);
    }

    public function hookDisplayAdminOrderSide($params)
    {
        return $this->renderAdminOrderSide($params);
    }

    /**
     * Adds an "Intigo Parcel" tab to the order view's tab bar (next to
     * Status/Documents/Carriers). Only shown when the order's carrier is
     * Intigo Delivery.
     */
    public function hookDisplayAdminOrderTabLink($params)
    {
        // Retired: the parcel panel renders once in the order's left column via
        // hookDisplayAdminOrderSide. Keeping this as a no-op avoids a duplicate
        // tab and the old debug scaffolding. (See REBUILD_SPEC §5.3 / §10.)
        return '';
    }

    public function hookDisplayAdminOrderTabContent($params)
    {
        return '';
    }

    private function renderAdminOrderSide($params)
    {
        // Render the panel only once per request, even if several order-view
        // hooks fire (displayAdminOrder on 1.7, displayAdminOrderSide on 8/9).
        static $alreadyRendered = false;
        if ($alreadyRendered) {
            return '';
        }
        $alreadyRendered = true;

        // HARD GUARANTEE: this hook must NEVER break a core admin page. Any
        // failure is logged and swallowed; the order page renders without us.
        try {
            return $this->buildAdminOrderSide($params);
        } catch (\Throwable $e) {
            if (class_exists('IntigoLog')) {
                IntigoLog::add('side_hook_error', $e->getMessage());
            }
            return '';
        }
    }

    private function buildAdminOrderSide($params)
    {
        // Not configured yet → render a tiny, safe note and touch nothing else
        // (no Order/Address loads, no API). Matches "do nothing until configured".
        if (!$this->isConfigured()) {
            return '<div class="card mb-3"><div class="card-body"><p class="text-muted" style="margin:0;">'
                . 'Intigo isn\'t configured yet — add your API key in <strong>Intigo &rsaquo; Settings</strong> to manage parcels here.'
                . '</p></div></div>';
        }

        $id_order = isset($params['id_order']) ? (int) $params['id_order'] : 0;
        // PS 8.x sometimes passes the order object directly instead of id
        if ($id_order <= 0 && isset($params['order']) && is_object($params['order'])) {
            $id_order = (int) $params['order']->id;
        }
        if ($id_order <= 0) {
            return '<div class="alert alert-warning">Intigo: hook fired but no id_order in params</div>';
        }
        $order = new Order($id_order);
        if (!Validate::isLoadedObject($order)) {
            return '<div class="alert alert-warning">Intigo: hook fired but Order #' . $id_order . ' not loaded</div>';
        }
        $intigo_carrier_id = (int) Configuration::get('INTIGO_CARRIER_ID');
        $is_intigo = (int) $order->id_carrier === $intigo_carrier_id;

        $parcel = IntigoParcel::findByOrderId($id_order);

        // Build form values: parcel row > PS shipping address fallback.
        $form = [
            'recipient_name' => '',
            'recipient_phone' => '',
            'destination_address' => '',
            'destination_city_id' => 0,
            'destination_district_id' => 0,
            'destination_neighborhood_id' => 0,
            'package_size' => 1,
        ];
        if ($parcel) {
            $form['recipient_name'] = (string) $parcel->recipient_name;
            $form['recipient_phone'] = (string) $parcel->recipient_phone;
            $form['destination_address'] = (string) $parcel->destination_address;
            $form['destination_city_id'] = (int) $parcel->destination_city_id;
            $form['destination_district_id'] = (int) $parcel->destination_district_id;
            $form['destination_neighborhood_id'] = (int) $parcel->destination_neighborhood_id;
            $form['package_size'] = (int) $parcel->package_size ?: 1;
        }
        // Fallback to PS shipping address for empty fields — for ANY order, since
        // a merchant can ship any order via Intigo (not only Intigo-carrier ones).
        if ((int) $order->id_address_delivery > 0) {
            $addr = new Address((int) $order->id_address_delivery);
            if (Validate::isLoadedObject($addr)) {
                if ($form['recipient_name'] === '') {
                    $form['recipient_name'] = trim((string) $addr->firstname . ' ' . (string) $addr->lastname);
                }
                if ($form['recipient_phone'] === '') {
                    $form['recipient_phone'] = (string) ($addr->phone_mobile ?: $addr->phone);
                }
                if ($form['destination_address'] === '') {
                    $form['destination_address'] = trim((string) $addr->address1 . ' ' . (string) $addr->address2);
                }
            }
        }

        // Push-gating: the merchant can always Save partial data, but "Send to
        // Intigo" is disabled until everything required by the API is present.
        $missing = [];
        if (trim((string) $form['recipient_name']) === '') { $missing[] = 'recipient name'; }
        if (trim((string) $form['recipient_phone']) === '') { $missing[] = 'phone'; }
        if (trim((string) $form['destination_address']) === '') { $missing[] = 'address'; }
        if ((int) $form['destination_city_id'] <= 0) { $missing[] = 'city'; }
        if ((int) $form['destination_district_id'] <= 0) { $missing[] = 'district'; }

        $this->context->smarty->assign([
            'intigo_is_intigo_carrier' => $is_intigo,
            'intigo_order_id' => $id_order,
            'intigo_parcel' => $parcel,
            'intigo_form' => $form,
            'intigo_sizes' => [1 => 'S', 2 => 'M', 4 => 'L', 5 => 'XL'],
            'intigo_missing' => implode(', ', $missing),
            'intigo_can_push' => empty($missing),
            'intigo_action_url' => $this->context->link->getAdminLink('AdminIntigoOrderAction'),
            'intigo_regions_url' => $this->context->link->getModuleLink(
                $this->name,
                'regions',
                ['action' => 'cities'],
                true
            ),
        ]);

        // Never let a template/render error take down the whole BO order page.
        try {
            $rendered = $this->display(__FILE__, 'displayAdminOrderSide.tpl');
        } catch (\Throwable $e) {
            IntigoLog::add('side_hook_render_error', $e->getMessage());
            return '<div class="card mb-3"><div class="card-body"><div class="alert alert-warning" style="margin:0;">'
                . '<strong>Intigo:</strong> the parcel panel couldn\'t render here. '
                . 'Manage this order from <strong>Intigo → Orders</strong> instead.</div></div></div>';
        }
        return $rendered;
    }
}
