<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Push/update/cancel parcels at Intigo. Direct port of class-intigo-order-service.php
 * from the WP plugin, adapted to PrestaShop's Order / Address / Customer model.
 *
 *   pushParcel($order)   — POST /v3/parcels/  (idempotent by md5(ps:shop:order:event:v1))
 *   updateParcel($order) — PATCH /v3/parcels/{nid}, with phone/address/price fallback
 *                          if PATCH 4xxs (mirrors the WP plugin's lock-aware logic)
 *   cancelParcel($order) — POST /v3/parcels/{nid}/cancel
 */
class IntigoOrderService
{
    /** @var IntigoApiClient */
    private $api;

    public function __construct()
    {
        $this->api = new IntigoApiClient();
    }

    public function pushParcel(Order $order, $force = false)
    {
        $parcel = IntigoParcel::findByOrderId((int) $order->id);

        // Idempotency: only skip when we already have a successful NID.
        // Failed attempts (no NID) are always retryable so the merchant can
        // fix missing fields (district, etc.) and click Send again.
        if (!$force && $parcel && trim((string) $parcel->nid) !== '') {
            return [
                'ok' => true,
                'skipped' => true,
                'message' => 'Already pushed (NID=' . $parcel->nid . ')',
                'nid' => $parcel->nid,
            ];
        }

        $payload = $this->orderToPayload($order);
        $validation = $this->validatePayload($payload);
        if ($validation !== null) {
            $this->savePushFailure($order, $payload, 'validation: ' . $validation);
            return ['ok' => false, 'message' => $validation];
        }

        $res = $this->api->createParcel($payload);
        if (!empty($res['ok']) && !empty($res['data']['nid'])) {
            $nid = (string) $res['data']['nid'];
            $this->savePushSuccess($order, $payload, $nid, (string) ($res['adapter'] ?? 'primary'));
            IntigoLog::add('order_push_ok', 'id_order=' . (int) $order->id . ' nid=' . $nid);
            return ['ok' => true, 'nid' => $nid, 'message' => 'Parcel created'];
        }
        $err = $this->formatApiError($res);
        $this->savePushFailure($order, $payload, $err);
        IntigoLog::add('order_push_failed', 'id_order=' . (int) $order->id . ' err=' . $err);
        return ['ok' => false, 'message' => $err];
    }

    public function updateParcel(Order $order)
    {
        $parcel = IntigoParcel::findByOrderId((int) $order->id);
        if (!$parcel || trim((string) $parcel->nid) === '') {
            return ['ok' => false, 'message' => 'No parcel NID for this order — push first'];
        }
        if ((int) $parcel->sync_locked === 1) {
            return ['ok' => false, 'message' => 'Parcel locked at Intigo (delivered/return) — updates not allowed'];
        }

        $payload = $this->orderToPayload($order);
        $validation = $this->validatePayload($payload);
        if ($validation !== null) {
            return ['ok' => false, 'message' => 'validation: ' . $validation];
        }

        $res = $this->api->updateParcel($parcel->nid, $payload);
        if (!empty($res['ok'])) {
            IntigoLog::add('order_update_ok', 'id_order=' . (int) $order->id . ' nid=' . $parcel->nid);
            return ['ok' => true, 'message' => 'Updated via PATCH'];
        }
        if ($this->isParcelLockedError($res)) {
            $parcel->sync_locked = 1;
            $parcel->save();
            return ['ok' => false, 'locked' => true, 'message' => 'Parcel is locked at Intigo (delivered/return)'];
        }

        // Fallback: try the per-field change endpoints
        $errs = [];
        $phone_res = $this->api->changePhone($parcel->nid, $payload['phone1'] ?? '');
        if (empty($phone_res['ok'])) {
            $errs[] = 'phone=' . $this->formatApiError($phone_res);
        }
        $addr_res = $this->api->changeAddress($parcel->nid, [
            'address' => $payload['destination_address'] ?? '',
            'city_id' => (int) ($payload['destination_city_id'] ?? 0),
            'district_id' => (int) ($payload['destination_district_id'] ?? 0),
            'neighborhood_id' => (int) ($payload['destination_neighborhood_id'] ?? 0),
        ]);
        if (empty($addr_res['ok'])) {
            $errs[] = 'address=' . $this->formatApiError($addr_res);
        }
        $price_res = $this->api->changePrice($parcel->nid, (float) ($payload['price'] ?? 0));
        if (empty($price_res['ok'])) {
            $errs[] = 'price=' . $this->formatApiError($price_res);
        }
        if (count($errs) < 3) {
            IntigoLog::add('order_update_fallback_ok', 'id_order=' . (int) $order->id . ' nid=' . $parcel->nid);
            return ['ok' => true, 'message' => 'Updated via per-field fallback'];
        }
        $err = $this->formatApiError($res) . ' | fallback: ' . implode(' ', $errs);
        IntigoLog::add('order_update_failed', 'id_order=' . (int) $order->id . ' err=' . $err);
        return ['ok' => false, 'message' => $err];
    }

    public function cancelParcel(Order $order)
    {
        $parcel = IntigoParcel::findByOrderId((int) $order->id);
        if (!$parcel || trim((string) $parcel->nid) === '') {
            return ['ok' => false, 'message' => 'No parcel NID for this order'];
        }
        $res = $this->api->cancelParcel($parcel->nid);
        if (!empty($res['ok'])) {
            IntigoLog::add('order_cancel_ok', 'id_order=' . (int) $order->id . ' nid=' . $parcel->nid);
            return ['ok' => true, 'message' => 'Parcel cancelled'];
        }
        $err = $this->formatApiError($res);
        IntigoLog::add('order_cancel_failed', 'id_order=' . (int) $order->id . ' err=' . $err);
        return ['ok' => false, 'message' => $err];
    }

    public function generateBordereau(Order $order)
    {
        $parcel = IntigoParcel::findByOrderId((int) $order->id);
        if (!$parcel || trim((string) $parcel->nid) === '') {
            return ['ok' => false, 'message' => 'No parcel NID for this order'];
        }
        $res = $this->api->generateBordereau([$parcel->nid]);
        if (!empty($res['ok']) && !empty($res['data']['url'])) {
            $parcel->bordereau_url = (string) $res['data']['url'];
            $parcel->save();
            IntigoLog::add('order_bordereau_ok', 'id_order=' . (int) $order->id . ' nid=' . $parcel->nid);
            return ['ok' => true, 'url' => $parcel->bordereau_url];
        }
        $err = $this->formatApiError($res);
        IntigoLog::add('order_bordereau_failed', 'id_order=' . (int) $order->id . ' err=' . $err);
        return ['ok' => false, 'message' => $err];
    }

    /* -------------------- Payload building -------------------- */

    /**
     * Build the parcel-creation payload from a PrestaShop Order.
     *
     * Precedence:
     *   - Intigo cart meta (city/district/etc captured at checkout) wins
     *   - Falls back to ps_intigo_parcel row (if order was edited)
     *   - Falls back to PrestaShop shipping address (best-effort)
     */
    public function orderToPayload(Order $order, $resolveViaApi = true)
    {
        $address = new Address((int) $order->id_address_delivery);
        $address_loaded = Validate::isLoadedObject($address);

        // Invoice address is a useful fallback — customers often put phone on
        // the billing address only, leaving the shipping address phone empty.
        $invoice = (int) $order->id_address_invoice > 0 && (int) $order->id_address_invoice !== (int) $order->id_address_delivery
            ? new Address((int) $order->id_address_invoice)
            : null;
        $invoice_loaded = $invoice && Validate::isLoadedObject($invoice);

        // All Intigo data lives in ps_intigo_parcel (admin fills it in BO).
        // Fall back to PS shipping address for any field the admin hasn't set.
        $parcel = IntigoParcel::findByOrderId((int) $order->id);

        $recipient_name = '';
        $phone = '';
        $destination_address = '';
        $city_id = 0;
        $district_id = 0;
        $neighborhood_id = 0;

        if ($parcel) {
            $recipient_name = (string) $parcel->recipient_name;
            $phone = (string) $parcel->recipient_phone;
            $destination_address = (string) $parcel->destination_address;
            $city_id = (int) $parcel->destination_city_id;
            $district_id = (int) $parcel->destination_district_id;
            $neighborhood_id = (int) $parcel->destination_neighborhood_id;
        }

        // Last-resort fallback: PrestaShop addresses (delivery first, then invoice).
        if ($recipient_name === '' && $address_loaded) {
            $recipient_name = trim((string) $address->firstname . ' ' . (string) $address->lastname);
        }
        if ($recipient_name === '' && $invoice_loaded) {
            $recipient_name = trim((string) $invoice->firstname . ' ' . (string) $invoice->lastname);
        }
        if ($phone === '' && $address_loaded) {
            $phone = (string) ($address->phone_mobile ?: $address->phone);
        }
        if ($phone === '' && $invoice_loaded) {
            $phone = (string) ($invoice->phone_mobile ?: $invoice->phone);
        }
        if ($destination_address === '' && $address_loaded) {
            $destination_address = trim((string) $address->address1 . ' ' . (string) $address->address2);
        }
        if ($destination_address === '' && $invoice_loaded) {
            $destination_address = trim((string) $invoice->address1 . ' ' . (string) $invoice->address2);
        }

        // Resolve city by name from address.city when we still don't have a
        // city_id. This makes a network call, so it is SKIPPED during checkout
        // (resolveViaApi=false) to never block order creation.
        if ($resolveViaApi && $city_id <= 0 && $address_loaded && trim((string) $address->city) !== '') {
            $resolved = $this->resolveCityIdByName((string) $address->city);
            if ($resolved > 0) {
                $city_id = $resolved;
            }
        }

        // Resolve size: per-order parcel.package_size > cart-based waterfall
        $size_letter = 'S';
        if ($parcel && (int) $parcel->package_size > 0) {
            $letter = IntigoSizeResolver::codeToLetter((int) $parcel->package_size);
            if ($letter !== '') {
                $size_letter = $letter;
            }
        } else {
            $size_letter = IntigoSizeResolver::resolveForOrder($order);
        }
        $package_size_code = IntigoApiClient::sizeLetterToCode($size_letter);

        $payload = [
            'recipient_name' => $recipient_name,
            'phone1' => $this->normalizePhone($phone),
            'destination_address' => $destination_address,
            'destination_city_id' => $city_id,
            'destination_district_id' => $district_id,
            'price' => (float) $order->total_paid_tax_incl,
            'package_size' => $package_size_code,
            'description' => 'PrestaShop Order #' . (int) $order->id,
            'can_open' => false,
        ];
        if ($neighborhood_id > 0) {
            $payload['destination_neighborhood_id'] = $neighborhood_id;
        }
        return $payload;
    }

    /* -------------------- Persistence helpers -------------------- */

    private function savePushSuccess(Order $order, array $payload, $nid, $adapter)
    {
        $parcel = IntigoParcel::findByOrderId((int) $order->id) ?: new IntigoParcel();
        $parcel->id_order = (int) $order->id;
        $parcel->nid = (string) $nid;
        $parcel->api_target_used = (string) $adapter;
        $parcel->status_code = 1000; // "Pending pickup" — Intigo's initial state
        $parcel->package_size = (int) $payload['package_size'];
        $parcel->recipient_name = (string) $payload['recipient_name'];
        $parcel->recipient_phone = (string) $payload['phone1'];
        $parcel->destination_address = (string) $payload['destination_address'];
        $parcel->destination_city_id = (int) $payload['destination_city_id'];
        $parcel->destination_district_id = (int) $payload['destination_district_id'];
        $parcel->destination_neighborhood_id = isset($payload['destination_neighborhood_id'])
            ? (int) $payload['destination_neighborhood_id'] : 0;
        $parcel->idempotency_hash = md5($this->idempotencyKey($order, 'manual_create'));
        $parcel->sync_locked = 0;
        $parcel->last_error = null;
        $parcel->last_attempt_at = date('Y-m-d H:i:s');
        $parcel->save();
    }

    private function savePushFailure(Order $order, array $payload, $error_message)
    {
        $parcel = IntigoParcel::findByOrderId((int) $order->id) ?: new IntigoParcel();
        $parcel->id_order = (int) $order->id;
        if ($parcel->nid === null) { $parcel->nid = ''; }
        $parcel->package_size = (int) $payload['package_size'];
        $parcel->recipient_name = (string) $payload['recipient_name'];
        $parcel->recipient_phone = (string) $payload['phone1'];
        $parcel->destination_address = (string) $payload['destination_address'];
        $parcel->destination_city_id = (int) $payload['destination_city_id'];
        $parcel->destination_district_id = (int) $payload['destination_district_id'];
        $parcel->destination_neighborhood_id = isset($payload['destination_neighborhood_id'])
            ? (int) $payload['destination_neighborhood_id'] : 0;
        // NOTE: do NOT set idempotency_hash on failure — that's reserved for
        // successful pushes so future retries aren't blocked by it.
        $parcel->last_error = substr((string) $error_message, 0, 4000);
        $parcel->last_attempt_at = date('Y-m-d H:i:s');
        $parcel->save();
    }

    /* -------------------- Validation / errors -------------------- */

    /**
     * Returns null when the parcel can be sent, or a human-friendly message
     * naming exactly what the merchant still needs to fill in (never raw API
     * field names like "destination_city_id").
     */
    private function validatePayload(array $payload)
    {
        $missing = [];
        if (trim((string) $payload['recipient_name']) === '') {
            $missing[] = 'recipient name';
        }
        if (trim((string) $payload['phone1']) === '') {
            $missing[] = 'phone number';
        }
        if (trim((string) $payload['destination_address']) === '') {
            $missing[] = 'delivery address';
        }
        if ((int) $payload['destination_city_id'] <= 0) {
            $missing[] = 'city';
        }
        if ((int) $payload['destination_district_id'] <= 0) {
            $missing[] = 'district';
        }
        if (empty($missing)) {
            return null;
        }
        $last = array_pop($missing);
        $list = $missing ? implode(', ', $missing) . ' and ' . $last : $last;

        return 'This order can\'t be sent to Intigo yet — please add the ' . $list
            . '. Click "Edit" on the order to choose the Intigo delivery address, then send.';
    }

    private function formatApiError($res)
    {
        if (!is_array($res)) { return 'unknown error'; }
        $parts = [];
        if (isset($res['adapter'])) { $parts[] = 'adapter=' . $res['adapter']; }
        if (isset($res['code'])) { $parts[] = 'http=' . $res['code']; }
        if (!empty($res['url'])) { $parts[] = 'url=' . $res['url']; }
        if (!empty($res['error'])) {
            $parts[] = 'error=' . $res['error'];
        } elseif (!empty($res['data'])) {
            $parts[] = 'response=' . json_encode($res['data']);
        }
        if (!empty($res['legacy_attempt'])) {
            $la = $res['legacy_attempt'];
            $sub = [];
            if (!empty($la['code'])) { $sub[] = 'http=' . $la['code']; }
            if (!empty($la['url'])) { $sub[] = 'url=' . $la['url']; }
            if (!empty($la['error'])) { $sub[] = 'error=' . $la['error']; }
            elseif (!empty($la['data'])) { $sub[] = 'response=' . json_encode($la['data']); }
            if ($sub) { $parts[] = 'legacy(' . implode(' ', $sub) . ')'; }
        }
        return $parts ? implode(' | ', $parts) : 'unknown error';
    }

    /**
     * Detect "parcel is locked at Intigo" errors — same heuristics as the WP plugin.
     */
    private function isParcelLockedError($res)
    {
        if (!is_array($res)) { return false; }
        $status = (int) ($res['code'] ?? 0);
        if ($status !== 400 && $status !== 409) { return false; }
        $detail = '';
        if (isset($res['data']['detail'])) {
            $detail = strtolower((string) $res['data']['detail']);
        } elseif (isset($res['error'])) {
            $detail = strtolower((string) $res['error']);
        }
        if ($detail === '') { return false; }
        return strpos($detail, 'deja livre') !== false
            || strpos($detail, 'déjà livré') !== false
            || strpos($detail, 'en retour') !== false
            || strpos($detail, 'ne peut plus être modifié') !== false
            || strpos($detail, 'ne peut plus etre modifie') !== false;
    }

    private function idempotencyKey(Order $order, $event)
    {
        $shop_id = (int) $order->id_shop ?: 1;
        return sprintf('ps:%d:%d:%s:v1', $shop_id, (int) $order->id, $event);
    }

    private function normalizePhone($phone)
    {
        $digits = preg_replace('/\D+/', '', (string) $phone);
        if ($digits === null) {
            return '';
        }
        if (strpos($digits, '00') === 0) {
            $digits = substr($digits, 2);
        }
        return $digits;
    }

    private function resolveCityIdByName($city_name)
    {
        $res = $this->api->fetchCities($city_name);
        if (!empty($res['ok']) && !empty($res['items'])) {
            // Exact match first, else first hit
            $lower = strtolower(trim($city_name));
            foreach ($res['items'] as $item) {
                if (strtolower((string) $item['name']) === $lower) {
                    return (int) $item['id'];
                }
            }
            return (int) $res['items'][0]['id'];
        }
        return 0;
    }
}
