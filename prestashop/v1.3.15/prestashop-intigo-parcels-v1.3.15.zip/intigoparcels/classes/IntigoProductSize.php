<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Per-product size assignment (layer 2 of the 3-layer waterfall).
 * PK is id_product (1:1 with ps_product), value is S|M|L|XL.
 */
class IntigoProductSize
{
    const TABLE = 'intigo_product_size';
    const ALLOWED = ['S', 'M', 'L', 'XL'];

    /**
     * Returns 'S' | 'M' | 'L' | 'XL' or '' when no override set.
     */
    public static function getForProduct($id_product)
    {
        $id_product = (int) $id_product;
        if ($id_product <= 0) {
            return '';
        }
        $row = Db::getInstance()->getRow(
            'SELECT size FROM `' . _DB_PREFIX_ . self::TABLE . '` WHERE id_product = ' . $id_product
        );
        if (!$row || empty($row['size'])) {
            return '';
        }
        $size = strtoupper((string) $row['size']);
        return in_array($size, self::ALLOWED, true) ? $size : '';
    }

    /**
     * @param int    $id_product
     * @param string $size 'S' | 'M' | 'L' | 'XL' or '' to clear.
     */
    public static function setForProduct($id_product, $size)
    {
        $id_product = (int) $id_product;
        if ($id_product <= 0) {
            return false;
        }
        $size = strtoupper(trim((string) $size));
        if ($size === '') {
            return Db::getInstance()->delete(self::TABLE, 'id_product = ' . $id_product);
        }
        if (!in_array($size, self::ALLOWED, true)) {
            return false;
        }
        $existing = Db::getInstance()->getValue(
            'SELECT id_product FROM `' . _DB_PREFIX_ . self::TABLE . '` WHERE id_product = ' . $id_product
        );
        if ($existing) {
            return Db::getInstance()->update(self::TABLE, ['size' => $size], 'id_product = ' . $id_product, 1);
        }
        return Db::getInstance()->insert(self::TABLE, ['id_product' => $id_product, 'size' => $size]);
    }

    /**
     * Bulk read for cart aggregation. Returns id_product => size.
     *
     * @param int[] $ids
     * @return array<int,string>
     */
    public static function getForProducts(array $ids)
    {
        $ids = array_filter(array_map('intval', $ids));
        if (empty($ids)) {
            return [];
        }
        $in = implode(',', $ids);
        $rows = Db::getInstance()->executeS(
            'SELECT id_product, size FROM `' . _DB_PREFIX_ . self::TABLE . '` WHERE id_product IN (' . $in . ')'
        );
        $out = [];
        if (is_array($rows)) {
            foreach ($rows as $row) {
                $size = strtoupper((string) $row['size']);
                if (in_array($size, self::ALLOWED, true)) {
                    $out[(int) $row['id_product']] = $size;
                }
            }
        }
        return $out;
    }
}
