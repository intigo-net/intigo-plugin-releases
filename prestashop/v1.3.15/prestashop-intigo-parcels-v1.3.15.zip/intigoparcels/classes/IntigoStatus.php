<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Intigo parcel statuses + the merchant-configurable mapping to PrestaShop order
 * states (used by the status-sync webhook).
 *
 * The webhook can fire on any of the statuses below. Instead of hard-coding three
 * milestones, the merchant maps EACH Intigo status to a PS order state of their
 * choice (many Intigo statuses may point at the same PS state). An unmapped status
 * still updates the stored parcel status, but doesn't move the PS order.
 *
 * Map is stored as JSON in config INTIGO_WH_STATUS_MAP: { "<intigo_code>": <id_order_state>, ... }.
 */
class IntigoStatus
{
    const MAP_KEY = 'INTIGO_WH_STATUS_MAP';

    /** Intigo statuses that fire a webhook → French label (display order). */
    public static function webhookStatuses()
    {
        return [
            1000 => 'En attente de ramassage',
            1100 => 'Ramassage programmé',
            2000 => 'En attente de livraison',
            2001 => 'Relance',
            2004 => 'En dépôt',
            3100 => 'En transfert (livraison)',
            3201 => 'En transfert (retour)',
            4000 => 'En cours de livraison',
            5000 => 'Livré',
            5001 => 'Livré partiellement',
            6000 => 'Retour en préparation',
            6100 => 'Retourné',
            6200 => 'Retour confirmé par expéditeur',
        ];
    }

    /** Human label for a parcel status code (exact for the 13 webhook codes, else bucketed). */
    public static function label($code)
    {
        $code = (int) $code;
        $ws = self::webhookStatuses();
        if (isset($ws[$code])) {
            return $ws[$code];
        }
        if ($code <= 0) {
            return 'Créé';
        }
        if ($code >= 1000 && $code < 2000) {
            return 'En attente de ramassage';
        }
        if ($code >= 2000 && $code < 4000) {
            return 'En transit';
        }
        if ($code === 4000) {
            return 'En cours de livraison';
        }
        if ($code >= 5000 && $code < 6000) {
            return 'Livré';
        }
        if ($code >= 6000 && $code < 7000) {
            return 'Retour';
        }
        if ($code >= 9000) {
            return 'Annulé';
        }
        return 'En cours';
    }

    /** intigo-badge--* colour class for a status code. */
    public static function badgeClass($code)
    {
        $code = (int) $code;
        if ($code >= 5000 && $code < 6000) {
            return 'intigo-badge--success';        // Livré
        }
        if ($code >= 6000) {
            return 'intigo-badge--warning';        // Retour / Annulé
        }
        if ($code >= 2000) {
            return 'intigo-badge--info';           // en transit / en livraison
        }
        return 'intigo-badge--muted';              // créé / en attente de ramassage
    }

    /** The configured map: [ intigo_code => id_order_state ]. */
    public static function getMap()
    {
        $raw = Configuration::get(self::MAP_KEY);
        if ($raw === false || trim((string) $raw) === '') {
            return [];
        }
        $arr = json_decode((string) $raw, true);
        if (!is_array($arr)) {
            return [];
        }
        $out = [];
        foreach ($arr as $code => $state) {
            if ((int) $state > 0) {
                $out[(int) $code] = (int) $state;
            }
        }
        return $out;
    }

    /** Persist the map (values <= 0 are dropped = "no transition"). */
    public static function setMap(array $map)
    {
        $clean = [];
        foreach ($map as $code => $state) {
            $code = (int) $code;
            $state = (int) $state;
            if ($code > 0 && $state > 0 && isset(self::webhookStatuses()[$code])) {
                $clean[(string) $code] = $state;
            }
        }
        Configuration::updateValue(self::MAP_KEY, json_encode($clean));
    }

    /**
     * The PS order state to move to for an incoming Intigo status — exact match in
     * the map; if absent, the nearest mapped status in the SAME thousand-bucket
     * (5000/6000/…) so a sub-status (5001) follows its milestone (5000). Returns 0
     * when nothing is mapped (= leave the PS order untouched).
     */
    public static function psStateFor($intigo_code)
    {
        $intigo_code = (int) $intigo_code;
        $map = self::getMap();
        if (isset($map[$intigo_code])) {
            return (int) $map[$intigo_code];
        }
        $bucket = intval($intigo_code / 1000) * 1000;
        $best = 0;
        $best_code = PHP_INT_MAX;
        foreach ($map as $code => $state) {
            if (intval($code / 1000) * 1000 === $bucket && abs($code - $intigo_code) < $best_code) {
                $best = (int) $state;
                $best_code = abs($code - $intigo_code);
            }
        }
        return $best;
    }
}
