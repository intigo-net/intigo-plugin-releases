<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Activity log — circular buffer capped at 200 entries (matches WP plugin).
 * Oldest rows are trimmed on insert so storage stays bounded.
 */
class IntigoLog
{
    const TABLE = 'intigo_log';
    const MAX_ROWS = 200;

    public static function add($action, $context = '', $actor = null)
    {
        $action = trim((string) $action);
        if ($action === '') {
            return false;
        }

        if ($actor === null) {
            $actor = 'system';
            if (class_exists('Context')) {
                $ctx = Context::getContext();
                if ($ctx && isset($ctx->employee) && is_object($ctx->employee) && !empty($ctx->employee->id)) {
                    $actor = (string) ($ctx->employee->email ?: ('employee#' . $ctx->employee->id));
                }
            }
        }

        if (is_array($context)) {
            $context = json_encode($context);
        }

        $ok = Db::getInstance()->insert(self::TABLE, [
            'created_at' => date('Y-m-d H:i:s'),
            'actor' => substr((string) $actor, 0, 64),
            'action' => substr((string) $action, 0, 64),
            'context' => (string) $context,
        ]);

        self::trim();
        return $ok;
    }

    /**
     * Keeps only the most recent MAX_ROWS entries. Runs after every insert.
     * Cheap because the table is bounded; one DELETE keyed on id range.
     *
     * Db::getValue/getRow auto-appends `LIMIT 1` to the query, which collides
     * with our manual `LIMIT 1 OFFSET MAX_ROWS`. Use executeS to bypass that.
     */
    public static function trim()
    {
        $rows = Db::getInstance()->executeS(
            'SELECT id_intigo_log FROM `' . _DB_PREFIX_ . self::TABLE . '`
            ORDER BY id_intigo_log DESC LIMIT 1 OFFSET ' . (int) self::MAX_ROWS
        );
        if (is_array($rows) && !empty($rows) && isset($rows[0]['id_intigo_log'])) {
            $cutoff_id = (int) $rows[0]['id_intigo_log'];
            Db::getInstance()->execute(
                'DELETE FROM `' . _DB_PREFIX_ . self::TABLE . '` WHERE id_intigo_log <= ' . $cutoff_id
            );
        }
    }

    /**
     * Page through recent log entries.
     *
     * @param int $page  1-indexed
     * @param int $per_page
     * @return array{rows: array, total: int}
     */
    public static function paginate($page = 1, $per_page = 25)
    {
        $page = max(1, (int) $page);
        $per_page = max(1, min(200, (int) $per_page));
        $offset = ($page - 1) * $per_page;

        $rows = Db::getInstance()->executeS(
            'SELECT * FROM `' . _DB_PREFIX_ . self::TABLE . '`
            ORDER BY id_intigo_log DESC
            LIMIT ' . (int) $per_page . ' OFFSET ' . (int) $offset
        );
        $total = (int) Db::getInstance()->getValue(
            'SELECT COUNT(*) FROM `' . _DB_PREFIX_ . self::TABLE . '`'
        );
        return ['rows' => is_array($rows) ? $rows : [], 'total' => $total];
    }
}
