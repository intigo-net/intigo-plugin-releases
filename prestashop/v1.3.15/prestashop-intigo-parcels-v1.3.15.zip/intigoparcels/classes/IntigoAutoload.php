<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Registers a lightweight autoloader for the module's Intigo* helper classes so
 * they resolve no matter the include order or which controller PrestaShop
 * dispatches first.
 *
 * Without this, a legacy module controller rendered inside the Symfony-wrapped
 * back office (PS 1.7.8+) can fatal with "Attempted to load class IntigoAdminUi
 * from the global namespace" when the module main file has not been included yet
 * for that request. The controllers reference IntigoAdminUi/IntigoLog/etc.
 * directly but did not require them — they relied on intigoparcels.php loading
 * first, which is not guaranteed on every admin route / every PS version.
 *
 * Class names map 1:1 to files in this directory (IntigoAdminUi -> IntigoAdminUi.php),
 * so a prefix-matched require is all that is needed. Guarded to register once.
 */
if (!defined('INTIGO_AUTOLOAD_REGISTERED')) {
    define('INTIGO_AUTOLOAD_REGISTERED', true);
    spl_autoload_register(function ($class) {
        if (strncmp($class, 'Intigo', 6) !== 0) {
            return;
        }
        $file = __DIR__ . '/' . $class . '.php';
        if (is_file($file)) {
            require_once $file;
        }
    });
}
