<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Simple, page-level access control for the Intigo back-office pages — a thin,
 * merchant-friendly wrapper over PrestaShop's per-tab permission roles so the
 * merchant can grant/revoke each employee profile from one screen (Réglages →
 * Accès) instead of the full native permissions grid.
 *
 * Model: a page is "accessible" to a profile when that profile holds the tab's
 * READ role; saving grants/revokes all four CRUD roles together (a page is on or
 * off — no field-level granularity). The menu parent + the hidden action handler
 * follow automatically: a profile with ANY page gets them, a profile with none
 * loses them. SuperAdmin (profile 1) always has everything and isn't managed here.
 */
class IntigoAccess
{
    /** Manageable Intigo pages: class_name => human label (display order). */
    public static function pages()
    {
        return [
            'AdminIntigoDashboard' => 'Tableau de bord',
            'AdminIntigoOrders' => 'Commandes',
            'AdminIntigoPickup' => 'Adresses de ramassage',
            'AdminIntigoProductSizes' => 'Tailles produits',
            'AdminIntigoSettings' => 'Réglages',
            'AdminIntigoLogs' => 'Journaux',
            'AdminIntigoDocs' => 'Aide',
        ];
    }

    /** Controllers that must follow any granted page (menu parent + form action). */
    private static function infra()
    {
        return ['AdminIntigoParent', 'AdminIntigoOrderAction'];
    }

    /** Manageable profiles — every profile except SuperAdmin (which always has all). */
    public static function profiles($id_lang)
    {
        $out = [];
        $rows = Db::getInstance()->executeS(
            'SELECT p.id_profile, pl.name
             FROM `' . _DB_PREFIX_ . 'profile` p
             JOIN `' . _DB_PREFIX_ . 'profile_lang` pl
               ON pl.id_profile = p.id_profile AND pl.id_lang = ' . (int) $id_lang . '
             WHERE p.id_profile > 1
             ORDER BY p.id_profile'
        );
        foreach ((array) $rows as $r) {
            $out[] = ['id' => (int) $r['id_profile'], 'name' => (string) $r['name']];
        }
        return $out;
    }

    private static function roleId($class, $action)
    {
        $slug = 'ROLE_MOD_TAB_' . strtoupper($class) . '_' . $action;
        return (int) Db::getInstance()->getValue(
            'SELECT id_authorization_role FROM `' . _DB_PREFIX_ . 'authorization_role` WHERE slug = "' . pSQL($slug) . '"'
        );
    }

    /** True when the profile can open this page (holds its READ role). */
    public static function has($id_profile, $class)
    {
        $id_role = self::roleId($class, 'READ');
        if ($id_role <= 0) {
            return false;
        }
        return (int) Db::getInstance()->getValue(
            'SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'access`
             WHERE id_profile = ' . (int) $id_profile . ' AND id_authorization_role = ' . $id_role
        ) > 0;
    }

    /** Grant ($granted=true) or revoke all four CRUD roles for (profile, page). */
    public static function set($id_profile, $class, $granted)
    {
        $db = Db::getInstance();
        foreach (['CREATE', 'READ', 'UPDATE', 'DELETE'] as $action) {
            $id_role = self::roleId($class, $action);
            if ($id_role <= 0) {
                continue;
            }
            if ($granted) {
                $db->execute('INSERT IGNORE INTO `' . _DB_PREFIX_ . 'access` (id_profile, id_authorization_role) VALUES ('
                    . (int) $id_profile . ', ' . $id_role . ')');
            } else {
                $db->execute('DELETE FROM `' . _DB_PREFIX_ . 'access` WHERE id_profile = '
                    . (int) $id_profile . ' AND id_authorization_role = ' . $id_role);
            }
        }
    }

    /**
     * Apply a full grid: [id_profile => [class_name => bool]]. Pages not present
     * for a profile are treated as revoked. Infra (parent + action) is synced: a
     * profile with at least one page keeps them, otherwise they're removed.
     */
    public static function apply(array $grid)
    {
        foreach ($grid as $id_profile => $pages) {
            $id_profile = (int) $id_profile;
            if ($id_profile <= 1) {
                continue; // never touch SuperAdmin
            }
            $any = false;
            foreach (array_keys(self::pages()) as $class) {
                $granted = !empty($pages[$class]);
                self::set($id_profile, $class, $granted);
                $any = $any || $granted;
            }
            foreach (self::infra() as $class) {
                self::set($id_profile, $class, $any);
            }
        }
    }
}
