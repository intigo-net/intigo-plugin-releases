<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * HTTP wrapper for the Intigo API. Direct port of the WP plugin's
 * Intigo_API_Client — same endpoints, same fallback semantics, same
 * structured response shape.
 *
 * Response shape (always):
 *   ['ok' => bool, 'code' => int, 'data' => mixed, 'error' => string,
 *    'adapter' => 'primary'|'legacy', 'url' => string]
 *
 * The transport prefers Guzzle (bundled with PS 1.7.6+) and falls back to
 * a thin curl wrapper for older 1.7.x installations.
 */
class IntigoApiClient
{
    const SANDBOX_BASE_URL = 'https://dev-api.intigo.net/api';
    const PRODUCTION_BASE_URL = 'https://api.intigo.net/api';
    const LOCATION_QUERY_BASE_URL = 'https://intishop.dannous.shop/parcels/api/public/locations/?q=';

    public function getSettings()
    {
        $mode = Configuration::get('INTIGO_ENVIRONMENT') === 'production' ? 'production' : 'sandbox';
        $active_primary = $mode === 'production' ? self::PRODUCTION_BASE_URL : self::SANDBOX_BASE_URL;
        return [
            'environment_mode' => $mode,
            'api_key' => (string) Configuration::get('INTIGO_API_KEY'),
            'fallback_enabled' => (string) Configuration::get('INTIGO_FALLBACK_ENABLED') === '1' ? 'yes' : 'no',
            'auto_create' => (string) Configuration::get('INTIGO_AUTO_CREATE') === '1',
            'default_package_size' => self::normalizeSizeLetter(Configuration::get('INTIGO_DEFAULT_SIZE'), 'S'),
            'primary_base_url' => $active_primary,
            'legacy_base_url' => $active_primary,
        ];
    }

    /* ---------------- Endpoints ---------------- */

    public function createParcel($payload)
    {
        return $this->withFallback('POST', '/v3/parcels/', $payload, '/expediteurs/api/parcel/create/');
    }

    public function createParcelsBatch($payload)
    {
        return $this->withFallback('POST', '/v3/parcels/batch', $payload, '/expediteurs/api/parcels/batch/');
    }

    /**
     * Create a parcel by POSTAL CODE (v3 API v1.1.0). Intigo resolves the city /
     * district / neighborhood from the postcode (core_neighborhood.postal_code),
     * so the payload must NOT carry destination_city_id / district_id / etc. Used
     * as a complementary path to the free-text guesser — see IntigoOrderService.
     */
    public function createParcelByPostalCode($payload)
    {
        return $this->withFallback('POST', '/v3/parcels/by-postal-code', $payload, null);
    }

    /** Bulk create-by-postal-code (max 100; per-item resolution failures). */
    public function createParcelsBatchByPostalCode($payload)
    {
        return $this->withFallback('POST', '/v3/parcels/batch-by-postal-code', $payload, null);
    }

    public function generateBordereau(array $nids)
    {
        return $this->withFallback('POST', '/v3/parcels/bordereau', ['nids' => $nids], null);
    }

    public function statusBulk(array $nids)
    {
        return $this->withFallback('POST', '/v3/parcels/status', ['nids' => $nids], null);
    }

    public function updateParcel($nid, $payload)
    {
        $nid = rawurlencode((string) $nid);
        return $this->withFallback('PATCH', '/v3/parcels/' . $nid, $payload, null);
    }

    public function cancelParcel($nid)
    {
        $nid = rawurlencode((string) $nid);
        return $this->withFallback('POST', '/v3/parcels/' . $nid . '/cancel', [], null);
    }

    public function relanceParcel($nid, $accept_fee = false)
    {
        $nid = rawurlencode((string) $nid);
        return $this->withFallback('POST', '/v3/parcels/' . $nid . '/relance', ['accept_fee' => (bool) $accept_fee], null);
    }

    public function reportDelay($nid, $reason = '')
    {
        $nid = rawurlencode((string) $nid);
        $payload = [];
        if (trim((string) $reason) !== '') {
            $payload['reason'] = (string) $reason;
        }
        return $this->withFallback('POST', '/v3/parcels/' . $nid . '/report-delay', $payload, null);
    }

    public function changePhone($nid, $phone)
    {
        $nid = rawurlencode((string) $nid);
        return $this->withFallback('POST', '/v3/parcels/' . $nid . '/change-phone', ['phone' => (string) $phone], null);
    }

    public function changePrice($nid, $price)
    {
        $nid = rawurlencode((string) $nid);
        return $this->withFallback('POST', '/v3/parcels/' . $nid . '/change-price', ['price' => (float) $price], null);
    }

    public function changeAddress($nid, $payload)
    {
        $nid = rawurlencode((string) $nid);
        return $this->withFallback('POST', '/v3/parcels/' . $nid . '/change-address', $payload, null);
    }

    /* ---------------- Region lookups ---------------- */

    public function fetchCities($query = '')
    {
        $settings = $this->getSettings();
        $base = rtrim((string) $settings['primary_base_url'], '/');
        if ($base === '') {
            return ['ok' => false, 'error' => 'primary_base_url is not configured', 'items' => []];
        }
        $items = $this->fetchLookupArray($base . '/v3/regions/cities', $settings);
        return $this->filterLookupItems($items, $query);
    }

    public function fetchDistricts($city_id, $query = '')
    {
        $city_id = (int) $city_id;
        if ($city_id <= 0) {
            return ['ok' => false, 'error' => 'city_id is required', 'items' => []];
        }
        $settings = $this->getSettings();
        $base = rtrim((string) $settings['primary_base_url'], '/');
        $url = $base . '/v3/regions/cities/' . rawurlencode((string) $city_id) . '/districts';
        $items = $this->fetchLookupArray($url, $settings);
        return $this->filterLookupItems($items, $query);
    }

    public function fetchNeighborhoods($district_id)
    {
        $district_id = (int) $district_id;
        if ($district_id <= 0) {
            return ['ok' => false, 'error' => 'district_id is required', 'items' => []];
        }
        $settings = $this->getSettings();
        $base = rtrim((string) $settings['primary_base_url'], '/');
        $url = $base . '/v3/regions/districts/' . rawurlencode((string) $district_id) . '/neighborhoods';
        return $this->fetchLookupArray($url, $settings);
    }

    /**
     * Quick connection check used by the Settings page health pill.
     * Hits /v3/regions/cities — cheap, requires API key, gives a clear signal.
     */
    public function healthCheck()
    {
        $res = $this->fetchCities('');
        if (!empty($res['ok'])) {
            $count = isset($res['items']) ? count($res['items']) : 0;
            return ['ok' => true, 'message' => 'Connected — ' . $count . ' cities reachable'];
        }
        $msg = isset($res['error']) ? (string) $res['error'] : 'unknown error';
        return ['ok' => false, 'message' => $msg];
    }

    /* ---------------- Address resolution (free-text guesser) ---------------- */

    /**
     * Free-text address guesser (OpenSearch). PUBLIC endpoint (no API key) on a
     * SEPARATE host. Returns ranked candidates, each carrying Intigo region IDs.
     * Fails CLOSED: any transport/HTTP/parse error → ['ok'=>false,'items'=>[]],
     * so a degraded guesser can never produce a bogus "match".
     *
     * Each item: district_id, district_name, neighborhood_id, neighborhood_name,
     * city_name, type.
     */
    public function searchLocations($query)
    {
        $query = trim((string) $query);
        if ($query === '') {
            return ['ok' => false, 'error' => 'empty query', 'items' => []];
        }
        $url = self::LOCATION_QUERY_BASE_URL . rawurlencode($query);
        list($code, $body, $error) = $this->httpRequest('GET', $url, ['Content-Type' => 'application/json'], null);
        if ($code === 0) {
            return ['ok' => false, 'error' => $error, 'items' => []];
        }
        if ($code < 200 || $code >= 300) {
            return ['ok' => false, 'error' => 'http=' . $code, 'items' => []];
        }
        $json = json_decode((string) $body, true);
        $rows = (is_array($json) && isset($json['results']) && is_array($json['results'])) ? $json['results'] : [];
        $items = [];
        foreach ($rows as $r) {
            if (!is_array($r)) {
                continue;
            }
            $items[] = [
                'district_id' => isset($r['district_id']) ? (int) $r['district_id'] : 0,
                'district_name' => isset($r['district_name']) ? (string) $r['district_name'] : '',
                'neighborhood_id' => (isset($r['neighborhood_id']) && $r['neighborhood_id'] !== null) ? (int) $r['neighborhood_id'] : 0,
                'neighborhood_name' => isset($r['neighborhood_name']) ? (string) $r['neighborhood_name'] : '',
                'city_name' => isset($r['city_name']) ? (string) $r['city_name'] : '',
                'type' => isset($r['type']) ? (string) $r['type'] : '',
            ];
        }
        return ['ok' => true, 'items' => $items];
    }

    /**
     * Cached normalized city-name → city_id map (request-scoped + Configuration
     * cache, 24h TTL). The guesser returns city_NAME, not city_id; this turns it
     * into the canonical id from /v3/regions/cities.
     */
    public function cityNameToIdMap()
    {
        static $map = null;
        if ($map !== null) {
            return $map;
        }
        $ts = (int) Configuration::get('INTIGO_CITIES_CACHE_TS');
        $raw = Configuration::get('INTIGO_CITIES_CACHE');
        if ($raw !== false && trim((string) $raw) !== '' && (time() - $ts) < 86400) {
            $cached = json_decode((string) $raw, true);
            if (is_array($cached) && !empty($cached)) {
                $map = $cached;
                return $map;
            }
        }
        $map = [];
        $res = $this->fetchCities('');
        if (!empty($res['ok']) && !empty($res['items'])) {
            foreach ($res['items'] as $c) {
                $key = self::normalizeName((string) $c['name']);
                if ($key !== '') {
                    $map[$key] = (int) $c['id'];
                }
            }
        }
        if (!empty($map)) {
            Configuration::updateValue('INTIGO_CITIES_CACHE', json_encode($map));
            Configuration::updateValue('INTIGO_CITIES_CACHE_TS', (string) time());
        }
        return $map;
    }

    /**
     * Resolve a city name to its id. Returns ['id'=>int,'exact'=>bool]: exact when
     * the normalized name matched a city outright, false when no match (id=0).
     */
    public function resolveCityNameToId($city_name)
    {
        $key = self::normalizeName((string) $city_name);
        if ($key === '') {
            return ['id' => 0, 'exact' => false];
        }
        $map = $this->cityNameToIdMap();
        if (isset($map[$key])) {
            return ['id' => (int) $map[$key], 'exact' => true];
        }
        return ['id' => 0, 'exact' => false];
    }

    /**
     * True if $district_id is a real district of $city_id (the server enforces
     * this on create with a 400; we check first to avoid sending a bad pair).
     */
    public function districtBelongsToCity($district_id, $city_id)
    {
        $district_id = (int) $district_id;
        $city_id = (int) $city_id;
        if ($district_id <= 0 || $city_id <= 0) {
            return false;
        }
        $res = $this->fetchDistricts($city_id, '');
        if (empty($res['ok']) || empty($res['items'])) {
            return false;
        }
        foreach ($res['items'] as $d) {
            if ((int) $d['id'] === $district_id) {
                return true;
            }
        }
        return false;
    }

    /**
     * Normalize a place name for matching: lowercase, strip accents, drop
     * punctuation, collapse whitespace. "Ariana Ville " → "ariana ville".
     */
    public static function normalizeName($name)
    {
        $s = (string) $name;
        if (function_exists('iconv')) {
            $conv = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $s);
            if ($conv !== false) {
                $s = $conv;
            }
        }
        $s = strtolower($s);
        $s = preg_replace('/[^a-z0-9]+/', ' ', $s);
        $s = trim(preg_replace('/\s+/', ' ', $s));
        return $s;
    }

    /* ---------------- Pickup addresses ---------------- */

    /**
     * GET /v3/pickup-addresses/ — the merchant's pickup addresses.
     * Returns ['ok'=>bool, 'items'=>PickupAddressItem[], 'error'=>string].
     * Each item: id, index, street_address, city_name, district_name, has_gps.
     * No legacy fallback — this endpoint only exists on the v3 API.
     */
    public function listPickupAddresses()
    {
        $res = $this->request('GET', '/v3/pickup-addresses/', null, 'primary');
        if (empty($res['ok'])) {
            return [
                'ok' => false,
                'error' => $this->errorString($res),
                'items' => [],
            ];
        }
        return ['ok' => true, 'items' => $this->extractPickupList($res['data']), 'error' => ''];
    }

    /**
     * POST /v3/pickup-addresses/ — create a pickup address.
     * Returns the raw request shape (ok/code/data/error) so the caller can read
     * the created PickupAddressItem from data.pickup_address.
     */
    public function createPickupAddress(array $payload)
    {
        return $this->request('POST', '/v3/pickup-addresses/', $payload, 'primary');
    }

    public function getPickupAddress($index)
    {
        $index = rawurlencode((string) $index);
        return $this->request('GET', '/v3/pickup-addresses/' . $index, null, 'primary');
    }

    public function updatePickupAddress($index, array $payload)
    {
        $index = rawurlencode((string) $index);
        return $this->request('PATCH', '/v3/pickup-addresses/' . $index, $payload, 'primary');
    }

    /**
     * Normalize a pickup-addresses response into a flat list of items. The list
     * may arrive bare, or wrapped under data/results/pickup_addresses.
     */
    private function extractPickupList($json)
    {
        if (!is_array($json)) {
            return [];
        }
        $candidates = $json;
        foreach (['data', 'results', 'pickup_addresses'] as $key) {
            if (isset($json[$key]) && is_array($json[$key])) {
                $candidates = $json[$key];
                break;
            }
        }
        if (!is_array($candidates)) {
            return [];
        }
        $out = [];
        foreach ($candidates as $row) {
            if (!is_array($row)) {
                continue;
            }
            // `index` (the value sent as parcel.pickup_index) may legitimately be
            // null — we keep it null so the UI can mark the address unselectable.
            $index = array_key_exists('index', $row) && $row['index'] !== null ? (int) $row['index'] : null;
            $out[] = [
                'id' => isset($row['id']) ? (int) $row['id'] : 0,
                'index' => $index,
                'street_address' => isset($row['street_address']) ? (string) $row['street_address'] : '',
                'city_name' => isset($row['city_name']) ? (string) $row['city_name'] : '',
                'district_name' => isset($row['district_name']) ? (string) $row['district_name'] : '',
                'has_gps' => !empty($row['has_gps']),
                'is_primary' => !empty($row['is_primary']),
            ];
        }
        return $out;
    }

    /**
     * Human-readable error from a request() result (http code + body/error).
     */
    private function errorString($res)
    {
        if (!is_array($res)) {
            return 'unknown error';
        }
        if (!empty($res['error'])) {
            return (string) $res['error'];
        }
        if (isset($res['data']['detail'])) {
            return 'http=' . (int) ($res['code'] ?? 0) . ' ' . (string) $res['data']['detail'];
        }
        return 'http=' . (int) ($res['code'] ?? 0);
    }

    /* ---------------- Internals ---------------- */

    private function request($method, $path, $payload, $adapter)
    {
        $settings = $this->getSettings();
        $base = $adapter === 'legacy' ? $settings['legacy_base_url'] : $settings['primary_base_url'];
        $url = rtrim((string) $base, '/') . '/' . ltrim($path, '/');

        // No API key → never hit the network. Return a clear, non-throwing error.
        if (trim((string) $settings['api_key']) === '') {
            return ['ok' => false, 'code' => 0, 'error' => 'Intigo API key not configured', 'adapter' => $adapter, 'url' => $url];
        }

        $headers = [
            'Content-Type' => 'application/json',
            'X-API-KEY' => (string) $settings['api_key'],
        ];
        $body = $payload === null ? null : json_encode($payload);

        list($code, $resp_body, $error) = $this->httpRequest($method, $url, $headers, $body);

        if ($code === 0) {
            return ['ok' => false, 'code' => 0, 'error' => $error, 'adapter' => $adapter, 'url' => $url];
        }

        $json = json_decode((string) $resp_body, true);
        $data = is_array($json) ? $json : ['raw_body' => (string) $resp_body];

        if ($code >= 200 && $code < 300) {
            return ['ok' => true, 'code' => $code, 'data' => $data, 'adapter' => $adapter, 'url' => $url];
        }
        return ['ok' => false, 'code' => $code, 'data' => $data, 'adapter' => $adapter, 'url' => $url];
    }

    private function withFallback($method, $primary_path, $payload, $legacy_path)
    {
        $settings = $this->getSettings();
        $primary = $this->request($method, $primary_path, $payload, 'primary');
        if (!empty($primary['ok'])) {
            return $primary;
        }
        if ($settings['fallback_enabled'] !== 'yes') {
            return $primary;
        }
        if ((int) ($primary['code'] ?? 0) === 401 || empty($legacy_path)) {
            return $primary;
        }
        $primary_base = rtrim((string) $settings['primary_base_url'], '/');
        $legacy_base = rtrim((string) $settings['legacy_base_url'], '/');
        if ($primary_base !== '' && $primary_base === $legacy_base) {
            return $primary;
        }
        $legacy = $this->request($method, $legacy_path, $payload, 'legacy');
        if (!empty($legacy['ok'])) {
            return $legacy;
        }
        $primary['legacy_attempt'] = [
            'code' => $legacy['code'] ?? 0,
            'error' => $legacy['error'] ?? '',
            'data' => $legacy['data'] ?? null,
            'url' => $legacy['url'] ?? '',
        ];
        return $primary;
    }

    private function fetchLookupArray($url, $settings)
    {
        // No API key → never hit the network.
        if (trim((string) ($settings['api_key'] ?? '')) === '') {
            return ['ok' => false, 'error' => 'Intigo API key not configured', 'items' => []];
        }
        $headers = [
            'Content-Type' => 'application/json',
            'X-API-KEY' => (string) ($settings['api_key'] ?? ''),
        ];
        list($code, $body, $error) = $this->httpRequest('GET', $url, $headers, null);

        // The WP plugin retries with a trailing slash for 301/302/307/308/404 — same behavior here.
        if (in_array($code, [301, 302, 307, 308, 404], true) && substr($url, -1) !== '/') {
            list($retry_code, $retry_body, $retry_error) = $this->httpRequest('GET', $url . '/', $headers, null);
            if ($retry_code >= 200 && $retry_code < 300) {
                $code = $retry_code;
                $body = $retry_body;
                $error = $retry_error;
            }
        }
        if ($code === 0) {
            return ['ok' => false, 'error' => $error, 'items' => []];
        }
        if ($code < 200 || $code >= 300) {
            return ['ok' => false, 'error' => 'http=' . $code, 'items' => []];
        }
        $json = json_decode((string) $body, true);
        return ['ok' => true, 'items' => $this->extractList($json)];
    }

    private function extractList($json)
    {
        if (!is_array($json)) {
            return [];
        }
        $candidates = $json;
        if (isset($json['data']) && is_array($json['data'])) {
            $candidates = $json['data'];
        } elseif (isset($json['results']) && is_array($json['results'])) {
            $candidates = $json['results'];
        } elseif (isset($json['cities']) && is_array($json['cities'])) {
            $candidates = $json['cities'];
        } elseif (isset($json['districts']) && is_array($json['districts'])) {
            $candidates = $json['districts'];
        } elseif (isset($json['neighborhoods']) && is_array($json['neighborhoods'])) {
            $candidates = $json['neighborhoods'];
        }
        if (!is_array($candidates)) {
            return [];
        }
        $out = [];
        foreach ($candidates as $row) {
            if (is_array($row) && isset($row['id'], $row['name'])) {
                $out[] = ['id' => (int) $row['id'], 'name' => (string) $row['name']];
            }
        }
        return $out;
    }

    private function filterLookupItems($result, $query)
    {
        if (empty($result['ok'])) {
            return $result;
        }
        $query = strtolower(trim((string) $query));
        if ($query === '') {
            return $result;
        }
        $result['items'] = array_values(array_filter($result['items'], function ($item) use ($query) {
            return is_array($item) && isset($item['name'])
                && strpos(strtolower((string) $item['name']), $query) !== false;
        }));
        return $result;
    }

    /**
     * Transport: prefers Guzzle when present, falls back to curl.
     * Returns [http_code, body, error_message]. http_code = 0 on transport error.
     */
    private function httpRequest($method, $url, array $headers, $body)
    {
        $method = strtoupper($method);

        // Use cURL directly (a PrestaShop system requirement, stable API on all
        // versions). We deliberately do NOT use the bundled Guzzle: its version —
        // and even whether GuzzleHttp\Client::request() exists — varies across
        // PrestaShop 1.7/8/9 and 500'd on 1.7.8.11 ("undefined method request").
        if (!function_exists('curl_init')) {
            return [0, '', 'cURL extension not available'];
        }
        $ch = curl_init($url);
        $hdr = [];
        foreach ($headers as $k => $v) {
            $hdr[] = $k . ': ' . $v;
        }
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CONNECTTIMEOUT => 4,
            CURLOPT_TIMEOUT => 10,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => $hdr,
        ]);
        if ($body !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        }
        $resp = curl_exec($ch);
        if ($resp === false) {
            $err = curl_error($ch);
            curl_close($ch);
            return [0, '', $err];
        }
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return [$code, (string) $resp, ''];
    }

    /* ---------------- Helpers ---------------- */

    public static function normalizeSizeLetter($raw, $default = 'S')
    {
        $u = strtoupper(trim((string) $raw));
        return in_array($u, ['S', 'M', 'L', 'XL'], true) ? $u : $default;
    }

    /**
     * Mapping: S=1, M=2, L=4, XL=5. Matches the WP plugin's normalize_package_size().
     */
    public static function sizeLetterToCode($letter)
    {
        $map = ['S' => 1, 'M' => 2, 'L' => 4, 'XL' => 5];
        $u = strtoupper(trim((string) $letter));
        return isset($map[$u]) ? $map[$u] : 1;
    }
}
