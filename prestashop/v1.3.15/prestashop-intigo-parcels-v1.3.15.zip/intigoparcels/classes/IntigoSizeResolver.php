<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * 3-layer waterfall (port of class-intigo-size-resolver.php):
 *
 *   1. Per-order admin override (column intigo_parcel.package_size, set via order BO)
 *   2. Per-product seller assignment (intigo_product_size table)
 *   3. Plugin-wide default (Configuration INTIGO_DEFAULT_SIZE)
 *
 * Cart aggregation: MAX by rank (S<M<L<XL) — parcel must physically contain
 * the biggest item.
 */
class IntigoSizeResolver
{
    const ALLOWED = ['S', 'M', 'L', 'XL'];
    const RANK = ['S' => 1, 'M' => 2, 'L' => 3, 'XL' => 4];

    public static function resolveForProduct($id_product)
    {
        $override = IntigoProductSize::getForProduct((int) $id_product);
        if ($override !== '') {
            return $override;
        }
        return self::pluginDefault();
    }

    /**
     * Aggregate sizes across a PrestaShop Cart's products.
     */
    public static function resolveForCart(Cart $cart)
    {
        $products = $cart->getProducts();
        if (!is_array($products) || empty($products)) {
            return self::pluginDefault();
        }
        $ids = array_map(function ($p) {
            return (int) $p['id_product'];
        }, $products);
        $overrides = IntigoProductSize::getForProducts($ids);

        $sizes = [];
        $default = self::pluginDefault();
        foreach ($ids as $id) {
            $sizes[] = isset($overrides[$id]) ? $overrides[$id] : $default;
        }
        return self::maxByRank($sizes);
    }

    /**
     * Per-order override wins; otherwise aggregate from order's products.
     */
    public static function resolveForOrder(Order $order)
    {
        $parcel = IntigoParcel::findByOrderId((int) $order->id);
        if ($parcel && !empty($parcel->package_size)) {
            // package_size is stored as int code (1/2/4/5) on the order row;
            // the order-level override is set explicitly by admin and should win.
            // But only honor it if it was deliberately set — we treat 0 as "not set"
            // and the default 1 (S) is indistinguishable from "set to S", so we
            // re-derive from products when package_size is the default value 1
            // AND there's no row-level signal. Simplest correct behavior: if
            // parcel row exists and admin saved it, treat it as authoritative.
            $letter = self::codeToLetter((int) $parcel->package_size);
            if ($letter !== '') {
                return $letter;
            }
        }
        $products = $order->getProducts();
        if (!is_array($products) || empty($products)) {
            return self::pluginDefault();
        }
        $ids = array_map(function ($p) {
            return (int) $p['product_id'];
        }, $products);
        $overrides = IntigoProductSize::getForProducts($ids);
        $sizes = [];
        $default = self::pluginDefault();
        foreach ($ids as $id) {
            $sizes[] = isset($overrides[$id]) ? $overrides[$id] : $default;
        }
        return self::maxByRank($sizes);
    }

    public static function pluginDefault()
    {
        return IntigoApiClient::normalizeSizeLetter(Configuration::get('INTIGO_DEFAULT_SIZE'), 'S');
    }

    public static function maxByRank(array $sizes)
    {
        $best_rank = 0;
        $best = 'S';
        foreach ($sizes as $code) {
            $code = strtoupper(trim((string) $code));
            $rank = isset(self::RANK[$code]) ? self::RANK[$code] : 0;
            if ($rank > $best_rank) {
                $best_rank = $rank;
                $best = $code;
            }
        }
        return $best;
    }

    public static function codeToLetter($code)
    {
        $map = [1 => 'S', 2 => 'M', 4 => 'L', 5 => 'XL'];
        return isset($map[(int) $code]) ? $map[(int) $code] : '';
    }
}
