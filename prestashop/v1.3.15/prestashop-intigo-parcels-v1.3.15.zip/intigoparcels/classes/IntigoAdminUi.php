<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Shared back-office UI helpers, written in the portable legacy style so they
 * render identically on PrestaShop 1.7 / 8 / 9 (plain HTML + BO Bootstrap/UI-Kit
 * classes that exist across all three). This is the Shopify-style chrome — the
 * top nav bar and small building blocks — reused by every Intigo admin screen.
 */
class IntigoAdminUi
{
    /**
     * Lightweight translator. The module defaults to FRENCH (the Intigo / Fnac
     * Darty audience); it falls back to the given English source only when the
     * back-office is explicitly in English. Pass English source text as the key.
     */
    public static function t($en)
    {
        // The module defaults to FRENCH (the Intigo / Fnac Darty audience),
        // regardless of the back-office language — so it reads French even on a
        // shop that doesn't have the French language pack installed. Any key not
        // in the dictionary falls back to its English source text.
        $fr = self::frDictionary();

        return isset($fr[$en]) ? $fr[$en] : $en;
    }

    /**
     * Transient toast for the flash-style notice query params (auto-dismisses).
     * Returns '' when there is no notice. Position-fixed, so call it once per page.
     */
    public static function noticeToast()
    {
        $msg = (string) Tools::getValue('intigo_notice');
        if (trim($msg) === '') {
            return '';
        }
        $type = (string) Tools::getValue('intigo_notice_type');
        $cls = $type === 'error' ? 'intigo-toast--error'
            : ($type === 'warning' ? 'intigo-toast--warning' : 'intigo-toast--success');
        $icon = $type === 'error' ? 'error_outline' : ($type === 'warning' ? 'warning' : 'check_circle');

        return '<div class="intigo-toast ' . $cls . '" id="intigo-toast">'
            . '<i class="material-icons">' . $icon . '</i>'
            . '<span>' . htmlspecialchars($msg) . '</span>'
            . '<span class="intigo-toast-close" onclick="this.parentNode.remove()">&times;</span>'
            . '</div>'
            . '<script>setTimeout(function(){var t=document.getElementById("intigo-toast");'
            . 'if(t){t.style.transition="opacity .4s,transform .4s";t.style.opacity=0;t.style.transform="translateX(40px)";'
            . 'setTimeout(function(){if(t.parentNode){t.parentNode.removeChild(t);}},420);}},5000);</script>';
    }

    private static function frDictionary()
    {
        return [
            // Navigation
            'Dashboard' => 'Tableau de bord',
            'Orders' => 'Commandes',
            'Product sizes' => 'Tailles produits',
            'Product Sizes' => 'Tailles produits',
            'Logs' => 'Journaux',
            'Settings' => 'Réglages',
            'Docs' => 'Aide',
            // Dashboard
            'Recent orders' => 'Commandes récentes',
            'In your shop' => 'Dans votre boutique',
            'Synced to Intigo' => 'Synchronisées avec Intigo',
            'of orders' => 'des commandes',
            'Bordereaux ready' => 'Bordereaux prêts',
            'Of' => 'Sur',
            'synced' => 'synchronisées',
            'API calls (24h)' => 'Appels API (24h)',
            'All healthy' => 'Tout fonctionne',
            'failed — see Logs' => 'en échec — voir Journaux',
            'Sync coverage' => 'Couverture de synchronisation',
            'How many of your orders have a matching Intigo parcel.' => 'Combien de vos commandes ont un colis Intigo associé.',
            'Coverage' => 'Couverture',
            'Open Orders' => 'Ouvrir les commandes',
            'Environment' => 'Environnement',
            'Production' => 'Production',
            'Sandbox' => 'Bac à sable',
            'API key set' => 'Clé API définie',
            'API key missing' => 'Clé API manquante',
            'Service URL' => 'URL du service',
            'Change environment' => 'Changer d\'environnement',
            // Orders
            'No orders yet' => 'Aucune commande pour l\'instant',
            'When customers place orders in your shop, they appear here so you can ship them with Intigo. Start by adding your API key, then create your first parcel from an order.' => 'Lorsque des clients passent commande, elles apparaissent ici pour être expédiées via Intigo. Commencez par saisir votre clé API, puis créez votre premier colis depuis une commande.',
            'Go to Settings' => 'Aller aux Réglages',
            'API key required.' => 'Clé API requise.',
            'Add your Intigo API key before pushing parcels.' => 'Ajoutez votre clé API Intigo avant d\'envoyer des colis.',
            'Add your Intigo API key to start creating parcels.' => 'Ajoutez votre clé API Intigo pour commencer à créer des colis.',
            'All' => 'Toutes',
            'Not synced' => 'Non synchronisée',
            'Synced' => 'Synchronisée',
            'Failed' => 'Échec',
            'Intigo carrier' => 'Transporteur Intigo',
            'No orders match this filter' => 'Aucune commande ne correspond à ce filtre',
            'Reference' => 'Référence',
            'Customer' => 'Client',
            'City' => 'Ville',
            'Carrier' => 'Transporteur',
            'Total' => 'Total',
            'Intigo status' => 'Statut Intigo',
            'Actions' => 'Actions',
            'Bordereau ready' => 'Bordereau prêt',
            'Edit' => 'Modifier',
            'Send to Intigo' => 'Envoyer à Intigo',
            'Open bordereau' => 'Ouvrir le bordereau',
            'Copy' => 'Copier',
            'Copy link' => 'Copier le lien',
            'Generate bordereau' => 'Générer le bordereau',
            'Cancel' => 'Annuler',
            'Edit Intigo delivery details' => 'Modifier les détails de livraison Intigo',
            'Add city & district first — click Edit to complete, then Send.' => 'Ajoutez d\'abord la ville et le district — cliquez sur Modifier pour compléter, puis Envoyer.',
            'Bordereau ready.' => 'Bordereau prêt.',
            // Settings
            'Connection' => 'Connexion',
            'API key' => 'Clé API',
            'Tracking URL' => 'URL de suivi',
            'Legacy fallback' => 'Repli hérité',
            'Test connection' => 'Tester la connexion',
            'Order processing' => 'Traitement des commandes',
            'Mode' => 'Mode',
            'Defaults' => 'Valeurs par défaut',
            'Default package size' => 'Taille de colis par défaut',
            'Shipping price per size' => 'Tarif de livraison par taille',
            'Save' => 'Enregistrer',
            'Cron / status sync' => 'Cron / synchro des statuts',
            'Settings saved.' => 'Réglages enregistrés.',
            // Product sizes
            'Search' => 'Rechercher',
            'Clear' => 'Effacer',
            'Product' => 'Produit',
            'Intigo size' => 'Taille Intigo',
            'Save sizes' => 'Enregistrer les tailles',
            'No products found' => 'Aucun produit trouvé',
            // Pickup addresses
            'Pickup addresses' => 'Adresses de ramassage',
            'Your pickup addresses' => 'Vos adresses de ramassage',
            'Add a pickup address' => 'Ajouter une adresse de ramassage',
            'Address' => 'Adresse',
            'City / District' => 'Ville / Délégation',
            'GPS' => 'GPS',
            'Index' => 'Index',
            'Linked status' => 'Statut associé',
            'None' => 'Aucun',
            'Save associations' => 'Enregistrer les associations',
            'Street address' => 'Adresse (rue)',
            'District' => 'Délégation',
            'Neighborhood' => 'Cité',
            'Primary pickup address' => 'Adresse de ramassage principale',
            'Create address' => 'Créer l\'adresse',
            'Configure your API key first in Settings.' => 'Configurez d\'abord votre clé API dans Réglages.',
            'Unable to reach Intigo — showing cached data.' => 'Impossible de joindre Intigo — affichage du cache.',
            'last sync' => 'dernière synchro',
            'not available' => 'non disponible',
            'This address has no usable index; contact Intigo.' => 'Cette adresse n\'a pas d\'index utilisable ; contactez Intigo.',
            'No pickup addresses yet' => 'Aucune adresse de ramassage pour l\'instant',
            'Create your first pickup address below — the courier collects parcels from it.' => 'Créez votre première adresse de ramassage ci-dessous — le livreur y récupère les colis.',
            'Associations saved.' => 'Associations enregistrées.',
            'Pickup address created.' => 'Adresse de ramassage créée.',
            'Choose a status…' => 'Choisir un statut…',
            'Use a mapped status as an automatic push trigger' => 'Utiliser un statut associé comme déclencheur de push automatique',
            'When ON, moving an order to a mapped status pushes its parcel automatically (with the matching pickup).' => 'Si activé, faire passer une commande à un statut associé envoie son colis automatiquement (avec le bon ramassage).',
            'Select a city' => 'Sélectionner une ville',
            'Optional' => 'Optionnel',
            'obsolete' => 'obsolète',
        ];
    }

    /**
     * Horizontal in-page navigation bar (the Shopify NavMenu analogue). Always
     * visible at the top of every Intigo screen, so navigation never depends on
     * where the BO sidebar parks our tab.
     *
     * @param Link   $link   PrestaShop link generator ($this->context->link)
     * @param string $active one of: dashboard|orders|product_sizes|logs|settings|docs
     */
    /**
     * Whether the current employee's profile may VIEW a given admin tab. Mirrors
     * PrestaShop's own left-menu filtering so the in-page nav never shows a tab
     * the user cannot open. SuperAdmin always passes; any error degrades to
     * hidden (never throws — must not break a back-office page).
     */
    public static function canSeeTab($className)
    {
        try {
            $ctx = Context::getContext();
            if (!isset($ctx->employee) || !Validate::isLoadedObject($ctx->employee)) {
                return false;
            }
            if ((int) $ctx->employee->id_profile === 1) {
                return true; // SuperAdmin
            }
            $id_tab = (int) Tab::getIdFromClassName($className);
            if ($id_tab <= 0) {
                return false;
            }
            $access = Profile::getProfileAccess((int) $ctx->employee->id_profile, $id_tab);
            return !empty($access['view']);
        } catch (\Throwable $e) {
            return false;
        }
    }

    /** Whether the current employee may open the "Accès" page (SuperAdmin, or explicitly granted). */
    public static function canSeeAccess()
    {
        return self::canSeeTab('AdminIntigoAccess');
    }

    public static function navHtml($link, $active)
    {
        $items = [
            ['Dashboard', 'dashboard', 'AdminIntigoDashboard', 'dashboard'],
            ['Orders', 'local_shipping', 'AdminIntigoOrders', 'orders'],
            ['Pickup addresses', 'place', 'AdminIntigoPickup', 'pickup'],
            ['Product sizes', 'straighten', 'AdminIntigoProductSizes', 'product_sizes'],
            ['Logs', 'receipt', 'AdminIntigoLogs', 'logs'],
            ['Settings', 'settings', 'AdminIntigoSettings', 'settings'],
            ['Docs', 'menu_book', 'AdminIntigoDocs', 'docs'],
            ['Accès', 'admin_panel_settings', 'AdminIntigoAccess', 'access'],
        ];
        $h = '<nav class="intigo-nav">';
        foreach ($items as $it) {
            // Hide tabs the current employee's profile cannot view — mirrors the
            // left-hand menu, which PrestaShop already filters by tab permission.
            if (!self::canSeeTab($it[2])) {
                continue;
            }
            $url = $link->getAdminLink($it[2]);
            $cls = $it[3] === $active ? ' active' : '';
            $h .= '<a href="' . htmlspecialchars($url) . '" class="intigo-nav-item' . $cls . '">'
                . '<i class="material-icons">' . $it[1] . '</i><span>' . htmlspecialchars(self::t($it[0])) . '</span></a>';
        }
        $h .= '</nav>';

        return $h;
    }

    /**
     * Friendly empty state with an optional primary call-to-action.
     */
    public static function emptyState($icon, $title, $message, $ctaLabel = '', $ctaUrl = '')
    {
        $h = '<div class="intigo-empty">'
            . '<i class="material-icons intigo-empty-icon">' . htmlspecialchars($icon) . '</i>'
            . '<h3>' . htmlspecialchars(self::t($title)) . '</h3>'
            . '<p>' . self::t($message) . '</p>';
        if ($ctaLabel !== '' && $ctaUrl !== '') {
            $h .= '<a href="' . htmlspecialchars($ctaUrl) . '" class="btn btn-primary">' . htmlspecialchars(self::t($ctaLabel)) . '</a>';
        }
        $h .= '</div>';

        return $h;
    }
}
