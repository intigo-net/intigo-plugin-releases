(function () {
    "use strict";

    function init() {
        var panel = document.getElementById("intigo-order-side");
        if (!panel || panel.dataset.intigoBound === "1") {
            return;
        }
        panel.dataset.intigoBound = "1";

        var regionsUrl = panel.getAttribute("data-regions-url");
        if (!regionsUrl) { return; }

        // Locked parcels start read-only; "Modifier" unlocks every field. We must
        // not auto-enable the cascading selects while locked, or the lock leaks.
        var lockedAtStart = panel.dataset.hasNid === "1";
        var editable = !lockedAtStart;

        var cityEl = panel.querySelector(".intigo-city");
        var districtEl = panel.querySelector(".intigo-district");
        var neighborhoodEl = panel.querySelector(".intigo-neighborhood");
        if (!cityEl || !districtEl) { return; }

        var preCity = parseInt(cityEl.dataset.selected || "0", 10);
        var preDistrict = parseInt(districtEl.dataset.selected || "0", 10);
        var preNeighborhood = parseInt(neighborhoodEl ? neighborhoodEl.dataset.selected || "0" : "0", 10);

        // ---- Edit / lock toggle ----
        var editBtn = panel.querySelector(".intigo-edit-btn");
        var saveBtn = panel.querySelector(".intigo-save-btn");
        var cancelEditBtn = panel.querySelector(".intigo-cancel-edit-btn");
        var lockedActions = panel.querySelectorAll(".intigo-locked-action");

        if (editBtn) {
            editBtn.addEventListener("click", function () {
                editable = true;
                panel.classList.remove("intigo-locked");
                // Enable every stored field for editing.
                panel.querySelectorAll(".intigo-field").forEach(function (el) {
                    el.disabled = false;
                });
                editBtn.style.display = "none";
                lockedActions.forEach(function (b) { b.style.display = "none"; });
                if (saveBtn) { saveBtn.style.display = ""; }
                if (cancelEditBtn) { cancelEditBtn.style.display = ""; }
            });
        }
        if (cancelEditBtn) {
            // Discard unsaved edits by reloading the order view.
            cancelEditBtn.addEventListener("click", function () {
                window.location.reload();
            });
        }

        loadCities(preCity);

        cityEl.addEventListener("change", function () {
            districtEl.innerHTML = '<option value="">— choisir une délégation —</option>';
            if (editable) { districtEl.disabled = !cityEl.value; }
            if (neighborhoodEl) {
                neighborhoodEl.innerHTML = '<option value="">— facultatif —</option>';
                if (editable) { neighborhoodEl.disabled = true; }
            }
            if (cityEl.value) {
                loadDistricts(parseInt(cityEl.value, 10), 0);
            }
        });
        districtEl.addEventListener("change", function () {
            if (!neighborhoodEl) { return; }
            neighborhoodEl.innerHTML = '<option value="">— facultatif —</option>';
            if (editable) { neighborhoodEl.disabled = !districtEl.value; }
            if (districtEl.value) {
                loadNeighborhoods(parseInt(districtEl.value, 10), 0);
            }
        });

        function loadCities(selectId) {
            fetchJson(regionsUrl + "&action=cities").then(function (data) {
                if (!data || !data.ok) { return; }
                fillSelect(cityEl, data.items, selectId);
                if (selectId > 0) {
                    loadDistricts(selectId, preDistrict);
                }
            });
        }
        function loadDistricts(cityId, selectId) {
            fetchJson(regionsUrl + "&action=districts&city_id=" + cityId).then(function (data) {
                if (!data || !data.ok) { return; }
                fillSelect(districtEl, data.items, selectId);
                if (editable) { districtEl.disabled = false; }
                if (selectId > 0 && neighborhoodEl) {
                    loadNeighborhoods(selectId, preNeighborhood);
                }
            });
        }
        function loadNeighborhoods(districtId, selectId) {
            fetchJson(regionsUrl + "&action=neighborhoods&district_id=" + districtId).then(function (data) {
                if (!data || !data.ok || !neighborhoodEl) { return; }
                fillSelect(neighborhoodEl, data.items, selectId);
                if (editable) { neighborhoodEl.disabled = false; }
            });
        }

        function fillSelect(sel, items, selectId) {
            while (sel.options.length > 1) { sel.remove(1); }
            (items || []).forEach(function (it) {
                var opt = document.createElement("option");
                opt.value = it.id;
                opt.textContent = it.name;
                if (parseInt(selectId, 10) === parseInt(it.id, 10)) {
                    opt.selected = true;
                }
                sel.appendChild(opt);
            });
        }

        function fetchJson(url) {
            return fetch(url, { credentials: "same-origin" })
                .then(function (r) { return r.json(); })
                .catch(function () { return null; });
        }
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", init);
    } else {
        init();
    }
})();
