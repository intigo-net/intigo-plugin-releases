<div class="panel" id="intigo-settings-panel">
    <div class="panel-heading">
        <i class="material-icons">settings</i> {l s='Intigo — Settings' mod='intigoparcels'}
    </div>

    {if $intigo_notice}
        <div class="alert alert-{if $intigo_notice_type == 'success'}success{elseif $intigo_notice_type == 'error'}danger{elseif $intigo_notice_type == 'warning'}warning{else}info{/if}">
            {$intigo_notice|escape:'html':'UTF-8'}
        </div>
    {/if}

    {if $intigo_health}
        <div class="alert alert-{if $intigo_health.ok}success{else}danger{/if}">
            <strong>{l s='Connection' mod='intigoparcels'}:</strong>
            {$intigo_health.message|escape:'html':'UTF-8'}
            <small class="text-muted">({$intigo_health.at|escape:'html':'UTF-8'})</small>
        </div>
    {/if}

    <form method="post" action="{$intigo_form_action|escape:'html':'UTF-8'}" class="form-horizontal">
        <fieldset>
            <legend>{l s='Connection' mod='intigoparcels'}</legend>

            <div class="form-group">
                <label class="control-label col-lg-3">{l s='Environment' mod='intigoparcels'}</label>
                <div class="col-lg-6">
                    <label class="radio-inline">
                        <input type="radio" name="INTIGO_ENVIRONMENT" value="sandbox" {if $intigo_settings.environment_mode == 'sandbox'}checked{/if}>
                        {l s='Sandbox' mod='intigoparcels'} <small>(dev-api.intigo.net)</small>
                    </label>
                    <label class="radio-inline">
                        <input type="radio" name="INTIGO_ENVIRONMENT" value="production" {if $intigo_settings.environment_mode == 'production'}checked{/if}>
                        {l s='Production' mod='intigoparcels'} <small>(api.intigo.net)</small>
                    </label>
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-lg-3">{l s='API Key' mod='intigoparcels'}</label>
                <div class="col-lg-6">
                    <input type="text" name="INTIGO_API_KEY" value="{$intigo_settings.api_key|escape:'html':'UTF-8'}" class="form-control" autocomplete="off">
                    <p class="help-block">{l s='Sent as the X-API-KEY header on every API call.' mod='intigoparcels'}</p>
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-lg-3">{l s='Legacy fallback' mod='intigoparcels'}</label>
                <div class="col-lg-6">
                    <label class="checkbox-inline">
                        <input type="checkbox" name="INTIGO_FALLBACK_ENABLED" value="1" {if $intigo_settings.fallback_enabled == 'yes'}checked{/if}>
                        {l s='Enabled' mod='intigoparcels'}
                    </label>
                    <p class="help-block">{l s='Retry against legacy /expediteurs/api endpoints when the v3 call fails (non-auth errors only).' mod='intigoparcels'}</p>
                </div>
            </div>
        </fieldset>

        <fieldset>
            <legend>{l s='Order processing' mod='intigoparcels'}</legend>
            <div class="form-group">
                <label class="control-label col-lg-3">{l s='Mode' mod='intigoparcels'}</label>
                <div class="col-lg-6">
                    <label class="radio-inline">
                        <input type="radio" name="INTIGO_AUTO_CREATE" value="0" {if !$intigo_settings.auto_create}checked{/if}>
                        {l s='Manual — admin sends each order from the Orders tab' mod='intigoparcels'}
                    </label><br>
                    <label class="radio-inline">
                        <input type="radio" name="INTIGO_AUTO_CREATE" value="1" {if $intigo_settings.auto_create}checked{/if}>
                        {l s='Automatic — push parcel to Intigo as soon as the order is paid' mod='intigoparcels'}
                    </label>
                </div>
            </div>
        </fieldset>

        <fieldset>
            <legend>{l s='Default package size' mod='intigoparcels'}</legend>
            <div class="form-group">
                <label class="control-label col-lg-3">{l s='Default size' mod='intigoparcels'}</label>
                <div class="col-lg-3">
                    <select name="INTIGO_DEFAULT_SIZE" class="form-control">
                        {foreach from=['S','M','L','XL'] item=s}
                            <option value="{$s}" {if $intigo_settings.default_package_size == $s}selected{/if}>{$s}</option>
                        {/foreach}
                    </select>
                    <p class="help-block">{l s='Used when a product has no per-product size override. Sent to Intigo as the package_size field on each parcel.' mod='intigoparcels'}</p>
                </div>
            </div>
            <div class="alert alert-info">
                <strong>{l s='Shipping price?' mod='intigoparcels'}</strong>
                {l s='This module does not manage shipping prices. Configure pricing for Intigo Delivery in' mod='intigoparcels'}
                <strong>Shipping → Carriers → Intigo Delivery</strong>
                {l s='— PrestaShop\'s native price/weight ranges.' mod='intigoparcels'}
            </div>
        </fieldset>

        <fieldset>
            <legend>{l s='Cron / status sync' mod='intigoparcels'}</legend>
            <p>{l s='Run this URL hourly via the Cron Jobs module or system cron:' mod='intigoparcels'}</p>
            <pre style="white-space: pre-wrap; word-break: break-all;"><code>{$intigo_cron_url|escape:'html':'UTF-8'}</code></pre>
            <p class="help-block">{l s='Token:' mod='intigoparcels'} <code>{$intigo_cron_token|escape:'html':'UTF-8'}</code></p>
        </fieldset>

        <div class="panel-footer">
            <button type="submit" name="submitIntigoSettings" value="1" class="btn btn-default pull-right">
                <i class="process-icon-save"></i> {l s='Save' mod='intigoparcels'}
            </button>
            <button type="submit" name="intigo_test_connection" value="1" class="btn btn-default">
                <i class="icon-flash"></i> {l s='Test connection' mod='intigoparcels'}
            </button>
        </div>
    </form>
</div>
