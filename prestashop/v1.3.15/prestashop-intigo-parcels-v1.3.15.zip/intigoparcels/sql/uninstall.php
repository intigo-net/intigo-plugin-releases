<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

$sql = [
    'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'intigo_parcel`',
    'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'intigo_product_size`',
    'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'intigo_cart`',
    'DROP TABLE IF EXISTS `' . _DB_PREFIX_ . 'intigo_log`',
];

foreach ($sql as $query) {
    if (Db::getInstance()->execute($query) == false) {
        return false;
    }
}

return true;
