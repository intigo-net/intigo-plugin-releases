<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

require_once dirname(__FILE__) . '/../../classes/IntigoAutoload.php';

/**
 * Intigo → Settings (legacy ModuleAdminController — portable across PS 1.7/8/9).
 * Connection, order-processing mode, default size, cron token + a connection test.
 */
class AdminIntigoSettingsController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        $this->display = 'view';
        parent::__construct();
        $this->meta_title = 'Intigo — Settings';
        // Hide PrestaShop's default "Afficher" page-header toolbar; our in-page
        // nav bar + breadcrumb already identify the screen (cleaner header).
        $this->show_page_header_toolbar = false;
    }

    public function initContent()
    {
        parent::initContent();
        try {
            if (Tools::isSubmit('submitIntigoSettings')) {
                $this->handleSave();
            } elseif (Tools::isSubmit('submitIntigoWebhook')) {
                $this->handleSaveWebhook();
            } elseif (Tools::isSubmit('intigo_gen_webhook_token')) {
                Configuration::updateValue('INTIGO_WEBHOOK_TOKEN', bin2hex(random_bytes(16)));
                $this->redirectWithNotice('Nouveau jeton généré.', 'success');
            } elseif (Tools::isSubmit('intigo_test_connection')) {
                $this->handleTest();
            }
            $this->content = $this->render();
        } catch (Exception $e) {
            IntigoLog::add('settings_error', $e->getMessage());
            $this->content = '<div class="alert alert-warning">Intigo settings are temporarily unavailable.</div>';
        }
        $this->context->smarty->assign('content', $this->content);
    }

    private function handleSave()
    {
        $env = Tools::getValue('INTIGO_ENVIRONMENT') === 'production' ? 'production' : 'sandbox';
        Configuration::updateValue('INTIGO_ENVIRONMENT', $env);
        Configuration::updateValue('INTIGO_API_KEY', trim((string) Tools::getValue('INTIGO_API_KEY')));
        Configuration::updateValue('INTIGO_FALLBACK_ENABLED', Tools::getValue('INTIGO_FALLBACK_ENABLED') ? '1' : '0');
        Configuration::updateValue('INTIGO_AUTO_CREATE', Tools::getValue('INTIGO_AUTO_CREATE') ? '1' : '0');
        Configuration::updateValue('INTIGO_DEFAULT_SIZE', IntigoApiClient::normalizeSizeLetter(Tools::getValue('INTIGO_DEFAULT_SIZE'), 'S'));

        // Tracking URL → applied to the live carrier so customers see it.
        $tracking = trim((string) Tools::getValue('INTIGO_TRACKING_URL'));
        Configuration::updateValue('INTIGO_TRACKING_URL', $tracking);
        $cid = (int) Configuration::get('INTIGO_CARRIER_ID');
        if ($cid > 0) {
            $carrier = new Carrier($cid);
            if (Validate::isLoadedObject($carrier)) {
                $carrier->url = $tracking;
                $carrier->update();
            }
        }

        // Per-size shipping prices (the carrier charges by resolved package size).
        foreach (['S', 'M', 'L', 'XL'] as $s) {
            $v = (float) str_replace(',', '.', (string) Tools::getValue('INTIGO_PRICE_' . $s));
            Configuration::updateValue('INTIGO_PRICE_' . $s, $v < 0 ? 0 : $v);
        }

        // Cash-on-delivery methods: ticked payment methods + any extra keywords.
        // COD → full amount to Intigo; every other (paid-online) method → 0.
        $sel = Tools::getValue('INTIGO_COD_METHODS_SEL');
        $parts = is_array($sel) ? array_map('trim', $sel) : [];
        $extra = trim((string) Tools::getValue('INTIGO_COD_METHODS_EXTRA'));
        if ($extra !== '') {
            foreach (preg_split('/[\r\n,;]+/', $extra) as $e) {
                $e = trim($e);
                if ($e !== '') {
                    $parts[] = $e;
                }
            }
        }
        $parts = array_values(array_unique(array_filter($parts, function ($v) { return $v !== ''; })));
        Configuration::updateValue('INTIGO_COD_METHODS', implode(',', $parts));

        IntigoLog::add('settings_save', 'env=' . $env);
        $this->redirectWithNotice('Settings saved.', 'success');
    }

    private function handleSaveWebhook()
    {
        require_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoStatus.php';
        Configuration::updateValue('INTIGO_WEBHOOK_TOKEN', trim((string) Tools::getValue('INTIGO_WEBHOOK_TOKEN')));
        Configuration::updateValue('INTIGO_WH_UPDATE_ORDERS', Tools::getValue('INTIGO_WH_UPDATE_ORDERS') ? '1' : '0');
        // Full Intigo-status → PS-state map (many-to-many).
        $posted = Tools::getValue('wh_map');
        $posted = is_array($posted) ? $posted : [];
        $map = [];
        foreach ($posted as $code => $state) {
            $map[(int) $code] = (int) $state;
        }
        IntigoStatus::setMap($map);
        IntigoLog::add('webhook_settings_save', 'statuses mapped=' . count(IntigoStatus::getMap()));
        $this->redirectWithNotice('Synchronisation des statuts enregistrée.', 'success');
    }

    private function handleTest()
    {
        $api = new IntigoApiClient();
        $res = $api->healthCheck();
        IntigoLog::add($res['ok'] ? 'health_ok' : 'health_failed', (string) $res['message']);
        $this->redirectWithNotice(
            ($res['ok'] ? 'Connection OK — ' : 'Connection failed — ') . (string) $res['message'],
            $res['ok'] ? 'success' : 'error'
        );
    }

    private function redirectWithNotice($message, $type)
    {
        Tools::redirectAdmin(
            self::$currentIndex . '&token=' . $this->token
            . '&intigo_notice=' . rawurlencode($message)
            . '&intigo_notice_type=' . rawurlencode($type)
        );
    }

    private function render()
    {
        $env = Configuration::get('INTIGO_ENVIRONMENT') === 'production' ? 'production' : 'sandbox';
        $api_key = (string) Configuration::get('INTIGO_API_KEY');
        $fallback = (string) Configuration::get('INTIGO_FALLBACK_ENABLED') === '1';
        $auto = (string) Configuration::get('INTIGO_AUTO_CREATE') === '1';
        $size = IntigoApiClient::normalizeSizeLetter(Configuration::get('INTIGO_DEFAULT_SIZE'), 'S');
        $tracking = (string) Configuration::get('INTIGO_TRACKING_URL');
        $cron_token = (string) Configuration::get('INTIGO_CRON_TOKEN');
        $price = function ($k) {
            $v = (float) Configuration::get('INTIGO_PRICE_' . $k);
            return rtrim(rtrim(number_format($v, 3, '.', ''), '0'), '.');
        };
        $currency = 'TND';
        $cur = Currency::getDefaultCurrency();
        if (Validate::isLoadedObject($cur)) {
            $currency = $cur->sign ? $cur->sign : $cur->iso_code;
        }
        $action = self::$currentIndex . '&token=' . $this->token;

        $notice = (string) Tools::getValue('intigo_notice');
        $ntype = (string) Tools::getValue('intigo_notice_type');
        $alert = $ntype === 'success' ? 'success' : ($ntype === 'error' ? 'danger' : 'info');

        $checked = function ($cond) {
            return $cond ? ' checked' : '';
        };
        $sel = function ($cond) {
            return $cond ? ' selected' : '';
        };

        $h = '<div class="intigo-screen intigo-form">';
        $h .= IntigoAdminUi::navHtml($this->context->link, 'settings');
        $h .= IntigoAdminUi::noticeToast();

        $h .= '<form method="post" action="' . htmlspecialchars($action) . '" class="form-horizontal">';

        // Connection
        $h .= '<div class="card"><div class="card-header"><h3 class="card-header-title">' . IntigoAdminUi::t('Connection') . '</h3></div><div class="card-body">';
        $h .= '<div class="form-group"><label class="control-label col-lg-3">' . IntigoAdminUi::t('Environment') . '</label><div class="col-lg-7">'
            . '<label class="radio-inline"><input type="radio" name="INTIGO_ENVIRONMENT" value="sandbox"' . $checked($env === 'sandbox') . '> Sandbox <small>(dev-api.intigo.net)</small></label> '
            . '<label class="radio-inline"><input type="radio" name="INTIGO_ENVIRONMENT" value="production"' . $checked($env === 'production') . '> Production <small>(api.intigo.net)</small></label>'
            . '<p class="help-block">En <strong>Sandbox</strong>, les colis sont créés dans le tableau de bord partenaire de test '
            . '<a href="https://partner-staging.intigo.net/" target="_blank" rel="noopener">partner-staging.intigo.net</a> — pas en production.</p>'
            . '</div></div>';
        $h .= '<div class="form-group"><label class="control-label col-lg-3">' . IntigoAdminUi::t('API key') . '</label><div class="col-lg-7">'
            . '<input type="text" name="INTIGO_API_KEY" class="form-control" autocomplete="off" value="' . htmlspecialchars($api_key) . '">'
            . '<p class="help-block">Envoyé dans l\'en-tête X-API-KEY à chaque appel à l\'API.</p></div></div>';
        $h .= '<div class="form-group"><label class="control-label col-lg-3">' . IntigoAdminUi::t('Tracking URL') . '</label><div class="col-lg-7">'
            . '<input type="text" name="INTIGO_TRACKING_URL" class="form-control" value="' . htmlspecialchars($tracking) . '" placeholder="https://play.google.com/store/apps/details?id=net.intigo.client">'
            . '<p class="help-block">Affiché aux clients sur le transporteur Intigo. Par défaut, pointe vers l\'application Intigo sur Google Play.</p></div></div>';
        $h .= '<div class="form-group"><label class="control-label col-lg-3">' . IntigoAdminUi::t('Legacy fallback') . '</label><div class="col-lg-7">'
            . '<label class="checkbox-inline"><input type="checkbox" name="INTIGO_FALLBACK_ENABLED" value="1"' . $checked($fallback) . '> Réessayer les anciens points d\'accès en cas d\'échec (hors authentification)</label></div></div>';
        $h .= '<div class="form-group"><div class="col-lg-offset-3 col-lg-7">'
            . '<button type="submit" name="intigo_test_connection" value="1" class="btn btn-outline-secondary btn-sm"><i class="icon-flash"></i> ' . IntigoAdminUi::t('Test connection') . '</button></div></div>';
        $h .= '</div></div>';

        // Order processing
        $h .= '<div class="card"><div class="card-header"><h3 class="card-header-title">' . IntigoAdminUi::t('Order processing') . '</h3></div><div class="card-body">';
        $h .= '<div class="form-group"><label class="control-label col-lg-3">' . IntigoAdminUi::t('Mode') . '</label><div class="col-lg-7">'
            . '<label class="radio-inline"><input type="radio" name="INTIGO_AUTO_CREATE" value="0"' . $checked(!$auto) . '> Manuel — envoyer chaque commande depuis l\'écran Commandes</label><br>'
            . '<label class="radio-inline"><input type="radio" name="INTIGO_AUTO_CREATE" value="1"' . $checked($auto) . '> Automatique — envoyer à Intigo dès que la commande est payée</label>'
            . '</div></div></div></div>';

        // Defaults
        $h .= '<div class="card"><div class="card-header"><h3 class="card-header-title">' . IntigoAdminUi::t('Defaults') . '</h3></div><div class="card-body">';
        $h .= '<div class="form-group"><label class="control-label col-lg-3">' . IntigoAdminUi::t('Default package size') . '</label><div class="col-lg-3"><select name="INTIGO_DEFAULT_SIZE" class="form-control">';
        foreach (['S', 'M', 'L', 'XL'] as $s) {
            $h .= '<option value="' . $s . '"' . $sel($size === $s) . '>' . $s . '</option>';
        }
        $h .= '</select><p class="help-block">Utilisé lorsqu\'un produit n\'a pas de taille spécifique.</p></div></div>';

        // Per-size shipping prices — the carrier charges by the order's resolved size.
        $h .= '<hr><div class="form-group"><label class="control-label col-lg-3">' . IntigoAdminUi::t('Shipping price per size') . '</label><div class="col-lg-9">';
        $h .= '<p class="help-block">Le transporteur Intigo facture selon la taille du colis — déterminée par la taille Intigo de chaque produit (définie dans <strong>Tailles produits</strong>), agrégée au plus grand article, avec repli sur la taille par défaut ci-dessus. Saisissez vos tarifs Intigo négociés.</p>';
        foreach (['S', 'M', 'L', 'XL'] as $s) {
            $h .= '<div class="row" style="margin-bottom:6px;"><div class="col-lg-2"><label style="font-weight:600;padding-top:7px;">Taille ' . $s . '</label></div>'
                . '<div class="col-lg-4"><div class="input-group">'
                . '<input type="text" name="INTIGO_PRICE_' . $s . '" class="form-control" value="' . htmlspecialchars($price($s)) . '">'
                . '<span class="input-group-addon">' . htmlspecialchars($currency) . '</span></div></div></div>';
        }
        $h .= '</div></div>';

        // Cash-on-delivery detection: list the shop's real payment methods and let
        // the merchant tick which are COD. COD → exact amount; others (paid online)
        // → 0 sent to Intigo.
        $cod_kws = array_filter(array_map(function ($v) { return Tools::strtolower(trim($v)); },
            preg_split('/[\r\n,;]+/', (string) Configuration::get('INTIGO_COD_METHODS'))));
        $methods = $this->detectPaymentMethods();
        $h .= '<hr><div class="form-group"><label class="control-label col-lg-3">Encaissement à la livraison (COD)</label><div class="col-lg-9">';
        $h .= '<p class="help-block">Cochez vos moyens de paiement <strong>en espèces à la livraison (COD)</strong>. Une commande COD est envoyée à Intigo avec le <strong>montant exact à encaisser</strong> ; toutes les autres (déjà payées en ligne) sont envoyées avec <strong>0,000</strong>.</p>';
        if (!empty($methods)) {
            $h .= '<div style="margin:6px 0 10px;">';
            foreach ($methods as $mth) {
                $low = Tools::strtolower($mth);
                $checked = false;
                foreach ($cod_kws as $kw) {
                    if ($kw !== '' && (strpos($low, $kw) !== false || strpos($kw, $low) !== false)) {
                        $checked = true;
                        break;
                    }
                }
                $h .= '<label class="checkbox-inline" style="display:block;margin:3px 0;font-weight:600;">'
                    . '<input type="checkbox" name="INTIGO_COD_METHODS_SEL[]" value="' . htmlspecialchars($mth) . '"' . ($checked ? ' checked' : '') . '> '
                    . htmlspecialchars($mth) . ($checked ? ' <span style="color:#12805c;font-weight:400;">— montant exact encaissé</span>' : ' <span style="color:#98a2b3;font-weight:400;">— envoyé avec 0 (déjà payé)</span>') . '</label>';
            }
            $h .= '</div>';
        } else {
            $h .= '<p class="text-muted">Aucun moyen de paiement détecté sur les commandes pour l\'instant — utilisez le champ ci-dessous.</p>';
        }
        $h .= '<label class="control-label" style="font-weight:600;">Autres mots-clés COD (optionnel)</label>'
            . '<input type="text" name="INTIGO_COD_METHODS_EXTRA" class="form-control" value="' . htmlspecialchars($this->codExtras($methods, (string) Configuration::get('INTIGO_COD_METHODS'))) . '" placeholder="ex : contre-remboursement, espèces, cod">'
            . '<p class="help-block">Pour un moyen COD pas encore présent dans les commandes. Correspondance insensible à la casse sur le nom + le module du paiement.</p>';
        $h .= '</div></div>';
        $h .= '</div><div class="card-footer text-right"><button type="submit" name="submitIntigoSettings" value="1" class="btn btn-primary">' . IntigoAdminUi::t('Save') . '</button></div></div>';

        $h .= '</form>';

        // Webhook status sync (Intigo → PrestaShop)
        $webhook_url = $this->context->link->getModuleLink('intigoparcels', 'webhook', [], true);
        $wtoken = (string) Configuration::get('INTIGO_WEBHOOK_TOKEN');
        $last_ts = (int) Configuration::get('INTIGO_WEBHOOK_LAST_TS');
        $states = OrderState::getOrderStates((int) $this->context->language->id);
        $states = is_array($states) ? $states : [];
        $state_select = function ($name, $current) use ($states, $sel) {
            $s = '<select name="' . $name . '" class="form-control"><option value="0">— Ne pas changer le statut —</option>';
            foreach ($states as $st) {
                $sid = (int) $st['id_order_state'];
                $s .= '<option value="' . $sid . '"' . $sel($sid === (int) $current) . '>' . htmlspecialchars((string) $st['name']) . '</option>';
            }
            return $s . '</select>';
        };

        $h .= '<div class="card"><div class="card-header"><h3 class="card-header-title">'
            . '<i class="material-icons">sync_alt</i> Synchronisation des statuts (Webhook)</h3></div><div class="card-body">';
        $h .= '<form method="post" action="' . htmlspecialchars($action) . '" class="form-horizontal">';
        $h .= '<p class="help-block">Intigo prévient automatiquement votre boutique à chaque changement de statut d\'un colis (livré, en transit, retour…). '
            . 'Copiez l\'URL et le jeton ci-dessous dans votre tableau de bord Intigo (<strong>Paramètres → Webhook</strong>) — voir l\'<a href="' . htmlspecialchars($this->context->link->getAdminLink('AdminIntigoDocs')) . '">Aide</a>.</p>';
        $h .= '<div class="form-group"><label class="control-label col-lg-3">URL du webhook</label><div class="col-lg-7"><div class="input-group">'
            . '<input type="text" class="form-control" readonly value="' . htmlspecialchars($webhook_url) . '">'
            . '<span class="input-group-btn"><button type="button" class="btn btn-default intigo-copy" data-copy="' . htmlspecialchars($webhook_url) . '">Copier</button></span>'
            . '</div></div></div>';
        $h .= '<div class="form-group"><label class="control-label col-lg-3">Jeton (secret partagé)</label><div class="col-lg-7"><div class="input-group">'
            . '<input type="text" name="INTIGO_WEBHOOK_TOKEN" class="form-control" value="' . htmlspecialchars($wtoken) . '">'
            . '<span class="input-group-btn"><button type="submit" name="intigo_gen_webhook_token" value="1" class="btn btn-default">Générer</button></span>'
            . '</div><p class="help-block">Le <strong>même</strong> jeton doit être saisi côté Intigo. Il signe et vérifie chaque notification (HMAC-SHA256).</p></div></div>';
        // Toggle: does the webhook also move the native PS order status?
        $wh_update = (string) Configuration::get('INTIGO_WH_UPDATE_ORDERS') !== '0';
        $h .= '<hr><div class="form-group"><label class="control-label col-lg-3">Mettre à jour les commandes</label>'
            . '<div class="col-lg-7" style="padding-top:6px;">'
            . '<label style="font-weight:400;"><input type="checkbox" name="INTIGO_WH_UPDATE_ORDERS" value="1"' . ($wh_update ? ' checked' : '') . '> '
            . '<strong>Changer automatiquement</strong> le statut de la commande PrestaShop selon le tableau ci-dessous.</label>'
            . '<p class="help-block">Si décoché&nbsp;: vos commandes ne sont <strong>pas</strong> modifiées — le nouveau statut Intigo reste affiché dans la liste des commandes, mais votre flux PrestaShop reste intact.</p>'
            . '</div></div>';
        $h .= '<p class="help-block">Pour <strong>chaque statut Intigo</strong>, choisissez le statut de commande PrestaShop à appliquer automatiquement. '
            . 'Laissez « — Ne pas changer le statut — » pour les statuts à ignorer. Plusieurs statuts Intigo peuvent pointer vers le même statut PrestaShop.</p>';
        require_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoStatus.php';
        $wmap = IntigoStatus::getMap();
        $h .= '<div style="overflow-x:auto;"><table class="table" style="max-width:740px;"><thead><tr>'
            . '<th style="width:55%;">Statut Intigo</th><th>→ Statut PrestaShop</th></tr></thead><tbody>';
        foreach (IntigoStatus::webhookStatuses() as $code => $label) {
            $cur = isset($wmap[$code]) ? (int) $wmap[$code] : 0;
            $h .= '<tr><td><strong>' . htmlspecialchars($label) . '</strong> '
                . '<span class="text-muted" style="font-size:11px;">#' . (int) $code . '</span></td>'
                . '<td>' . $state_select('wh_map[' . (int) $code . ']', $cur) . '</td></tr>';
        }
        $h .= '</tbody></table></div>';
        $last_txt = $last_ts > 0 ? date('Y-m-d H:i', $last_ts) : 'aucune notification reçue pour l\'instant';
        $h .= '<div class="form-group"><label class="control-label col-lg-3">Dernier webhook reçu</label><div class="col-lg-7">'
            . '<p style="padding-top:7px;margin:0;"><strong>' . htmlspecialchars($last_txt) . '</strong></p></div></div>';
        $h .= '</div><div class="card-footer text-right"><button type="submit" name="submitIntigoWebhook" value="1" class="btn btn-primary">' . IntigoAdminUi::t('Save') . '</button></div>';
        $h .= '</form></div>';

        // Copy-to-clipboard for the webhook URL.
        $h .= '<script>document.addEventListener("click",function(e){var b=e.target.closest(".intigo-copy");if(!b)return;e.preventDefault();'
            . 'var t=b.getAttribute("data-copy")||"";var d=function(){var o=b.textContent;b.textContent="Copié !";setTimeout(function(){b.textContent=o;},1200);};'
            . 'if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(t).then(d,d);}else{var i=document.createElement("input");i.value=t;document.body.appendChild(i);i.select();try{document.execCommand("copy");}catch(err){}i.remove();d();}});</script>';

        $h .= '</div>'; // .intigo-screen

        return $h;
    }

    /**
     * The payment methods actually present in this shop — distinct order payment
     * labels plus installed payment modules' display names. Used to let the
     * merchant tick which ones are Cash-on-Delivery.
     */
    private function detectPaymentMethods()
    {
        $out = [];
        // The merchant's live payment solutions = ACTIVE payment modules. This is
        // the dynamic source (no hardcoded list).
        try {
            foreach ((array) PaymentModule::getInstalledPaymentModules() as $pm) {
                $mod = Module::getInstanceByName($pm['name']);
                if (Validate::isLoadedObject($mod) && $mod->active && !empty($mod->displayName)) {
                    $out[trim((string) $mod->displayName)] = true;
                }
            }
        } catch (\Throwable $e) {
        }
        // Plus any payment label already seen on orders (covers manual orders or a
        // solution that was since removed) — still dynamic, from the shop's data.
        try {
            $rows = Db::getInstance()->executeS('SELECT DISTINCT payment FROM `' . _DB_PREFIX_ . 'orders` WHERE payment <> "" ORDER BY payment');
            foreach ((array) $rows as $r) {
                $p = trim((string) $r['payment']);
                if ($p !== '') {
                    $out[$p] = true;
                }
            }
        } catch (\Throwable $e) {
        }
        $list = array_keys($out);
        sort($list);
        return $list;
    }

    /**
     * COD keywords that don't correspond to any detected payment method — shown in
     * the free-text field so they're preserved across saves.
     */
    private function codExtras(array $methods, $codRaw)
    {
        $low = array_map(function ($m) { return Tools::strtolower($m); }, $methods);
        $extras = [];
        foreach (preg_split('/[\r\n,;]+/', (string) $codRaw) as $kw) {
            $kw = trim($kw);
            if ($kw === '') {
                continue;
            }
            $lkw = Tools::strtolower($kw);
            $matched = false;
            foreach ($low as $lm) {
                if (strpos($lm, $lkw) !== false || strpos($lkw, $lm) !== false) {
                    $matched = true;
                    break;
                }
            }
            if (!$matched) {
                $extras[] = $kw;
            }
        }
        return implode(', ', $extras);
    }
}
