<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

require_once dirname(__FILE__) . '/../../classes/IntigoAutoload.php';

require_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoAdminUi.php';
require_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoAccess.php';
require_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoLog.php';

/**
 * Dedicated "Accès" page — a friendly, Intigo-only view over PrestaShop's native
 * per-profile tab permissions (Paramètres avancés → Équipe → Permissions). Lets
 * the admin grant/revoke each employee profile, one Intigo page at a time. This
 * page itself is SuperAdmin-only by default (it is NOT granted to other profiles
 * by the module's access self-heal), so non-admins can't widen their own access.
 */
class AdminIntigoAccessController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        parent::__construct();
        if (Shop::isFeatureActive()) {
            Shop::setContext(Shop::CONTEXT_ALL);
        }
    }

    public function initContent()
    {
        parent::initContent();
        try {
            if (Tools::isSubmit('submitIntigoAccess')) {
                $this->handleSave();
            }
            $this->content = $this->render();
        } catch (\Throwable $e) {
            IntigoLog::add('access_page_error', $e->getMessage());
            $this->content = '<div class="alert alert-warning">Accès — temporairement indisponible.</div>';
        }
        $this->context->smarty->assign('content', $this->content);
    }

    private function handleSave()
    {
        // Posted as access[id_profile][AdminIntigoXxx] = 1 for each checked page.
        $posted = Tools::getValue('access');
        $posted = is_array($posted) ? $posted : [];
        $grid = [];
        foreach (IntigoAccess::profiles((int) $this->context->language->id) as $p) {
            $grid[$p['id']] = isset($posted[$p['id']]) && is_array($posted[$p['id']]) ? $posted[$p['id']] : [];
        }
        IntigoAccess::apply($grid);
        IntigoLog::add('access_saved', 'profiles=' . count($grid));
        Tools::redirectAdmin(
            self::$currentIndex . '&token=' . $this->token
            . '&intigo_notice=' . rawurlencode('Accès mis à jour.')
            . '&intigo_notice_type=success'
        );
    }

    private function render()
    {
        $action = self::$currentIndex . '&token=' . $this->token;
        $ia_profiles = IntigoAccess::profiles((int) $this->context->language->id);
        $ia_pages = IntigoAccess::pages();

        $h = '<div class="intigo-screen intigo-form">';
        $h .= IntigoAdminUi::navHtml($this->context->link, 'access');
        $h .= IntigoAdminUi::noticeToast();

        $h .= '<form method="post" action="' . htmlspecialchars($action) . '">';
        $h .= '<div class="card"><div class="card-header"><h3 class="card-header-title">'
            . '<i class="material-icons">admin_panel_settings</i> Accès &amp; permissions</h3></div><div class="card-body">';
        $h .= '<p class="text-muted" style="margin-top:0;">Cochez les pages Intigo que chaque profil d\'employé peut ouvrir. '
            . 'Le profil <strong>SuperAdmin</strong> a toujours accès à tout. Ces réglages utilisent les permissions natives de '
            . 'PrestaShop (<em>Paramètres avancés → Équipe → Permissions</em>).</p>';

        if (empty($ia_profiles)) {
            $h .= '<div class="alert alert-info">Aucun profil autre que SuperAdmin. Créez-en dans '
                . '<em>Paramètres avancés → Équipe → Profils</em>, puis revenez ici.</div>';
            $h .= '</div></div></form>';
        } else {
            $h .= '<div style="overflow-x:auto;"><table class="table" style="min-width:780px;"><thead><tr>'
                . '<th>Profil</th>';
            foreach ($ia_pages as $cls => $label) {
                $h .= '<th style="text-align:center;font-size:12px;font-weight:600;">' . htmlspecialchars($label) . '</th>';
            }
            $h .= '<th style="text-align:right;">Raccourci</th></tr></thead><tbody>';
            foreach ($ia_profiles as $p) {
                $h .= '<tr><td><strong>' . htmlspecialchars($p['name']) . '</strong></td>';
                foreach ($ia_pages as $cls => $label) {
                    $on = IntigoAccess::has((int) $p['id'], $cls);
                    $h .= '<td style="text-align:center;"><input type="checkbox" class="intigo-acc" '
                        . 'name="access[' . (int) $p['id'] . '][' . $cls . ']" value="1"' . ($on ? ' checked' : '') . '></td>';
                }
                $h .= '<td style="text-align:right;white-space:nowrap;">'
                    . '<button type="button" class="btn btn-default btn-sm intigo-acc-all">Tout</button> '
                    . '<button type="button" class="btn btn-default btn-sm intigo-acc-none">Aucun</button></td></tr>';
            }
            $h .= '</tbody></table></div>';
            $h .= '<p class="text-muted" style="font-size:12px;margin-bottom:0;">Pour donner cet accès à une personne&nbsp;: '
                . '<em>Équipe → Employés</em>, puis affectez-lui le profil voulu.</p>';
            $h .= '</div><div class="card-footer text-right"><button type="submit" name="submitIntigoAccess" value="1" '
                . 'class="btn btn-primary">' . IntigoAdminUi::t('Save') . '</button></div></div></form>';

            $h .= '<script>document.addEventListener("click",function(e){var r;'
                . 'if(e.target.closest(".intigo-acc-all")){r=e.target.closest("tr");}'
                . 'else if(e.target.closest(".intigo-acc-none")){r=e.target.closest("tr");}else{return;}'
                . 'var on=!!e.target.closest(".intigo-acc-all");'
                . 'r.querySelectorAll(".intigo-acc").forEach(function(x){x.checked=on;});});</script>';
        }

        $h .= '</div>'; // .intigo-screen
        return $h;
    }
}
