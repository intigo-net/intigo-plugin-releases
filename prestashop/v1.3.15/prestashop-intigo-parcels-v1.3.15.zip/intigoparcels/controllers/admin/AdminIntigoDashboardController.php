<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

require_once dirname(__FILE__) . '/../../classes/IntigoAutoload.php';

/**
 * Intigo → Tableau de bord (legacy ModuleAdminController — portable 1.7/8/9).
 *
 * A rich, at-a-glance overview of ALL the merchant's Intigo activity: parcels by
 * live status, cash-on-delivery in circulation, delivery rate, the to-do backlog
 * (orders to send / addresses to check), pickup addresses, and recent activity.
 * Live statuses are pulled in one cached call (5 min) and written back to the DB,
 * so the figures are real without a separate sync engine. Everything degrades
 * gracefully: no API key → DB-only; API down → last snapshot.
 */
class AdminIntigoDashboardController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        $this->display = 'view';
        parent::__construct();
        $this->meta_title = 'Intigo — Tableau de bord';
        $this->show_page_header_toolbar = false;
    }

    public function initContent()
    {
        parent::initContent();
        try {
            $this->content = $this->render();
        } catch (Exception $e) {
            IntigoLog::add('dashboard_error', $e->getMessage());
            $this->content = '<div class="alert alert-warning">Le tableau de bord Intigo est momentanément indisponible.</div>';
        } catch (\Throwable $e) {
            IntigoLog::add('dashboard_error', $e->getMessage());
            $this->content = '<div class="alert alert-warning">Le tableau de bord Intigo est momentanément indisponible.</div>';
        }
        $this->context->smarty->assign('content', $this->content);
    }

    /* ---------------- Status helpers ---------------- */

    private function statusGroup($code)
    {
        $c = (int) $code;
        if ($c >= 9000) { return 'canceled'; }
        if ($c >= 6000) { return 'return'; }
        if ($c >= 5000 && $c < 6000) { return 'delivered'; }
        if ($c === 4000) { return 'out'; }
        if ($c >= 2000) { return 'transit'; }
        return 'pickup'; // 0..1999 (created / awaiting pickup)
    }

    /**
     * Live parcel-status snapshot, cached 5 min. Pulls current statuses for up to
     * 200 parcels in one /v3/parcels/status call, aggregates by group + COD, and
     * writes the live status back to ps_intigo_parcel. Falls back to stored
     * status_code when the API is unavailable. Never throws.
     */
    private function liveStatusData($db, $pfx, $has_api_key)
    {
        $force = (string) Tools::getValue('refresh') === '1';
        $ts = (int) Configuration::get('INTIGO_DASH_STATUS_TS');
        $raw = Configuration::get('INTIGO_DASH_STATUS');
        if (!$force && $raw !== false && trim((string) $raw) !== '' && (time() - $ts) < 300) {
            $d = json_decode((string) $raw, true);
            if (is_array($d) && isset($d['groups'])) {
                return $d;
            }
        }

        $groups = ['pickup' => 0, 'transit' => 0, 'out' => 0, 'delivered' => 0, 'return' => 0, 'canceled' => 0];
        $inflight_cod = 0.0;
        $delivered_cod = 0.0;
        $live = false;

        $rows = $db->executeS(
            'SELECT p.nid, p.status_code, o.total_paid_tax_incl AS tot
             FROM `' . $pfx . 'intigo_parcel` p
             JOIN `' . $pfx . 'orders` o ON o.id_order = p.id_order
             WHERE p.nid <> "" ORDER BY p.id_order DESC LIMIT 200'
        );
        $rows = is_array($rows) ? $rows : [];

        $statusByNid = [];
        if ($has_api_key && !empty($rows)) {
            try {
                $nids = array_map(function ($r) { return $r['nid']; }, $rows);
                $api = new IntigoApiClient();
                $res = $api->statusBulk($nids);
                if (!empty($res['ok']) && isset($res['data']['parcels']) && is_array($res['data']['parcels'])) {
                    foreach ($res['data']['parcels'] as $p) {
                        if (isset($p['nid'], $p['status'])) {
                            $statusByNid[(string) $p['nid']] = (int) $p['status'];
                        }
                    }
                    $live = true;
                }
            } catch (\Throwable $e) {
                IntigoLog::add('dash_status_error', $e->getMessage());
            }
        }

        foreach ($rows as $r) {
            $nid = (string) $r['nid'];
            $code = isset($statusByNid[$nid]) ? $statusByNid[$nid] : (int) $r['status_code'];
            $g = $this->statusGroup($code);
            if (!isset($groups[$g])) { $g = 'pickup'; }
            $groups[$g]++;
            $cod = (float) $r['tot'];
            if ($g === 'delivered') {
                $delivered_cod += $cod;
            } elseif ($g !== 'canceled' && $g !== 'return') {
                $inflight_cod += $cod;
            }
            // Write the fresh live status back so the DB stays current too.
            if ($live && isset($statusByNid[$nid]) && (int) $r['status_code'] !== $statusByNid[$nid]) {
                $db->update('intigo_parcel',
                    ['status_code' => (int) $statusByNid[$nid], 'last_sync_at' => date('Y-m-d H:i:s')],
                    'nid = "' . pSQL($nid) . '"');
            }
        }

        $out = ['groups' => $groups, 'inflight_cod' => $inflight_cod, 'delivered_cod' => $delivered_cod, 'live' => $live, 'ts' => time()];
        Configuration::updateValue('INTIGO_DASH_STATUS', json_encode($out));
        Configuration::updateValue('INTIGO_DASH_STATUS_TS', (string) time());
        return $out;
    }

    /* ---------------- Render ---------------- */

    private function render()
    {
        $db = Db::getInstance();
        $pfx = _DB_PREFIX_;
        $has_api_key = trim((string) Configuration::get('INTIGO_API_KEY')) !== '';
        $environment = Configuration::get('INTIGO_ENVIRONMENT') === 'production' ? 'production' : 'sandbox';
        $service_url = $environment === 'production' ? 'https://api.intigo.net/api' : 'https://dev-api.intigo.net/api';
        $version = (string) $this->module->version;

        $settings_url = $this->context->link->getAdminLink('AdminIntigoSettings');
        $orders_url = $this->context->link->getAdminLink('AdminIntigoOrders');
        $pickup_url = $this->context->link->getAdminLink('AdminIntigoPickup');
        $logs_url = $this->context->link->getAdminLink('AdminIntigoLogs');
        $dash_url = self::$currentIndex . '&token=' . $this->token;

        /* --- DB metrics (fast, no network) --- */
        $total_orders = (int) $db->getValue('SELECT COUNT(*) FROM `' . $pfx . 'orders`');
        $total_parcels = (int) $db->getValue('SELECT COUNT(*) FROM `' . $pfx . 'intigo_parcel` WHERE nid <> ""');
        $backlog = (int) $db->getValue('SELECT COUNT(*) FROM `' . $pfx . 'orders` o LEFT JOIN `' . $pfx . 'intigo_parcel` p ON o.id_order = p.id_order WHERE p.nid IS NULL OR p.nid = ""');
        $ready = (int) $db->getValue('SELECT COUNT(*) FROM `' . $pfx . 'intigo_parcel` WHERE (nid IS NULL OR nid = "") AND resolution_status = "resolved"');
        $review = (int) $db->getValue('SELECT COUNT(*) FROM `' . $pfx . 'intigo_parcel` WHERE (nid IS NULL OR nid = "") AND resolution_status IN ("review","blocked")');
        $bordereaux = (int) $db->getValue('SELECT COUNT(*) FROM `' . $pfx . 'intigo_parcel` WHERE bordereau_url <> ""');
        $calls24 = (int) $db->getValue('SELECT COUNT(*) FROM `' . $pfx . 'intigo_log` WHERE created_at >= (NOW() - INTERVAL 24 HOUR)');
        $failed24 = (int) $db->getValue('SELECT COUNT(*) FROM `' . $pfx . 'intigo_log` WHERE created_at >= (NOW() - INTERVAL 24 HOUR) AND action LIKE "%failed%"');
        $coverage = $total_orders > 0 ? (int) round($total_parcels / $total_orders * 100) : 0;
        $backlog_cod = (float) $db->getValue('SELECT COALESCE(SUM(o.total_paid_tax_incl),0) FROM `' . $pfx . 'orders` o LEFT JOIN `' . $pfx . 'intigo_parcel` p ON o.id_order = p.id_order WHERE p.nid IS NULL OR p.nid = ""');

        $pickup_count = 0;
        $pc = Configuration::get('INTIGO_PICKUP_CACHE');
        if ($pc !== false && trim((string) $pc) !== '') {
            $arr = json_decode((string) $pc, true);
            $pickup_count = is_array($arr) ? count($arr) : 0;
        }

        /* --- Live status snapshot --- */
        $st = $this->liveStatusData($db, $pfx, $has_api_key);
        $g = $st['groups'];
        $delivered = (int) $g['delivered'];
        $in_progress = (int) ($g['pickup'] + $g['transit'] + $g['out']);
        $returns = (int) ($g['return'] + $g['canceled']);
        $delivery_rate = $total_parcels > 0 ? (int) round($delivered / $total_parcels * 100) : 0;
        $cur = function ($v) { return number_format((float) $v, 0, ',', ' ') . ' DT'; };

        $h = '<div class="intigo-screen intigo-dash">';
        $h .= IntigoAdminUi::navHtml($this->context->link, 'dashboard');

        if (!$has_api_key) {
            $h .= '<div class="alert alert-warning"><strong>Clé API requise.</strong> '
                . 'Ajoutez votre clé API Intigo pour activer le suivi en temps réel. '
                . '<a href="' . htmlspecialchars($settings_url) . '">Aller aux Réglages</a></div>';
        }

        /* --- Header bar --- */
        $env_pill = $environment === 'production'
            ? '<span class="intigo-badge intigo-badge--success">Production</span>'
            : '<span class="intigo-badge intigo-badge--warning">Bac à sable</span>';
        $sync_note = !empty($st['live'])
            ? 'Statuts en direct · maj ' . date('H:i')
            : ($has_api_key ? 'Statuts hors-ligne (cache)' : 'Connectez votre clé API');
        $h .= '<div class="intigo-dash-head">'
            . '<div><h2 class="intigo-dash-title">Tableau de bord</h2>'
            . '<div class="intigo-dash-sub">Toute votre activité Intigo en un coup d\'œil · ' . htmlspecialchars($sync_note) . '</div></div>'
            . '<div class="intigo-dash-head-right">'
            . '<a href="' . htmlspecialchars($dash_url . '&refresh=1') . '" class="btn btn-default btn-sm">'
            . '<i class="material-icons" style="font-size:16px;vertical-align:middle;">refresh</i> Rafraîchir</a></div>'
            . '</div>';

        /* --- Environnement strip (top of the page) --- */
        $key_badge = $has_api_key
            ? '<span class="intigo-badge intigo-badge--success">Clé API définie</span>'
            : '<span class="intigo-badge intigo-badge--danger">Clé API manquante</span>';
        $health = $failed24 > 0
            ? '<span class="intigo-badge intigo-badge--warning">' . $failed24 . ' échec(s)</span>'
            : '<span class="intigo-badge intigo-badge--success">Tout fonctionne</span>';
        $h .= '<div class="intigo-dash-foot intigo-dash-top">'
            . '<div><span class="text-muted">Environnement</span><div>' . $env_pill . ' ' . $key_badge . '</div></div>'
            . '<div><span class="text-muted">Appels API (24h)</span><div><strong>' . $calls24 . '</strong> ' . $health . ' · <a href="' . htmlspecialchars($logs_url) . '">Journaux</a></div></div>'
            . '<div><span class="text-muted">Service</span><div><code>' . htmlspecialchars($service_url) . '</code></div></div>'
            . '<div><span class="text-muted">Version du module</span><div><strong>v' . htmlspecialchars($version) . '</strong> · <a href="' . htmlspecialchars($settings_url) . '">Réglages</a></div></div>'
            . '</div>';

        /* --- Hero KPI row --- */
        $kpi = function ($icon, $value, $label, $hint, $tone) {
            return '<div class="intigo-kpi2 intigo-kpi2--' . $tone . '">'
                . '<div class="intigo-kpi2-icon"><i class="material-icons">' . $icon . '</i></div>'
                . '<div class="intigo-kpi2-body">'
                . '<div class="intigo-kpi2-value">' . $value . '</div>'
                . '<div class="intigo-kpi2-label">' . $label . '</div>'
                . '<div class="intigo-kpi2-hint">' . $hint . '</div>'
                . '</div></div>';
        };
        $h .= '<div class="intigo-kpi2-grid">';
        $h .= $kpi('local_shipping', (int) $total_parcels, 'Colis chez Intigo', $coverage . '% de vos commandes', 'indigo');
        $h .= $kpi('check_circle', (int) $delivered, 'Livrés', $delivery_rate . '% de réussite', 'green');
        $h .= $kpi('sync', (int) $in_progress, 'En cours', 'ramassage + transit', 'blue');
        $h .= $kpi('keyboard_return', (int) $returns, 'Retours / Annulés', $returns > 0 ? 'à surveiller' : 'aucun', $returns > 0 ? 'amber' : 'slate');
        $h .= $kpi('payments', $cur($st['inflight_cod']), 'COD en circulation', $cur($st['delivered_cod']) . ' encaissés', 'violet');
        $h .= '</div>';

        /* --- Charts: status donut + 14-day "colis envoyés" trend --- */
        $segs = [
            ['En attente', (int) $g['pickup'], '#f59e0b'],
            ['En transit', (int) ($g['transit'] + $g['out']), '#3b82f6'],
            ['Livrés', (int) $g['delivered'], '#10b981'],
            ['Retours', (int) $g['return'], '#f97316'],
            ['Annulés', (int) $g['canceled'], '#ef4444'],
        ];
        $sum = 0;
        foreach ($segs as $s) { $sum += $s[1]; }

        $trendRows = $db->executeS(
            'SELECT DATE(created_at) d, COUNT(*) c FROM `' . $pfx . 'intigo_parcel`
             WHERE nid <> "" AND created_at >= (CURDATE() - INTERVAL 13 DAY) GROUP BY DATE(created_at)'
        );
        $byDay = [];
        foreach ((array) $trendRows as $tr) { $byDay[(string) $tr['d']] = (int) $tr['c']; }
        $days = [];
        for ($k = 13; $k >= 0; $k--) {
            $dts = date('Y-m-d', strtotime('-' . $k . ' day'));
            $days[] = ['label' => date('d/m', strtotime($dts)), 'count' => isset($byDay[$dts]) ? $byDay[$dts] : 0];
        }

        $h .= '<div class="intigo-charts">';
        // Donut
        $h .= '<div class="card"><div class="card-header"><h3 class="card-header-title">'
            . '<i class="material-icons">donut_large</i> Répartition par statut</h3></div><div class="card-body">';
        if ($sum > 0) {
            $h .= '<div class="intigo-donut-wrap">' . $this->donutSvg($segs, $sum, $delivery_rate . '%', 'livrés')
                . '<div class="intigo-statuslegend">';
            foreach ($segs as $s) {
                $h .= '<span class="intigo-legend"><i style="background:' . $s[2] . ';"></i>' . htmlspecialchars($s[0])
                    . ' <strong>' . $s[1] . '</strong></span>';
            }
            $h .= '</div></div>';
        } else {
            $h .= '<p class="text-muted" style="margin:0;">Aucun colis envoyé. Envoyez vos premières commandes depuis <a href="' . htmlspecialchars($orders_url) . '">Commandes</a>.</p>';
        }
        $h .= '</div></div>';
        // Trend
        $h .= '<div class="card"><div class="card-header"><h3 class="card-header-title">'
            . '<i class="material-icons">show_chart</i> Colis envoyés (14 jours)</h3></div><div class="card-body">'
            . $this->trendSvg($days) . '</div></div>';
        $h .= '</div>';

        /* --- Two columns: to-do + recent activity --- */
        $h .= '<div class="intigo-dash-cols">';

        // Left: To-do / actions
        $h .= '<div class="intigo-dash-col-main">';
        $h .= '<div class="card"><div class="card-header"><h3 class="card-header-title">'
            . '<i class="material-icons">checklist</i> À traiter</h3></div><div class="card-body">';
        $h .= '<div class="intigo-todo">';
        $h .= $this->todoRow('inventory_2', 'indigo', $backlog, 'commande(s) à envoyer', $cur($backlog_cod) . ' à expédier', 'Voir', $orders_url);
        $h .= $this->todoRow('verified', 'green', $ready, 'prête(s) à envoyer', 'adresse détectée automatiquement', 'Envoyer', $orders_url . '&f=ready');
        $h .= $this->todoRow('error_outline', 'amber', $review, 'adresse(s) à vérifier', 'à confirmer avant l\'envoi', 'Vérifier', $orders_url . '&f=review');
        $h .= $this->todoRow('receipt', 'blue', $bordereaux, 'bordereau(x) prêt(s)', 'documents de transport générés', 'Synchronisées', $orders_url . '&f=synced');
        $h .= $this->todoRow('place', 'violet', $pickup_count, 'adresse(s) de ramassage', 'points de collecte configurés', 'Gérer', $pickup_url);
        $h .= '</div>';
        // Coverage bar
        $h .= '<div class="intigo-coverage"><div class="intigo-coverage-top"><span>Couverture Intigo</span><strong>' . $coverage . '%</strong></div>'
            . '<div class="progress"><div class="progress-bar" style="width:' . $coverage . '%"></div></div>'
            . '<div class="text-muted" style="font-size:12px;margin-top:4px;">' . $total_parcels . ' colis sur ' . $total_orders . ' commandes</div></div>';
        $h .= '</div></div>';
        $h .= '</div>';

        // Right: recent activity
        $h .= '<div class="intigo-dash-col-side">';
        $h .= '<div class="card"><div class="card-header"><h3 class="card-header-title">'
            . '<i class="material-icons">history</i> Activité récente</h3></div><div class="card-body" style="padding-top:6px;">';
        $recent = $db->executeS(
            'SELECT o.id_order, o.reference, o.total_paid_tax_incl AS tot, a.firstname, a.lastname,
                    p.nid, p.status_code, p.destination_city_name
             FROM `' . $pfx . 'intigo_parcel` p
             JOIN `' . $pfx . 'orders` o ON o.id_order = p.id_order
             LEFT JOIN `' . $pfx . 'address` a ON o.id_address_delivery = a.id_address
             WHERE p.nid <> "" ORDER BY p.id_order DESC LIMIT 8'
        );
        $recent = is_array($recent) ? $recent : [];
        if (empty($recent)) {
            $h .= '<p class="text-muted" style="margin:8px 0;">Aucun colis envoyé pour l\'instant.</p>';
        } else {
            $h .= '<div class="intigo-activity">';
            foreach ($recent as $r) {
                $label = $this->groupLabel($this->statusGroup((int) $r['status_code']));
                $h .= '<div class="intigo-activity-row">'
                    . '<div class="intigo-activity-main"><strong>#' . (int) $r['id_order'] . '</strong> '
                    . '<span class="text-muted">' . htmlspecialchars(trim((string) $r['firstname'] . ' ' . $r['lastname'])) . '</span>'
                    . '<div class="intigo-activity-sub">' . htmlspecialchars((string) $r['destination_city_name'] ?: '—') . ' · ' . $cur($r['tot']) . '</div></div>'
                    . '<div>' . $label . '</div></div>';
            }
            $h .= '</div>';
        }
        $h .= '<div style="margin-top:10px;"><a href="' . htmlspecialchars($orders_url) . '" class="btn btn-default btn-sm">Toutes les commandes</a></div>';
        $h .= '</div></div>';
        $h .= '</div>'; // col-side
        $h .= '</div>'; // cols

        $h .= '</div>'; // .intigo-screen
        return $h;
    }

    /* ---------------- SVG charts (no external library) ---------------- */

    /** Donut chart from [[label,count,color], …] via stacked stroke-dasharray. */
    private function donutSvg($segments, $total, $centerTop, $centerBottom)
    {
        $size = 168; $stroke = 24; $r = ($size - $stroke) / 2; $c = $size / 2;
        $circ = 2 * M_PI * $r;
        $s = '<svg viewBox="0 0 ' . $size . ' ' . $size . '" width="' . $size . '" height="' . $size . '" class="intigo-donut">';
        $s .= '<circle cx="' . $c . '" cy="' . $c . '" r="' . $r . '" fill="none" stroke="#eef2f6" stroke-width="' . $stroke . '"/>';
        $offset = 0;
        if ($total > 0) {
            foreach ($segments as $seg) {
                if ($seg[1] <= 0) { continue; }
                $len = ($seg[1] / $total) * $circ;
                $s .= '<circle cx="' . $c . '" cy="' . $c . '" r="' . $r . '" fill="none" stroke="' . $seg[2] . '" stroke-width="' . $stroke . '"'
                    . ' stroke-dasharray="' . round($len, 2) . ' ' . round($circ - $len, 2) . '" stroke-dashoffset="' . round(-$offset, 2) . '"'
                    . ' transform="rotate(-90 ' . $c . ' ' . $c . ')"><title>' . htmlspecialchars($seg[0] . ' : ' . $seg[1]) . '</title></circle>';
                $offset += $len;
            }
        }
        $s .= '<text x="' . $c . '" y="' . ($c - 1) . '" text-anchor="middle" class="intigo-donut-top">' . htmlspecialchars($centerTop) . '</text>';
        $s .= '<text x="' . $c . '" y="' . ($c + 17) . '" text-anchor="middle" class="intigo-donut-bot">' . htmlspecialchars($centerBottom) . '</text>';
        $s .= '</svg>';
        return $s;
    }

    /** 14-day bar chart from [['label'=>..,'count'=>..], …]. */
    private function trendSvg($days)
    {
        $w = 560; $h = 150; $padX = 6; $padTop = 18; $padBot = 22;
        $n = max(1, count($days));
        $max = 1;
        foreach ($days as $d) { $max = max($max, (int) $d['count']); }
        $bw = ($w - 2 * $padX) / $n;
        $plotH = $h - $padTop - $padBot;
        $s = '<svg viewBox="0 0 ' . $w . ' ' . $h . '" preserveAspectRatio="none" width="100%" height="' . $h . '" class="intigo-trend">';
        $i = 0;
        foreach ($days as $d) {
            $cnt = (int) $d['count'];
            $bh = $max > 0 ? ($cnt / $max) * $plotH : 0;
            $x = $padX + $i * $bw + $bw * 0.16;
            $bwBar = $bw * 0.68;
            $y = $padTop + ($plotH - $bh);
            $s .= '<rect x="' . round($x, 1) . '" y="' . round($y, 1) . '" width="' . round($bwBar, 1) . '" height="' . round($bh, 1) . '"'
                . ' rx="3" fill="#4F46E5" fill-opacity="' . ($cnt > 0 ? '0.9' : '0.12') . '"><title>' . htmlspecialchars($d['label'] . ' : ' . $cnt) . '</title></rect>';
            if ($cnt > 0) {
                $s .= '<text x="' . round($x + $bwBar / 2, 1) . '" y="' . round($y - 4, 1) . '" text-anchor="middle" class="intigo-trend-val">' . $cnt . '</text>';
            }
            // x-axis label every other day to avoid crowding
            if ($i % 2 === 0) {
                $s .= '<text x="' . round($x + $bwBar / 2, 1) . '" y="' . ($h - 6) . '" text-anchor="middle" class="intigo-trend-lbl">' . htmlspecialchars($d['label']) . '</text>';
            }
            $i++;
        }
        $s .= '</svg>';
        return $s;
    }

    private function todoRow($icon, $tone, $count, $label, $hint, $cta, $url)
    {
        $dim = (int) $count === 0 ? ' intigo-todo-row--zero' : '';
        return '<a href="' . htmlspecialchars($url) . '" class="intigo-todo-row' . $dim . '">'
            . '<span class="intigo-todo-ic intigo-todo-ic--' . $tone . '"><i class="material-icons">' . $icon . '</i></span>'
            . '<span class="intigo-todo-num">' . (int) $count . '</span>'
            . '<span class="intigo-todo-txt"><strong>' . htmlspecialchars($label) . '</strong><small>' . htmlspecialchars($hint) . '</small></span>'
            . '<span class="intigo-todo-cta">' . htmlspecialchars($cta) . ' <i class="material-icons">chevron_right</i></span>'
            . '</a>';
    }

    private function groupLabel($group)
    {
        $map = [
            'pickup' => ['En attente', 'warning'],
            'transit' => ['En transit', 'info'],
            'out' => ['En livraison', 'info'],
            'delivered' => ['Livré', 'success'],
            'return' => ['Retour', 'warning'],
            'canceled' => ['Annulé', 'danger'],
        ];
        $m = isset($map[$group]) ? $map[$group] : ['—', 'muted'];
        return '<span class="intigo-badge intigo-badge--' . $m[1] . '">' . $m[0] . '</span>';
    }
}
