<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * AJAX endpoint for cascading dropdowns at checkout.
 *
 *   GET /module/intigoparcels/regions?action=cities
 *   GET /module/intigoparcels/regions?action=districts&city_id=N
 *   GET /module/intigoparcels/regions?action=neighborhoods&district_id=N
 *
 * Returns: { ok: bool, items: [{id, name}, ...], error?: string }
 */
class IntigoparcelsRegionsModuleFrontController extends ModuleFrontController
{
    public $ssl = true;
    public $auth = false;
    public $ajax = true;

    public function postProcess()
    {
        $this->ajax = true;
        $this->display_header = false;
        $this->display_footer = false;
    }

    public function displayAjax()
    {
        header('Content-Type: application/json; charset=utf-8');

        require_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoApiClient.php';
        require_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoLog.php';

        $action = Tools::getValue('action');
        $api = new IntigoApiClient();

        switch ($action) {
            case 'cities':
                $res = $api->fetchCities((string) Tools::getValue('q', ''));
                break;
            case 'districts':
                $city_id = (int) Tools::getValue('city_id');
                $res = $api->fetchDistricts($city_id, (string) Tools::getValue('q', ''));
                break;
            case 'neighborhoods':
                $district_id = (int) Tools::getValue('district_id');
                $res = $api->fetchNeighborhoods($district_id);
                break;
            default:
                echo json_encode(['ok' => false, 'error' => 'unknown action', 'items' => []]);
                return;
        }

        if (empty($res['ok'])) {
            IntigoLog::add('lookup_' . $action . '_failed', isset($res['error']) ? (string) $res['error'] : '');
        }
        echo json_encode([
            'ok' => !empty($res['ok']),
            'items' => isset($res['items']) ? $res['items'] : [],
            'error' => isset($res['error']) ? (string) $res['error'] : '',
        ]);
    }
}
