<?php
/**
 * Upgrade to 1.3.1 — access management.
 *
 *  - The new "Accès" admin page (AdminIntigoAccess) under the Intigo parent.
 *  - Grant every employee profile access to the Intigo pages (PrestaShop only
 *    auto-grants SuperAdmin when a tab is added, so custom profiles were locked
 *    out). The "Accès" page itself stays SuperAdmin-only.
 *
 * No schema change since 1.3.0. Everything here is idempotent.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_3_1($module)
{
    // Schema safety net (idempotent CREATE/ALTER) in case an older column is missing.
    if (!(include dirname(__FILE__) . '/../sql/install.php')) {
        return false;
    }

    // Create the "Accès" tab (SuperAdmin-only) and grant the other pages to all
    // profiles. Both are public + idempotent on the module instance.
    if (method_exists($module, 'ensureAccessTab')) {
        $module->ensureAccessTab();
    }
    if (method_exists($module, 'grantTabAccess')) {
        $module->grantTabAccess();
    }
    Configuration::updateValue('INTIGO_TAB_ACCESS_V1', '1');

    // Migrate the old 3 fixed webhook states into the new many-to-many status map,
    // so existing installs keep working and gain the full mapping. Only seed when
    // the new map is empty (never clobber a map the merchant already configured).
    if (trim((string) Configuration::get('INTIGO_WH_STATUS_MAP')) === '') {
        $delivered = (int) Configuration::get('INTIGO_STATE_DELIVERED');
        $returned = (int) Configuration::get('INTIGO_STATE_RETURNED');
        $in_delivery = (int) Configuration::get('INTIGO_STATE_IN_DELIVERY');
        $map = [];
        if ($delivered > 0) { $map['5000'] = $delivered; $map['5001'] = $delivered; }
        if ($in_delivery > 0) { $map['4000'] = $in_delivery; }
        if ($returned > 0) { $map['6000'] = $returned; $map['6100'] = $returned; $map['6200'] = $returned; }
        if (!empty($map)) {
            Configuration::updateValue('INTIGO_WH_STATUS_MAP', json_encode($map));
        }
    }

    return true;
}
