<?php
/**
 * Upgrade to 1.3.0 — address auto-match hardening (postal-code dual send),
 * pickup-address GPS editing, and the Orders pickup filter.
 *
 * Schema delta vs. 1.2.0: the `pickup_index` column on intigo_parcel (used by the
 * Orders "Adresse de ramassage" filter). sql/install.php adds it via an idempotent
 * ALTER, so re-including it is safe on an already-upgraded install.
 *
 * Every step is idempotent — a re-run (or a partial earlier run) is harmless.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_3_0($module)
{
    // 1. Schema — install.php's idempotent CREATE/ALTER adds the pickup_index
    //    column (and any other column a pre-1.3.0 install might still lack).
    if (!(include dirname(__FILE__) . '/../sql/install.php')) {
        return false;
    }

    // 2. Config keys introduced since the install may pre-date them — only set
    //    when absent so a merchant's existing values are never clobbered.
    $defaults = [
        'INTIGO_WEBHOOK_TOKEN' => bin2hex(random_bytes(16)),
        'INTIGO_WEBHOOK_LAST_TS' => '0',
        'INTIGO_STATE_DELIVERED' => '0',
        'INTIGO_STATE_RETURNED' => '0',
        'INTIGO_STATE_IN_DELIVERY' => '0',
    ];
    foreach ($defaults as $k => $v) {
        if (Configuration::get($k) === false) {
            Configuration::updateValue($k, $v);
        }
    }

    return true;
}
