<?php
/**
 * Upgrade to 1.1.0 — Pickup addresses ↔ order-status mapping.
 *
 * Canonical PS upgrade path for modules already installed in production:
 *   1. Create the `intigo_pickup_map` table (idempotent, IF NOT EXISTS).
 *   2. Add the new pickup config keys (only when absent — never clobber values).
 *   3. Register the "Pickup addresses" admin tab under the Intigo parent.
 *
 * Every step is idempotent so a re-run (or a partial earlier run) is safe.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_1_0($module)
{
    // 1. Tables — install.php creates every table with CREATE TABLE IF NOT EXISTS,
    //    so existing tables are untouched and intigo_pickup_map is added.
    if (!(include dirname(__FILE__) . '/../sql/install.php')) {
        return false;
    }

    // 2. New config keys — preserve any value a merchant may already have.
    $defaults = [
        'INTIGO_DEFAULT_PICKUP_INDEX' => '',
        'INTIGO_PICKUP_AS_TRIGGER' => '0',
        'INTIGO_PICKUP_CACHE' => '',
        'INTIGO_PICKUP_CACHE_TS' => '0',
    ];
    foreach ($defaults as $k => $v) {
        if (Configuration::get($k) === false) {
            Configuration::updateValue($k, $v);
        }
    }

    // 3. "Pickup addresses" tab under the Intigo parent (skip if it already exists).
    if ((int) Tab::getIdFromClassName('AdminIntigoPickup') <= 0) {
        $id_parent = (int) Tab::getIdFromClassName('AdminIntigoParent');
        $tab = new Tab();
        $tab->class_name = 'AdminIntigoPickup';
        $tab->module = $module->name;
        $tab->id_parent = $id_parent > 0 ? $id_parent : 0;
        $tab->active = 1;
        foreach (Language::getLanguages(true) as $lang) {
            $tab->name[$lang['id_lang']] = 'Pickup addresses';
        }
        $tab->add();
    }

    return true;
}
