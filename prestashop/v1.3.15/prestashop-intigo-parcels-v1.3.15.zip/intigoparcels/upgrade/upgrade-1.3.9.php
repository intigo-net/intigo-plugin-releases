<?php
/**
 * Upgrade to 1.3.9 — smarter address zone detection.
 *
 * Uses the postal code to isolate the locality (the place name follows it in
 * Tunisian addresses) and prefers the candidate whose delegation is actually
 * named in the address — so "…2091 Jardins d'el menzah 2" resolves to El Menzah
 * (Tunis) instead of a far-away "Cité des Jardins / Ghardimaou". Code-only.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_3_9($module)
{
    if (!(include dirname(__FILE__) . '/../sql/install.php')) {
        return false;
    }
    if (method_exists($module, 'ensureTabs')) {
        $module->ensureTabs();
    }
    return true;
}
