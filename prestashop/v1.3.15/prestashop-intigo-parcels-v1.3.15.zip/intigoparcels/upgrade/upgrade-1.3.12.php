<?php
/**
 * Upgrade to 1.3.12 — two real fixes found on the client (Fnac):
 *
 *  1. Reference (and any field) not saving on some orders: the parcel table was
 *     left missing columns by an incomplete earlier upgrade, so ObjectModel::save()
 *     silently failed (it writes every column at once) while the list still worked.
 *     The schema heal now covers EVERY column, runs here, and the save self-heals
 *     + retries and surfaces a real error instead of a false "enregistré".
 *  2. Wrong address zone (e.g. El Menzah detected as Jendouba): the resolver never
 *     read PrestaShop's separate postal-code field. It now uses it to isolate the
 *     locality.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_3_12($module)
{
    if (!(include dirname(__FILE__) . '/../sql/install.php')) {
        return false;
    }
    if (method_exists($module, 'ensureTabs')) {
        $module->ensureTabs();
    }
    return true;
}
