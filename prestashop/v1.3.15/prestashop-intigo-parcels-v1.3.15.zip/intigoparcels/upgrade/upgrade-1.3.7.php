<?php
/**
 * Upgrade to 1.3.7 — prepaid orders sent to Intigo with COD amount 0.
 *
 * Orders paid online (Flouci, card, …) must not be collected again on delivery.
 * The merchant lists their prepaid payment methods in Settings; matching orders
 * that were actually paid are sent with price=0. Seeds the new config key (only
 * when absent) so existing installs get a sensible default without clobbering a
 * merchant's own value. Code-only otherwise.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_3_7($module)
{
    if (!(include dirname(__FILE__) . '/../sql/install.php')) {
        return false;
    }
    // INTIGO_COD_METHODS is left empty on upgrade — the merchant ticks their COD
    // payment solution(s) in Settings (dynamic list). Empty = collect full.
    if (method_exists($module, 'ensureTabs')) {
        $module->ensureTabs();
    }
    return true;
}
