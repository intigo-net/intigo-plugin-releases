<?php
/**
 * Upgrade to 1.3.6 — "Renvoyer avec le bon ramassage" action.
 *
 * Adds a button on the order panel that cancels an already-created parcel and
 * recreates it from the pickup address mapped to the order's CURRENT status.
 * Needed because Intigo has no "change pickup" on an existing parcel, so a parcel
 * created from the wrong pickup (e.g. before the status was set) could not be
 * corrected without this.
 *
 * Code-only change — no schema or tab change. Idempotent safety nets kept.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_3_6($module)
{
    if (!(include dirname(__FILE__) . '/../sql/install.php')) {
        return false;
    }
    if (method_exists($module, 'ensureTabs')) {
        $module->ensureTabs();
    }
    return true;
}
