<?php
/** Upgrade to 1.3.14 — date-range filter on the Orders list (From/To + Appliquer);
 * carries the order-independent schema heal + real-DB-error from 1.3.13. */
if (!defined('_PS_VERSION_')) { exit; }
function upgrade_module_1_3_14($module)
{
    if (!(include dirname(__FILE__) . '/../sql/install.php')) { return false; }
    if (method_exists($module, 'ensureTabs')) { $module->ensureTabs(); }
    return true;
}
