<?php
/**
 * Upgrade to 1.3.2.
 *
 *  - Grant MODULE access to every profile (ROLE_MOD_MODULE_INTIGOPARCELS_*).
 *    PrestaShop skips a module's hooks for profiles without module "view" access,
 *    so on shops with custom profiles the Intigo pages rendered UNSTYLED (the
 *    CSS/JS hooks never fired). This is coarse + idempotent and does NOT touch
 *    per-page tab access, so it never undoes the merchant's "Accès" restrictions.
 *  - Bundled Material Icons font (icons render on PrestaShop versions whose BO
 *    doesn't provide the font on legacy module pages, e.g. 1.7.8.0).
 *  - Many-to-many webhook status map + the "update orders" toggle + live status
 *    column. New config keys are seeded with safe defaults.
 *
 * No DB schema change. Everything here is idempotent.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_3_2($module)
{
    if (!(include dirname(__FILE__) . '/../sql/install.php')) {
        return false;
    }

    // The real 1.3.2 fix: grant module access so the hooks (CSS/JS) run for every
    // profile. Tab access is left as-is (restrictions preserved).
    if (method_exists($module, 'grantModuleAccess')) {
        $module->grantModuleAccess();
    }
    if (method_exists($module, 'ensureAccessTab')) {
        $module->ensureAccessTab();
    }
    Configuration::updateValue('INTIGO_TAB_ACCESS_V2', '1');

    // New config defaults (only when absent — never clobber merchant values).
    if (Configuration::get('INTIGO_WH_UPDATE_ORDERS') === false) {
        Configuration::updateValue('INTIGO_WH_UPDATE_ORDERS', '1');
    }
    if (Configuration::get('INTIGO_WH_STATUS_MAP') === false) {
        Configuration::updateValue('INTIGO_WH_STATUS_MAP', '');
    }

    return true;
}
