<?php
/**
 * Upgrade to 1.3.10 — new-orders badge fix + re-detect address button.
 *
 *  - The sidebar "new orders" badge was carrier-based (always 0 for shops that
 *    don't use the Intigo carrier). It now matches the Intigo Orders list scope.
 *  - The order edit page gets a "Re-détecter la ville / délégation" button that
 *    re-runs the address auto-detection on demand. Code-only.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_3_10($module)
{
    if (!(include dirname(__FILE__) . '/../sql/install.php')) {
        return false;
    }
    if (method_exists($module, 'ensureTabs')) {
        $module->ensureTabs();
    }
    return true;
}
