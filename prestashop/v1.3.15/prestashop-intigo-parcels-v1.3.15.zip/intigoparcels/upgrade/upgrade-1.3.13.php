<?php
/** Upgrade to 1.3.13 — make the parcel-table schema heal order-independent
 * (v1.3.12's ADD COLUMN ... AFTER `col` could abort when that column was itself
 * still missing, leaving the save broken) and surface the real DB error. */
if (!defined('_PS_VERSION_')) { exit; }
function upgrade_module_1_3_13($module)
{
    if (!(include dirname(__FILE__) . '/../sql/install.php')) { return false; }
    if (method_exists($module, 'ensureTabs')) { $module->ensureTabs(); }
    return true;
}
