<?php
/** Upgrade to 1.3.15 — THE real save fix: parcel values (recipient name, address,
 * reference…) are now SQL-escaped, so an apostrophe ("Salma B'chir", "Rue d'Alger")
 * no longer breaks the save on an existing parcel. */
if (!defined('_PS_VERSION_')) { exit; }
function upgrade_module_1_3_15($module)
{
    if (!(include dirname(__FILE__) . '/../sql/install.php')) { return false; }
    if (method_exists($module, 'ensureTabs')) { $module->ensureTabs(); }
    return true;
}
