<?php
/**
 * Upgrade to 1.3.8 — address auto-detect on the Intigo Orders edit page.
 *
 * The "Préciser la zone" edit page (Intigo → Commandes) now runs the same
 * address auto-detection as the native order panel, so the Ville/Délégation are
 * filled in instead of blank when reached from the Orders list. Code-only change.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_3_8($module)
{
    if (!(include dirname(__FILE__) . '/../sql/install.php')) {
        return false;
    }
    if (method_exists($module, 'ensureTabs')) {
        $module->ensureTabs();
    }
    return true;
}
