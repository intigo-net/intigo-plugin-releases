<?php
/**
 * Upgrade to 1.3.4 — auto-detect the Intigo zone on the native order page.
 *
 * Pre-existing orders opened from PrestaShop's own order view showed empty
 * Ville/Délégation because the address auto-detection only ran on the Intigo
 * Orders list, not the native order panel. 1.3.4 wires it into the panel
 * (one-time per order, persisted, fully guarded).
 *
 * This is a code-only change — no schema or tab change. We still run the
 * idempotent schema + tab safety nets so an install that jumped versions ends up
 * fully consistent.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_3_4($module)
{
    if (!(include dirname(__FILE__) . '/../sql/install.php')) {
        return false;
    }
    if (method_exists($module, 'ensureTabs')) {
        $module->ensureTabs();
    }
    return true;
}
