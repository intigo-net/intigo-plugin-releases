<?php
/**
 * Upgrade to 1.3.5 — status→pickup mapping honored even with a cold cache.
 *
 * The push-time GPS-safety guard read the pickup GPS state from the local cache
 * (INTIGO_PICKUP_CACHE). When that cache was empty/stale it discarded the
 * correctly-mapped pickup and omitted pickup_index, so Intigo fell back to the
 * account-default address (wrong pickup for the mapped status). 1.3.5 refreshes
 * the cache at push time when needed and only overrides a mapping when GPS is
 * positively known absent — otherwise it trusts and sends the mapping.
 *
 * Code-only change — no schema or tab change. Idempotent safety nets kept.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_3_5($module)
{
    if (!(include dirname(__FILE__) . '/../sql/install.php')) {
        return false;
    }
    if (method_exists($module, 'ensureTabs')) {
        $module->ensureTabs();
    }
    return true;
}
