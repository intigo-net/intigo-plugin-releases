<?php
/**
 * Upgrade to 1.3.11 — fix: order edit form could not be saved when the Ville
 * (city) was not yet detected. The required-but-empty <select> made the browser
 * silently block submission, so the Reference (and other fields) never saved.
 * The save buttons now bypass HTML5 validation (save-as-draft); completeness is
 * still enforced server-side before an actual send. Code-only.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_3_11($module)
{
    if (!(include dirname(__FILE__) . '/../sql/install.php')) {
        return false;
    }
    if (method_exists($module, 'ensureTabs')) {
        $module->ensureTabs();
    }
    return true;
}
