<?php
/**
 * Upgrade to 1.3.3 — fix missing pages on in-place upgrades + class autoloading.
 *
 * Root cause this addresses: shops that upgraded the module by uploading new
 * files under a version they already had ran NO upgrade script, so pages added
 * meanwhile — notably "Adresses de ramassage" (AdminIntigoPickup) — never got
 * their tab created. A legacy controller without a tab has no authorization
 * role, so the page is inaccessible *even to SuperAdmin* and the module shows
 * only under "Configure".
 *
 * Steps (all idempotent):
 *   1. Schema safety net (CREATE TABLE IF NOT EXISTS incl. intigo_pickup_map).
 *   2. Create any missing Intigo tab + (re)grant access — ensureTabs().
 *   3. Seed pickup config keys for installs that jumped past the 1.1.0 upgrade.
 *
 * The class-autoloading fix (classes/IntigoAutoload.php, required by every
 * controller) is code-only and needs no DB step. Bumping to 1.3.3 is what makes
 * PrestaShop run this script on shops stuck on an older recorded version.
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

function upgrade_module_1_3_3($module)
{
    // 1. Schema (idempotent).
    if (!(include dirname(__FILE__) . '/../sql/install.php')) {
        return false;
    }

    // 2. Create any missing Intigo tabs (Pickup, etc.) and re-grant access.
    if (method_exists($module, 'ensureTabs')) {
        $module->ensureTabs();
    }
    if (method_exists($module, 'grantTabAccess')) {
        $module->grantTabAccess();
    }
    if (method_exists($module, 'grantModuleAccess')) {
        $module->grantModuleAccess();
    }

    // 3. Pickup config defaults — only when absent (never clobber merchant values).
    $defaults = [
        'INTIGO_DEFAULT_PICKUP_INDEX' => '',
        'INTIGO_PICKUP_AS_TRIGGER' => '0',
        'INTIGO_PICKUP_CACHE' => '',
        'INTIGO_PICKUP_CACHE_TS' => '0',
    ];
    foreach ($defaults as $k => $v) {
        if (Configuration::get($k) === false) {
            Configuration::updateValue($k, $v);
        }
    }

    Configuration::updateValue('INTIGO_TABS_V3', '1');

    return true;
}
