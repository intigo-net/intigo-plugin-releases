<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Push/update/cancel parcels at Intigo. Direct port of class-intigo-order-service.php
 * from the WP plugin, adapted to PrestaShop's Order / Address / Customer model.
 *
 *   pushParcel($order)   — POST /v3/parcels/  (idempotent by md5(ps:shop:order:event:v1))
 *   updateParcel($order) — PATCH /v3/parcels/{nid}, with phone/address/price fallback
 *                          if PATCH 4xxs (mirrors the WP plugin's lock-aware logic)
 *   cancelParcel($order) — POST /v3/parcels/{nid}/cancel
 */
class IntigoOrderService
{
    /** @var IntigoApiClient */
    private $api;

    public function __construct()
    {
        $this->api = new IntigoApiClient();
    }

    public function pushParcel(Order $order, $force = false, $autoTriggered = false)
    {
        $parcel = IntigoParcel::findByOrderId((int) $order->id);

        // HARD RULE: an order is NEVER auto-synced without a Référence. Automatic
        // triggers (checkout auto-create, status→pickup trigger) must pass through
        // this gate; only a manual send (merchant clicks "Envoyer") may ship an
        // order that has no reference. Keeps automation explicit and opt-in.
        if ($autoTriggered && (!$parcel || trim((string) $parcel->reference_id) === '')) {
            if (class_exists('IntigoLog')) {
                IntigoLog::add('auto_push_skipped_no_reference', 'id_order=' . (int) $order->id);
            }
            return ['ok' => false, 'skipped' => true,
                'message' => 'Synchronisation automatique ignorée : aucune référence définie sur la commande.'];
        }

        // Idempotency: only skip when we already have a successful NID.
        // Failed attempts (no NID) are always retryable so the merchant can
        // fix missing fields (district, etc.) and click Send again.
        if (!$force && $parcel && trim((string) $parcel->nid) !== '') {
            return [
                'ok' => true,
                'skipped' => true,
                'message' => 'Colis déjà envoyé (numéro de suivi ' . $parcel->nid . ')',
                'nid' => $parcel->nid,
            ];
        }

        // Build the ordered send plan BEFORE claiming (the standard payload may
        // resolve the city via API) so we never hold the send-lock during a slow
        // resolve, and never lock for nothing. The plan carries up to two methods
        // — the free-text-guesser zone and the postal-code path — in confidence
        // order; if the first fails we fall through to the second.
        $plan = $this->buildSendPlan($order, $parcel);
        if (empty($plan)) {
            $std = $this->orderToPayload($order);
            $msg = $this->validatePayload($std);
            $msg = $msg !== null ? $msg : 'Adresse incomplète : renseignez la ville et la délégation, ou un code postal valide.';
            $this->savePushFailure($order, $std, 'validation: ' . $msg);
            return ['ok' => false, 'message' => $msg];
        }

        // Atomically claim the order — only ONE concurrent push reaches the API.
        // The v3 API has no idempotency key, so this is the only thing preventing
        // duplicate parcels under bulk send / double-click / cron-overlap.
        if (!IntigoParcel::claimForSend((int) $order->id, $force)) {
            $existing = IntigoParcel::findByOrderId((int) $order->id);
            if ($existing && trim((string) $existing->nid) !== '') {
                return ['ok' => true, 'skipped' => true, 'nid' => $existing->nid,
                    'message' => 'Colis déjà envoyé (numéro de suivi ' . $existing->nid . ')'];
            }
            return ['ok' => false, 'skipped' => true, 'message' => 'Un envoi est déjà en cours pour cette commande'];
        }

        try {
            $errors = [];
            foreach ($plan as $attempt) {
                $res = ($attempt['method'] === 'postal')
                    ? $this->api->createParcelByPostalCode($attempt['payload'])
                    : $this->api->createParcel($attempt['payload']);
                if (!empty($res['ok']) && !empty($res['data']['nid'])) {
                    $nid = (string) $res['data']['nid'];
                    $this->savePushSuccess($order, $attempt['payload'], $nid, (string) ($res['adapter'] ?? 'primary'));
                    IntigoLog::add('order_push_ok', 'id_order=' . (int) $order->id . ' nid=' . $nid . ' via=' . $attempt['method']);
                    return ['ok' => true, 'nid' => $nid, 'message' => 'Colis créé avec succès (suivi : ' . $nid . ')'];
                }
                $errors[] = $attempt['method'] . ' → ' . $this->formatApiError($res);
                IntigoLog::add('order_push_attempt_failed', 'id_order=' . (int) $order->id . ' via=' . $attempt['method']);
            }
            $err = implode(' | ', $errors);
            $this->savePushFailure($order, $plan[count($plan) - 1]['payload'], $err);
            IntigoLog::add('order_push_failed', 'id_order=' . (int) $order->id . ' err=' . $err);
            return ['ok' => false, 'message' => 'Échec de l\'envoi à Intigo. ' . $err];
        } finally {
            IntigoParcel::releaseSendLock((int) $order->id);
        }
    }

    public function updateParcel(Order $order)
    {
        $parcel = IntigoParcel::findByOrderId((int) $order->id);
        if (!$parcel || trim((string) $parcel->nid) === '') {
            return ['ok' => false, 'message' => 'Aucun colis pour cette commande — envoyez-le d\'abord'];
        }
        if ((int) $parcel->sync_locked === 1) {
            return ['ok' => false, 'message' => 'Colis verrouillé chez Intigo (livré/en retour) — modification impossible'];
        }

        $payload = $this->orderToPayload($order);
        $validation = $this->validatePayload($payload);
        if ($validation !== null) {
            return ['ok' => false, 'message' => 'validation: ' . $validation];
        }

        $res = $this->api->updateParcel($parcel->nid, $payload);
        if (!empty($res['ok'])) {
            IntigoLog::add('order_update_ok', 'id_order=' . (int) $order->id . ' nid=' . $parcel->nid);
            return ['ok' => true, 'message' => 'Colis mis à jour'];
        }
        if ($this->isParcelLockedError($res)) {
            $parcel->sync_locked = 1;
            $parcel->save();
            return ['ok' => false, 'locked' => true, 'message' => 'Colis verrouillé chez Intigo (livré/en retour)'];
        }

        // Fallback: try the per-field change endpoints
        $errs = [];
        $phone_res = $this->api->changePhone($parcel->nid, $payload['phone1'] ?? '');
        if (empty($phone_res['ok'])) {
            $errs[] = 'phone=' . $this->formatApiError($phone_res);
        }
        $addr_res = $this->api->changeAddress($parcel->nid, [
            'address' => $payload['destination_address'] ?? '',
            'city_id' => (int) ($payload['destination_city_id'] ?? 0),
            'district_id' => (int) ($payload['destination_district_id'] ?? 0),
            'neighborhood_id' => (int) ($payload['destination_neighborhood_id'] ?? 0),
        ]);
        if (empty($addr_res['ok'])) {
            $errs[] = 'address=' . $this->formatApiError($addr_res);
        }
        $price_res = $this->api->changePrice($parcel->nid, (float) ($payload['price'] ?? 0));
        if (empty($price_res['ok'])) {
            $errs[] = 'price=' . $this->formatApiError($price_res);
        }
        if (count($errs) < 3) {
            IntigoLog::add('order_update_fallback_ok', 'id_order=' . (int) $order->id . ' nid=' . $parcel->nid);
            return ['ok' => true, 'message' => 'Colis mis à jour'];
        }
        $err = $this->formatApiError($res) . ' | fallback: ' . implode(' ', $errs);
        IntigoLog::add('order_update_failed', 'id_order=' . (int) $order->id . ' err=' . $err);
        return ['ok' => false, 'message' => $err];
    }

    public function cancelParcel(Order $order)
    {
        $parcel = IntigoParcel::findByOrderId((int) $order->id);
        if (!$parcel || trim((string) $parcel->nid) === '') {
            return ['ok' => false, 'message' => 'Aucun colis pour cette commande'];
        }
        $res = $this->api->cancelParcel($parcel->nid);
        if (!empty($res['ok'])) {
            IntigoLog::add('order_cancel_ok', 'id_order=' . (int) $order->id . ' nid=' . $parcel->nid);
            return ['ok' => true, 'message' => 'Colis annulé'];
        }
        $err = $this->formatApiError($res);
        IntigoLog::add('order_cancel_failed', 'id_order=' . (int) $order->id . ' err=' . $err);
        return ['ok' => false, 'message' => $err];
    }

    public function generateBordereau(Order $order)
    {
        $parcel = IntigoParcel::findByOrderId((int) $order->id);
        if (!$parcel || trim((string) $parcel->nid) === '') {
            return ['ok' => false, 'message' => 'Aucun colis pour cette commande'];
        }
        $res = $this->api->generateBordereau([$parcel->nid]);
        if (!empty($res['ok']) && !empty($res['data']['url'])) {
            $parcel->bordereau_url = (string) $res['data']['url'];
            $parcel->save();
            IntigoLog::add('order_bordereau_ok', 'id_order=' . (int) $order->id . ' nid=' . $parcel->nid);
            return ['ok' => true, 'url' => $parcel->bordereau_url];
        }
        $err = $this->formatApiError($res);
        IntigoLog::add('order_bordereau_failed', 'id_order=' . (int) $order->id . ' err=' . $err);
        return ['ok' => false, 'message' => $err];
    }

    /**
     * Bulk-create parcels for many orders in ONE request via /v3/parcels/batch
     * (max 100; returns per-item results mapped by index). Each order is atomically
     * claimed first so a concurrent/duplicate bulk can't double-create. Orders that
     * are already pushed, incomplete, or locked are skipped (not failed).
     *
     * @return array ['total','created','failed','skipped','skip_detail'=>[id=>reason]]
     */
    public function pushParcelsBulk(array $order_ids)
    {
        $order_ids = array_values(array_unique(array_map('intval', $order_ids)));
        $jobs = [];   // ['order'=>, 'plan'=>[], 'done'=>bool, 'err'=>str, 'payload'=>last-tried]
        $skipped = [];

        foreach ($order_ids as $oid) {
            if ($oid <= 0) {
                continue;
            }
            $order = new Order($oid);
            if (!Validate::isLoadedObject($order)) {
                $skipped[$oid] = 'not_found';
                continue;
            }
            $existing = IntigoParcel::findByOrderId($oid);
            if ($existing && trim((string) $existing->nid) !== '') {
                $skipped[$oid] = 'already';
                continue;
            }
            $plan = $this->buildSendPlan($order, $existing);
            if (empty($plan)) {
                // No usable zone AND no usable postal code — skip WITHOUT marking a
                // failure (already flagged by its resolution status). Only a real
                // API rejection is a failure.
                $skipped[$oid] = 'incomplete';
                continue;
            }
            if (!IntigoParcel::claimForSend($oid, false)) {
                $skipped[$oid] = 'locked';
                continue;
            }
            $jobs[] = ['order' => $order, 'plan' => $plan, 'done' => false, 'err' => '', 'payload' => $plan[0]['payload']];
        }

        // Up to two rounds: round 0 = each job's primary method, round 1 = its
        // fallback. Within a round, jobs are grouped by method and sent in ONE
        // batch call per method (standard → /batch, postal → /batch-by-postal-code).
        $created = 0;
        $failed = 0;
        for ($round = 0; $round < 2; $round++) {
            $byMethod = ['standard' => [], 'postal' => []];
            foreach ($jobs as $ji => $job) {
                if ($job['done'] || !isset($job['plan'][$round])) {
                    continue;
                }
                $m = $job['plan'][$round]['method'];
                $byMethod[$m][] = ['ji' => $ji, 'payload' => $job['plan'][$round]['payload']];
            }
            foreach (['standard', 'postal'] as $m) {
                if (empty($byMethod[$m])) {
                    continue;
                }
                $batch = $byMethod[$m];
                $payloads = array_map(function ($b) { return $b['payload']; }, $batch);
                $res = ($m === 'postal')
                    ? $this->api->createParcelsBatchByPostalCode(['parcels' => $payloads])
                    : $this->api->createParcelsBatch(['parcels' => $payloads]);
                $results = (!empty($res['ok']) && isset($res['data']['results']) && is_array($res['data']['results']))
                    ? $res['data']['results'] : null;
                if ($results === null) {
                    // Whole batch failed — record the error on each job so the next
                    // round (or finalize) can fall back / report it.
                    $err = $m . ' → ' . $this->formatApiError($res);
                    foreach ($batch as $b) {
                        $jobs[$b['ji']]['err'] = $err;
                        $jobs[$b['ji']]['payload'] = $b['payload'];
                    }
                    continue;
                }
                foreach ($results as $item) {
                    $bidx = isset($item['index']) ? (int) $item['index'] : -1;
                    if (!isset($batch[$bidx])) {
                        continue;
                    }
                    $ji = $batch[$bidx]['ji'];
                    if (!empty($item['success']) && !empty($item['nid'])) {
                        $this->savePushSuccess($jobs[$ji]['order'], $batch[$bidx]['payload'], (string) $item['nid'], (string) ($res['adapter'] ?? 'primary'));
                        $jobs[$ji]['done'] = true;
                        $created++;
                    } else {
                        $jobs[$ji]['err'] = $m . ' → ' . (string) (isset($item['error']) ? $item['error'] : 'échec');
                        $jobs[$ji]['payload'] = $batch[$bidx]['payload'];
                    }
                }
            }
        }

        foreach ($jobs as $job) {
            if (!$job['done']) {
                $this->savePushFailure($job['order'], $job['payload'], $job['err'] !== '' ? $job['err'] : 'échec de l\'envoi');
                $failed++;
            }
            IntigoParcel::releaseSendLock((int) $job['order']->id);
        }

        IntigoLog::add('bulk_push', 'created=' . $created . ' failed=' . $failed . ' skipped=' . count($skipped));
        return [
            'total' => count($order_ids),
            'created' => $created,
            'failed' => $failed,
            'skipped' => count($skipped),
            'skip_detail' => $skipped,
        ];
    }

    /* -------------------- Send plan (guesser zone + postal code) -------------------- */

    /**
     * Build the ordered list of send attempts for an order. Each attempt is
     * ['method' => 'standard'|'postal', 'payload' => array]. A GREEN guesser
     * resolution is trusted first; otherwise the deterministic postal-code path
     * leads (Intigo resolves the zone from its own core_neighborhood.postal_code).
     * The other method, when available, is appended as a fallback. Empty array =
     * nothing to send (neither a valid zone nor a usable postal code).
     */
    private function buildSendPlan(Order $order, $parcel)
    {
        $std = $this->orderToPayload($order);
        $std_valid = ($this->validatePayload($std) === null);
        $pc = $this->usablePostalCode($order);
        $postal = ($pc !== '') ? $this->orderToPostalPayload($order) : null;

        $green = $parcel && (string) $parcel->resolution_status === 'resolved';

        $plan = [];
        if ($std_valid && ($green || $postal === null)) {
            $plan[] = ['method' => 'standard', 'payload' => $std];
            if ($postal !== null) {
                $plan[] = ['method' => 'postal', 'payload' => $postal];
            }
        } elseif ($postal !== null) {
            $plan[] = ['method' => 'postal', 'payload' => $postal];
            if ($std_valid) {
                $plan[] = ['method' => 'standard', 'payload' => $std];
            }
        } elseif ($std_valid) {
            $plan[] = ['method' => 'standard', 'payload' => $std];
        }
        return $plan;
    }

    /** The delivery postal code if it's a usable Tunisian 4-digit code, else ''. */
    public function usablePostalCode(Order $order)
    {
        $pc = '';
        if ((int) $order->id_address_delivery > 0) {
            $address = new Address((int) $order->id_address_delivery);
            if (Validate::isLoadedObject($address)) {
                $pc = (string) $address->postcode;
            }
        }
        $digits = preg_replace('/\D+/', '', $pc);
        return (is_string($digits) && strlen($digits) === 4) ? $digits : '';
    }

    /**
     * Postal-code variant of the parcel payload: the full standard payload minus
     * the destination zone IDs, plus `postal_code`. Intigo resolves city/district/
     * neighborhood from the postcode. resolveViaApi=false — no need to resolve the
     * city by name when the postcode carries the zone.
     */
    public function orderToPostalPayload(Order $order)
    {
        $p = $this->orderToPayload($order, false);
        unset($p['destination_city_id'], $p['destination_district_id'], $p['destination_neighborhood_id']);
        $p['postal_code'] = $this->usablePostalCode($order);
        return $p;
    }

    /* -------------------- Payload building -------------------- */

    /**
     * Build the parcel-creation payload from a PrestaShop Order.
     *
     * Precedence:
     *   - Intigo cart meta (city/district/etc captured at checkout) wins
     *   - Falls back to ps_intigo_parcel row (if order was edited)
     *   - Falls back to PrestaShop shipping address (best-effort)
     */
    public function orderToPayload(Order $order, $resolveViaApi = true)
    {
        $address = new Address((int) $order->id_address_delivery);
        $address_loaded = Validate::isLoadedObject($address);

        // Invoice address is a useful fallback — customers often put phone on
        // the billing address only, leaving the shipping address phone empty.
        $invoice = (int) $order->id_address_invoice > 0 && (int) $order->id_address_invoice !== (int) $order->id_address_delivery
            ? new Address((int) $order->id_address_invoice)
            : null;
        $invoice_loaded = $invoice && Validate::isLoadedObject($invoice);

        // All Intigo data lives in ps_intigo_parcel (admin fills it in BO).
        // Fall back to PS shipping address for any field the admin hasn't set.
        $parcel = IntigoParcel::findByOrderId((int) $order->id);

        $recipient_name = '';
        $phone = '';
        $destination_address = '';
        $city_id = 0;
        $district_id = 0;
        $neighborhood_id = 0;

        if ($parcel) {
            $recipient_name = (string) $parcel->recipient_name;
            $phone = (string) $parcel->recipient_phone;
            $destination_address = (string) $parcel->destination_address;
            $city_id = (int) $parcel->destination_city_id;
            $district_id = (int) $parcel->destination_district_id;
            $neighborhood_id = (int) $parcel->destination_neighborhood_id;
        }

        // Last-resort fallback: PrestaShop addresses (delivery first, then invoice).
        if ($recipient_name === '' && $address_loaded) {
            $recipient_name = trim((string) $address->firstname . ' ' . (string) $address->lastname);
        }
        if ($recipient_name === '' && $invoice_loaded) {
            $recipient_name = trim((string) $invoice->firstname . ' ' . (string) $invoice->lastname);
        }
        if ($phone === '' && $address_loaded) {
            $phone = (string) ($address->phone_mobile ?: $address->phone);
        }
        if ($phone === '' && $invoice_loaded) {
            $phone = (string) ($invoice->phone_mobile ?: $invoice->phone);
        }
        if ($destination_address === '' && $address_loaded) {
            $destination_address = trim((string) $address->address1 . ' ' . (string) $address->address2);
        }
        if ($destination_address === '' && $invoice_loaded) {
            $destination_address = trim((string) $invoice->address1 . ' ' . (string) $invoice->address2);
        }

        // Resolve city by name from address.city when we still don't have a
        // city_id. This makes a network call, so it is SKIPPED during checkout
        // (resolveViaApi=false) to never block order creation.
        if ($resolveViaApi && $city_id <= 0 && $address_loaded && trim((string) $address->city) !== '') {
            $resolved = $this->resolveCityIdByName((string) $address->city);
            if ($resolved > 0) {
                $city_id = $resolved;
            }
        }

        // Resolve size: per-order parcel.package_size > cart-based waterfall
        $size_letter = 'S';
        if ($parcel && (int) $parcel->package_size > 0) {
            $letter = IntigoSizeResolver::codeToLetter((int) $parcel->package_size);
            if ($letter !== '') {
                $size_letter = $letter;
            }
        } else {
            $size_letter = IntigoSizeResolver::resolveForOrder($order);
        }
        $package_size_code = IntigoApiClient::sizeLetterToCode($size_letter);

        $payload = [
            'recipient_name' => $recipient_name,
            'phone1' => $this->normalizePhone($phone),
            'destination_address' => $destination_address,
            'destination_city_id' => $city_id,
            'destination_district_id' => $district_id,
            'price' => (float) $order->total_paid_tax_incl,
            'package_size' => $package_size_code,
            'can_open' => false,
            // Correlation id (v1.1.0 schema): a stable per-order key so Intigo can
            // de-duplicate a re-push and we can match order↔parcel both ways.
            'cid' => 'ps-' . ((int) $order->id_shop ?: 1) . '-' . (int) $order->id,
        ];
        if ($neighborhood_id > 0) {
            $payload['destination_neighborhood_id'] = $neighborhood_id;
        }

        // Merchant "Référence" → goes into the parcel `description`, which Intigo
        // prints on the bordereau as the "Commentaire" section (verified against
        // partner2-api/services/bordereau_service.py). We append the PS order # for
        // traceability, and also copy the reference into `additional_info` (driver
        // notes) so it's visible both on the label and to the courier.
        $reference_id = $parcel ? trim((string) $parcel->reference_id) : '';
        $payload['description'] = $reference_id !== ''
            ? ($reference_id . ' (Commande #' . (int) $order->id . ')')
            : ('Commande PrestaShop #' . (int) $order->id);
        if ($reference_id !== '') {
            $payload['additional_info'] = $reference_id;
        }

        // Pickup address according to the order's current status. This is purely
        // local (status map + cached pickup list) — NO network call — so it is
        // safe during checkout too. The pickup_index is frozen at parcel creation;
        // the API exposes no way to change it afterward, so resolution only
        // matters at push time.
        $pickup = $this->resolvePickupIndex($order);
        if ($pickup !== null && $pickup >= 1) {
            $payload['pickup_index'] = (int) $pickup;
        }

        return $payload;
    }

    /**
     * Resolve the pickup index for this order, in cascade:
     *   status-mapped address → configured default → cached is_primary → null.
     * Returning null means "omit pickup_index" so Intigo uses the account default
     * — we never send an invalid/null index.
     */
    private function resolvePickupIndex(Order $order)
    {
        if (!class_exists('IntigoPickupMap')) {
            @include_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoPickupMap.php';
        }
        if (!class_exists('IntigoPickupMap')) {
            return null;
        }
        $id_shop = (int) $order->id_shop ?: 1;
        $id_state = (int) $order->getCurrentState();
        $idx = IntigoPickupMap::resolvePickupIndex($id_shop, $id_state);
        if ($idx === null) {
            $idx = $this->resolveDefaultPickupIndex();
        }
        // GPS safety: Intigo rejects a parcel ("Pickup address has no GPS
        // coordinates") if the chosen pickup has no coordinates, and OMITTING the
        // pickup makes Intigo fall back to the recipient's address (→ create
        // fails). So if the resolved pickup lacks GPS, fall back to a pickup that
        // HAS GPS (preferring the primary). Only return null if the merchant has
        // no GPS-enabled pickup at all (then the account default applies).
        if ($idx === null || (int) $idx < 1 || !$this->pickupHasGps((int) $idx)) {
            $fallback = $this->firstPickupWithGps();
            if ($idx !== null && (int) $idx >= 1 && $fallback !== (int) $idx) {
                IntigoLog::add('pickup_no_gps_fallback', 'from=' . (int) $idx
                    . ' to=' . ($fallback === null ? 'none' : $fallback) . ' id_order=' . (int) $order->id);
            }
            $idx = $fallback;
        }
        return $idx;
    }

    /** True only when the cached pickup list CONFIRMS this index has GPS. */
    private function pickupHasGps($index)
    {
        foreach ($this->pickupCacheList() as $it) {
            if (is_array($it) && isset($it['index']) && (int) $it['index'] === (int) $index) {
                return !empty($it['has_gps']);
            }
        }
        return false;
    }

    /** First pickup index that has GPS — the primary if it does, else any. */
    private function firstPickupWithGps()
    {
        $fallback = null;
        foreach ($this->pickupCacheList() as $it) {
            if (is_array($it) && !empty($it['has_gps']) && isset($it['index']) && $it['index'] !== null) {
                if (!empty($it['is_primary'])) {
                    return (int) $it['index'];
                }
                if ($fallback === null) {
                    $fallback = (int) $it['index'];
                }
            }
        }
        return $fallback;
    }

    private function pickupCacheList()
    {
        $cache = Configuration::get('INTIGO_PICKUP_CACHE');
        if ($cache === false || trim((string) $cache) === '') {
            return [];
        }
        $list = json_decode((string) $cache, true);
        return is_array($list) ? $list : [];
    }

    /**
     * Default pickup index when no status mapping applies:
     *   INTIGO_DEFAULT_PICKUP_INDEX (if set) → is_primary address from the cached
     *   pickup list → null (omit).
     */
    private function resolveDefaultPickupIndex()
    {
        $configured = Configuration::get('INTIGO_DEFAULT_PICKUP_INDEX');
        if ($configured !== false && trim((string) $configured) !== '' && (int) $configured >= 0) {
            return (int) $configured;
        }
        $cache = Configuration::get('INTIGO_PICKUP_CACHE');
        if ($cache !== false && trim((string) $cache) !== '') {
            $list = json_decode((string) $cache, true);
            if (is_array($list)) {
                foreach ($list as $item) {
                    if (is_array($item) && !empty($item['is_primary'])
                        && isset($item['index']) && $item['index'] !== null) {
                        return (int) $item['index'];
                    }
                }
            }
        }
        return null;
    }

    /* -------------------- Persistence helpers -------------------- */

    private function savePushSuccess(Order $order, array $payload, $nid, $adapter)
    {
        $parcel = IntigoParcel::findByOrderId((int) $order->id) ?: new IntigoParcel();
        $parcel->id_order = (int) $order->id;
        $parcel->nid = (string) $nid;
        $parcel->api_target_used = (string) $adapter;
        $parcel->status_code = 1000; // "Pending pickup" — Intigo's initial state
        $parcel->package_size = (int) $payload['package_size'];
        $parcel->recipient_name = (string) $payload['recipient_name'];
        $parcel->recipient_phone = (string) $payload['phone1'];
        $parcel->destination_address = (string) $payload['destination_address'];
        // Postal-code sends carry no zone IDs (Intigo resolves them server-side) —
        // only overwrite when the payload actually has them, else keep what's stored.
        if (isset($payload['destination_city_id'])) {
            $parcel->destination_city_id = (int) $payload['destination_city_id'];
        }
        if (isset($payload['destination_district_id'])) {
            $parcel->destination_district_id = (int) $payload['destination_district_id'];
        }
        if (isset($payload['destination_neighborhood_id'])) {
            $parcel->destination_neighborhood_id = (int) $payload['destination_neighborhood_id'];
        }
        $parcel->idempotency_hash = md5($this->idempotencyKey($order, 'manual_create'));
        $parcel->sync_locked = 0;
        $parcel->last_error = null;
        $parcel->last_attempt_at = date('Y-m-d H:i:s');
        $parcel->save();
    }

    private function savePushFailure(Order $order, array $payload, $error_message)
    {
        $parcel = IntigoParcel::findByOrderId((int) $order->id) ?: new IntigoParcel();
        $parcel->id_order = (int) $order->id;
        if ($parcel->nid === null) { $parcel->nid = ''; }
        $parcel->package_size = (int) $payload['package_size'];
        $parcel->recipient_name = (string) $payload['recipient_name'];
        $parcel->recipient_phone = (string) $payload['phone1'];
        $parcel->destination_address = (string) $payload['destination_address'];
        // Postal-code payloads carry no zone IDs — keep whatever's stored.
        if (isset($payload['destination_city_id'])) {
            $parcel->destination_city_id = (int) $payload['destination_city_id'];
        }
        if (isset($payload['destination_district_id'])) {
            $parcel->destination_district_id = (int) $payload['destination_district_id'];
        }
        if (isset($payload['destination_neighborhood_id'])) {
            $parcel->destination_neighborhood_id = (int) $payload['destination_neighborhood_id'];
        }
        // NOTE: do NOT set idempotency_hash on failure — that's reserved for
        // successful pushes so future retries aren't blocked by it.
        $parcel->last_error = substr((string) $error_message, 0, 4000);
        $parcel->last_attempt_at = date('Y-m-d H:i:s');
        $parcel->save();
    }

    /* -------------------- Validation / errors -------------------- */

    /**
     * Returns null when the parcel can be sent, or a human-friendly message
     * naming exactly what the merchant still needs to fill in (never raw API
     * field names like "destination_city_id").
     */
    private function validatePayload(array $payload)
    {
        $missing = [];
        if (trim((string) $payload['recipient_name']) === '') {
            $missing[] = 'le nom du destinataire';
        }
        if (trim((string) $payload['phone1']) === '') {
            $missing[] = 'le téléphone';
        }
        if (trim((string) $payload['destination_address']) === '') {
            $missing[] = 'l\'adresse de livraison';
        }
        if ((int) $payload['destination_city_id'] <= 0) {
            $missing[] = 'la ville';
        }
        if ((int) $payload['destination_district_id'] <= 0) {
            $missing[] = 'la délégation';
        }
        if (empty($missing)) {
            return null;
        }
        $last = array_pop($missing);
        $list = $missing ? implode(', ', $missing) . ' et ' . $last : $last;

        return 'Ce colis ne peut pas encore être envoyé — veuillez renseigner ' . $list
            . '. Cliquez sur « Modifier » pour compléter les informations, puis envoyez.';
    }

    private function formatApiError($res)
    {
        if (!is_array($res)) { return 'unknown error'; }
        $parts = [];
        if (isset($res['adapter'])) { $parts[] = 'adapter=' . $res['adapter']; }
        if (isset($res['code'])) { $parts[] = 'http=' . $res['code']; }
        if (!empty($res['url'])) { $parts[] = 'url=' . $res['url']; }
        if (!empty($res['error'])) {
            $parts[] = 'error=' . $res['error'];
        } elseif (!empty($res['data'])) {
            $parts[] = 'response=' . json_encode($res['data']);
        }
        if (!empty($res['legacy_attempt'])) {
            $la = $res['legacy_attempt'];
            $sub = [];
            if (!empty($la['code'])) { $sub[] = 'http=' . $la['code']; }
            if (!empty($la['url'])) { $sub[] = 'url=' . $la['url']; }
            if (!empty($la['error'])) { $sub[] = 'error=' . $la['error']; }
            elseif (!empty($la['data'])) { $sub[] = 'response=' . json_encode($la['data']); }
            if ($sub) { $parts[] = 'legacy(' . implode(' ', $sub) . ')'; }
        }
        return $parts ? implode(' | ', $parts) : 'unknown error';
    }

    /**
     * Detect "parcel is locked at Intigo" errors — same heuristics as the WP plugin.
     */
    private function isParcelLockedError($res)
    {
        if (!is_array($res)) { return false; }
        $status = (int) ($res['code'] ?? 0);
        if ($status !== 400 && $status !== 409) { return false; }
        $detail = '';
        if (isset($res['data']['detail'])) {
            $detail = strtolower((string) $res['data']['detail']);
        } elseif (isset($res['error'])) {
            $detail = strtolower((string) $res['error']);
        }
        if ($detail === '') { return false; }
        return strpos($detail, 'deja livre') !== false
            || strpos($detail, 'déjà livré') !== false
            || strpos($detail, 'en retour') !== false
            || strpos($detail, 'ne peut plus être modifié') !== false
            || strpos($detail, 'ne peut plus etre modifie') !== false;
    }

    private function idempotencyKey(Order $order, $event)
    {
        $shop_id = (int) $order->id_shop ?: 1;
        return sprintf('ps:%d:%d:%s:v1', $shop_id, (int) $order->id, $event);
    }

    private function normalizePhone($phone)
    {
        $digits = preg_replace('/\D+/', '', (string) $phone);
        if ($digits === null) {
            return '';
        }
        if (strpos($digits, '00') === 0) {
            $digits = substr($digits, 2);
        }
        return $digits;
    }

    private function resolveCityIdByName($city_name)
    {
        $res = $this->api->fetchCities($city_name);
        if (!empty($res['ok']) && !empty($res['items'])) {
            // Exact match first, else first hit
            $lower = strtolower(trim($city_name));
            foreach ($res['items'] as $item) {
                if (strtolower((string) $item['name']) === $lower) {
                    return (int) $item['id'];
                }
            }
            return (int) $res['items'][0]['id'];
        }
        return 0;
    }
}
