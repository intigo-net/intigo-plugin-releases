<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Intigo → Aide (Docs). Step-by-step getting-started guide, supported-versions
 * notice, and support contact. Legacy ModuleAdminController — portable 1.7/8/9.
 */
class AdminIntigoDocsController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        $this->display = 'view';
        parent::__construct();
        $this->meta_title = 'Intigo — Aide';
        $this->show_page_header_toolbar = false;
    }

    public function initContent()
    {
        parent::initContent();
        try {
            $this->content = $this->render();
        } catch (Exception $e) {
            IntigoLog::add('docs_error', $e->getMessage());
            $this->content = '<div class="alert alert-warning">Aide indisponible.</div>';
        }
        $this->context->smarty->assign('content', $this->content);
    }

    private function render()
    {
        $settings_url = $this->context->link->getAdminLink('AdminIntigoSettings');
        $orders_url = $this->context->link->getAdminLink('AdminIntigoOrders');
        $sizes_url = $this->context->link->getAdminLink('AdminIntigoProductSizes');

        $steps = [
            ['vpn_key', 'Saisir votre clé API',
                'Ouvrez <a href="' . htmlspecialchars($settings_url) . '">Réglages → Connexion</a>, collez la clé API fournie par Intigo, '
                . 'choisissez l\'environnement (<strong>Sandbox</strong> pour tester, <strong>Production</strong> pour le réel), puis <strong>Enregistrer</strong>. '
                . 'Cliquez sur <strong>Tester la connexion</strong> pour vérifier.'],
            ['straighten', 'Définir les tailles de produits',
                'Dans <a href="' . htmlspecialchars($sizes_url) . '">Tailles produits</a>, assignez une taille (S / M / L / XL) à chaque produit. '
                . 'Les produits sans taille utilisent la <strong>taille par défaut</strong> définie dans les Réglages.'],
            ['payments', 'Définir les tarifs par taille',
                'Dans <a href="' . htmlspecialchars($settings_url) . '">Réglages → Tarif de livraison par taille</a>, saisissez vos tarifs Intigo négociés '
                . 'pour S / M / L / XL. Le transporteur « Intigo Delivery » facture automatiquement selon la taille du colis de la commande.'],
            ['edit_location', 'Compléter la commande',
                'Dans <a href="' . htmlspecialchars($orders_url) . '">Commandes</a>, cliquez sur <strong>Modifier</strong> et renseignez la ville, le district, '
                . 'le destinataire, le téléphone et l\'adresse, puis <strong>Enregistrer</strong>. Le bouton <strong>Envoyer à Intigo</strong> s\'active une fois la ville et le district renseignés.'],
            ['local_shipping', 'Envoyer à Intigo',
                'Cliquez sur <strong>Envoyer à Intigo</strong> : un colis est créé et un numéro de suivi (NID) est retourné. '
                . 'Activez le mode <em>Automatique</em> dans les Réglages pour pousser les commandes payées sans intervention.'],
            ['picture_as_pdf', 'Générer le bordereau',
                'Une fois la commande synchronisée, cliquez sur <strong>Générer le bordereau</strong>, puis <strong>Ouvrir</strong> ou <strong>Copier le lien</strong> pour l\'imprimer.'],
            ['track_changes', 'Suivi client',
                'L\'URL de suivi du transporteur pointe vers l\'application Intigo sur Google Play, où le client suit son colis.'],
        ];

        $h = '<div class="intigo-screen intigo-form">';
        $h .= IntigoAdminUi::navHtml($this->context->link, 'docs');

        $h .= '<div class="card"><div class="card-header"><h3 class="card-header-title">'
            . '<i class="material-icons">menu_book</i> Comment ça marche</h3></div><div class="card-body">';
        foreach ($steps as $i => $s) {
            $h .= '<div style="display:flex; gap:14px; align-items:flex-start; padding:12px 0; border-bottom:1px solid #f0f3f7;">'
                . '<div style="flex:0 0 auto; width:34px; height:34px; border-radius:50%; background:#F47A20; color:#fff; '
                . 'display:flex; align-items:center; justify-content:center; font-weight:700;">' . ($i + 1) . '</div>'
                . '<div style="flex:1 1 auto;"><h4 style="margin:2px 0 4px; color:#1f2a37; font-weight:700;">'
                . '<i class="material-icons" style="font-size:18px; vertical-align:text-bottom; color:#F47A20;">' . $s[0] . '</i> '
                . htmlspecialchars($s[1]) . '</h4><p class="text-muted" style="margin:0;">' . $s[2] . '</p></div></div>';
        }
        $h .= '</div></div>';

        // Supported versions + contact
        $h .= '<div class="card"><div class="card-header"><h3 class="card-header-title">'
            . '<i class="material-icons">verified</i> Versions PrestaShop prises en charge</h3></div><div class="card-body">';
        $h .= '<p>Ce module est testé et compatible avec :</p>';
        $h .= '<ul>'
            . '<li><strong>PrestaShop 1.7.x</strong> (validé sur 1.7.8.11)</li>'
            . '<li><strong>PrestaShop 8.x</strong> (validé sur 8.1)</li>'
            . '<li><strong>PrestaShop 9.x</strong> (validé sur 9.1.3)</li>'
            . '<li><strong>PHP 7.2 à 8.x</strong> (validé sur PHP 7.4.33)</li>'
            . '</ul>';
        $h .= '<div class="alert alert-warning"><strong>Vous utilisez une autre version&nbsp;?</strong> '
            . 'Contactez l\'équipe de développement Intigo avant l\'installation : '
            . '<a href="mailto:hello@intigo.tn">hello@intigo.tn</a>. Nous validerons la compatibilité pour votre version.</div>';
        $h .= '</div></div>';

        // Technical reference
        $h .= '<div class="card"><div class="card-header"><h3 class="card-header-title">'
            . '<i class="material-icons">code</i> Référence technique</h3></div><div class="card-body">';
        $h .= '<ul>'
            . '<li>API Sandbox : <code>https://dev-api.intigo.net/api</code></li>'
            . '<li>API Production : <code>https://api.intigo.net/api</code></li>'
            . '<li>Authentification : en-tête <code>X-API-KEY</code></li>'
            . '<li>Support : <a href="mailto:hello@intigo.tn">hello@intigo.tn</a></li>'
            . '</ul>';
        $h .= '</div></div>';

        $h .= '</div>'; // .intigo-screen

        return $h;
    }
}
