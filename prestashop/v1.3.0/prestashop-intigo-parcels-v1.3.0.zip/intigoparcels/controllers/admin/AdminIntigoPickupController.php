<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Intigo → Pickup addresses (legacy ModuleAdminController — portable 1.7/8/9).
 *
 * "The system is based on status": the merchant maps each Intigo pickup address
 * to a PrestaShop order status. When an order reaches that status, the module
 * sends the address's `index` as `parcel.pickup_index` at push time.
 *
 * Zero-fault rules (PICKUP_STATUS_SPEC §9): the page never crashes — no API key
 * means no network call (it still renders + guides to Settings); an unreachable
 * API falls back to the cached list; every action is wrapped in try/catch.
 */
class AdminIntigoPickupController extends ModuleAdminController
{
    /** @var string[] error message + retained values when a create attempt fails */
    private $createError = '';
    private $createValues = [];
    private $updateError = '';
    private $updateValues = [];

    public function __construct()
    {
        $this->bootstrap = true;
        $this->display = 'view';
        parent::__construct();
        $this->meta_title = 'Intigo — Pickup addresses';
        $this->show_page_header_toolbar = false;
    }

    public function initContent()
    {
        parent::initContent();
        try {
            if (Tools::isSubmit('submitSavePickupMap')) {
                $this->handleSaveMap(); // PRG redirect
            }
            if (Tools::isSubmit('submitCreatePickup')) {
                $this->handleCreate(); // redirects on success; sets error state on failure
            }
            if (Tools::isSubmit('submitUpdatePickup')) {
                $this->handleUpdate(); // redirects on success; sets error state on failure
            }
            $this->content = ((string) Tools::getValue('a') === 'edit')
                ? $this->renderEditPickup()
                : $this->render();
        } catch (Exception $e) {
            IntigoLog::add('pickup_page_error', $e->getMessage());
            $this->content = '<div class="alert alert-warning">'
                . htmlspecialchars(IntigoAdminUi::t('Pickup addresses')) . ' — '
                . 'temporarily unavailable.</div>';
        } catch (\Throwable $e) {
            IntigoLog::add('pickup_page_error', $e->getMessage());
            $this->content = '<div class="alert alert-warning">'
                . htmlspecialchars(IntigoAdminUi::t('Pickup addresses')) . ' — '
                . 'temporarily unavailable.</div>';
        }
        $this->context->smarty->assign('content', $this->content);
    }

    /* -------------------- Actions -------------------- */

    /**
     * Save the status↔address associations + the push-trigger options.
     * Posted: pickup_status[index] => id_order_state, pickup_id[index],
     * pickup_label[index]; intigo_pickup_trigger; intigo_default_pickup_index.
     */
    private function handleSaveMap()
    {
        $id_shop = (int) $this->context->shop->id ?: 1;
        $statuses = Tools::getValue('pickup_status');
        $ids = Tools::getValue('pickup_id');
        $labels = Tools::getValue('pickup_label');
        $statuses = is_array($statuses) ? $statuses : [];
        $ids = is_array($ids) ? $ids : [];
        $labels = is_array($labels) ? $labels : [];

        // Indices visible (selectable) in this form — the only ones this save
        // "manages". Statuses currently pointing at one of these are cleared
        // first, then rebuilt from the POST. Mappings to addresses NOT in the
        // visible list (stale/disappeared) are left untouched (preserved).
        $visible = array_map('intval', array_keys($statuses));
        $map = IntigoPickupMap::getMap($id_shop);
        foreach ($map as $state => $m) {
            if (in_array((int) $m['pickup_index'], $visible, true)) {
                IntigoPickupMap::clearForState($id_shop, (int) $state);
            }
        }

        // Rebuild from the submitted selections. The UNIQUE(id_shop, status) key
        // already guarantees one address per status; we also dedupe statuses so
        // the first address wins deterministically if two rows picked the same.
        $used = [];
        foreach ($statuses as $index => $state) {
            $index = (int) $index;
            $state = (int) $state;
            if ($state <= 0 || isset($used[$state])) {
                continue;
            }
            $id = isset($ids[$index]) ? (int) $ids[$index] : 0;
            $label = isset($labels[$index]) ? (string) $labels[$index] : '';
            IntigoPickupMap::set($id_shop, $state, $index, $id, $label);
            $used[$state] = true;
        }

        // Push-trigger options.
        Configuration::updateValue('INTIGO_PICKUP_AS_TRIGGER', Tools::getValue('intigo_pickup_trigger') ? '1' : '0');
        $default = trim((string) Tools::getValue('intigo_default_pickup_index'));
        Configuration::updateValue('INTIGO_DEFAULT_PICKUP_INDEX', ($default !== '' && (int) $default >= 0) ? (string) (int) $default : '');

        IntigoLog::add('pickup_map_saved', count($used) . ' association(s)');
        $this->redirectBack(IntigoAdminUi::t('Associations saved.'), 'success');
    }

    /**
     * Create a pickup address via POST /v3/pickup-addresses/.
     */
    private function handleCreate()
    {
        $street = trim((string) Tools::getValue('street_address'));
        $city_id = (int) Tools::getValue('city_id');
        $district_id = (int) Tools::getValue('district_id');
        $neighborhood_id = (int) Tools::getValue('neighborhood_id');
        $is_primary = (bool) Tools::getValue('is_primary');
        $lat = trim((string) Tools::getValue('latitude'));
        $lng = trim((string) Tools::getValue('longitude'));

        // Retain values so the form can be re-shown on failure.
        $this->createValues = [
            'street_address' => $street,
            'city_id' => $city_id,
            'district_id' => $district_id,
            'neighborhood_id' => $neighborhood_id,
            'is_primary' => $is_primary,
            'latitude' => $lat,
            'longitude' => $lng,
        ];

        // Client-side validation (the API rejects these too, but fail fast/clear).
        if ($street === '' || $city_id <= 0) {
            $this->createError = IntigoAdminUi::t('Street address') . ' + ' . IntigoAdminUi::t('City') . ' required.';
            return;
        }
        // GPS is MANDATORY: a pickup address with no coordinates makes Intigo
        // reject every parcel collected from it ("Pickup address has no GPS
        // coordinates"). Require both latitude and longitude, and validate ranges.
        if ($lat === '' || $lng === '') {
            $this->createError = 'Les coordonnées GPS (latitude et longitude) sont obligatoires pour créer une adresse de ramassage.';
            return;
        }
        if (!is_numeric($lat) || !is_numeric($lng)
            || (float) $lat < -90 || (float) $lat > 90 || (float) $lng < -180 || (float) $lng > 180) {
            $this->createError = 'Coordonnées GPS invalides (latitude -90..90, longitude -180..180).';
            return;
        }

        $payload = [
            'street_address' => $street,
            'city_id' => $city_id,
            'is_primary' => $is_primary,
        ];
        if ($district_id > 0) {
            $payload['district_id'] = $district_id;
        }
        if ($neighborhood_id > 0) {
            $payload['neighborhood_id'] = $neighborhood_id;
        }
        if ($lat !== '' && $lng !== '') {
            $payload['latitude'] = (float) $lat;
            $payload['longitude'] = (float) $lng;
        }

        $api = new IntigoApiClient();
        $res = $api->createPickupAddress($payload);
        if (!empty($res['ok'])) {
            // Refresh the cache so the new address (and resolution) is up to date.
            $this->refreshCache($api);
            IntigoLog::add('pickup_created', 'city_id=' . $city_id);
            $this->redirectBack(IntigoAdminUi::t('Pickup address created.'), 'success');
        }

        $detail = isset($res['data']['detail']) ? (string) $res['data']['detail']
            : (isset($res['error']) ? (string) $res['error'] : ('http=' . (int) ($res['code'] ?? 0)));
        $this->createError = $detail;
        IntigoLog::add('pickup_create_failed', $detail);
    }

    /**
     * Update an existing pickup address via PATCH /v3/pickup-addresses/{index}.
     * Primary use: add the GPS coordinates to an address that has none (Intigo
     * rejects parcels collected from a coordinate-less pickup). Only the fields
     * provided are sent; the rest (zone, etc.) are preserved.
     */
    private function handleUpdate()
    {
        $index = (int) Tools::getValue('index');
        $street = trim((string) Tools::getValue('street_address'));
        $lat = trim((string) Tools::getValue('latitude'));
        $lng = trim((string) Tools::getValue('longitude'));
        $is_primary = (bool) Tools::getValue('is_primary');
        $current_has_gps = (int) Tools::getValue('current_has_gps') === 1;

        $this->updateValues = [
            'index' => $index, 'street_address' => $street,
            'latitude' => $lat, 'longitude' => $lng, 'is_primary' => $is_primary,
        ];

        if ($index <= 0) {
            $this->updateError = 'Adresse de ramassage introuvable.';
            return;
        }
        if ($street === '') {
            $this->updateError = IntigoAdminUi::t('Street address') . ' requise.';
            return;
        }
        $gps_given = ($lat !== '' || $lng !== '');
        // GPS is required when the address has none yet (the whole point of editing).
        if (!$current_has_gps && !$gps_given) {
            $this->updateError = 'Ajoutez les coordonnées GPS (latitude et longitude) — obligatoires pour cette adresse.';
            return;
        }
        if ($gps_given && ($lat === '' || $lng === '' || !is_numeric($lat) || !is_numeric($lng)
            || (float) $lat < -90 || (float) $lat > 90 || (float) $lng < -180 || (float) $lng > 180)) {
            $this->updateError = 'Coordonnées GPS invalides (latitude -90..90 et longitude -180..180, les deux requises).';
            return;
        }

        $payload = [
            'street_address' => $street,
            'is_primary' => $is_primary,
        ];
        if ($gps_given) {
            $payload['latitude'] = (float) $lat;
            $payload['longitude'] = (float) $lng;
        }

        $api = new IntigoApiClient();
        $res = $api->updatePickupAddress($index, $payload);
        if (!empty($res['ok'])) {
            $this->refreshCache($api);
            IntigoLog::add('pickup_updated', 'index=' . $index . ($gps_given ? ' +gps' : ''));
            $this->redirectBack('Adresse de ramassage mise à jour.', 'success');
        }
        $detail = isset($res['data']['detail']) ? (string) $res['data']['detail']
            : (isset($res['error']) ? (string) $res['error'] : ('http=' . (int) ($res['code'] ?? 0)));
        $this->updateError = $detail;
        IntigoLog::add('pickup_update_failed', 'index=' . $index . ' ' . $detail);
    }

    /* -------------------- Rendering -------------------- */

    /**
     * Edit form for one pickup address — focused on adding/updating GPS. Pre-fills
     * street + primary + current zone (read-only) from the cached list; GPS is
     * required when the address has none. Only changed fields are PATCHed.
     */
    private function renderEditPickup()
    {
        $index = (int) Tools::getValue('index');
        $base_url = self::$currentIndex . '&token=' . $this->token;

        $addr = null;
        foreach ($this->cachedItems() as $it) {
            if (is_array($it) && isset($it['index']) && (int) $it['index'] === $index) {
                $addr = $it;
                break;
            }
        }

        $h = '<div class="intigo-screen">';
        $h .= IntigoAdminUi::navHtml($this->context->link, 'pickup');
        $h .= IntigoAdminUi::noticeToast();

        if (!$addr) {
            $h .= '<div class="alert alert-danger">Adresse de ramassage #' . $index . ' introuvable.</div>'
                . '<a href="' . htmlspecialchars($base_url) . '" class="btn btn-default">← Retour</a></div>';
            return $h;
        }

        $err = $this->updateError !== '';
        $street = $err && isset($this->updateValues['street_address']) ? (string) $this->updateValues['street_address'] : (string) (isset($addr['street_address']) ? $addr['street_address'] : '');
        $lat = $err && isset($this->updateValues['latitude']) ? (string) $this->updateValues['latitude'] : '';
        $lng = $err && isset($this->updateValues['longitude']) ? (string) $this->updateValues['longitude'] : '';
        $is_primary = $err ? !empty($this->updateValues['is_primary']) : !empty($addr['is_primary']);
        $has_gps = !empty($addr['has_gps']);
        $loc = trim((string) (isset($addr['city_name']) ? $addr['city_name'] : '')
            . ((isset($addr['district_name']) && $addr['district_name'] !== '') ? ' / ' . $addr['district_name'] : ''));

        $h .= '<div class="card"><div class="card-header"><h3 class="card-header-title">'
            . '<i class="material-icons">edit_location</i> Modifier l\'adresse de ramassage #' . $index . '</h3></div><div class="card-body">';
        if ($err) {
            $h .= '<div class="alert alert-danger">' . htmlspecialchars($this->updateError) . '</div>';
        }
        $h .= '<form method="post" action="' . htmlspecialchars($base_url . '&a=edit&index=' . $index) . '">';
        $h .= '<input type="hidden" name="index" value="' . $index . '">';
        $h .= '<input type="hidden" name="current_has_gps" value="' . ($has_gps ? 1 : 0) . '">';

        $h .= '<div class="form-group"><label class="control-label">' . htmlspecialchars(IntigoAdminUi::t('Street address')) . ' *</label>'
            . '<input type="text" name="street_address" class="form-control" maxlength="255" required value="' . htmlspecialchars($street) . '"></div>';

        $h .= '<div class="form-group"><label class="control-label">Ville / Délégation</label>'
            . '<p style="padding-top:7px;margin:0;color:#475569;">' . htmlspecialchars($loc !== '' ? $loc : '—')
            . ' <span class="text-muted" style="font-size:12px;">(zone conservée)</span></p></div>';

        $gps_state = $has_gps
            ? '<span class="intigo-badge intigo-badge--success">GPS présent</span> <span class="text-muted" style="font-size:12px;">— laissez vide pour conserver, ou saisissez de nouvelles coordonnées.</span>'
            : '<span class="intigo-badge intigo-badge--danger">GPS manquant</span> <span class="text-muted" style="font-size:12px;">— obligatoire pour expédier depuis cette adresse.</span>';
        $h .= '<div class="form-group"><label class="control-label">Coordonnées GPS' . ($has_gps ? '' : ' <span style="color:#d92d20;">*</span>') . ' '
            . '<button type="button" id="intigo-pk-geo" class="btn btn-default btn-sm" style="margin-left:8px;">'
            . '<i class="material-icons" style="font-size:15px;vertical-align:-3px;">my_location</i> Utiliser ma position</button></label>'
            . '<div style="margin-bottom:8px;">' . $gps_state . '</div>'
            . '<div class="row"><div class="col-md-6">'
            . '<input type="text" name="latitude" id="intigo-pk-lat" class="form-control" placeholder="Latitude (ex : 36.8623)" value="' . htmlspecialchars($lat) . '"></div>'
            . '<div class="col-md-6">'
            . '<input type="text" name="longitude" id="intigo-pk-lng" class="form-control" placeholder="Longitude (ex : 10.1956)" value="' . htmlspecialchars($lng) . '"></div></div>'
            . '<p class="help-block">Astuce : sur Google Maps, faites un clic droit sur le lieu puis copiez les coordonnées affichées.</p></div>';

        $h .= '<div class="form-group"><label class="control-label"><input type="checkbox" name="is_primary" value="1"' . ($is_primary ? ' checked' : '') . '> '
            . htmlspecialchars(IntigoAdminUi::t('Primary pickup address')) . '</label></div>';

        $h .= '<a href="' . htmlspecialchars($base_url) . '" class="btn btn-default">← Retour</a> '
            . '<button type="submit" name="submitUpdatePickup" value="1" class="btn btn-primary">Enregistrer</button>';
        $h .= '</form></div></div>';
        $h .= $this->geolocationScript();
        $h .= '</div>';
        return $h;
    }

    private function render()
    {
        $configured = trim((string) Configuration::get('INTIGO_API_KEY')) !== '';

        $items = [];
        $stale = false;       // showing cache because the live call failed
        $cache_ts = 0;

        if ($configured) {
            $api = new IntigoApiClient();
            $res = $api->listPickupAddresses();
            if (!empty($res['ok'])) {
                $items = $res['items'];
                $this->refreshCache($api, $items);
            } else {
                $items = $this->cachedItems();
                $cache_ts = (int) Configuration::get('INTIGO_PICKUP_CACHE_TS');
                $stale = true;
            }
        }

        $id_shop = (int) $this->context->shop->id ?: 1;
        $id_lang = (int) $this->context->language->id;
        $map = IntigoPickupMap::getMap($id_shop);
        // Reverse index→status for preselecting each address row's selector.
        $index_to_status = [];
        foreach ($map as $state => $m) {
            $index_to_status[(int) $m['pickup_index']] = (int) $state;
        }
        $states = OrderState::getOrderStates($id_lang);
        $states = is_array($states) ? $states : [];

        $base_url = self::$currentIndex . '&token=' . $this->token;

        $h = '<div class="intigo-screen">';
        $h .= IntigoAdminUi::navHtml($this->context->link, 'pickup');
        $h .= IntigoAdminUi::noticeToast();

        // ---- Block A: status banner ----
        if (!$configured) {
            $h .= '<div class="alert alert-warning">'
                . htmlspecialchars(IntigoAdminUi::t('Configure your API key first in Settings.'))
                . ' <a href="' . htmlspecialchars($this->context->link->getAdminLink('AdminIntigoSettings')) . '">'
                . htmlspecialchars(IntigoAdminUi::t('Go to Settings')) . '</a></div>';
        } elseif ($stale) {
            $when = $cache_ts > 0 ? date('Y-m-d H:i', $cache_ts) : '—';
            $h .= '<div class="alert alert-warning">'
                . htmlspecialchars(IntigoAdminUi::t('Unable to reach Intigo — showing cached data.'))
                . ' (' . htmlspecialchars(IntigoAdminUi::t('last sync')) . ': ' . $when . ')</div>';
        }

        // ---- Block B: addresses + status associations ----
        $h .= '<div class="card"><div class="card-header"><h3 class="card-header-title">'
            . '<i class="material-icons">place</i> ' . htmlspecialchars(IntigoAdminUi::t('Your pickup addresses'))
            . ' (' . count($items) . ')</h3></div><div class="card-body">';

        if (empty($items)) {
            $h .= IntigoAdminUi::emptyState(
                'place',
                'No pickup addresses yet',
                'Create your first pickup address below — the courier collects parcels from it.'
            );
        } else {
            $h .= '<form method="post" action="' . htmlspecialchars($base_url) . '">';
            $h .= '<table class="table"><thead><tr>'
                . '<th>' . htmlspecialchars(IntigoAdminUi::t('Address')) . '</th>'
                . '<th>' . htmlspecialchars(IntigoAdminUi::t('City / District')) . '</th>'
                . '<th>' . htmlspecialchars(IntigoAdminUi::t('GPS')) . '</th>'
                . '<th>' . htmlspecialchars(IntigoAdminUi::t('Index')) . '</th>'
                . '<th style="min-width:220px;">' . htmlspecialchars(IntigoAdminUi::t('Linked status')) . '</th>'
                . '<th>' . htmlspecialchars(IntigoAdminUi::t('Actions')) . '</th>'
                . '</tr></thead><tbody>';

            foreach ($items as $it) {
                $index = $it['index']; // may be null → unselectable
                $loc = trim((string) $it['city_name'] . (($it['district_name'] !== '') ? ' / ' . $it['district_name'] : ''));
                $gps = !empty($it['has_gps'])
                    ? '<span style="color:#16a34a;">&#10004;</span>'
                    : '<span class="intigo-badge intigo-badge--danger">Manquant</span>';

                $h .= '<tr>';
                $h .= '<td>' . htmlspecialchars((string) $it['street_address']);
                if (!empty($it['is_primary'])) {
                    $h .= ' <span class="badge badge-info">' . htmlspecialchars(IntigoAdminUi::t('Primary pickup address')) . '</span>';
                }
                $h .= '</td>';
                $h .= '<td>' . htmlspecialchars($loc) . '</td>';
                $h .= '<td>' . $gps . '</td>';

                if ($index === null) {
                    $h .= '<td><span class="badge badge-secondary" title="'
                        . htmlspecialchars(IntigoAdminUi::t('This address has no usable index; contact Intigo.')) . '">'
                        . htmlspecialchars(IntigoAdminUi::t('not available')) . '</span></td>';
                    $h .= '<td><select class="form-control" disabled><option>'
                        . htmlspecialchars(IntigoAdminUi::t('None')) . '</option></select></td>';
                } else {
                    $index = (int) $index;
                    $cur = isset($index_to_status[$index]) ? (int) $index_to_status[$index] : 0;
                    $h .= '<td><span class="intigo-ix">#' . $index . '</span></td>';
                    $h .= '<td>'
                        . '<input type="hidden" name="pickup_id[' . $index . ']" value="' . (int) $it['id'] . '">'
                        . '<input type="hidden" name="pickup_label[' . $index . ']" value="' . htmlspecialchars(trim((string) $it['street_address'] . ' ' . (string) $it['city_name'])) . '">'
                        . '<select name="pickup_status[' . $index . ']" class="form-control intigo-pk-status">';
                    $h .= '<option value="0">' . htmlspecialchars(IntigoAdminUi::t('None')) . '</option>';
                    foreach ($states as $st) {
                        $sid = (int) $st['id_order_state'];
                        $sel = ($sid === $cur) ? ' selected' : '';
                        $h .= '<option value="' . $sid . '"' . $sel . '>' . htmlspecialchars((string) $st['name']) . '</option>';
                    }
                    $h .= '</select></td>';
                }
                // Actions: edit the address — prominent "Ajouter le GPS" when missing.
                if ($index !== null) {
                    $eu = $base_url . '&a=edit&index=' . (int) $index;
                    $action_cell = empty($it['has_gps'])
                        ? '<a href="' . $eu . '" class="btn btn-sm btn-warning"><i class="material-icons intigo-bi">add_location</i> Ajouter le GPS</a>'
                        : '<a href="' . $eu . '" class="btn btn-sm btn-default"><i class="material-icons intigo-bi">edit</i> ' . htmlspecialchars(IntigoAdminUi::t('Edit')) . '</a>';
                } else {
                    $action_cell = '<span class="text-muted">—</span>';
                }
                $h .= '<td style="white-space:nowrap;">' . $action_cell . '</td>';
                $h .= '</tr>';
            }
            $h .= '</tbody></table>';

            // Push-trigger options.
            $trigger_on = (string) Configuration::get('INTIGO_PICKUP_AS_TRIGGER') === '1';
            $default_index = (string) Configuration::get('INTIGO_DEFAULT_PICKUP_INDEX');
            $h .= '<div class="form-group" style="margin-top:8px;">'
                . '<label class="control-label"><input type="checkbox" name="intigo_pickup_trigger" value="1"' . ($trigger_on ? ' checked' : '') . '> '
                . htmlspecialchars(IntigoAdminUi::t('Use a mapped status as an automatic push trigger')) . '</label>'
                . '<p class="help-block">' . htmlspecialchars(IntigoAdminUi::t('When ON, moving an order to a mapped status pushes its parcel automatically (with the matching pickup).')) . '</p>'
                . '</div>';

            $h .= '<button type="submit" name="submitSavePickupMap" value="1" class="btn btn-primary">'
                . htmlspecialchars(IntigoAdminUi::t('Save associations')) . '</button>';
            $h .= '</form>';

            // JS: a status can only be linked to one address (mirror the unique key).
            $h .= $this->uniquenessScript();
        }
        $h .= '</div></div>'; // end card B

        // ---- Block C: create address ----
        if ($configured) {
            $h .= $this->renderCreateForm($base_url);
        }

        $h .= '</div>'; // end intigo-screen
        return $h;
    }

    private function renderCreateForm($base_url)
    {
        $v = $this->createValues;
        $street = isset($v['street_address']) ? (string) $v['street_address'] : '';
        $lat = isset($v['latitude']) ? (string) $v['latitude'] : '';
        $lng = isset($v['longitude']) ? (string) $v['longitude'] : '';
        $is_primary = !empty($v['is_primary']);

        $regions_url = $this->context->link->getModuleLink(
            'intigoparcels',
            'regions',
            ['action' => 'cities'],
            true
        );

        $h = '<div class="card" style="margin-top:16px;"><div class="card-header"><h3 class="card-header-title">'
            . '<i class="material-icons">add_location</i> ' . htmlspecialchars(IntigoAdminUi::t('Add a pickup address'))
            . '</h3></div><div class="card-body">';

        if ($this->createError !== '') {
            $h .= '<div class="alert alert-danger">' . htmlspecialchars($this->createError) . '</div>';
        }

        $h .= '<form method="post" action="' . htmlspecialchars($base_url) . '" class="intigo-pk-create">';

        $h .= '<div class="form-group"><label class="control-label">' . htmlspecialchars(IntigoAdminUi::t('Street address')) . ' *</label>'
            . '<input type="text" name="street_address" class="form-control" maxlength="255" required value="' . htmlspecialchars($street) . '"></div>';

        $h .= '<div class="form-group"><label class="control-label">' . htmlspecialchars(IntigoAdminUi::t('City')) . ' *</label>'
            . '<select name="city_id" id="intigo-pk-city" class="form-control" required>'
            . '<option value="">' . htmlspecialchars(IntigoAdminUi::t('Select a city')) . '</option></select></div>';

        $h .= '<div class="form-group"><label class="control-label">' . htmlspecialchars(IntigoAdminUi::t('District')) . '</label>'
            . '<select name="district_id" id="intigo-pk-district" class="form-control">'
            . '<option value="">—</option></select></div>';

        $h .= '<div class="form-group"><label class="control-label">' . htmlspecialchars(IntigoAdminUi::t('Neighborhood')) . ' <span class="text-muted">(' . htmlspecialchars(IntigoAdminUi::t('Optional')) . ')</span></label>'
            . '<select name="neighborhood_id" id="intigo-pk-neighborhood" class="form-control">'
            . '<option value="">—</option></select></div>';

        $h .= '<div class="form-group"><label class="control-label">Coordonnées GPS <span style="color:#d92d20;">*</span> '
            . '<button type="button" id="intigo-pk-geo" class="btn btn-default btn-sm" style="margin-left:8px;">'
            . '<i class="material-icons" style="font-size:15px;vertical-align:-3px;">my_location</i> Utiliser ma position</button></label>'
            . '<div class="row"><div class="col-md-6">'
            . '<input type="text" name="latitude" id="intigo-pk-lat" class="form-control" required placeholder="Latitude (ex : 36.8623)" value="' . htmlspecialchars($lat) . '"></div>'
            . '<div class="col-md-6">'
            . '<input type="text" name="longitude" id="intigo-pk-lng" class="form-control" required placeholder="Longitude (ex : 10.1956)" value="' . htmlspecialchars($lng) . '"></div></div>'
            . '<p class="help-block" style="margin-top:6px;">Obligatoire — sans GPS, Intigo refuse les colis collectés depuis cette adresse. '
            . 'Astuce : sur Google Maps, faites un clic droit sur le lieu puis copiez les coordonnées affichées.</p></div>';

        $h .= '<div class="form-group"><label class="control-label"><input type="checkbox" name="is_primary" value="1"' . ($is_primary ? ' checked' : '') . '> '
            . htmlspecialchars(IntigoAdminUi::t('Primary pickup address')) . '</label></div>';

        $h .= '<button type="submit" name="submitCreatePickup" value="1" class="btn btn-primary">'
            . htmlspecialchars(IntigoAdminUi::t('Create address')) . '</button>';
        $h .= '</form>';

        // Cascading city → district → neighborhood selects, populated via the
        // existing regions AJAX endpoint (same one the order panel uses).
        $h .= $this->cascadeScript($regions_url, (int) (isset($v['city_id']) ? $v['city_id'] : 0), (int) (isset($v['district_id']) ? $v['district_id'] : 0));

        // "Use my location" → fill the GPS fields from the browser geolocation.
        $h .= '<script>(function(){var b=document.getElementById("intigo-pk-geo");'
            . 'if(!b)return;if(!navigator.geolocation){b.style.display="none";return;}'
            . 'b.addEventListener("click",function(){var o=b.innerHTML;b.disabled=true;b.textContent="Localisation…";'
            . 'navigator.geolocation.getCurrentPosition(function(p){'
            . 'document.getElementById("intigo-pk-lat").value=p.coords.latitude.toFixed(6);'
            . 'document.getElementById("intigo-pk-lng").value=p.coords.longitude.toFixed(6);'
            . 'b.disabled=false;b.innerHTML=o;},function(){b.disabled=false;b.innerHTML=o;'
            . 'alert("Impossible d\'obtenir votre position. Saisissez les coordonnées manuellement.");},'
            . '{enableHighAccuracy:true,timeout:10000});});})();</script>';

        $h .= '</div></div>';
        return $h;
    }

    /* -------------------- JS helpers -------------------- */

    /** "Use my location" → fill #intigo-pk-lat / #intigo-pk-lng from geolocation. */
    private function geolocationScript()
    {
        return '<script>(function(){var b=document.getElementById("intigo-pk-geo");'
            . 'if(!b)return;if(!navigator.geolocation){b.style.display="none";return;}'
            . 'b.addEventListener("click",function(){var o=b.innerHTML;b.disabled=true;b.textContent="Localisation…";'
            . 'navigator.geolocation.getCurrentPosition(function(p){'
            . 'document.getElementById("intigo-pk-lat").value=p.coords.latitude.toFixed(6);'
            . 'document.getElementById("intigo-pk-lng").value=p.coords.longitude.toFixed(6);'
            . 'b.disabled=false;b.innerHTML=o;},function(){b.disabled=false;b.innerHTML=o;'
            . 'alert("Impossible d\'obtenir votre position. Saisissez les coordonnées manuellement.");},'
            . '{enableHighAccuracy:true,timeout:10000});});})();</script>';
    }

    private function uniquenessScript()
    {
        return '<script>(function(){'
            . 'var sels=document.querySelectorAll(".intigo-pk-status");'
            . 'function sync(){var used={};sels.forEach(function(s){if(s.value!=="0")used[s.value]=s;});'
            . 'sels.forEach(function(s){Array.prototype.forEach.call(s.options,function(o){'
            . 'if(o.value!=="0"){o.disabled=(used[o.value]&&used[o.value]!==s);}});});}'
            . 'sels.forEach(function(s){s.addEventListener("change",sync);});sync();'
            . '})();</script>';
    }

    private function cascadeScript($regions_url, $sel_city, $sel_district)
    {
        // regions_url already targets action=cities; swap the action param for
        // districts/neighborhoods. Build a base without the action query.
        $base = preg_replace('/([?&])action=[^&]*/', '$1', $regions_url);
        $base = rtrim($base, '?&');
        $sep = (strpos($base, '?') !== false) ? '&' : '?';

        return '<script>(function(){'
            . 'var base=' . json_encode($base) . ';var sep=' . json_encode($sep) . ';'
            . 'var selCity=' . (int) $sel_city . ',selDist=' . (int) $sel_district . ';'
            . 'var city=document.getElementById("intigo-pk-city");'
            . 'var dist=document.getElementById("intigo-pk-district");'
            . 'var nb=document.getElementById("intigo-pk-neighborhood");'
            . 'if(!city)return;'
            . 'function fill(sel,items,placeholder,selected){sel.innerHTML="";'
            . 'var o0=document.createElement("option");o0.value="";o0.textContent=placeholder;sel.appendChild(o0);'
            . 'items.forEach(function(it){var o=document.createElement("option");o.value=it.id;o.textContent=it.name;'
            . 'if(selected&&parseInt(it.id,10)===selected)o.selected=true;sel.appendChild(o);});}'
            . 'function load(action,extra,cb){var url=base+sep+"action="+action+extra;'
            . 'fetch(url,{credentials:"same-origin"}).then(function(r){return r.json();}).then(function(d){cb((d&&d.items)||[]);}).catch(function(){cb([]);});}'
            . 'load("cities","",function(items){fill(city,items,"—",selCity);if(selCity)loadDistricts(selCity,selDist);});'
            . 'function loadDistricts(cityId,sd){if(!cityId){fill(dist,[],"—");fill(nb,[],"—");return;}'
            . 'load("districts","&city_id="+cityId,function(items){fill(dist,items,"—",sd);if(sd)loadNb(sd);});}'
            . 'function loadNb(distId){if(!distId){fill(nb,[],"—");return;}load("neighborhoods","&district_id="+distId,function(items){fill(nb,items,"—",0);});}'
            . 'city.addEventListener("change",function(){fill(nb,[],"—");loadDistricts(parseInt(city.value,10)||0,0);});'
            . 'dist.addEventListener("change",function(){loadNb(parseInt(dist.value,10)||0);});'
            . '})();</script>';
    }

    /* -------------------- Cache -------------------- */

    private function refreshCache(IntigoApiClient $api, $items = null)
    {
        if ($items === null) {
            $res = $api->listPickupAddresses();
            if (empty($res['ok'])) {
                return;
            }
            $items = $res['items'];
        }
        Configuration::updateValue('INTIGO_PICKUP_CACHE', json_encode($items));
        Configuration::updateValue('INTIGO_PICKUP_CACHE_TS', (string) time());
    }

    private function cachedItems()
    {
        $raw = Configuration::get('INTIGO_PICKUP_CACHE');
        if ($raw === false || trim((string) $raw) === '') {
            return [];
        }
        $list = json_decode((string) $raw, true);
        return is_array($list) ? $list : [];
    }

    private function redirectBack($message, $type = 'success')
    {
        Tools::redirectAdmin(
            self::$currentIndex . '&token=' . $this->token
            . '&intigo_notice=' . rawurlencode((string) $message)
            . '&intigo_notice_type=' . rawurlencode((string) $type)
        );
    }
}
