<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Intigo → Product Sizes (legacy ModuleAdminController — portable 1.7/8/9).
 * The partner assigns each product's Intigo delivery size (S/M/L/XL). This is
 * layer 2 of the size waterfall and drives the carrier's per-size price.
 */
class AdminIntigoProductSizesController extends ModuleAdminController
{
    const PER_PAGE = 50;

    public function __construct()
    {
        $this->bootstrap = true;
        $this->display = 'view';
        parent::__construct();
        $this->meta_title = 'Intigo — Product Sizes';
        $this->show_page_header_toolbar = false;
    }

    public function initContent()
    {
        parent::initContent();
        try {
            if (Tools::isSubmit('submitIntigoSizes')) {
                $this->handleSave();
            }
            $this->content = $this->render();
        } catch (Exception $e) {
            IntigoLog::add('product_sizes_error', $e->getMessage());
            $this->content = '<div class="alert alert-warning">Product sizes are temporarily unavailable.</div>';
        }
        $this->context->smarty->assign('content', $this->content);
    }

    private function handleSave()
    {
        $sizes = Tools::getValue('size');
        $n = 0;
        if (is_array($sizes)) {
            foreach ($sizes as $id_product => $letter) {
                $letter = strtoupper(trim((string) $letter));
                // '' clears the override (falls back to default size).
                if ($letter !== '' && !in_array($letter, ['S', 'M', 'L', 'XL'], true)) {
                    continue;
                }
                IntigoProductSize::setForProduct((int) $id_product, $letter);
                $n++;
            }
        }
        $q = (string) Tools::getValue('q');
        $p = (int) Tools::getValue('p', 1);
        Tools::redirectAdmin(
            self::$currentIndex . '&token=' . $this->token
            . ($q !== '' ? '&q=' . rawurlencode($q) : '')
            . ($p > 1 ? '&p=' . $p : '')
            . '&intigo_notice=' . rawurlencode($n . ' product size(s) saved.') . '&intigo_notice_type=success'
        );
    }

    private function render()
    {
        $db = Db::getInstance();
        $pfx = _DB_PREFIX_;
        $id_lang = (int) $this->context->language->id;
        $q = trim((string) Tools::getValue('q'));
        $page = max(1, (int) Tools::getValue('p', 1));
        $offset = ($page - 1) * self::PER_PAGE;

        $where = 'pl.id_lang = ' . $id_lang;
        if ($q !== '') {
            $qs = pSQL($q);
            $where .= ' AND (pl.name LIKE "%' . $qs . '%" OR p.reference LIKE "%' . $qs . '%")';
        }

        $total = (int) $db->getValue(
            'SELECT COUNT(DISTINCT p.id_product) FROM `' . $pfx . 'product` p
             JOIN `' . $pfx . 'product_lang` pl ON pl.id_product = p.id_product
             WHERE ' . $where
        );
        $pages = max(1, (int) ceil($total / self::PER_PAGE));

        $rows = $db->executeS(
            'SELECT p.id_product, p.reference, pl.name
             FROM `' . $pfx . 'product` p
             JOIN `' . $pfx . 'product_lang` pl ON pl.id_product = p.id_product
             WHERE ' . $where . '
             GROUP BY p.id_product
             ORDER BY p.id_product DESC
             LIMIT ' . self::PER_PAGE . ' OFFSET ' . $offset
        );
        $rows = is_array($rows) ? $rows : [];

        $ids = array_map(function ($r) { return (int) $r['id_product']; }, $rows);
        $current = IntigoProductSize::getForProducts($ids);
        $default = IntigoSizeResolver::pluginDefault();

        $base_url = self::$currentIndex . '&token=' . $this->token;
        $action = $base_url;
        $notice = (string) Tools::getValue('intigo_notice');
        $ntype = (string) Tools::getValue('intigo_notice_type');
        $alert = $ntype === 'success' ? 'success' : ($ntype === 'error' ? 'danger' : 'info');

        $h = '<div class="intigo-screen">';
        $h .= IntigoAdminUi::navHtml($this->context->link, 'product_sizes');
        $h .= IntigoAdminUi::noticeToast();

        $h .= '<div class="card"><div class="card-header"><h3 class="card-header-title">'
            . '<i class="material-icons">straighten</i> Product Sizes (' . $total . ')</h3></div><div class="card-body">';

        // Search (GET)
        $h .= '<form method="get" class="form-inline" style="margin-bottom:12px;">';
        foreach (['controller' => 'AdminIntigoProductSizes', 'token' => $this->token] as $k => $v) {
            $h .= '<input type="hidden" name="' . $k . '" value="' . htmlspecialchars($v) . '">';
        }
        $h .= '<input type="text" name="q" class="form-control" placeholder="Search product name or reference" value="' . htmlspecialchars($q) . '" style="min-width:280px;"> ';
        $h .= '<button type="submit" class="btn btn-default">Search</button>';
        if ($q !== '') {
            $h .= ' <a href="' . $base_url . '" class="btn btn-link">Clear</a>';
        }
        $h .= '</form>';

        if (empty($rows)) {
            $h .= IntigoAdminUi::emptyState('inventory', 'No products found', 'Add products to your catalog, or adjust your search.');
            $h .= '</div></div></div>';
            return $h;
        }

        // Sizes (POST)
        $h .= '<form method="post" action="' . htmlspecialchars($action) . '">';
        $h .= '<input type="hidden" name="q" value="' . htmlspecialchars($q) . '">';
        $h .= '<input type="hidden" name="p" value="' . $page . '">';
        $h .= '<table class="table"><thead><tr><th>#</th><th>Reference</th><th>Product</th><th style="width:200px;">Intigo size</th></tr></thead><tbody>';
        $opts = ['' => '— default (' . $default . ') —', 'S' => 'S', 'M' => 'M', 'L' => 'L', 'XL' => 'XL'];
        foreach ($rows as $r) {
            $id = (int) $r['id_product'];
            $cur = isset($current[$id]) ? $current[$id] : '';
            $h .= '<tr><td>' . $id . '</td>'
                . '<td><code>' . htmlspecialchars((string) $r['reference']) . '</code></td>'
                . '<td>' . htmlspecialchars((string) $r['name']) . '</td>'
                . '<td><select name="size[' . $id . ']" class="form-control">';
            foreach ($opts as $val => $label) {
                $sel = ((string) $cur === (string) $val) ? ' selected' : '';
                $h .= '<option value="' . $val . '"' . $sel . '>' . htmlspecialchars($label) . '</option>';
            }
            $h .= '</select></td></tr>';
        }
        $h .= '</tbody></table>';
        $h .= '<button type="submit" name="submitIntigoSizes" value="1" class="btn btn-primary">Save sizes</button>';
        $h .= '</form>';

        if ($pages > 1) {
            $h .= '<ul class="pagination" style="margin-top:12px;">';
            for ($i = 1; $i <= $pages; $i++) {
                $url = $base_url . ($q !== '' ? '&q=' . rawurlencode($q) : '') . '&p=' . $i;
                $cls = $i === $page ? ' class="active"' : '';
                $h .= '<li' . $cls . '><a href="' . htmlspecialchars($url) . '">' . $i . '</a></li>';
            }
            $h .= '</ul>';
        }

        $h .= '</div></div></div>';
        return $h;
    }
}
