{*
 * Intigo parcel panel shown inside PrestaShop's order view.
 * UX: when a parcel already exists, all fields are LOCKED (read-only) behind a
 * "Modifier" button; clicking it unlocks every stored field for editing. All
 * copy is plain French for non-technical merchants.
 *}
{* Asset loading is embedded here (not via hookActionAdminControllerSetMedia)
   because the order view runs as a Symfony controller on PS 1.7.8/8/9, where
   that media hook doesn't match — embedding guarantees the panel is styled and
   the Modifier/cascading-dropdowns JS runs on every version. *}
<link rel="stylesheet" href="{$intigo_module_uri|escape:'html':'UTF-8'}views/css/admin-order.css?v={$intigo_asset_v|escape:'html':'UTF-8'}">
<div class="card mb-3 intigo-panel{if $intigo_has_nid} intigo-locked{/if}" id="intigo-order-side"
     data-regions-url="{$intigo_regions_url|escape:'html':'UTF-8'}"
     data-has-nid="{if $intigo_has_nid}1{else}0{/if}">

    <div class="card-header intigo-panel-header">
        <h3 class="card-header-title">
            <i class="material-icons">local_shipping</i> Colis Intigo
        </h3>
        {if $intigo_has_nid}
            <span class="intigo-badge intigo-badge--status">{$intigo_status_label|escape:'html':'UTF-8'}</span>
        {/if}
    </div>

    <div class="card-body">

        {if $intigo_notice}
            <div class="intigo-toast intigo-toast--{if $intigo_notice_type == 'error'}error{elseif $intigo_notice_type == 'warning'}warn{else}ok{/if}" id="intigo-order-toast">
                <i class="material-icons">{if $intigo_notice_type == 'error'}error{elseif $intigo_notice_type == 'warning'}warning{else}check_circle{/if}</i>
                <span>{$intigo_notice|escape:'html':'UTF-8'}</span>
            </div>
        {/if}

        {if !$intigo_is_intigo_carrier}
            <p class="intigo-hint">
                <i class="material-icons">info</i>
                Cette commande n'utilise pas le transporteur Intigo, mais vous pouvez quand même
                l'expédier&nbsp;: complétez les informations ci-dessous puis envoyez.
            </p>
        {/if}

        {if $intigo_has_nid}
            {* Parcel created: show a clean confirmation banner. *}
            <div class="intigo-state intigo-state--ok">
                <i class="material-icons">check_circle</i>
                <div>
                    <strong>Colis créé chez Intigo.</strong>
                    <div class="intigo-state-meta">
                        Numéro de suivi&nbsp;: <code>{$intigo_parcel->nid|escape:'html':'UTF-8'}</code>
                    </div>
                    {if $intigo_parcel->bordereau_url}
                        <a href="{$intigo_parcel->bordereau_url|escape:'html':'UTF-8'}" target="_blank" class="intigo-link">
                            <i class="material-icons">receipt</i> Voir le bordereau (PDF)
                        </a>
                    {/if}
                </div>
            </div>
            <p class="intigo-hint intigo-hint--edit">
                <i class="material-icons">lock</i>
                Ces informations sont verrouillées. Cliquez sur <strong>Modifier</strong> pour les changer.
            </p>
        {elseif $intigo_parcel && $intigo_parcel->last_error}
            <div class="intigo-state intigo-state--error">
                <i class="material-icons">error</i>
                <div>
                    <strong>Le dernier envoi a échoué.</strong>
                    <div class="intigo-state-meta">Corrigez les informations puis renvoyez.</div>
                </div>
            </div>
        {else}
            <p class="intigo-hint">
                <i class="material-icons">edit</i>
                Aucun colis n'a encore été créé. Complétez les informations puis cliquez sur
                <strong>Envoyer à Intigo</strong>.
            </p>
        {/if}

        <form method="post" action="{$intigo_action_url|escape:'html':'UTF-8'}" class="intigo-order-form">
            <input type="hidden" name="id_order" value="{$intigo_order_id|intval}">

            <div class="form-group">
                <label>Référence <span class="intigo-opt">(votre numéro interne)</span></label>
                <input type="text" name="reference_id" class="form-control intigo-field"
                       placeholder="Ex : CMD-1024"
                       value="{$intigo_form.reference_id|escape:'html':'UTF-8'}"{if $intigo_has_nid} disabled{/if}>
                <small class="intigo-help">Apparaît sur le bordereau Intigo (section « Commentaire »).</small>
            </div>

            <div class="form-group">
                <label>Nom du destinataire <span class="intigo-req">*</span></label>
                <input type="text" name="recipient_name" class="form-control intigo-field"
                       value="{$intigo_form.recipient_name|escape:'html':'UTF-8'}"{if $intigo_has_nid} disabled{/if}>
            </div>

            <div class="form-group">
                <label>Téléphone <span class="intigo-req">*</span></label>
                <input type="tel" name="recipient_phone" class="form-control intigo-field"
                       value="{$intigo_form.recipient_phone|escape:'html':'UTF-8'}"{if $intigo_has_nid} disabled{/if}>
            </div>

            <div class="form-group">
                <label>Adresse de livraison <span class="intigo-req">*</span></label>
                <textarea name="destination_address" class="form-control intigo-field" rows="2"{if $intigo_has_nid} disabled{/if}>{$intigo_form.destination_address|escape:'html':'UTF-8'}</textarea>
            </div>

            <div class="form-group">
                <label>Ville <span class="intigo-req">*</span></label>
                <select name="destination_city_id" class="form-control intigo-field intigo-city"
                        data-selected="{$intigo_form.destination_city_id|intval}"{if $intigo_has_nid} disabled{/if}>
                    <option value="">— choisir une ville —</option>
                </select>
            </div>

            <div class="form-group">
                <label>Délégation <span class="intigo-req">*</span></label>
                <select name="destination_district_id" class="form-control intigo-field intigo-district"
                        data-selected="{$intigo_form.destination_district_id|intval}"{if $intigo_has_nid} disabled{/if}>
                    <option value="">— choisir d'abord une ville —</option>
                </select>
            </div>

            <div class="form-group">
                <label>Cité <span class="intigo-opt">(facultatif)</span></label>
                <select name="destination_neighborhood_id" class="form-control intigo-field intigo-neighborhood"
                        data-selected="{$intigo_form.destination_neighborhood_id|intval}"{if $intigo_has_nid} disabled{/if}>
                    <option value="">— facultatif —</option>
                </select>
            </div>

            <div class="form-group">
                <label>Taille du colis</label>
                <select name="package_size" class="form-control intigo-field"{if $intigo_has_nid} disabled{/if}>
                    {foreach from=$intigo_sizes key=code item=letter}
                        <option value="{$code}" {if $intigo_form.package_size == $code}selected{/if}>{$letter}</option>
                    {/foreach}
                </select>
            </div>

            {if !$intigo_can_push && !$intigo_has_nid}
                <div class="intigo-state intigo-state--warn">
                    <i class="material-icons">warning</i>
                    <div>
                        <strong>À compléter avant l'envoi&nbsp;:</strong> {$intigo_missing|escape:'html':'UTF-8'}.
                        <div class="intigo-state-meta">Vous pouvez <em>Enregistrer</em> maintenant et finir plus tard.</div>
                    </div>
                </div>
            {/if}

            <div class="intigo-actions">
                {if $intigo_has_nid}
                    {* Locked parcel: Modifier unlocks all fields, then Save updates Intigo. *}
                    <button type="button" class="btn btn-primary btn-sm intigo-edit-btn">
                        <i class="material-icons">edit</i> Modifier
                    </button>
                    <button type="submit" name="intigo_action" value="save_update" class="btn btn-primary btn-sm intigo-save-btn" style="display:none;">
                        <i class="material-icons">save</i> Enregistrer les modifications
                    </button>
                    <button type="button" class="btn btn-default btn-sm intigo-cancel-edit-btn" style="display:none;">
                        Annuler
                    </button>
                    <button type="submit" name="intigo_action" value="bordereau" class="btn btn-default btn-sm intigo-locked-action">
                        <i class="material-icons">receipt</i> Bordereau
                    </button>
                    <button type="submit" name="intigo_action" value="cancel" class="btn btn-link btn-sm intigo-danger intigo-locked-action"
                            onclick="return confirm('Annuler ce colis chez Intigo ? Cette action est définitive.');">
                        <i class="material-icons">cancel</i> Annuler le colis
                    </button>
                {else}
                    <button type="submit" name="intigo_action" value="save" class="btn btn-default btn-sm">
                        <i class="material-icons">save</i> Enregistrer
                    </button>
                    <button type="submit" name="intigo_action" value="save_push" class="btn btn-success btn-sm"{if !$intigo_can_push} disabled{/if}>
                        <i class="material-icons">send</i> Envoyer à Intigo
                    </button>
                {/if}
            </div>
        </form>
    </div>
</div>
<script src="{$intigo_module_uri|escape:'html':'UTF-8'}views/js/admin-order.js?v={$intigo_asset_v|escape:'html':'UTF-8'}"></script>
