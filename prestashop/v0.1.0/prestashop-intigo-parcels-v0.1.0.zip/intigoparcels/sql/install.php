<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

$sql = [];

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'intigo_parcel` (
    `id_order` INT UNSIGNED NOT NULL,
    `nid` VARCHAR(64) NOT NULL DEFAULT \'\',
    `status_code` INT NOT NULL DEFAULT 0,
    `package_size` TINYINT UNSIGNED NOT NULL DEFAULT 1,
    `recipient_name` VARCHAR(190) NOT NULL DEFAULT \'\',
    `recipient_phone` VARCHAR(32) NOT NULL DEFAULT \'\',
    `destination_address` TEXT NOT NULL,
    `destination_city_id` INT UNSIGNED NOT NULL DEFAULT 0,
    `destination_district_id` INT UNSIGNED NOT NULL DEFAULT 0,
    `destination_neighborhood_id` INT UNSIGNED NOT NULL DEFAULT 0,
    `bordereau_url` VARCHAR(512) NOT NULL DEFAULT \'\',
    `idempotency_hash` CHAR(32) NOT NULL DEFAULT \'\',
    `api_target_used` VARCHAR(16) NOT NULL DEFAULT \'\',
    `sync_locked` TINYINT(1) NOT NULL DEFAULT 0,
    `last_error` TEXT NULL,
    `last_attempt_at` DATETIME NULL,
    `last_sync_at` DATETIME NULL,
    `created_at` DATETIME NOT NULL,
    `updated_at` DATETIME NOT NULL,
    PRIMARY KEY (`id_order`),
    KEY `nid` (`nid`),
    KEY `status_code` (`status_code`),
    KEY `last_sync_at` (`last_sync_at`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'intigo_product_size` (
    `id_product` INT UNSIGNED NOT NULL,
    `size` ENUM(\'S\',\'M\',\'L\',\'XL\') NOT NULL,
    PRIMARY KEY (`id_product`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

$sql[] = 'CREATE TABLE IF NOT EXISTS `' . _DB_PREFIX_ . 'intigo_log` (
    `id_intigo_log` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `created_at` DATETIME NOT NULL,
    `actor` VARCHAR(64) NOT NULL DEFAULT \'system\',
    `action` VARCHAR(64) NOT NULL DEFAULT \'\',
    `context` TEXT NULL,
    PRIMARY KEY (`id_intigo_log`),
    KEY `created_at` (`created_at`)
) ENGINE=' . _MYSQL_ENGINE_ . ' DEFAULT CHARSET=utf8mb4;';

foreach ($sql as $query) {
    if (Db::getInstance()->execute($query) == false) {
        return false;
    }
}

return true;
