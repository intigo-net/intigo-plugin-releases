<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Intigo Orders — central list of every order that used the Intigo Delivery
 * carrier, with parcel status and inline actions, PLUS a dedicated edit page
 * (?a=edit&id_order=X) for setting city/district/neighborhood/phone/etc.
 *
 * Lives entirely inside our own controller so it renders 100% reliably,
 * unlike the BO order view's side/tab hooks which PS 8.x sometimes drops.
 */
class AdminIntigoOrdersController extends ModuleAdminController
{
    const PER_PAGE = 25;

    public function __construct()
    {
        $this->bootstrap = true;
        $this->display = 'view';
        parent::__construct();
        $this->meta_title = 'Intigo — Manage Orders';
    }

    public function initContent()
    {
        $action = (string) Tools::getValue('a');
        if ($action === 'edit') {
            $this->renderEditPage();
        } else {
            $this->renderListPage();
        }
        parent::initContent();
    }

    /* ---------------- LIST view ---------------- */

    private function renderListPage()
    {
        $intigo_carrier_id = (int) Configuration::get('INTIGO_CARRIER_ID');
        $page = max(1, (int) Tools::getValue('p', 1));
        $filter = (string) Tools::getValue('f', '');

        $where = 'o.id_carrier = ' . $intigo_carrier_id;
        if ($filter === 'pending') {
            $where .= ' AND (p.nid IS NULL OR p.nid = "")';
        } elseif ($filter === 'pushed') {
            $where .= ' AND p.nid IS NOT NULL AND p.nid <> ""';
        } elseif ($filter === 'failed') {
            $where .= ' AND p.last_error IS NOT NULL AND p.last_error <> "" AND (p.nid IS NULL OR p.nid = "")';
        }

        $total = (int) Db::getInstance()->getValue(
            'SELECT COUNT(*) FROM `' . _DB_PREFIX_ . 'orders` o
            LEFT JOIN `' . _DB_PREFIX_ . 'intigo_parcel` p ON o.id_order = p.id_order
            WHERE ' . $where
        );
        $pages = max(1, (int) ceil($total / self::PER_PAGE));
        $offset = ($page - 1) * self::PER_PAGE;

        $rows = Db::getInstance()->executeS(
            'SELECT o.id_order, o.reference, o.total_paid_tax_incl, o.date_add,
                    a.firstname, a.lastname, a.city,
                    p.nid, p.status_code, p.last_attempt_at, p.last_error,
                    p.destination_city_id, p.destination_district_id
             FROM `' . _DB_PREFIX_ . 'orders` o
             LEFT JOIN `' . _DB_PREFIX_ . 'intigo_parcel` p ON o.id_order = p.id_order
             LEFT JOIN `' . _DB_PREFIX_ . 'address` a ON o.id_address_delivery = a.id_address
             WHERE ' . $where . '
             ORDER BY o.id_order DESC
             LIMIT ' . self::PER_PAGE . ' OFFSET ' . $offset
        );
        $rows = is_array($rows) ? $rows : [];

        $base_url = self::$currentIndex . '&token=' . $this->token;
        $action_url = $this->context->link->getAdminLink('AdminIntigoOrderAction');

        $notice = (string) Tools::getValue('intigo_notice');
        $notice_type = (string) Tools::getValue('intigo_notice_type');
        $alert_class = $notice_type === 'success' ? 'success'
            : ($notice_type === 'error' ? 'danger'
            : ($notice_type === 'warning' ? 'warning' : 'info'));

        $h = '<div class="panel">';
        $h .= '<div class="panel-heading"><i class="material-icons">local_shipping</i> Intigo — Manage Orders (' . $total . ')</div>';

        if ($notice !== '') {
            $h .= '<div class="alert alert-' . $alert_class . '">' . htmlspecialchars($notice) . '</div>';
        }

        $tabs = [['', 'All'], ['pending', 'Pending push'], ['pushed', 'Pushed'], ['failed', 'Failed']];
        $h .= '<div style="margin-bottom:12px;">';
        foreach ($tabs as $t) {
            $active = $filter === $t[0] ? ' btn-primary' : ' btn-default';
            $url = $base_url . ($t[0] !== '' ? '&f=' . $t[0] : '');
            $h .= '<a href="' . $url . '" class="btn btn-sm' . $active . '" style="margin-right:4px;">' . $t[1] . '</a>';
        }
        $h .= '</div>';

        if (empty($rows)) {
            $h .= '<p class="text-muted"><em>No orders match this filter.</em></p>';
            $h .= '</div>';
            $this->content = $h;
            return;
        }

        $h .= '<table class="table">';
        $h .= '<thead><tr>'
            . '<th>#</th><th>Reference</th><th>Customer</th><th>City</th><th>Total</th>'
            . '<th>Intigo NID</th><th>Status</th><th>Last attempt</th>'
            . '<th style="white-space:nowrap;">Actions</th>'
            . '</tr></thead><tbody>';

        foreach ($rows as $r) {
            $id_order = (int) $r['id_order'];
            $nid = trim((string) $r['nid']);
            $has_nid = $nid !== '';
            $has_error = !$has_nid && trim((string) $r['last_error']) !== '';

            $h .= '<tr>';
            $h .= '<td>' . $id_order . '</td>';
            $h .= '<td><code>' . htmlspecialchars((string) $r['reference']) . '</code></td>';
            $h .= '<td>' . htmlspecialchars(trim((string) $r['firstname'] . ' ' . $r['lastname'])) . '</td>';
            $h .= '<td>' . htmlspecialchars((string) $r['city']) . '</td>';
            $h .= '<td>' . number_format((float) $r['total_paid_tax_incl'], 2) . '</td>';
            $h .= '<td>' . ($has_nid
                ? '<code style="font-size:11px;">' . htmlspecialchars($nid) . '</code>'
                : '<span class="text-muted">—</span>') . '</td>';
            $h .= '<td>' . ($has_nid
                ? '<span class="badge badge-success">Pushed (' . (int) $r['status_code'] . ')</span>'
                : ($has_error
                    ? '<span class="badge badge-danger" title="' . htmlspecialchars((string) $r['last_error']) . '">Failed</span>'
                    : '<span class="badge badge-warning">Pending</span>')) . '</td>';
            $h .= '<td><small class="text-muted">' . htmlspecialchars((string) ($r['last_attempt_at'] ?: '—')) . '</small></td>';

            $h .= '<td style="white-space:nowrap;">';
            // Our dedicated edit page (NOT the BO order view, which doesn't render our hooks)
            $edit_url = $base_url . '&a=edit&id_order=' . $id_order;
            $h .= '<a href="' . $edit_url . '" class="btn btn-default btn-sm" title="Edit Intigo fields">Edit</a> ';

            $h .= '<form method="post" action="' . htmlspecialchars($action_url) . '" style="display:inline;">';
            $h .= '<input type="hidden" name="id_order" value="' . $id_order . '">';
            $h .= '<input type="hidden" name="intigo_return" value="orders">';
            if (!$has_nid) {
                $h .= '<button type="submit" name="intigo_action" value="push" class="btn btn-primary btn-sm" '
                    . 'onclick="return confirm(\'Push order #' . $id_order . ' to Intigo? Make sure city/district are set (use Edit first).\');">'
                    . 'Send</button>';
            } else {
                $h .= '<button type="submit" name="intigo_action" value="bordereau" class="btn btn-default btn-sm">Bordereau</button> ';
                $h .= '<button type="submit" name="intigo_action" value="cancel" class="btn btn-danger btn-sm" '
                    . 'onclick="return confirm(\'Cancel parcel ' . htmlspecialchars($nid) . '?\');">Cancel</button>';
            }
            $h .= '</form>';
            $h .= '</td>';
            $h .= '</tr>';
        }
        $h .= '</tbody></table>';

        if ($pages > 1) {
            $h .= '<ul class="pagination">';
            for ($i = 1; $i <= $pages; $i++) {
                $url = $base_url . ($filter !== '' ? '&f=' . $filter : '') . '&p=' . $i;
                $cls = $i === $page ? ' class="active"' : '';
                $h .= '<li' . $cls . '><a href="' . $url . '">' . $i . '</a></li>';
            }
            $h .= '</ul>';
        }

        $h .= '<p class="text-muted" style="margin-top:12px;"><small>'
            . '<strong>Tip:</strong> click <em>Edit</em> on an order to set city/district/neighborhood and recipient overrides before pushing.'
            . '</small></p>';

        $h .= '</div>';
        $this->content = $h;
    }

    /* ---------------- EDIT view ---------------- */

    private function renderEditPage()
    {
        require_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoParcel.php';
        require_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoOrderService.php';

        $id_order = (int) Tools::getValue('id_order');
        $order = new Order($id_order);
        if (!Validate::isLoadedObject($order)) {
            $this->content = '<div class="alert alert-danger">Order #' . $id_order . ' not found</div>'
                . '<a href="' . self::$currentIndex . '&token=' . $this->token . '" class="btn btn-default">← Back to list</a>';
            return;
        }

        $parcel = IntigoParcel::findByOrderId($id_order);
        $svc = new IntigoOrderService();
        $preview = $svc->orderToPayload($order);

        // Form values: parcel row (if set) > preview from PS address fallback
        $f = [
            'recipient_name' => ($parcel && trim((string) $parcel->recipient_name) !== '')
                ? $parcel->recipient_name : ($preview['recipient_name'] ?? ''),
            'recipient_phone' => ($parcel && trim((string) $parcel->recipient_phone) !== '')
                ? $parcel->recipient_phone : ($preview['phone1'] ?? ''),
            'destination_address' => ($parcel && trim((string) $parcel->destination_address) !== '')
                ? $parcel->destination_address : ($preview['destination_address'] ?? ''),
            'city_id' => $parcel ? (int) $parcel->destination_city_id : (int) ($preview['destination_city_id'] ?? 0),
            'district_id' => $parcel ? (int) $parcel->destination_district_id : 0,
            'neighborhood_id' => $parcel ? (int) $parcel->destination_neighborhood_id : 0,
            'package_size' => $parcel ? ((int) $parcel->package_size ?: 1) : 1,
        ];

        $action_url = $this->context->link->getAdminLink('AdminIntigoOrderAction');
        $list_url = self::$currentIndex . '&token=' . $this->token;
        $regions_url = $this->context->link->getModuleLink('intigoparcels', 'regions', ['action' => 'cities'], true);

        $notice = (string) Tools::getValue('intigo_notice');
        $notice_type = (string) Tools::getValue('intigo_notice_type');
        $alert_class = $notice_type === 'success' ? 'success'
            : ($notice_type === 'error' ? 'danger'
            : ($notice_type === 'warning' ? 'warning' : 'info'));

        $h = '<div class="panel">';
        $h .= '<div class="panel-heading">'
            . '<i class="material-icons">local_shipping</i> '
            . 'Edit Intigo Parcel — Order #' . $id_order . ' (' . htmlspecialchars((string) $order->reference) . ')'
            . '</div>';

        if ($notice !== '') {
            $h .= '<div class="alert alert-' . $alert_class . '">' . htmlspecialchars($notice) . '</div>';
        }

        // Current parcel state banner
        if ($parcel && trim((string) $parcel->nid) !== '') {
            $h .= '<div class="alert alert-success">'
                . '<strong>NID:</strong> <code>' . htmlspecialchars($parcel->nid) . '</code> &nbsp; '
                . '<strong>Status:</strong> ' . (int) $parcel->status_code . ' &nbsp; '
                . '<small>Pushed ' . htmlspecialchars((string) $parcel->last_attempt_at) . ' via ' . htmlspecialchars((string) $parcel->api_target_used) . '</small>'
                . '</div>';
        } elseif ($parcel && trim((string) $parcel->last_error) !== '') {
            $h .= '<div class="alert alert-warning">'
                . '<strong>Last push failed:</strong><br>'
                . '<small><code>' . htmlspecialchars((string) $parcel->last_error) . '</code></small>'
                . '</div>';
        } else {
            $h .= '<div class="alert alert-info">No parcel created yet. Fill the fields and click <strong>Save &amp; Send to Intigo</strong>.</div>';
        }

        // Form
        $h .= '<form method="post" action="' . htmlspecialchars($action_url) . '" class="form-horizontal" id="intigo-edit-form" '
            . 'data-regions-url="' . htmlspecialchars($regions_url) . '">';
        $h .= '<input type="hidden" name="id_order" value="' . $id_order . '">';
        $h .= '<input type="hidden" name="intigo_return" value="orders">';

        $h .= $this->formGroup('Recipient name *', 'recipient_name', 'text', $f['recipient_name'], 'required');
        $h .= $this->formGroup('Phone *', 'recipient_phone', 'tel', $f['recipient_phone'], 'required');
        $h .= $this->formGroupTextarea('Delivery address *', 'destination_address', $f['destination_address']);

        $h .= '<div class="form-group">';
        $h .= '<label class="control-label col-lg-3">City *</label>';
        $h .= '<div class="col-lg-6">';
        $h .= '<select name="destination_city_id" id="intigo-city" class="form-control" data-selected="' . (int) $f['city_id'] . '" required>';
        $h .= '<option value="">— pick a city —</option>';
        $h .= '</select>';
        $h .= '</div></div>';

        $h .= '<div class="form-group">';
        $h .= '<label class="control-label col-lg-3">District *</label>';
        $h .= '<div class="col-lg-6">';
        $h .= '<select name="destination_district_id" id="intigo-district" class="form-control" data-selected="' . (int) $f['district_id'] . '" required disabled>';
        $h .= '<option value="">— pick a city first —</option>';
        $h .= '</select>';
        $h .= '</div></div>';

        $h .= '<div class="form-group">';
        $h .= '<label class="control-label col-lg-3">Neighborhood</label>';
        $h .= '<div class="col-lg-6">';
        $h .= '<select name="destination_neighborhood_id" id="intigo-neighborhood" class="form-control" data-selected="' . (int) $f['neighborhood_id'] . '" disabled>';
        $h .= '<option value="">— optional —</option>';
        $h .= '</select>';
        $h .= '</div></div>';

        $h .= '<div class="form-group">';
        $h .= '<label class="control-label col-lg-3">Package size</label>';
        $h .= '<div class="col-lg-3">';
        $h .= '<select name="package_size" class="form-control">';
        $size_map = [1 => 'S', 2 => 'M', 4 => 'L', 5 => 'XL'];
        foreach ($size_map as $code => $label) {
            $sel = (int) $f['package_size'] === $code ? ' selected' : '';
            $h .= '<option value="' . $code . '"' . $sel . '>' . $label . '</option>';
        }
        $h .= '</select>';
        $h .= '</div></div>';

        // Buttons
        $h .= '<div class="panel-footer" style="margin-top:24px;">';
        $h .= '<a href="' . $list_url . '" class="btn btn-default">← Back to list</a> ';
        $h .= '<button type="submit" name="intigo_action" value="save" class="btn btn-default">Save</button> ';
        if (!$parcel || trim((string) $parcel->nid) === '') {
            $h .= '<button type="submit" name="intigo_action" value="save_push" class="btn btn-primary">Save &amp; Send to Intigo</button>';
        } else {
            $h .= '<button type="submit" name="intigo_action" value="save_update" class="btn btn-primary">Save &amp; Update at Intigo</button>';
        }
        $h .= '</div>';

        $h .= '</form>';
        $h .= '</div>';

        // Inline cascading-dropdown JS (no external file dependency — self-contained)
        $h .= $this->cascadingJs();

        $this->content = $h;
    }

    private function formGroup($label, $name, $type, $value, $extra = '')
    {
        return '<div class="form-group">'
            . '<label class="control-label col-lg-3">' . htmlspecialchars($label) . '</label>'
            . '<div class="col-lg-6">'
            . '<input type="' . $type . '" name="' . $name . '" value="' . htmlspecialchars((string) $value) . '" class="form-control" ' . $extra . '>'
            . '</div></div>';
    }

    private function formGroupTextarea($label, $name, $value)
    {
        return '<div class="form-group">'
            . '<label class="control-label col-lg-3">' . htmlspecialchars($label) . '</label>'
            . '<div class="col-lg-6">'
            . '<textarea name="' . $name . '" class="form-control" rows="2" required>' . htmlspecialchars((string) $value) . '</textarea>'
            . '</div></div>';
    }

    private function cascadingJs()
    {
        return <<<'JS'
<script>
(function () {
    var form = document.getElementById('intigo-edit-form');
    if (!form) { return; }
    var regionsUrl = form.getAttribute('data-regions-url');
    var cityEl = document.getElementById('intigo-city');
    var districtEl = document.getElementById('intigo-district');
    var neighborhoodEl = document.getElementById('intigo-neighborhood');
    var preCity = parseInt(cityEl.dataset.selected || '0', 10);
    var preDistrict = parseInt(districtEl.dataset.selected || '0', 10);
    var preNeighborhood = parseInt(neighborhoodEl.dataset.selected || '0', 10);

    function fetchJson(url) {
        return fetch(url, { credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .catch(function () { return null; });
    }

    function fill(sel, items, selectId) {
        while (sel.options.length > 1) { sel.remove(1); }
        (items || []).forEach(function (it) {
            var o = document.createElement('option');
            o.value = it.id;
            o.textContent = it.name;
            if (parseInt(selectId, 10) === parseInt(it.id, 10)) { o.selected = true; }
            sel.appendChild(o);
        });
    }

    function loadCities(selectId) {
        fetchJson(regionsUrl + '&action=cities').then(function (data) {
            if (!data || !data.ok) { return; }
            fill(cityEl, data.items, selectId);
            if (selectId > 0) { loadDistricts(selectId, preDistrict); }
        });
    }
    function loadDistricts(cityId, selectId) {
        fetchJson(regionsUrl + '&action=districts&city_id=' + cityId).then(function (data) {
            if (!data || !data.ok) { return; }
            fill(districtEl, data.items, selectId);
            districtEl.disabled = false;
            if (selectId > 0) { loadNeighborhoods(selectId, preNeighborhood); }
        });
    }
    function loadNeighborhoods(districtId, selectId) {
        fetchJson(regionsUrl + '&action=neighborhoods&district_id=' + districtId).then(function (data) {
            if (!data || !data.ok) { return; }
            fill(neighborhoodEl, data.items, selectId);
            neighborhoodEl.disabled = false;
        });
    }

    cityEl.addEventListener('change', function () {
        districtEl.innerHTML = '<option value="">— pick a district —</option>';
        districtEl.disabled = !cityEl.value;
        neighborhoodEl.innerHTML = '<option value="">— optional —</option>';
        neighborhoodEl.disabled = true;
        if (cityEl.value) { loadDistricts(parseInt(cityEl.value, 10), 0); }
    });
    districtEl.addEventListener('change', function () {
        neighborhoodEl.innerHTML = '<option value="">— optional —</option>';
        neighborhoodEl.disabled = !districtEl.value;
        if (districtEl.value) { loadNeighborhoods(parseInt(districtEl.value, 10), 0); }
    });

    loadCities(preCity);
})();
</script>
JS;
    }
}
