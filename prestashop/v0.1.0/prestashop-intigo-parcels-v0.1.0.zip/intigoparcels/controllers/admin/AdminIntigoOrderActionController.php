<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * Receives action submissions from the BO order-side panel:
 *   save / save_push / save_update / push_force / cancel / bordereau
 *
 * For the save-prefixed actions, persists the form fields to ps_intigo_parcel
 * BEFORE invoking the API. Other actions just dispatch.
 *
 * Redirects back to the order edit page with a success/error notice.
 */
class AdminIntigoOrderActionController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        parent::__construct();
    }

    public function postProcess()
    {
        $id_order = (int) Tools::getValue('id_order');
        $action = (string) Tools::getValue('intigo_action');
        if ($id_order <= 0 || $action === '') {
            $this->redirectToOrder($id_order, 'Missing parameters', 'error');
        }

        $order = new Order($id_order);
        if (!Validate::isLoadedObject($order)) {
            $this->redirectToOrder($id_order, 'Order not found', 'error');
        }

        require_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoOrderService.php';

        // Save submitted form fields first (for any save-prefixed action)
        if (strpos($action, 'save') === 0) {
            $this->saveParcelFromForm($order);
        }

        $svc = new IntigoOrderService();
        $res = null;

        switch ($action) {
            case 'save':
                $res = ['ok' => true, 'message' => 'Intigo data saved'];
                break;
            case 'push':         // From Intigo Orders list — push without touching parcel fields
            case 'save_push':    // From order edit form — save form THEN push
                $res = $svc->pushParcel($order, false);
                break;
            case 'push_force':
                $res = $svc->pushParcel($order, true);
                break;
            case 'update':
            case 'save_update':
                $res = $svc->updateParcel($order);
                break;
            case 'cancel':
                $res = $svc->cancelParcel($order);
                break;
            case 'bordereau':
                $res = $svc->generateBordereau($order);
                break;
            default:
                $this->redirectToOrder($id_order, 'Unknown action', 'error');
                return;
        }

        $type = !empty($res['ok']) ? 'success' : 'error';
        $msg = isset($res['message']) ? (string) $res['message'] : ($type === 'success' ? 'OK' : 'Failed');
        if (!empty($res['nid'])) {
            $msg .= ' (NID: ' . $res['nid'] . ')';
        }
        if (!empty($res['url'])) {
            $msg .= ' — ' . $res['url'];
        }
        $this->redirectToOrder($id_order, $msg, $type);
    }

    private function saveParcelFromForm(Order $order)
    {
        require_once _PS_MODULE_DIR_ . 'intigoparcels/classes/IntigoParcel.php';

        $parcel = IntigoParcel::findByOrderId((int) $order->id) ?: new IntigoParcel();
        $parcel->id_order = (int) $order->id;
        $parcel->recipient_name = trim((string) Tools::getValue('recipient_name'));
        $parcel->recipient_phone = self::normalizePhone((string) Tools::getValue('recipient_phone'));
        $parcel->destination_address = trim((string) Tools::getValue('destination_address'));
        $parcel->destination_city_id = (int) Tools::getValue('destination_city_id');
        $parcel->destination_district_id = (int) Tools::getValue('destination_district_id');
        $parcel->destination_neighborhood_id = (int) Tools::getValue('destination_neighborhood_id');
        $size = (int) Tools::getValue('package_size');
        if (in_array($size, [1, 2, 4, 5], true)) {
            $parcel->package_size = $size;
        }
        $parcel->save();
    }

    private static function normalizePhone($phone)
    {
        $digits = preg_replace('/\D+/', '', (string) $phone);
        if ($digits === null) {
            return '';
        }
        if (strpos($digits, '00') === 0) {
            $digits = substr($digits, 2);
        }
        return $digits;
    }

    private function redirectToOrder($id_order, $message, $type = 'info')
    {
        $return_to = (string) Tools::getValue('intigo_return');
        if ($return_to === 'orders') {
            $url = $this->context->link->getAdminLink('AdminIntigoOrders', true, [], [
                'intigo_notice' => $message,
                'intigo_notice_type' => $type,
            ]);
        } else {
            $url = $this->context->link->getAdminLink('AdminOrders', true, [], [
                'id_order' => (int) $id_order,
                'vieworder' => 1,
                'intigo_notice' => $message,
                'intigo_notice_type' => $type,
            ]);
        }
        Tools::redirectAdmin($url);
        exit;
    }
}
