<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

class AdminIntigoSettingsController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        $this->display = 'view';
        parent::__construct();
        $this->meta_title = $this->trans('Intigo — Settings', [], 'Modules.Intigoparcels.Admin');
    }

    public function initContent()
    {
        $this->initToolbar();
        $this->initPageHeaderToolbar();

        if (Tools::isSubmit('submitIntigoSettings')) {
            $this->handleSave();
        }
        if (Tools::isSubmit('intigo_test_connection')) {
            $this->handleHealthCheck();
        }

        $api = new IntigoApiClient();
        $settings = $api->getSettings();
        // Tests are not stored — just rendered if a recent test was triggered.
        $health = $this->context->cookie->__get('intigo_last_health');
        $health = $health ? json_decode($health, true) : null;

        $this->context->smarty->assign([
            'intigo_settings' => $settings,
            'intigo_health' => $health,
            'intigo_form_action' => self::$currentIndex . '&token=' . $this->token,
            'intigo_cron_token' => Configuration::get('INTIGO_CRON_TOKEN'),
            'intigo_cron_url' => $this->context->link->getModuleLink(
                'intigoparcels',
                'synccron',
                ['token' => Configuration::get('INTIGO_CRON_TOKEN')],
                true
            ),
            'intigo_notice' => Tools::getValue('intigo_notice'),
            'intigo_notice_type' => Tools::getValue('intigo_notice_type'),
        ]);

        $this->content = $this->context->smarty->fetch(
            _PS_MODULE_DIR_ . 'intigoparcels/views/templates/admin/settings.tpl'
        );

        parent::initContent();
    }

    private function handleSave()
    {
        $env = Tools::getValue('INTIGO_ENVIRONMENT') === 'production' ? 'production' : 'sandbox';
        $api_key = trim((string) Tools::getValue('INTIGO_API_KEY'));
        $fallback = Tools::getValue('INTIGO_FALLBACK_ENABLED') ? '1' : '0';
        $auto_create = Tools::getValue('INTIGO_AUTO_CREATE') ? '1' : '0';
        $size = IntigoApiClient::normalizeSizeLetter(Tools::getValue('INTIGO_DEFAULT_SIZE'), 'S');

        Configuration::updateValue('INTIGO_ENVIRONMENT', $env);
        Configuration::updateValue('INTIGO_API_KEY', $api_key);
        Configuration::updateValue('INTIGO_FALLBACK_ENABLED', $fallback);
        Configuration::updateValue('INTIGO_AUTO_CREATE', $auto_create);
        Configuration::updateValue('INTIGO_DEFAULT_SIZE', $size);
        IntigoLog::add('settings_save', 'env=' . $env . ' fallback=' . $fallback . ' auto=' . $auto_create);

        $this->redirectWithNotice($this->l('Settings saved.'), 'success');
    }

    private function handleHealthCheck()
    {
        $api = new IntigoApiClient();
        $res = $api->healthCheck();
        $this->context->cookie->__set('intigo_last_health', json_encode([
            'ok' => !empty($res['ok']),
            'message' => (string) $res['message'],
            'at' => date('Y-m-d H:i:s'),
        ]));
        $this->context->cookie->write();
        IntigoLog::add(
            $res['ok'] ? 'health_ok' : 'health_failed',
            (string) $res['message']
        );
        $this->redirectWithNotice(
            $res['ok'] ? $this->l('Connection OK.') : $this->l('Connection failed: ') . $res['message'],
            $res['ok'] ? 'success' : 'error'
        );
    }

    private function redirectWithNotice($message, $type = 'info')
    {
        $url = self::$currentIndex
            . '&token=' . $this->token
            . '&intigo_notice=' . rawurlencode($message)
            . '&intigo_notice_type=' . rawurlencode($type);
        Tools::redirectAdmin($url);
    }
}
