<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

class AdminIntigoDocsController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        $this->display = 'view';
        parent::__construct();
        $this->meta_title = $this->trans('Intigo — Docs', [], 'Modules.Intigoparcels.Admin');
    }

    public function initContent()
    {
        $this->content = '<div class="panel"><div class="panel-heading"><i class="material-icons">menu_book</i> Intigo — Docs</div>'
            . '<p>Quick reference and troubleshooting guide will land in Phase 5.</p>'
            . '<ul>'
            . '<li>Sandbox base URL: <code>https://dev-api.intigo.net/api</code></li>'
            . '<li>Production base URL: <code>https://api.intigo.net/api</code></li>'
            . '<li>Auth: <code>X-API-KEY</code> header</li>'
            . '<li>Source: <a href="https://github.com/" target="_blank">prestashop-intigo-parcels</a></li>'
            . '</ul>'
            . '</div>';
        parent::initContent();
    }
}
