<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

class AdminIntigoDashboardController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        $this->display = 'view';
        parent::__construct();
        $this->meta_title = $this->trans('Intigo — Dashboard', [], 'Modules.Intigoparcels.Admin');
    }

    public function initContent()
    {
        $parcels = IntigoParcel::recent(20);
        $log = IntigoLog::paginate(1, 10);
        $this->content = '<div class="panel"><div class="panel-heading"><i class="material-icons">dashboard</i> Intigo — Dashboard</div>'
            . '<p>Recent parcels: ' . count($parcels) . '. Activity entries: ' . (int) $log['total'] . '.</p>'
            . '<p class="text-muted"><em>Full dashboard widgets land in Phase 5.</em></p>'
            . '</div>';
        parent::initContent();
    }
}
