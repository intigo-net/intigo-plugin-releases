<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

class AdminIntigoProductSizesController extends ModuleAdminController
{
    public function __construct()
    {
        $this->bootstrap = true;
        $this->display = 'view';
        parent::__construct();
        $this->meta_title = $this->trans('Intigo — Product Sizes', [], 'Modules.Intigoparcels.Admin');
    }

    public function initContent()
    {
        $this->content = '<div class="panel"><div class="panel-heading"><i class="material-icons">straighten</i> Intigo — Product Sizes</div>'
            . '<p class="text-muted"><em>Per-product size assignment UI lands in Phase 5.</em></p>'
            . '</div>';
        parent::initContent();
    }
}
