(function () {
    "use strict";

    function init() {
        var panel = document.getElementById("intigo-order-side");
        if (!panel || panel.dataset.intigoBound === "1") {
            return;
        }
        panel.dataset.intigoBound = "1";

        var regionsUrl = panel.getAttribute("data-regions-url");
        if (!regionsUrl) { return; }

        var cityEl = panel.querySelector(".intigo-city");
        var districtEl = panel.querySelector(".intigo-district");
        var neighborhoodEl = panel.querySelector(".intigo-neighborhood");
        if (!cityEl || !districtEl) { return; }

        var preCity = parseInt(cityEl.dataset.selected || "0", 10);
        var preDistrict = parseInt(districtEl.dataset.selected || "0", 10);
        var preNeighborhood = parseInt(neighborhoodEl ? neighborhoodEl.dataset.selected || "0" : "0", 10);

        loadCities(preCity);

        cityEl.addEventListener("change", function () {
            districtEl.innerHTML = '<option value="">— pick a district —</option>';
            districtEl.disabled = !cityEl.value;
            if (neighborhoodEl) {
                neighborhoodEl.innerHTML = '<option value="">— optional —</option>';
                neighborhoodEl.disabled = true;
            }
            if (cityEl.value) {
                loadDistricts(parseInt(cityEl.value, 10), 0);
            }
        });
        districtEl.addEventListener("change", function () {
            if (!neighborhoodEl) { return; }
            neighborhoodEl.innerHTML = '<option value="">— optional —</option>';
            neighborhoodEl.disabled = !districtEl.value;
            if (districtEl.value) {
                loadNeighborhoods(parseInt(districtEl.value, 10), 0);
            }
        });

        function loadCities(selectId) {
            fetchJson(regionsUrl + "&action=cities").then(function (data) {
                if (!data || !data.ok) { return; }
                fillSelect(cityEl, data.items, selectId);
                if (selectId > 0) {
                    loadDistricts(selectId, preDistrict);
                }
            });
        }
        function loadDistricts(cityId, selectId) {
            fetchJson(regionsUrl + "&action=districts&city_id=" + cityId).then(function (data) {
                if (!data || !data.ok) { return; }
                fillSelect(districtEl, data.items, selectId);
                districtEl.disabled = false;
                if (selectId > 0 && neighborhoodEl) {
                    loadNeighborhoods(selectId, preNeighborhood);
                }
            });
        }
        function loadNeighborhoods(districtId, selectId) {
            fetchJson(regionsUrl + "&action=neighborhoods&district_id=" + districtId).then(function (data) {
                if (!data || !data.ok || !neighborhoodEl) { return; }
                fillSelect(neighborhoodEl, data.items, selectId);
                neighborhoodEl.disabled = false;
            });
        }

        function fillSelect(sel, items, selectId) {
            while (sel.options.length > 1) { sel.remove(1); }
            (items || []).forEach(function (it) {
                var opt = document.createElement("option");
                opt.value = it.id;
                opt.textContent = it.name;
                if (parseInt(selectId, 10) === parseInt(it.id, 10)) {
                    opt.selected = true;
                }
                sel.appendChild(opt);
            });
        }

        function fetchJson(url) {
            return fetch(url, { credentials: "same-origin" })
                .then(function (r) { return r.json(); })
                .catch(function () { return null; });
        }
    }

    if (document.readyState === "loading") {
        document.addEventListener("DOMContentLoaded", init);
    } else {
        init();
    }
})();
