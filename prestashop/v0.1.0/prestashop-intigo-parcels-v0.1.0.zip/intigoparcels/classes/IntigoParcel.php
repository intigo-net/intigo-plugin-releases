<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * One row per PrestaShop order that has interacted with Intigo.
 *
 * Primary key is `id_order` (1:1 with ps_orders). Created on first push attempt,
 * regardless of whether the API call succeeded — we need somewhere to record
 * `last_error` and `last_attempt_at` even when no NID came back yet.
 */
class IntigoParcel extends ObjectModel
{
    public $id_order;
    public $nid = '';
    public $status_code = 0;
    public $package_size = 1;
    public $recipient_name = '';
    public $recipient_phone = '';
    public $destination_address = '';
    public $destination_city_id = 0;
    public $destination_district_id = 0;
    public $destination_neighborhood_id = 0;
    public $bordereau_url = '';
    public $idempotency_hash = '';
    public $api_target_used = '';
    public $sync_locked = 0;
    public $last_error;
    public $last_attempt_at;
    public $last_sync_at;
    public $created_at;
    public $updated_at;

    public static $definition = [
        'table' => 'intigo_parcel',
        'primary' => 'id_order',
        'fields' => [
            'id_order' => ['type' => self::TYPE_INT, 'validate' => 'isUnsignedId', 'required' => true],
            'nid' => ['type' => self::TYPE_STRING, 'size' => 64],
            'status_code' => ['type' => self::TYPE_INT],
            'package_size' => ['type' => self::TYPE_INT],
            'recipient_name' => ['type' => self::TYPE_STRING, 'size' => 190],
            'recipient_phone' => ['type' => self::TYPE_STRING, 'size' => 32],
            'destination_address' => ['type' => self::TYPE_HTML],
            'destination_city_id' => ['type' => self::TYPE_INT],
            'destination_district_id' => ['type' => self::TYPE_INT],
            'destination_neighborhood_id' => ['type' => self::TYPE_INT],
            'bordereau_url' => ['type' => self::TYPE_STRING, 'size' => 512],
            'idempotency_hash' => ['type' => self::TYPE_STRING, 'size' => 32],
            'api_target_used' => ['type' => self::TYPE_STRING, 'size' => 16],
            'sync_locked' => ['type' => self::TYPE_BOOL],
            'last_error' => ['type' => self::TYPE_HTML, 'allow_null' => true],
            'last_attempt_at' => ['type' => self::TYPE_DATE, 'allow_null' => true],
            'last_sync_at' => ['type' => self::TYPE_DATE, 'allow_null' => true],
            'created_at' => ['type' => self::TYPE_DATE],
            'updated_at' => ['type' => self::TYPE_DATE],
        ],
    ];

    /**
     * ObjectModel's default flow uses an auto-increment `id_intigo_parcel` PK.
     * Our PK is `id_order` (1:1 with ps_orders) — so we override save() to do
     * an upsert keyed on id_order instead.
     */
    public function save($null_values = false, $auto_date = true)
    {
        $now = date('Y-m-d H:i:s');
        if (empty($this->created_at)) {
            $this->created_at = $now;
        }
        $this->updated_at = $now;

        $existing = self::findByOrderId((int) $this->id_order);
        if ($existing) {
            $data = $this->toRow();
            unset($data['id_order']);
            return Db::getInstance()->update(
                self::$definition['table'],
                $data,
                'id_order = ' . (int) $this->id_order,
                1
            );
        }
        return Db::getInstance()->insert(self::$definition['table'], $this->toRow());
    }

    public static function findByOrderId($id_order)
    {
        $id_order = (int) $id_order;
        if ($id_order <= 0) {
            return null;
        }
        $row = Db::getInstance()->getRow(
            'SELECT * FROM `' . _DB_PREFIX_ . self::$definition['table'] . '` WHERE id_order = ' . $id_order
        );
        if (!$row) {
            return null;
        }
        $instance = new self();
        foreach ($row as $key => $value) {
            if (property_exists($instance, $key)) {
                $instance->{$key} = $value;
            }
        }
        return $instance;
    }

    public static function findByNid($nid)
    {
        $nid = pSQL((string) $nid);
        if ($nid === '') {
            return null;
        }
        // Db::getRow auto-appends LIMIT 1, so we don't add one ourselves.
        $row = Db::getInstance()->getRow(
            'SELECT * FROM `' . _DB_PREFIX_ . self::$definition['table'] . '` WHERE nid = "' . $nid . '"'
        );
        if (!$row) {
            return null;
        }
        $instance = new self();
        foreach ($row as $key => $value) {
            if (property_exists($instance, $key)) {
                $instance->{$key} = $value;
            }
        }
        return $instance;
    }

    /**
     * Returns the N most recent parcels (any status) for sync sweep / dashboard.
     */
    public static function recent($limit = 50)
    {
        $limit = max(1, (int) $limit);
        $rows = Db::getInstance()->executeS(
            'SELECT * FROM `' . _DB_PREFIX_ . self::$definition['table'] . '`
            WHERE nid <> ""
            ORDER BY COALESCE(last_sync_at, last_attempt_at, created_at) DESC
            LIMIT ' . $limit
        );
        return is_array($rows) ? $rows : [];
    }

    private function toRow()
    {
        $row = [];
        foreach (self::$definition['fields'] as $key => $def) {
            $value = $this->{$key};
            if ($value === null && empty($def['allow_null'])) {
                continue;
            }
            $row[$key] = $value;
        }
        return $row;
    }
}
