<?php
if (!defined('_PS_VERSION_')) {
    exit;
}

/**
 * HTTP wrapper for the Intigo API. Direct port of the WP plugin's
 * Intigo_API_Client — same endpoints, same fallback semantics, same
 * structured response shape.
 *
 * Response shape (always):
 *   ['ok' => bool, 'code' => int, 'data' => mixed, 'error' => string,
 *    'adapter' => 'primary'|'legacy', 'url' => string]
 *
 * The transport prefers Guzzle (bundled with PS 1.7.6+) and falls back to
 * a thin curl wrapper for older 1.7.x installations.
 */
class IntigoApiClient
{
    const SANDBOX_BASE_URL = 'https://dev-api.intigo.net/api';
    const PRODUCTION_BASE_URL = 'https://api.intigo.net/api';
    const LOCATION_QUERY_BASE_URL = 'https://intishop.dannous.shop/parcels/api/public/locations/?q=';

    public function getSettings()
    {
        $mode = Configuration::get('INTIGO_ENVIRONMENT') === 'production' ? 'production' : 'sandbox';
        $active_primary = $mode === 'production' ? self::PRODUCTION_BASE_URL : self::SANDBOX_BASE_URL;
        return [
            'environment_mode' => $mode,
            'api_key' => (string) Configuration::get('INTIGO_API_KEY'),
            'fallback_enabled' => (string) Configuration::get('INTIGO_FALLBACK_ENABLED') === '1' ? 'yes' : 'no',
            'auto_create' => (string) Configuration::get('INTIGO_AUTO_CREATE') === '1',
            'default_package_size' => self::normalizeSizeLetter(Configuration::get('INTIGO_DEFAULT_SIZE'), 'S'),
            'primary_base_url' => $active_primary,
            'legacy_base_url' => $active_primary,
        ];
    }

    /* ---------------- Endpoints ---------------- */

    public function createParcel($payload)
    {
        return $this->withFallback('POST', '/v3/parcels/', $payload, '/expediteurs/api/parcel/create/');
    }

    public function createParcelsBatch($payload)
    {
        return $this->withFallback('POST', '/v3/parcels/batch', $payload, '/expediteurs/api/parcels/batch/');
    }

    public function generateBordereau(array $nids)
    {
        return $this->withFallback('POST', '/v3/parcels/bordereau', ['nids' => $nids], null);
    }

    public function statusBulk(array $nids)
    {
        return $this->withFallback('POST', '/v3/parcels/status', ['nids' => $nids], null);
    }

    public function updateParcel($nid, $payload)
    {
        $nid = rawurlencode((string) $nid);
        return $this->withFallback('PATCH', '/v3/parcels/' . $nid, $payload, null);
    }

    public function cancelParcel($nid)
    {
        $nid = rawurlencode((string) $nid);
        return $this->withFallback('POST', '/v3/parcels/' . $nid . '/cancel', [], null);
    }

    public function relanceParcel($nid, $accept_fee = false)
    {
        $nid = rawurlencode((string) $nid);
        return $this->withFallback('POST', '/v3/parcels/' . $nid . '/relance', ['accept_fee' => (bool) $accept_fee], null);
    }

    public function reportDelay($nid, $reason = '')
    {
        $nid = rawurlencode((string) $nid);
        $payload = [];
        if (trim((string) $reason) !== '') {
            $payload['reason'] = (string) $reason;
        }
        return $this->withFallback('POST', '/v3/parcels/' . $nid . '/report-delay', $payload, null);
    }

    public function changePhone($nid, $phone)
    {
        $nid = rawurlencode((string) $nid);
        return $this->withFallback('POST', '/v3/parcels/' . $nid . '/change-phone', ['phone' => (string) $phone], null);
    }

    public function changePrice($nid, $price)
    {
        $nid = rawurlencode((string) $nid);
        return $this->withFallback('POST', '/v3/parcels/' . $nid . '/change-price', ['price' => (float) $price], null);
    }

    public function changeAddress($nid, $payload)
    {
        $nid = rawurlencode((string) $nid);
        return $this->withFallback('POST', '/v3/parcels/' . $nid . '/change-address', $payload, null);
    }

    /* ---------------- Region lookups ---------------- */

    public function fetchCities($query = '')
    {
        $settings = $this->getSettings();
        $base = rtrim((string) $settings['primary_base_url'], '/');
        if ($base === '') {
            return ['ok' => false, 'error' => 'primary_base_url is not configured', 'items' => []];
        }
        $items = $this->fetchLookupArray($base . '/v3/regions/cities', $settings);
        return $this->filterLookupItems($items, $query);
    }

    public function fetchDistricts($city_id, $query = '')
    {
        $city_id = (int) $city_id;
        if ($city_id <= 0) {
            return ['ok' => false, 'error' => 'city_id is required', 'items' => []];
        }
        $settings = $this->getSettings();
        $base = rtrim((string) $settings['primary_base_url'], '/');
        $url = $base . '/v3/regions/cities/' . rawurlencode((string) $city_id) . '/districts';
        $items = $this->fetchLookupArray($url, $settings);
        return $this->filterLookupItems($items, $query);
    }

    public function fetchNeighborhoods($district_id)
    {
        $district_id = (int) $district_id;
        if ($district_id <= 0) {
            return ['ok' => false, 'error' => 'district_id is required', 'items' => []];
        }
        $settings = $this->getSettings();
        $base = rtrim((string) $settings['primary_base_url'], '/');
        $url = $base . '/v3/regions/districts/' . rawurlencode((string) $district_id) . '/neighborhoods';
        return $this->fetchLookupArray($url, $settings);
    }

    /**
     * Quick connection check used by the Settings page health pill.
     * Hits /v3/regions/cities — cheap, requires API key, gives a clear signal.
     */
    public function healthCheck()
    {
        $res = $this->fetchCities('');
        if (!empty($res['ok'])) {
            $count = isset($res['items']) ? count($res['items']) : 0;
            return ['ok' => true, 'message' => 'Connected — ' . $count . ' cities reachable'];
        }
        $msg = isset($res['error']) ? (string) $res['error'] : 'unknown error';
        return ['ok' => false, 'message' => $msg];
    }

    /* ---------------- Internals ---------------- */

    private function request($method, $path, $payload, $adapter)
    {
        $settings = $this->getSettings();
        $base = $adapter === 'legacy' ? $settings['legacy_base_url'] : $settings['primary_base_url'];
        $url = rtrim((string) $base, '/') . '/' . ltrim($path, '/');

        $headers = [
            'Content-Type' => 'application/json',
            'X-API-KEY' => (string) $settings['api_key'],
        ];
        $body = $payload === null ? null : json_encode($payload);

        list($code, $resp_body, $error) = $this->httpRequest($method, $url, $headers, $body);

        if ($code === 0) {
            return ['ok' => false, 'code' => 0, 'error' => $error, 'adapter' => $adapter, 'url' => $url];
        }

        $json = json_decode((string) $resp_body, true);
        $data = is_array($json) ? $json : ['raw_body' => (string) $resp_body];

        if ($code >= 200 && $code < 300) {
            return ['ok' => true, 'code' => $code, 'data' => $data, 'adapter' => $adapter, 'url' => $url];
        }
        return ['ok' => false, 'code' => $code, 'data' => $data, 'adapter' => $adapter, 'url' => $url];
    }

    private function withFallback($method, $primary_path, $payload, $legacy_path)
    {
        $settings = $this->getSettings();
        $primary = $this->request($method, $primary_path, $payload, 'primary');
        if (!empty($primary['ok'])) {
            return $primary;
        }
        if ($settings['fallback_enabled'] !== 'yes') {
            return $primary;
        }
        if ((int) ($primary['code'] ?? 0) === 401 || empty($legacy_path)) {
            return $primary;
        }
        $primary_base = rtrim((string) $settings['primary_base_url'], '/');
        $legacy_base = rtrim((string) $settings['legacy_base_url'], '/');
        if ($primary_base !== '' && $primary_base === $legacy_base) {
            return $primary;
        }
        $legacy = $this->request($method, $legacy_path, $payload, 'legacy');
        if (!empty($legacy['ok'])) {
            return $legacy;
        }
        $primary['legacy_attempt'] = [
            'code' => $legacy['code'] ?? 0,
            'error' => $legacy['error'] ?? '',
            'data' => $legacy['data'] ?? null,
            'url' => $legacy['url'] ?? '',
        ];
        return $primary;
    }

    private function fetchLookupArray($url, $settings)
    {
        $headers = [
            'Content-Type' => 'application/json',
            'X-API-KEY' => (string) ($settings['api_key'] ?? ''),
        ];
        list($code, $body, $error) = $this->httpRequest('GET', $url, $headers, null);

        // The WP plugin retries with a trailing slash for 301/302/307/308/404 — same behavior here.
        if (in_array($code, [301, 302, 307, 308, 404], true) && substr($url, -1) !== '/') {
            list($retry_code, $retry_body, $retry_error) = $this->httpRequest('GET', $url . '/', $headers, null);
            if ($retry_code >= 200 && $retry_code < 300) {
                $code = $retry_code;
                $body = $retry_body;
                $error = $retry_error;
            }
        }
        if ($code === 0) {
            return ['ok' => false, 'error' => $error, 'items' => []];
        }
        if ($code < 200 || $code >= 300) {
            return ['ok' => false, 'error' => 'http=' . $code, 'items' => []];
        }
        $json = json_decode((string) $body, true);
        return ['ok' => true, 'items' => $this->extractList($json)];
    }

    private function extractList($json)
    {
        if (!is_array($json)) {
            return [];
        }
        $candidates = $json;
        if (isset($json['data']) && is_array($json['data'])) {
            $candidates = $json['data'];
        } elseif (isset($json['results']) && is_array($json['results'])) {
            $candidates = $json['results'];
        } elseif (isset($json['cities']) && is_array($json['cities'])) {
            $candidates = $json['cities'];
        } elseif (isset($json['districts']) && is_array($json['districts'])) {
            $candidates = $json['districts'];
        } elseif (isset($json['neighborhoods']) && is_array($json['neighborhoods'])) {
            $candidates = $json['neighborhoods'];
        }
        if (!is_array($candidates)) {
            return [];
        }
        $out = [];
        foreach ($candidates as $row) {
            if (is_array($row) && isset($row['id'], $row['name'])) {
                $out[] = ['id' => (int) $row['id'], 'name' => (string) $row['name']];
            }
        }
        return $out;
    }

    private function filterLookupItems($result, $query)
    {
        if (empty($result['ok'])) {
            return $result;
        }
        $query = strtolower(trim((string) $query));
        if ($query === '') {
            return $result;
        }
        $result['items'] = array_values(array_filter($result['items'], function ($item) use ($query) {
            return is_array($item) && isset($item['name'])
                && strpos(strtolower((string) $item['name']), $query) !== false;
        }));
        return $result;
    }

    /**
     * Transport: prefers Guzzle when present, falls back to curl.
     * Returns [http_code, body, error_message]. http_code = 0 on transport error.
     */
    private function httpRequest($method, $url, array $headers, $body)
    {
        $method = strtoupper($method);

        if (class_exists('\\GuzzleHttp\\Client')) {
            try {
                $client = new \GuzzleHttp\Client(['timeout' => 20, 'http_errors' => false]);
                $options = ['headers' => $headers];
                if ($body !== null) {
                    $options['body'] = $body;
                }
                $resp = $client->request($method, $url, $options);
                return [(int) $resp->getStatusCode(), (string) $resp->getBody(), ''];
            } catch (\Exception $e) {
                return [0, '', $e->getMessage()];
            }
        }

        // curl fallback for PS 1.7.0-1.7.5
        $ch = curl_init($url);
        $hdr = [];
        foreach ($headers as $k => $v) {
            $hdr[] = $k . ': ' . $v;
        }
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_CUSTOMREQUEST => $method,
            CURLOPT_HTTPHEADER => $hdr,
        ]);
        if ($body !== null) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        }
        $resp = curl_exec($ch);
        if ($resp === false) {
            $err = curl_error($ch);
            curl_close($ch);
            return [0, '', $err];
        }
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        return [$code, (string) $resp, ''];
    }

    /* ---------------- Helpers ---------------- */

    public static function normalizeSizeLetter($raw, $default = 'S')
    {
        $u = strtoupper(trim((string) $raw));
        return in_array($u, ['S', 'M', 'L', 'XL'], true) ? $u : $default;
    }

    /**
     * Mapping: S=1, M=2, L=4, XL=5. Matches the WP plugin's normalize_package_size().
     */
    public static function sizeLetterToCode($letter)
    {
        $map = ['S' => 1, 'M' => 2, 'L' => 4, 'XL' => 5];
        $u = strtoupper(trim((string) $letter));
        return isset($map[$u]) ? $map[$u] : 1;
    }
}
