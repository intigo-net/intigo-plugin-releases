<?php
/**
 * Intigo Parcels for PrestaShop — main module class.
 *
 * Port of the WordPress Intigo Parcels for WooCommerce plugin.
 * Compatible with PrestaShop 1.7.x and 8.x; PHP 7.2+.
 */

if (!defined('_PS_VERSION_')) {
    exit;
}

require_once __DIR__ . '/classes/IntigoApiClient.php';
require_once __DIR__ . '/classes/IntigoParcel.php';
require_once __DIR__ . '/classes/IntigoProductSize.php';
require_once __DIR__ . '/classes/IntigoLog.php';
require_once __DIR__ . '/classes/IntigoSizeResolver.php';
require_once __DIR__ . '/classes/IntigoOrderService.php';

class Intigoparcels extends Module
{
    /**
     * Configuration keys for module behavior. Shipping price is NOT one of them —
     * PrestaShop's native carrier ranges (Shipping → Carriers → Intigo Delivery)
     * handle that. See feedback memory feedback-prestashop-no-shipping-pricing.
     */
    const CONFIG_KEYS = [
        'INTIGO_ENVIRONMENT',
        'INTIGO_API_KEY',
        'INTIGO_FALLBACK_ENABLED',
        'INTIGO_AUTO_CREATE',
        'INTIGO_DEFAULT_SIZE',
        'INTIGO_CARRIER_ID',
        'INTIGO_CRON_TOKEN',
    ];

    /**
     * Hooks registered at install time.
     *
     * NOTE: no customer-facing checkout hooks (displayCarrierExtraContent,
     * actionValidateStepComplete, displayHeader). All Intigo data is captured
     * in the BO order page after checkout — see feedback memory
     * feedback-prestashop-no-checkout-injection.
     */
    const HOOKS = [
        'displayBackOfficeHeader',
        'actionAdminControllerSetMedia',
        'actionValidateOrder',
        'actionOrderStatusPostUpdate',
        'actionObjectOrderUpdateAfter',
        'displayAdminOrder',
        'displayAdminOrderSide',
        // Tab hooks — these render reliably in PS 8.x's Symfony order view,
        // unlike displayAdminOrderSide which can drop output silently.
        'displayAdminOrderTabLink',
        'displayAdminOrderTabContent',
    ];

    public function __construct()
    {
        $this->name = 'intigoparcels';
        $this->tab = 'shipping_logistics';
        $this->version = '0.1.0';
        $this->author = 'Intigo';
        $this->need_instance = 0;
        $this->bootstrap = true;
        $this->ps_versions_compliancy = ['min' => '1.7.0.0', 'max' => _PS_VERSION_];

        parent::__construct();

        $this->displayName = $this->l('Intigo Parcels');
        $this->description = $this->l('Sell on PrestaShop, ship via Intigo. Checkout flow with Intigo zone selection, automatic or manual push of orders to Intigo, bordereau generation, and status sync.');
        $this->confirmUninstall = $this->l('Are you sure? Order-to-parcel mapping, product size assignments and activity logs will be deleted.');
    }

    public function install()
    {
        if (!parent::install()) {
            return false;
        }
        if (!$this->installSql()) {
            return false;
        }
        if (!$this->installDefaults()) {
            return false;
        }
        if (!$this->installCarrier()) {
            return false;
        }
        if (!$this->installTabs()) {
            return false;
        }
        foreach (self::HOOKS as $hook) {
            if (!$this->registerHook($hook)) {
                return false;
            }
        }
        return true;
    }

    public function uninstall()
    {
        $this->uninstallTabs();
        $this->uninstallCarrier();
        $this->uninstallSql();
        foreach (self::CONFIG_KEYS as $key) {
            Configuration::deleteByName($key);
        }
        return parent::uninstall();
    }

    /* -------------------- Install helpers -------------------- */

    private function installSql()
    {
        return include __DIR__ . '/sql/install.php';
    }

    private function uninstallSql()
    {
        return include __DIR__ . '/sql/uninstall.php';
    }

    private function installDefaults()
    {
        $defaults = [
            'INTIGO_ENVIRONMENT' => 'sandbox',
            'INTIGO_API_KEY' => '',
            'INTIGO_FALLBACK_ENABLED' => '1',
            'INTIGO_AUTO_CREATE' => '0',
            'INTIGO_DEFAULT_SIZE' => 'S',
            'INTIGO_CRON_TOKEN' => bin2hex(random_bytes(16)),
        ];
        foreach ($defaults as $k => $v) {
            if (Configuration::get($k) === false) {
                Configuration::updateValue($k, $v);
            }
        }
        return true;
    }

    /**
     * Registers the "Intigo Delivery" carrier as a standard carrier (NOT a
     * CarrierModule). Pricing is handled entirely by PrestaShop's native
     * Shipping → Carriers UI (price ranges, weight ranges). The merchant
     * configures the price grid there; the module never overrides it.
     *
     * We seed one price range at 0 TND covering all zones/groups so the
     * carrier shows up in checkout even before the merchant tweaks pricing —
     * but the merchant is expected to set real prices in Shipping → Carriers.
     */
    private function installCarrier()
    {
        if ((int) Configuration::get('INTIGO_CARRIER_ID') > 0) {
            return true;
        }
        $carrier = new Carrier();
        $carrier->name = 'Intigo Delivery';
        $carrier->active = 1;
        $carrier->deleted = 0;
        $carrier->shipping_handling = false;
        $carrier->range_behavior = 0;
        $carrier->is_module = true;
        $carrier->shipping_external = false;
        $carrier->external_module_name = $this->name;
        $carrier->shipping_method = Carrier::SHIPPING_METHOD_PRICE;
        $carrier->need_range = 1;
        foreach (Language::getLanguages() as $lang) {
            $carrier->delay[$lang['id_lang']] = '24-72h livraison via Intigo';
        }
        if (!$carrier->add()) {
            return false;
        }
        $range_price = new RangePrice();
        $range_price->id_carrier = (int) $carrier->id;
        $range_price->delimiter1 = 0;
        $range_price->delimiter2 = 100000;
        $range_price->add();
        foreach (Zone::getZones(true) as $zone) {
            Db::getInstance()->insert('carrier_zone', [
                'id_carrier' => (int) $carrier->id,
                'id_zone' => (int) $zone['id_zone'],
            ]);
            Db::getInstance()->insert('delivery', [
                'id_carrier' => (int) $carrier->id,
                'id_range_price' => (int) $range_price->id,
                'id_range_weight' => null,
                'id_zone' => (int) $zone['id_zone'],
                'price' => 0,
            ], false, true, Db::INSERT_IGNORE);
        }
        foreach (Group::getGroups(true) as $group) {
            Db::getInstance()->insert('carrier_group', [
                'id_carrier' => (int) $carrier->id,
                'id_group' => (int) $group['id_group'],
            ]);
        }
        Configuration::updateValue('INTIGO_CARRIER_ID', (int) $carrier->id);
        return true;
    }

    private function uninstallCarrier()
    {
        $id_carrier = (int) Configuration::get('INTIGO_CARRIER_ID');
        if ($id_carrier > 0) {
            $carrier = new Carrier($id_carrier);
            if (Validate::isLoadedObject($carrier)) {
                $carrier->deleted = 1;
                $carrier->update();
            }
        }
        return true;
    }

    /**
     * Creates one parent tab "Intigo" plus 5 child tabs. Stub controllers exist
     * for tabs whose features land in later phases — they render "Coming soon"
     * so the navigation is complete from day 1.
     */
    private function installTabs()
    {
        // Parent
        $parent = new Tab();
        foreach (Language::getLanguages(true) as $lang) {
            $parent->name[$lang['id_lang']] = 'Intigo';
        }
        $parent->class_name = 'AdminIntigoParent';
        $parent->module = $this->name;
        $parent->id_parent = 0;
        $parent->icon = 'local_shipping';
        $parent->add();

        $children = [
            ['AdminIntigoDashboard', 'Dashboard', true],
            ['AdminIntigoOrders', 'Orders', true],
            ['AdminIntigoProductSizes', 'Product Sizes', true],
            ['AdminIntigoLogs', 'Logs', true],
            ['AdminIntigoSettings', 'Settings', true],
            ['AdminIntigoDocs', 'Docs', true],
            ['AdminIntigoOrderAction', '', false], // hidden — only reachable via form action
        ];
        foreach ($children as $row) {
            $tab = new Tab();
            $tab->class_name = $row[0];
            $tab->module = $this->name;
            $tab->id_parent = (int) $parent->id;
            $tab->active = (bool) $row[2] ? 1 : 0;
            foreach (Language::getLanguages(true) as $lang) {
                $tab->name[$lang['id_lang']] = $row[1] !== '' ? $row[1] : $row[0];
            }
            $tab->add();
        }
        return true;
    }

    private function uninstallTabs()
    {
        $class_names = [
            'AdminIntigoDashboard',
            'AdminIntigoOrders',
            'AdminIntigoProductSizes',
            'AdminIntigoLogs',
            'AdminIntigoSettings',
            'AdminIntigoDocs',
            'AdminIntigoOrderAction',
            'AdminIntigoParent',
        ];
        foreach ($class_names as $cn) {
            $id = (int) Tab::getIdFromClassName($cn);
            if ($id) {
                $tab = new Tab($id);
                $tab->delete();
            }
        }
        return true;
    }

    /* -------------------- Configuration entry point -------------------- */

    /**
     * Module Manager "Configure" button lands here. We redirect into the proper
     * AdminIntigoSettings controller so the URL is bookmark-friendly and matches
     * the tab the user can reach from the menu.
     */
    public function getContent()
    {
        $url = $this->context->link->getAdminLink('AdminIntigoSettings');
        Tools::redirectAdmin($url);
        return ''; // unreachable
    }

    /* -------------------- Phase 1 hook stubs -------------------- */
    // Real hook bodies land in their respective phases. Defined here so install
    // succeeds and PrestaShop doesn't whine about missing hook handlers.

    public function hookActionAdminControllerSetMedia()
    {
        // Enqueue admin order JS/CSS on the order detail page so the editable
        // Intigo side panel has cascading-dropdown behavior.
        $ctrl = isset($this->context->controller) ? $this->context->controller : null;
        $ctrl_name = is_object($ctrl) ? get_class($ctrl) : '';
        if (strpos($ctrl_name, 'AdminOrders') !== false || $ctrl_name === 'AdminOrdersController') {
            $this->context->controller->addCSS(
                $this->_path . 'views/css/admin-order.css'
            );
            $this->context->controller->addJS(
                $this->_path . 'views/js/admin-order.js'
            );
        }
    }

    public function hookDisplayBackOfficeHeader()
    {
    }

    /**
     * Fires once when an order is created. We:
     *   1. Snapshot the PS shipping address onto a new ps_intigo_parcel row
     *      (best-effort: try to resolve city_id from address.city via API).
     *   2. If auto mode is ON, attempt to push. Push will fail if required
     *      fields can't be resolved — the merchant fixes those in the BO and
     *      clicks "Send to Intigo" manually.
     */
    public function hookActionValidateOrder($params)
    {
        $order = isset($params['order']) ? $params['order'] : null;
        if (!($order instanceof Order)) {
            return;
        }
        $intigo_carrier_id = (int) Configuration::get('INTIGO_CARRIER_ID');
        if ((int) $order->id_carrier !== $intigo_carrier_id) {
            return;
        }

        // Snapshot PS address onto a parcel row (no NID yet). The BO side
        // panel reads this and lets the merchant complete missing fields.
        $svc = new IntigoOrderService();
        $payload = $svc->orderToPayload($order);
        $parcel = IntigoParcel::findByOrderId((int) $order->id) ?: new IntigoParcel();
        $parcel->id_order = (int) $order->id;
        $parcel->recipient_name = (string) $payload['recipient_name'];
        $parcel->recipient_phone = (string) $payload['phone1'];
        $parcel->destination_address = (string) $payload['destination_address'];
        $parcel->destination_city_id = (int) $payload['destination_city_id'];
        $parcel->destination_district_id = (int) $payload['destination_district_id'];
        $parcel->destination_neighborhood_id = isset($payload['destination_neighborhood_id'])
            ? (int) $payload['destination_neighborhood_id'] : 0;
        if (empty($parcel->package_size)) {
            $parcel->package_size = (int) $payload['package_size'];
        }
        $parcel->save();

        // Auto-push if enabled (silently no-ops if validation fails — merchant resolves in BO)
        if ((string) Configuration::get('INTIGO_AUTO_CREATE') === '1') {
            $svc->pushParcel($order, false);
        }
    }

    public function hookActionOrderStatusPostUpdate($params)
    {
        // Safety-net: if auto mode is ON, the parcel still has no NID, and the
        // order moved to a "paid" state, try once more. This handles flows
        // where actionValidateOrder didn't fire (e.g. manual order creation).
        if ((string) Configuration::get('INTIGO_AUTO_CREATE') !== '1') {
            return;
        }
        $id_order = isset($params['id_order']) ? (int) $params['id_order'] : 0;
        $order = $id_order > 0 ? new Order($id_order) : null;
        if (!$order || !Validate::isLoadedObject($order)) {
            return;
        }
        if ((int) $order->id_carrier !== (int) Configuration::get('INTIGO_CARRIER_ID')) {
            return;
        }
        $parcel = IntigoParcel::findByOrderId((int) $order->id);
        if ($parcel && trim((string) $parcel->nid) !== '') {
            return;
        }
        $svc = new IntigoOrderService();
        $svc->pushParcel($order, false);
    }

    public function hookActionObjectOrderUpdateAfter($params)
    {
        $order = isset($params['object']) ? $params['object'] : null;
        if (!($order instanceof Order)) {
            return;
        }
        $parcel = IntigoParcel::findByOrderId((int) $order->id);
        if (!$parcel || trim((string) $parcel->nid) === '' || (int) $parcel->sync_locked === 1) {
            return;
        }
        $svc = new IntigoOrderService();
        $svc->updateParcel($order); // best-effort, swallows result
    }

    public function hookDisplayAdminOrder($params)
    {
        // PS 1.7 fallback path — same content as the 8.x side hook.
        return $this->renderAdminOrderSide($params);
    }

    public function hookDisplayAdminOrderSide($params)
    {
        return $this->renderAdminOrderSide($params);
    }

    /**
     * Adds an "Intigo Parcel" tab to the order view's tab bar (next to
     * Status/Documents/Carriers). Only shown when the order's carrier is
     * Intigo Delivery.
     */
    public function hookDisplayAdminOrderTabLink($params)
    {
        $id_order = isset($params['id_order']) ? (int) $params['id_order'] : 0;
        if ($id_order <= 0) return '';
        $order = new Order($id_order);
        if (!Validate::isLoadedObject($order)) return '';
        if ((int) $order->id_carrier !== (int) Configuration::get('INTIGO_CARRIER_ID')) return '';

        $parcel = IntigoParcel::findByOrderId($id_order);
        $count = $parcel && trim((string) $parcel->nid) !== '' ? 1 : 0;

        return '<li class="nav-item">
            <a class="nav-link" id="intigo-tab" data-toggle="tab" href="#intigoTabContent" role="tab">
                <i class="material-icons">local_shipping</i> Intigo Parcel
                <span class="count">' . $count . '</span>
            </a>
        </li>';
    }

    public function hookDisplayAdminOrderTabContent($params)
    {
        IntigoLog::add('tab_content_hook_called', 'params_keys=' . implode(',', array_keys((array) $params)));

        $id_order = isset($params['id_order']) ? (int) $params['id_order'] : 0;
        if ($id_order <= 0 && isset($params['order']) && is_object($params['order'])) {
            $id_order = (int) $params['order']->id;
        }

        // Always render visible content so we can tell whether the hook
        // output reaches the DOM at all. If it does but the inner template
        // is the failure, we'll see the warning lines below instead of an
        // empty pane.
        $debug_line = 'id_order=' . $id_order . ' | params_keys=' . implode(',', array_keys((array) $params));

        $inner = '';
        if ($id_order > 0) {
            $inner = $this->renderAdminOrderSide($params);
            if (trim($inner) === '') {
                $inner = '<div class="alert alert-warning">renderAdminOrderSide returned empty for order #' . $id_order . '</div>';
            }
        } else {
            $inner = '<div class="alert alert-warning">No id_order in tab content hook params</div>';
        }

        return '<div class="tab-pane fade show active" id="intigoTabContent" role="tabpanel" aria-labelledby="intigo-tab" style="padding:16px; border:2px solid #2271b1; background:#f0f6fc; margin-top:8px;">'
            . '<p style="color:#2271b1; font-size:12px;"><strong>DEBUG (will remove):</strong> ' . htmlspecialchars($debug_line) . '</p>'
            . $inner
            . '</div>';
    }

    private function renderAdminOrderSide($params)
    {
        // DEBUG: log every invocation so we can prove the hook is firing.
        IntigoLog::add('side_hook_called', 'params_keys=' . implode(',', array_keys((array) $params)));

        $id_order = isset($params['id_order']) ? (int) $params['id_order'] : 0;
        // PS 8.x sometimes passes the order object directly instead of id
        if ($id_order <= 0 && isset($params['order']) && is_object($params['order'])) {
            $id_order = (int) $params['order']->id;
        }
        if ($id_order <= 0) {
            return '<div class="alert alert-warning">Intigo: hook fired but no id_order in params</div>';
        }
        $order = new Order($id_order);
        if (!Validate::isLoadedObject($order)) {
            return '<div class="alert alert-warning">Intigo: hook fired but Order #' . $id_order . ' not loaded</div>';
        }
        $intigo_carrier_id = (int) Configuration::get('INTIGO_CARRIER_ID');
        $is_intigo = (int) $order->id_carrier === $intigo_carrier_id;

        $parcel = IntigoParcel::findByOrderId($id_order);

        // Build form values: parcel row > PS shipping address fallback.
        $form = [
            'recipient_name' => '',
            'recipient_phone' => '',
            'destination_address' => '',
            'destination_city_id' => 0,
            'destination_district_id' => 0,
            'destination_neighborhood_id' => 0,
            'package_size' => 1,
        ];
        if ($parcel) {
            $form['recipient_name'] = (string) $parcel->recipient_name;
            $form['recipient_phone'] = (string) $parcel->recipient_phone;
            $form['destination_address'] = (string) $parcel->destination_address;
            $form['destination_city_id'] = (int) $parcel->destination_city_id;
            $form['destination_district_id'] = (int) $parcel->destination_district_id;
            $form['destination_neighborhood_id'] = (int) $parcel->destination_neighborhood_id;
            $form['package_size'] = (int) $parcel->package_size ?: 1;
        }
        // Fallback to PS shipping address for empty fields
        if ($is_intigo) {
            $addr = new Address((int) $order->id_address_delivery);
            if (Validate::isLoadedObject($addr)) {
                if ($form['recipient_name'] === '') {
                    $form['recipient_name'] = trim((string) $addr->firstname . ' ' . (string) $addr->lastname);
                }
                if ($form['recipient_phone'] === '') {
                    $form['recipient_phone'] = (string) ($addr->phone_mobile ?: $addr->phone);
                }
                if ($form['destination_address'] === '') {
                    $form['destination_address'] = trim((string) $addr->address1 . ' ' . (string) $addr->address2);
                }
            }
        }

        $this->context->smarty->assign([
            'intigo_is_intigo_carrier' => $is_intigo,
            'intigo_order_id' => $id_order,
            'intigo_parcel' => $parcel,
            'intigo_form' => $form,
            'intigo_action_url' => $this->context->link->getAdminLink('AdminIntigoOrderAction'),
            'intigo_regions_url' => $this->context->link->getModuleLink(
                $this->name,
                'regions',
                ['action' => 'cities'],
                true
            ),
        ]);

        $rendered = $this->display(__FILE__, 'displayAdminOrderSide.tpl');
        if (trim((string) $rendered) === '') {
            // Template render returned empty — emit a debug marker so we
            // know the hook is firing but the template silently failed.
            IntigoLog::add('side_hook_empty_render', 'tpl returned empty for order #' . $id_order);
            return '<div class="alert alert-danger" style="margin:12px 0;"><strong>Intigo:</strong> hook fired but template render returned empty. Check var/logs/.</div>';
        }
        return $rendered;
    }
}
