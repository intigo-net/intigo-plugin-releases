<?php

if (!defined('ABSPATH')) {
    exit;
}

class Intigo_Admin {
    private $order_service;
    private $api_client;
    const META_OPS_STATUS = '_intigo_ops_status';
    const OPTION_AUTH = 'intigo_parcels_auth';
    const OPTION_LOGS = 'intigo_parcels_logs';
    const MAX_LOGS = 200;
    const LOGS_PER_PAGE = 25;
    const NOTICE_TRANSIENT_PREFIX = 'intigo_notices_';

    /** @var array|null Notices shown on the current Intigo page (read once per request). */
    private $page_notices = null;

    public function __construct($order_service) {
        $this->order_service = $order_service;
        $this->api_client = new Intigo_API_Client();
    }

    public function register() {
        add_action('admin_menu', [$this, 'add_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('add_meta_boxes', [$this, 'register_order_meta_box']);
        add_action('add_meta_boxes_woocommerce_page_wc-orders', [$this, 'register_order_meta_box_hpos']);
        add_action('save_post_shop_order', [$this, 'save_order_meta_box'], 10, 2);
        add_action('woocommerce_process_shop_order_meta', [$this, 'save_order_meta_box_from_order_id'], 10, 1);
        // After WooCommerce saved the addresses (40), before the "Order actions" box (50).
        add_action('woocommerce_process_shop_order_meta', [$this, 'detect_zone_after_admin_save'], 45, 2);
        add_action('wp_ajax_intigo_get_cities', [$this, 'ajax_get_cities']);
        add_action('wp_ajax_intigo_get_districts', [$this, 'ajax_get_districts']);
        add_action('wp_ajax_intigo_get_neighborhoods', [$this, 'ajax_get_neighborhoods']);
        add_action('wp_ajax_intigo_search_locations', [$this, 'ajax_search_locations']);
        add_action('wp_ajax_intigo_detect_order_zone', [$this, 'ajax_detect_order_zone']);
        add_action('admin_post_intigo_download_bordereau', [$this, 'handle_download_bordereau']);
        add_action('admin_post_intigo_order_action', [$this, 'handle_intigo_order_action']);
        add_action('admin_post_intigo_detect_addresses', [$this, 'handle_detect_addresses']);
        add_action('admin_post_intigo_login', [$this, 'handle_intigo_login']);
        add_action('admin_post_intigo_logout', [$this, 'handle_intigo_logout']);
        add_action('admin_post_intigo_add_to_zones', [$this, 'handle_add_to_zones']);
        add_action('admin_notices', [$this, 'render_order_screen_notices']);
        add_shortcode('intigo_manage_orders', [$this, 'render_manage_orders_shortcode']);
    }

    public function add_menu() {
        $new_orders_count = $this->get_new_orders_count();
        $manage_orders_label = __('Manage Orders', 'intigo-parcels');
        if ($new_orders_count > 0) {
            $manage_orders_label .= ' <span class="awaiting-mod count-' . intval($new_orders_count) . '"><span class="pending-count">' . intval($new_orders_count) . '</span></span>';
        }
        add_menu_page(
            __('Intigo Dashboard', 'intigo-parcels'),
            'Intigo',
            'manage_woocommerce',
            'intigo-dashboard',
            [$this, 'render_dashboard'],
            'dashicons-location-alt',
            56
        );
        add_submenu_page(
            'intigo-dashboard',
            __('Dashboard', 'intigo-parcels'),
            __('Dashboard', 'intigo-parcels'),
            'manage_woocommerce',
            'intigo-dashboard',
            [$this, 'render_dashboard']
        );
        add_submenu_page(
            'intigo-dashboard',
            __('Manage Orders', 'intigo-parcels'),
            $manage_orders_label,
            'manage_woocommerce',
            'intigo-manage-orders',
            [$this, 'render_panel']
        );
        add_submenu_page(
            'intigo-dashboard',
            __('Logs', 'intigo-parcels'),
            __('Logs', 'intigo-parcels'),
            'manage_woocommerce',
            'intigo-logs',
            [$this, 'render_logs']
        );

        add_submenu_page(
            'intigo-dashboard',
            __('Documentation', 'intigo-parcels'),
            __('Documentation', 'intigo-parcels'),
            'manage_woocommerce',
            'intigo-docs',
            [$this, 'render_docs']
        );

        add_submenu_page(
            'intigo-dashboard',
            __('Intigo Settings', 'intigo-parcels'),
            __('Settings', 'intigo-parcels'),
            'manage_woocommerce',
            'intigo-parcels-settings',
            [$this, 'render_settings']
        );
    }

    public function register_settings() {
        register_setting('intigo_parcels_group', Intigo_API_Client::OPTION_KEY);
    }

    public function render_settings() {
        $settings = get_option(Intigo_API_Client::OPTION_KEY, []);
        $health = $this->check_health();
        $opt = Intigo_API_Client::OPTION_KEY;
        $env_mode = ($settings['environment_mode'] ?? 'sandbox') === 'production' ? 'production' : 'sandbox';
        $auto_mode = ($settings['auto_create_on_paid'] ?? 'no') === 'yes';
        $fallback_on = ($settings['fallback_enabled'] ?? 'yes') === 'yes';
        $modal_on = ($settings['checkout_modal_enabled'] ?? 'yes') === 'yes';
        $pkg = (string) ($settings['default_package_size'] ?? 'S');
        $api_key = (string) ($settings['api_key'] ?? '');
        $price_s = isset($settings['size_price_s']) ? (string) $settings['size_price_s'] : '1';
        $price_m = isset($settings['size_price_m']) ? (string) $settings['size_price_m'] : '6';
        $price_l = isset($settings['size_price_l']) ? (string) $settings['size_price_l'] : '7';
        $price_xl = isset($settings['size_price_xl']) ? (string) $settings['size_price_xl'] : '8';
        $currency_symbol = function_exists('get_woocommerce_currency_symbol') ? get_woocommerce_currency_symbol() : '';
        if (isset($_GET['settings-updated'])) {
            // options.php redirects back here with settings-updated=true; any problem is
            // reported through the Settings API errors, which this non-core page must read itself.
            $errors = array_filter((array) get_settings_errors(), function ($e) {
                return isset($e['type']) && $e['type'] === 'error';
            });
            if (!empty($errors)) {
                self::queue_notice(__('Settings could not be saved.', 'intigo-parcels'), 'error', wp_list_pluck($errors, 'message'));
            } else {
                self::queue_notice(__('Settings saved.', 'intigo-parcels'), 'success');
            }
        }
        ?>
        <div class="wrap">
            <?php $this->render_responsive_styles(); ?>
            <?php $this->render_interface_nav('intigo-parcels-settings'); ?>
            <?php $this->render_snackbar(); ?>
            <?php $this->render_page_header(__('Settings', 'intigo-parcels'), __('Configure how this WooCommerce store connects to and behaves with Intigo.', 'intigo-parcels'), __('Configuration', 'intigo-parcels')); ?>
            <style>
                .intigo-settings { max-width: 880px; }

                .intigo-section { background:#fff; border:1px solid #e2e8f0; border-radius:14px; padding:0; margin:0 0 16px 0; box-shadow:0 1px 2px rgba(15,23,42,.04); }
                .intigo-section-head { padding:16px 20px 0 20px; }
                .intigo-section-title { margin:0; font-size:15px; font-weight:600; color:#0f172a; }
                .intigo-section-sub { margin:4px 0 0 0; color:#64748b; font-size:13px; }
                .intigo-section-body { padding:16px 20px 20px 20px; }

                .intigo-field { display:grid; grid-template-columns: 220px 1fr; gap:16px; padding:14px 0; border-top:1px solid #f1f5f9; align-items:start; }
                .intigo-field:first-child { border-top:0; padding-top:6px; }
                .intigo-field-label { font-weight:600; color:#0f172a; font-size:13px; }
                .intigo-field-hint { color:#64748b; font-size:12px; margin-top:4px; }
                .intigo-field-input input[type=text],
                .intigo-field-input input[type=password],
                .intigo-field-input select { min-width: 320px; max-width:100%; min-height:36px; border-radius:8px; border:1px solid #c7d2dc; padding:0 10px; }
                .intigo-field-input input[type=text]:focus,
                .intigo-field-input input[type=password]:focus,
                .intigo-field-input select:focus { border-color:#2271b1; box-shadow:0 0 0 3px rgba(34,113,177,.15); outline:none; }

                .intigo-segmented { display:inline-flex; padding:3px; background:#f1f5f9; border-radius:10px; gap:2px; }
                .intigo-segmented label { cursor:pointer; padding:7px 14px; border-radius:8px; font-size:13px; font-weight:600; color:#475569; transition:background .15s ease, color .15s ease; }
                .intigo-segmented input { position:absolute; opacity:0; pointer-events:none; }
                .intigo-segmented label:has(input:checked) { background:#fff; color:#0f172a; box-shadow:0 1px 2px rgba(15,23,42,.08); }

                .intigo-switch { display:inline-flex; align-items:center; gap:10px; cursor:pointer; user-select:none; }
                .intigo-switch input { position:absolute; opacity:0; pointer-events:none; }
                .intigo-switch .intigo-switch-track { width:38px; height:22px; background:#cbd5e1; border-radius:999px; position:relative; transition:background .15s ease; }
                .intigo-switch .intigo-switch-thumb { position:absolute; top:2px; left:2px; width:18px; height:18px; background:#fff; border-radius:50%; transition:transform .15s ease; box-shadow:0 1px 2px rgba(15,23,42,.2); }
                .intigo-switch:has(input:checked) .intigo-switch-track { background:#2271b1; }
                .intigo-switch:has(input:checked) .intigo-switch-thumb { transform:translateX(16px); }
                .intigo-switch-label { font-size:13px; color:#0f172a; font-weight:600; }

                .intigo-mode-cards { display:grid; grid-template-columns: 1fr 1fr; gap:10px; }
                .intigo-mode-card { display:flex; gap:12px; align-items:flex-start; padding:14px; border:1px solid #e2e8f0; border-radius:12px; background:#fff; cursor:pointer; transition:border-color .15s ease, background .15s ease, box-shadow .15s ease; }
                .intigo-mode-card:hover { border-color:#a7b9c9; }
                .intigo-mode-card:has(input:checked) { border-color:#2271b1; background:#f0f7ff; box-shadow:0 0 0 3px rgba(34,113,177,.10); }
                .intigo-mode-card input { margin-top:3px; }
                .intigo-mode-card .intigo-mode-title { display:block; font-size:14px; font-weight:600; color:#0f172a; }
                .intigo-mode-card .intigo-mode-desc { display:block; color:#475569; font-size:13px; margin-top:2px; line-height:1.45; }
                @media (max-width: 720px) { .intigo-mode-cards { grid-template-columns: 1fr; } .intigo-field { grid-template-columns: 1fr; } }

                .intigo-key-wrap { position:relative; display:inline-flex; align-items:center; gap:6px; max-width:100%; }
                .intigo-key-wrap input { padding-right:38px !important; min-width:380px; }
                .intigo-key-toggle { position:absolute; right:6px; top:50%; transform:translateY(-50%); background:transparent; border:0; padding:6px; cursor:pointer; color:#64748b; }
                .intigo-key-toggle:hover { color:#0f172a; }

                .intigo-package-grid { display:inline-grid; grid-template-columns: repeat(4, 1fr); gap:6px; }
                .intigo-package-grid label { padding:10px 16px; border:1px solid #e2e8f0; border-radius:10px; cursor:pointer; text-align:center; font-weight:700; color:#475569; min-width:54px; transition:border-color .15s ease, background .15s ease, color .15s ease; }
                .intigo-package-grid input { position:absolute; opacity:0; pointer-events:none; }
                .intigo-package-grid label:has(input:checked) { border-color:#2271b1; background:#f0f7ff; color:#0f172a; }

                .intigo-tech { background:#fff; border:1px solid #e2e8f0; border-radius:14px; padding:0; margin:0 0 16px 0; }
                .intigo-tech > summary { cursor:pointer; list-style:none; padding:14px 18px; font-weight:600; color:#0f172a; display:flex; justify-content:space-between; align-items:center; }
                .intigo-tech > summary::-webkit-details-marker { display:none; }
                .intigo-tech[open] > summary { border-bottom:1px solid #f1f5f9; }
                .intigo-tech-body { padding:14px 18px 18px 18px; color:#475569; font-size:13px; }
                .intigo-tech-body code { background:#f1f5f9; padding:2px 6px; border-radius:5px; font-size:12px; }

                .intigo-save-bar { position:sticky; bottom:0; background:linear-gradient(180deg, rgba(255,255,255,0), #fff 40%); padding:18px 0 4px 0; display:flex; gap:10px; align-items:center; }
                .intigo-save-bar .button-primary { padding:6px 22px !important; }
            </style>

            <div class="intigo-settings">
                <?php if (!$health['ok']): ?>
                    <div class="intigo-alert intigo-alert--error">
                        <span class="intigo-alert-icon"><span class="dashicons dashicons-warning"></span></span>
                        <span class="intigo-alert-body"><strong><?php esc_html_e('API not reachable.', 'intigo-parcels'); ?></strong> <?php echo esc_html($health['message']); ?></span>
                    </div>
                <?php endif; ?>

                <form method="post" action="options.php">
                    <?php settings_fields('intigo_parcels_group'); ?>

                    <section class="intigo-section">
                        <div class="intigo-section-head">
                            <h2 class="intigo-section-title"><?php esc_html_e('Connection', 'intigo-parcels'); ?></h2>
                            <p class="intigo-section-sub"><?php esc_html_e('Where this plugin sends data and the credentials it uses.', 'intigo-parcels'); ?></p>
                        </div>
                        <div class="intigo-section-body">
                            <div class="intigo-field">
                                <div>
                                    <div class="intigo-field-label"><?php esc_html_e('Environment', 'intigo-parcels'); ?></div>
                                    <div class="intigo-field-hint"><?php esc_html_e('Sandbox is safe for testing. Production sends real shipments.', 'intigo-parcels'); ?></div>
                                </div>
                                <div class="intigo-field-input">
                                    <div class="intigo-segmented" role="radiogroup" aria-label="<?php esc_attr_e('Environment', 'intigo-parcels'); ?>">
                                        <label><input type="radio" name="<?php echo esc_attr($opt); ?>[environment_mode]" value="sandbox" <?php checked($env_mode, 'sandbox'); ?>> <?php esc_html_e('Sandbox', 'intigo-parcels'); ?></label>
                                        <label><input type="radio" name="<?php echo esc_attr($opt); ?>[environment_mode]" value="production" <?php checked($env_mode, 'production'); ?>> <?php esc_html_e('Production', 'intigo-parcels'); ?></label>
                                    </div>
                                </div>
                            </div>
                            <div class="intigo-field">
                                <div>
                                    <div class="intigo-field-label"><?php esc_html_e('API Key', 'intigo-parcels'); ?></div>
                                    <div class="intigo-field-hint"><?php esc_html_e('Used for every call. Keep this key secret.', 'intigo-parcels'); ?></div>
                                </div>
                                <div class="intigo-field-input">
                                    <span class="intigo-key-wrap">
                                        <input id="intigo-api-key" type="password" class="regular-text" name="<?php echo esc_attr($opt); ?>[api_key]" value="<?php echo esc_attr($api_key); ?>" autocomplete="off" placeholder="<?php esc_attr_e('Paste your Intigo API key', 'intigo-parcels'); ?>">
                                        <button type="button" class="intigo-key-toggle" aria-label="<?php esc_attr_e('Show or hide API key', 'intigo-parcels'); ?>" onclick="(function(b){var i=document.getElementById('intigo-api-key');if(!i)return;i.type=i.type==='password'?'text':'password';b.textContent=i.type==='password'?<?php echo esc_attr(wp_json_encode(__('Show', 'intigo-parcels'))); ?>:<?php echo esc_attr(wp_json_encode(__('Hide', 'intigo-parcels'))); ?>;})(this)"><?php esc_html_e('Show', 'intigo-parcels'); ?></button>
                                    </span>
                                </div>
                            </div>
                            <div class="intigo-field">
                                <div>
                                    <div class="intigo-field-label"><?php esc_html_e('Fallback adapter', 'intigo-parcels'); ?></div>
                                    <div class="intigo-field-hint"><?php esc_html_e('If the primary API fails, retry through the legacy bridge.', 'intigo-parcels'); ?></div>
                                </div>
                                <div class="intigo-field-input">
                                    <label class="intigo-switch">
                                        <input type="hidden" name="<?php echo esc_attr($opt); ?>[fallback_enabled]" value="no">
                                        <input type="checkbox" name="<?php echo esc_attr($opt); ?>[fallback_enabled]" value="yes" <?php checked($fallback_on, true); ?>>
                                        <span class="intigo-switch-track"><span class="intigo-switch-thumb"></span></span>
                                        <span class="intigo-switch-label"><?php echo $fallback_on ? esc_html__('Enabled', 'intigo-parcels') : esc_html__('Disabled', 'intigo-parcels'); ?></span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </section>

                    <section class="intigo-section">
                        <div class="intigo-section-head">
                            <h2 class="intigo-section-title"><?php esc_html_e('Order processing', 'intigo-parcels'); ?></h2>
                            <p class="intigo-section-sub"><?php esc_html_e('How WooCommerce orders are pushed to Intigo.', 'intigo-parcels'); ?></p>
                        </div>
                        <div class="intigo-section-body">
                            <div class="intigo-mode-cards">
                                <label class="intigo-mode-card">
                                    <input type="radio" name="<?php echo esc_attr($opt); ?>[auto_create_on_paid]" value="yes" <?php checked($auto_mode, true); ?>>
                                    <div>
                                        <span class="intigo-mode-title"><?php esc_html_e('Automatic', 'intigo-parcels'); ?></span>
                                        <span class="intigo-mode-desc"><?php echo wp_kses_post(__('Push orders to Intigo automatically as soon as WooCommerce marks them as <em>Processing</em>. No action needed from your team.', 'intigo-parcels')); ?></span>
                                    </div>
                                </label>
                                <label class="intigo-mode-card">
                                    <input type="radio" name="<?php echo esc_attr($opt); ?>[auto_create_on_paid]" value="no" <?php checked($auto_mode, false); ?>>
                                    <div>
                                        <span class="intigo-mode-title"><?php esc_html_e('Manual', 'intigo-parcels'); ?></span>
                                        <span class="intigo-mode-desc"><?php echo wp_kses_post(__('Review each order in <em>Manage Orders</em> and click <strong>Send to Intigo</strong> when you\'re ready.', 'intigo-parcels')); ?></span>
                                    </div>
                                </label>
                            </div>
                            <p class="intigo-field-hint" style="margin-top:10px;"><?php esc_html_e('You can change this at any time.', 'intigo-parcels'); ?></p>
                        </div>
                    </section>

                    <section class="intigo-section">
                        <div class="intigo-section-head">
                            <h2 class="intigo-section-title"><?php esc_html_e('Checkout experience', 'intigo-parcels'); ?></h2>
                            <p class="intigo-section-sub"><?php esc_html_e('Controls what Intigo Delivery customers see and must complete at checkout.', 'intigo-parcels'); ?></p>
                        </div>
                        <div class="intigo-section-body">
                            <div class="intigo-field">
                                <div>
                                    <div class="intigo-field-label"><?php esc_html_e('Address confirmation modal', 'intigo-parcels'); ?></div>
                                    <div class="intigo-field-hint"><?php esc_html_e('When enabled, customers who pick Intigo Delivery must confirm their recipient details and choose their Intigo city & district before placing the order. Turn this off if you\'d rather collect the address with the standard WooCommerce fields — the Intigo zone is then resolved automatically from that address when the parcel is pushed.', 'intigo-parcels'); ?></div>
                                </div>
                                <div class="intigo-field-input">
                                    <label class="intigo-switch">
                                        <input type="hidden" name="<?php echo esc_attr($opt); ?>[checkout_modal_enabled]" value="no">
                                        <input type="checkbox" name="<?php echo esc_attr($opt); ?>[checkout_modal_enabled]" value="yes" <?php checked($modal_on, true); ?>>
                                        <span class="intigo-switch-track"><span class="intigo-switch-thumb"></span></span>
                                        <span class="intigo-switch-label"><?php echo $modal_on ? esc_html__('Enabled', 'intigo-parcels') : esc_html__('Disabled', 'intigo-parcels'); ?></span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </section>

                    <section class="intigo-section">
                        <div class="intigo-section-head">
                            <h2 class="intigo-section-title"><?php esc_html_e('Defaults', 'intigo-parcels'); ?></h2>
                            <p class="intigo-section-sub"><?php esc_html_e('Fallback size when a product hasn\'t been assigned one yet.', 'intigo-parcels'); ?></p>
                        </div>
                        <div class="intigo-section-body">
                            <div class="intigo-field">
                                <div>
                                    <div class="intigo-field-label"><?php esc_html_e('Default package size', 'intigo-parcels'); ?></div>
                                    <div class="intigo-field-hint"><?php echo wp_kses_post(__('Sellers assign each product to a size in <strong>Products → edit → Intigo Delivery</strong>. This default is used only when a product hasn\'t been assigned, and as the seed for a brand-new cart line.', 'intigo-parcels')); ?></div>
                                </div>
                                <div class="intigo-field-input">
                                    <div class="intigo-package-grid" role="radiogroup" aria-label="<?php esc_attr_e('Default package size', 'intigo-parcels'); ?>">
                                        <?php foreach (['S','M','L','XL'] as $size): ?>
                                            <label><input type="radio" name="<?php echo esc_attr($opt); ?>[default_package_size]" value="<?php echo esc_attr($size); ?>" <?php checked($pkg, $size); ?>><?php echo esc_html($size); ?></label>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>

                    <section class="intigo-section">
                        <div class="intigo-section-head">
                            <h2 class="intigo-section-title"><?php esc_html_e('Shipping pricing', 'intigo-parcels'); ?></h2>
                            <p class="intigo-section-sub"><?php echo wp_kses_post(__('Cost shown at checkout when a customer picks <strong>Intigo Delivery</strong>, by package size.', 'intigo-parcels')); ?></p>
                        </div>
                        <div class="intigo-section-body">
                            <?php
                                $zone_status = $this->get_intigo_zone_status();
                                $with = $zone_status['with'];
                                $without = $zone_status['without'];
                                $attached_count = count($with);
                                $missing_count = count($without);
                                $add_url = wp_nonce_url(admin_url('admin-post.php?action=intigo_add_to_zones'), 'intigo_add_to_zones');
                                $wc_shipping_url = admin_url('admin.php?page=wc-settings&tab=shipping');
                            ?>
                            <style>
                                .intigo-zones-card { display:flex; gap:14px; align-items:flex-start; padding:14px 16px; border-radius:12px; margin-bottom:18px; border:1px solid; flex-wrap:wrap; }
                                .intigo-zones-card.is-ok { background:var(--intigo-success-soft); border-color:#a7f3d0; }
                                .intigo-zones-card.is-warn { background:var(--intigo-warn-soft); border-color:#fde68a; }
                                .intigo-zones-card .intigo-zones-icon { flex:0 0 auto; width:36px; height:36px; border-radius:10px; display:flex; align-items:center; justify-content:center; color:#fff; }
                                .intigo-zones-card.is-ok .intigo-zones-icon { background:var(--intigo-success); }
                                .intigo-zones-card.is-warn .intigo-zones-icon { background:#dba617; }
                                .intigo-zones-body { flex:1 1 280px; min-width:0; }
                                .intigo-zones-title { font-weight:700; color:var(--intigo-text); font-size:14px; margin:0 0 4px 0; }
                                .intigo-zones-sub { color:var(--intigo-text-soft); font-size:13px; margin:0 0 8px 0; line-height:1.5; }
                                .intigo-zones-list { display:flex; flex-wrap:wrap; gap:6px; margin-top:6px; }
                                .intigo-zones-chip { display:inline-flex; align-items:center; gap:6px; padding:3px 10px; border-radius:999px; font-size:12px; font-weight:600; background:#fff; border:1px solid var(--intigo-border); color:var(--intigo-text); }
                                .intigo-zones-chip.is-on { border-color:#a7f3d0; color:#047857; }
                                .intigo-zones-chip.is-off { border-color:#fde68a; color:#92400e; }
                                .intigo-zones-actions { display:flex; gap:8px; align-items:center; flex-wrap:wrap; flex:0 0 auto; }
                            </style>
                            <?php if (!$zone_status['ok']): ?>
                                <div class="intigo-zones-card is-warn">
                                    <span class="intigo-zones-icon"><span class="dashicons dashicons-warning"></span></span>
                                    <div class="intigo-zones-body">
                                        <p class="intigo-zones-title"><?php esc_html_e('WooCommerce shipping not detected', 'intigo-parcels'); ?></p>
                                        <p class="intigo-zones-sub"><?php esc_html_e('WooCommerce must be active for the Intigo shipping method to register.', 'intigo-parcels'); ?></p>
                                    </div>
                                </div>
                            <?php elseif ($missing_count === 0): ?>
                                <div class="intigo-zones-card is-ok">
                                    <span class="intigo-zones-icon"><span class="dashicons dashicons-yes"></span></span>
                                    <div class="intigo-zones-body">
                                        <p class="intigo-zones-title"><?php esc_html_e('Intigo Delivery is active on every shipping zone', 'intigo-parcels'); ?></p>
                                        <p class="intigo-zones-sub"><?php
                                            /* translators: %d: number of shipping zones */
                                            echo esc_html(sprintf(__('Customers will see this option at checkout in all %d zone(s).', 'intigo-parcels'), $attached_count));
                                        ?></p>
                                        <div class="intigo-zones-list">
                                            <?php foreach ($with as $z): ?>
                                                <span class="intigo-zones-chip is-on"><span class="dashicons dashicons-yes" style="font-size:14px; width:14px; height:14px;"></span><?php echo esc_html($z['name']); ?></span>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                    <div class="intigo-zones-actions">
                                        <a class="button" href="<?php echo esc_url($wc_shipping_url); ?>"><?php esc_html_e('Manage zones', 'intigo-parcels'); ?></a>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="intigo-zones-card is-warn">
                                    <span class="intigo-zones-icon"><span class="dashicons dashicons-info-outline"></span></span>
                                    <div class="intigo-zones-body">
                                        <p class="intigo-zones-title">
                                            <?php if ($attached_count === 0): ?>
                                                <?php esc_html_e('Intigo Delivery is not attached to any shipping zone yet', 'intigo-parcels'); ?>
                                            <?php else: ?>
                                                <?php
                                                /* translators: %d: number of shipping zones */
                                                echo esc_html(sprintf(__('Intigo Delivery is missing from %d zone(s)', 'intigo-parcels'), $missing_count));
                                                ?>
                                            <?php endif; ?>
                                        </p>
                                        <p class="intigo-zones-sub"><?php echo wp_kses_post(__('WooCommerce needs the method on a zone before customers see it at checkout. Click the button to add it everywhere — or do it manually in <strong>WooCommerce &rarr; Settings &rarr; Shipping</strong>.', 'intigo-parcels')); ?></p>
                                        <div class="intigo-zones-list">
                                            <?php foreach ($with as $z): ?>
                                                <span class="intigo-zones-chip is-on"><span class="dashicons dashicons-yes" style="font-size:14px; width:14px; height:14px;"></span><?php echo esc_html($z['name']); ?></span>
                                            <?php endforeach; ?>
                                            <?php foreach ($without as $z): ?>
                                                <span class="intigo-zones-chip is-off"><span class="dashicons dashicons-warning" style="font-size:14px; width:14px; height:14px;"></span><?php echo esc_html($z['name']); ?></span>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                    <div class="intigo-zones-actions">
                                        <a class="button button-primary" href="<?php echo esc_url($add_url); ?>"><?php esc_html_e('Add to all zones', 'intigo-parcels'); ?></a>
                                        <a class="button" href="<?php echo esc_url($wc_shipping_url); ?>"><?php esc_html_e('Manage zones', 'intigo-parcels'); ?></a>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <style>
                                .intigo-price-grid { display:grid; grid-template-columns: repeat(2, 1fr); gap:12px; max-width:640px; }
                                @media (min-width: 720px) { .intigo-price-grid { grid-template-columns: repeat(4, 1fr); } }
                                .intigo-price-card { display:flex; flex-direction:column; gap:6px; padding:14px; border:1px solid #e2e8f0; border-radius:12px; background:#fff; }
                                .intigo-price-card .intigo-price-code { display:inline-flex; align-items:center; justify-content:center; width:30px; height:30px; border-radius:8px; background:#f1f5f9; color:#0f172a; font-weight:700; font-size:13px; }
                                .intigo-price-card .intigo-price-label { font-size:12px; color:#64748b; }
                                .intigo-price-card .intigo-price-input-wrap { position:relative; }
                                .intigo-price-card input[type=number] { width:100%; min-height:38px; padding:0 14px 0 38px; border:1px solid #c7d2dc; border-radius:8px; font-size:14px; font-weight:600; color:#0f172a; background:#fbfdff; }
                                .intigo-price-card input[type=number]:focus { border-color:#2271b1; box-shadow:0 0 0 3px rgba(34,113,177,.15); outline:none; background:#fff; }
                                .intigo-price-card .intigo-price-currency { position:absolute; left:12px; top:50%; transform:translateY(-50%); color:#64748b; font-weight:600; font-size:13px; pointer-events:none; }
                            </style>
                            <div class="intigo-price-grid">
                                <?php
                                $price_rows = [
                                    ['code' => 'S',  'name' => __('Small', 'intigo-parcels'),       'key' => 'size_price_s',  'val' => $price_s],
                                    ['code' => 'M',  'name' => __('Medium', 'intigo-parcels'),      'key' => 'size_price_m',  'val' => $price_m],
                                    ['code' => 'L',  'name' => __('Large', 'intigo-parcels'),       'key' => 'size_price_l',  'val' => $price_l],
                                    ['code' => 'XL', 'name' => __('Extra large', 'intigo-parcels'), 'key' => 'size_price_xl', 'val' => $price_xl],
                                ];
                                foreach ($price_rows as $row): ?>
                                    <div class="intigo-price-card">
                                        <div style="display:flex; align-items:center; gap:10px;">
                                            <span class="intigo-price-code"><?php echo esc_html($row['code']); ?></span>
                                            <div>
                                                <div style="font-weight:600; color:#0f172a; font-size:13.5px;"><?php echo esc_html($row['name']); ?></div>
                                                <div class="intigo-price-label"><?php esc_html_e('Per parcel', 'intigo-parcels'); ?></div>
                                            </div>
                                        </div>
                                        <div class="intigo-price-input-wrap">
                                            <span class="intigo-price-currency"><?php echo esc_html($currency_symbol !== '' ? $currency_symbol : 'DT'); ?></span>
                                            <input type="number" min="0" step="0.001" name="<?php echo esc_attr($opt); ?>[<?php echo esc_attr($row['key']); ?>]" value="<?php echo esc_attr($row['val']); ?>">
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <p class="intigo-field-hint" style="margin-top:12px;"><?php echo wp_kses_post(__('Prices use your store currency. Make sure WooCommerce shipping zones include <em>Intigo Delivery</em> under <strong>WooCommerce &rarr; Settings &rarr; Shipping</strong>.', 'intigo-parcels')); ?></p>
                        </div>
                    </section>

                    <details class="intigo-tech">
                        <summary>
                            <span><?php esc_html_e('Technical details', 'intigo-parcels'); ?></span>
                            <span style="color:#94a3b8; font-weight:500; font-size:12px;"><?php esc_html_e('Endpoints & reference URLs', 'intigo-parcels'); ?></span>
                        </summary>
                        <div class="intigo-tech-body">
                            <p style="margin-top:0;"><strong><?php esc_html_e('API base URL', 'intigo-parcels'); ?></strong> <?php esc_html_e('(auto-selected from environment):', 'intigo-parcels'); ?></p>
                            <ul style="margin:6px 0 14px 18px;">
                                <li><?php esc_html_e('Sandbox:', 'intigo-parcels'); ?> <code>https://dev-api.intigo.net/api</code></li>
                                <li><?php esc_html_e('Production:', 'intigo-parcels'); ?> <code>https://api.intigo.net/api</code></li>
                            </ul>
                            <p><strong><?php esc_html_e('Lookup endpoints', 'intigo-parcels'); ?></strong>:</p>
                            <ul style="margin:6px 0 0 18px;">
                                <li><code>/api/v3/regions/cities</code></li>
                                <li><code>/api/v3/regions/cities/{city_id}/districts</code></li>
                                <li><code>/api/v3/regions/districts/{district_id}/neighborhoods</code></li>
                            </ul>
                        </div>
                    </details>

                    <div class="intigo-save-bar">
                        <?php submit_button(__('Save changes', 'intigo-parcels'), 'primary', 'submit', false); ?>
                        <span style="color:#64748b; font-size:13px;"><?php esc_html_e('Changes apply immediately to new orders.', 'intigo-parcels'); ?></span>
                    </div>
                </form>
            </div>
        </div>
        <?php
    }

    public function render_dashboard() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('Unauthorized', 'intigo-parcels'));
        }
        if (!$this->is_intigo_logged_in()) {
            $this->render_login_interface(__('Please login to Intigo to manage system interactions.', 'intigo-parcels'));
            return;
        }
        $orders = function_exists('wc_get_orders') ? wc_get_orders(['type' => 'shop_order', 'limit' => 20, 'orderby' => 'date', 'order' => 'DESC']) : [];
        $stats_orders = function_exists('wc_get_orders') ? wc_get_orders(['type' => 'shop_order', 'limit' => 200, 'orderby' => 'date', 'order' => 'DESC']) : $orders;
        $metrics = $this->compute_dashboard_metrics($stats_orders);
        $total_orders_for_chart = max(1, intval($metrics['total_orders']));
        $product_posts = function_exists('wp_count_posts') ? wp_count_posts('product') : null;
        $metrics['total_products'] = ($product_posts && isset($product_posts->publish)) ? intval($product_posts->publish) : 0;
        $logs = array_slice($this->get_logs(), 0, 8);
        ?>
        <div class="wrap">
            <?php $this->render_responsive_styles(); ?>
            <?php $this->render_interface_nav('intigo-dashboard'); ?>
            <?php $this->render_snackbar(); ?>
            <?php $this->render_page_header(__('Dashboard', 'intigo-parcels'), __('Operational overview of your Intigo integration &mdash; orders, parcels and recent activity at a glance.', 'intigo-parcels'), __('Overview', 'intigo-parcels')); ?>
            <div style="display:flex; flex-wrap:wrap; gap:8px; margin:0 0 16px 0;">
                <a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=intigo-manage-orders')); ?>"><span class="dashicons dashicons-cart" style="margin:3px 6px 0 -2px; font-size:16px; width:16px; height:16px;"></span><?php esc_html_e('Manage orders', 'intigo-parcels'); ?></a>
                <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=intigo-logs')); ?>"><span class="dashicons dashicons-list-view" style="margin:3px 6px 0 -2px; font-size:16px; width:16px; height:16px;"></span><?php esc_html_e('View logs', 'intigo-parcels'); ?></a>
                <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=intigo-parcels-settings')); ?>"><span class="dashicons dashicons-admin-generic" style="margin:3px 6px 0 -2px; font-size:16px; width:16px; height:16px;"></span><?php esc_html_e('Settings', 'intigo-parcels'); ?></a>
            </div>
            <div class="intigo-kpis">
                <div class="intigo-kpi"><div class="intigo-kpi-label"><?php esc_html_e('Total orders', 'intigo-parcels'); ?></div><div class="intigo-kpi-value"><?php echo esc_html($metrics['total_orders']); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label"><?php esc_html_e('Orders in Intigo', 'intigo-parcels'); ?></div><div class="intigo-kpi-value"><?php echo esc_html($metrics['with_parcel']); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label"><?php esc_html_e('Orders not in Intigo', 'intigo-parcels'); ?></div><div class="intigo-kpi-value"><?php echo esc_html(max(0, intval($metrics['total_orders']) - intval($metrics['with_parcel']))); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label"><?php esc_html_e('Need verification', 'intigo-parcels'); ?></div><div class="intigo-kpi-value"><?php echo esc_html($metrics['need_confirmation']); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label"><?php esc_html_e('Missing data', 'intigo-parcels'); ?></div><div class="intigo-kpi-value"><?php echo esc_html($metrics['missing_data']); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label"><?php esc_html_e('Total products', 'intigo-parcels'); ?></div><div class="intigo-kpi-value"><?php echo esc_html($metrics['total_products']); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label"><?php esc_html_e('Total sales', 'intigo-parcels'); ?></div><div class="intigo-kpi-value"><?php echo wp_kses_post(wc_price($metrics['total_sales'])); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label"><?php esc_html_e('Average order', 'intigo-parcels'); ?></div><div class="intigo-kpi-value"><?php echo wp_kses_post(wc_price($metrics['avg_order_value'])); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label"><?php esc_html_e('Intigo coverage', 'intigo-parcels'); ?></div><div class="intigo-kpi-value"><?php echo esc_html($metrics['coverage_rate']); ?>%</div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label"><?php esc_html_e('Ready for shipment', 'intigo-parcels'); ?></div><div class="intigo-kpi-value"><?php echo esc_html($metrics['ready_for_shipment']); ?></div></div>
            </div>
            <div class="intigo-charts">
                <div class="intigo-chart-card">
                    <h3 class="intigo-chart-title"><?php esc_html_e('Order Progress', 'intigo-parcels'); ?></h3>
                    <div class="intigo-bar-row"><div class="intigo-bar-meta"><span><?php esc_html_e('Orders in Intigo', 'intigo-parcels'); ?></span><strong><?php echo esc_html($metrics['with_parcel']); ?></strong></div><div class="intigo-bar-track"><div class="intigo-bar-fill intigo-fill-blue" style="width:<?php echo esc_attr(round(($metrics['with_parcel'] / $total_orders_for_chart) * 100, 1)); ?>%;"></div></div></div>
                    <div class="intigo-bar-row"><div class="intigo-bar-meta"><span><?php esc_html_e('Ready for shipment', 'intigo-parcels'); ?></span><strong><?php echo esc_html($metrics['ready_for_shipment']); ?></strong></div><div class="intigo-bar-track"><div class="intigo-bar-fill intigo-fill-green" style="width:<?php echo esc_attr(round(($metrics['ready_for_shipment'] / $total_orders_for_chart) * 100, 1)); ?>%;"></div></div></div>
                    <div class="intigo-bar-row"><div class="intigo-bar-meta"><span><?php esc_html_e('Bordereau generated', 'intigo-parcels'); ?></span><strong><?php echo esc_html($metrics['with_bordereau']); ?></strong></div><div class="intigo-bar-track"><div class="intigo-bar-fill intigo-fill-green" style="width:<?php echo esc_attr(round(($metrics['with_bordereau'] / $total_orders_for_chart) * 100, 1)); ?>%;"></div></div></div>
                </div>
                <div class="intigo-chart-card">
                    <h3 class="intigo-chart-title"><?php esc_html_e('Recent plugin activity', 'intigo-parcels'); ?></h3>
                    <?php if (empty($logs)): ?>
                        <div class="intigo-empty" style="padding:18px 0;">
                            <div class="intigo-empty-icon"><span class="dashicons dashicons-clock"></span></div>
                            <div class="intigo-empty-title"><?php esc_html_e('No activity yet', 'intigo-parcels'); ?></div>
                            <div style="font-size:12.5px;"><?php esc_html_e('Actions will appear here once you start using Intigo.', 'intigo-parcels'); ?></div>
                        </div>
                    <?php else: ?>
                        <ul style="list-style:none; margin:0; padding:0; display:flex; flex-direction:column; gap:8px;">
                            <?php foreach ($logs as $log):
                                $action = (string) ($log['action'] ?? '');
                                $is_error = stripos($action, 'fail') !== false || stripos($action, 'error') !== false;
                                $is_success = stripos($action, 'success') !== false || stripos($action, 'created') !== false;
                                $dot_color = '#94a3b8';
                                if ($is_error) { $dot_color = '#dc2626'; }
                                elseif ($is_success) { $dot_color = '#16a34a'; }
                                ?>
                                <li style="display:flex; gap:10px; align-items:flex-start; padding:8px 10px; background:#fbfdff; border:1px solid #f1f5f9; border-radius:8px;">
                                    <span style="display:inline-block; width:8px; height:8px; border-radius:50%; background:<?php echo esc_attr($dot_color); ?>; margin-top:6px; flex:0 0 auto;"></span>
                                    <div style="flex:1; min-width:0;">
                                        <div style="font-size:13px; color:#0f172a; font-weight:500;"><?php echo esc_html($action); ?></div>
                                        <div style="font-size:11.5px; color:#64748b; margin-top:2px;"><?php echo esc_html((string) ($log['time'] ?? '')); ?> &middot; <?php echo esc_html((string) ($log['actor'] ?? 'system')); ?></div>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
    }

    public function render_panel() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('Unauthorized', 'intigo-parcels'));
        }
        if (!$this->is_intigo_logged_in()) {
            $this->render_login_interface(__('Please login to Intigo to manage system interactions.', 'intigo-parcels'));
            return;
        }
        $per_page = 10;
        $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        $orders = [];
        $total_pages = 1;
        $total_items = 0;
        if (function_exists('wc_get_orders')) {
            $total_ids = wc_get_orders([
                'type' => 'shop_order',
                'limit' => -1,
                'return' => 'ids',
            ]);
            $total_items = is_array($total_ids) ? count($total_ids) : 0;
            $total_pages = max(1, intval(ceil($total_items / $per_page)));
            $orders = wc_get_orders([
                'type' => 'shop_order',
                'limit' => $per_page,
                'offset' => ($current_page - 1) * $per_page,
                'orderby' => 'date',
                'order' => 'DESC',
            ]);
            if (!is_array($orders)) {
                $orders = [];
            }
        }
        $this->mark_orders_as_seen($orders);
        $metrics_source = function_exists('wc_get_orders') ? wc_get_orders(['type' => 'shop_order', 'limit' => 200, 'orderby' => 'date', 'order' => 'DESC']) : $orders;
        $metrics = $this->compute_dashboard_metrics($metrics_source);
        $total_orders_for_chart = max(1, intval($metrics['total_orders']));
        ?>
        <div class="wrap">
            <?php $this->render_responsive_styles(); ?>
            <?php $this->render_interface_nav('intigo-manage-orders'); ?>
            <?php $this->render_snackbar(); ?>
            <?php
                $logout_url = wp_nonce_url(admin_url('admin-post.php?action=intigo_logout'), 'intigo_logout');
                $extra_pills = '<span class="intigo-pill-status intigo-pill-neutral"><span class="dashicons dashicons-admin-users" style="font-size:13px; width:13px; height:13px;"></span>'
                    . esc_html($this->get_intigo_login_label())
                    . '</span>'
                    . '<a class="button button-small" href="' . esc_url($logout_url) . '">' . esc_html__('Logout', 'intigo-parcels') . '</a>';
                $this->render_page_header(__('Manage Orders', 'intigo-parcels'), __('Review WooCommerce orders, complete Intigo metadata and run shipment actions.', 'intigo-parcels'), __('Operations', 'intigo-parcels'), $extra_pills);
            ?>
            <?php $this->render_processing_mode_banner(); ?>

            <style>
                .intigo-actions .button { margin: 0 6px 6px 0; border-radius:8px; }
                .intigo-orders-head { display:flex; justify-content:space-between; align-items:flex-start; gap:12px; flex-wrap:wrap; margin-bottom:12px; }
                .intigo-orders-head h2 { margin:0; }
                .intigo-orders-head form { display:flex; align-items:center; gap:8px; flex-wrap:wrap; margin:0; }
                .intigo-orders-head small { color:var(--intigo-muted); }
                .intigo-zone-cell { min-width:220px; max-width:320px; }
                .intigo-zone-path { color:var(--intigo-text); font-weight:500; margin:6px 0 2px 0; line-height:1.4; }
                .intigo-zone-reason { font-size:12px; line-height:1.4; margin:2px 0; }
                .intigo-zone-reason.is-review { color:#92400e; }
                .intigo-zone-reason.is-blocked { color:#be123c; }
                .intigo-zone-reason.is-muted { color:var(--intigo-muted); }
                .intigo-zone-typed { font-size:11.5px; color:#94a3b8; margin-top:6px; line-height:1.4; word-break:break-word; }
                .intigo-zone-actions { display:flex; gap:6px; flex-wrap:wrap; margin-top:6px; }
                .intigo-zone-actions .button { margin:0; }
                .intigo-row-error td { background:#fff1f2 !important; color:#9f1239 !important; }

                /* Edit window */
                .intigo-zm-backdrop { position:fixed; inset:0; background:rgba(15,23,42,.5); display:flex; align-items:center; justify-content:center; z-index:99999; padding:12px; box-sizing:border-box; }
                .intigo-zm-backdrop[hidden] { display:none; }
                .intigo-zm { width:min(720px, 100%); max-height:calc(100vh - 24px); display:flex; flex-direction:column; background:#fff; border-radius:14px; border:1px solid var(--intigo-border); box-shadow:0 24px 60px rgba(15,23,42,.28); overflow:hidden; }
                .intigo-zm form { display:flex; flex-direction:column; min-height:0; flex:1 1 auto; margin:0; }
                .intigo-zm-header { display:flex; justify-content:space-between; align-items:center; gap:12px; padding:14px 18px; border-bottom:1px solid var(--intigo-border); }
                .intigo-zm-header h2 { margin:0; font-size:16px; font-weight:600; color:var(--intigo-text); line-height:1.3; }
                .intigo-zm-close { background:transparent; border:0; cursor:pointer; color:#64748b; border-radius:8px; padding:4px; line-height:0; }
                .intigo-zm-close:hover, .intigo-zm-close:focus { background:#f1f5f9; color:#0f172a; }
                .intigo-zm-body { padding:16px 18px; overflow-y:auto; flex:1 1 auto; }
                .intigo-zm-footer { display:flex; justify-content:flex-end; align-items:center; gap:8px; flex-wrap:wrap; padding:12px 18px; border-top:1px solid var(--intigo-border); background:#f8fafc; }
                .intigo-zm-footer .intigo-zm-why { margin-inline-end:auto; font-size:12px; color:var(--intigo-muted); }
                .intigo-zm-card { border:1px solid var(--intigo-border); background:#f8fafc; border-radius:10px; padding:10px 12px; margin-bottom:12px; font-size:13px; color:var(--intigo-text-soft); line-height:1.5; }
                .intigo-zm-card-title { font-size:11px; font-weight:600; letter-spacing:.04em; text-transform:uppercase; color:var(--intigo-muted); margin-bottom:4px; }
                .intigo-zm-card .intigo-zm-typed-name { color:var(--intigo-text); font-weight:600; }
                .intigo-zm-detect { display:flex; gap:10px; align-items:flex-start; margin-bottom:14px; font-size:13px; }
                .intigo-zm-detect-text { color:var(--intigo-text-soft); line-height:1.45; }
                .intigo-zm-field { margin-bottom:10px; }
                .intigo-zm-field label { display:block; font-weight:600; margin-bottom:4px; color:var(--intigo-text); font-size:13px; }
                .intigo-zm-field input[type=text], .intigo-zm-field input[type=tel] { width:100%; max-width:none; min-height:38px; border:1px solid #cbd5e1; border-radius:9px; padding:0 10px; background:#fff; box-sizing:border-box; }
                .intigo-zm-field textarea { width:100%; max-width:none; border:1px solid #cbd5e1; border-radius:9px; padding:7px 10px; background:#fff; box-sizing:border-box; resize:vertical; line-height:1.45; min-height:38px; }
                .intigo-zm-field textarea:focus { border-color:#4F46E5; box-shadow:0 0 0 3px rgba(79,70,229,.15); outline:none; }
                .intigo-zm-optional { font-weight:400; color:var(--intigo-muted); }
                .intigo-zm-hint.is-accent { color:#4338ca; }
                .intigo-zm-hint[hidden], .intigo-zm-body [hidden] { display:none; }
                .intigo-zm-detect.is-detecting .intigo-zone-badge::before, .intigo-zone-badge.is-detecting::before { animation:intigo-zm-pulse 1s ease-in-out infinite; }
                @keyframes intigo-zm-pulse { 50% { opacity:.25; } }
                .intigo-zm-field select { width:100%; max-width:none; min-height:38px; border:1px solid #cbd5e1; border-radius:9px; padding:0 28px 0 10px; box-sizing:border-box; background-color:#fff; background-repeat:no-repeat; background-position:right 8px top 55%; }
                .rtl .intigo-zm-field select { background-position:left 8px top 55%; padding-right:10px; padding-left:28px; }
                .intigo-zm-field select:disabled { background-color:#f8fafc; color:#94a3b8; }
                .intigo-zm-field input:focus, .intigo-zm-field select:focus { border-color:#4F46E5; box-shadow:0 0 0 3px rgba(79,70,229,.15); outline:none; }
                .intigo-zm-hint { display:block; font-size:12px; color:var(--intigo-muted); margin-top:4px; }
                .intigo-zm-grid { display:grid; grid-template-columns:repeat(3, minmax(0, 1fr)); gap:10px; }
                .intigo-zm-grid-2 { display:grid; grid-template-columns:repeat(2, minmax(0, 1fr)); gap:10px; }
                .intigo-zm-open { overflow:hidden; }
                @media (max-width: 600px) {
                    .intigo-zm-grid, .intigo-zm-grid-2 { grid-template-columns:1fr; }
                    .intigo-zm-footer .button { width:auto; margin:0; }
                    .intigo-zm-footer .intigo-zm-why { flex-basis:100%; }
                }
                /* Legacy "More actions" window */
                .intigo-modal-backdrop { position:fixed; inset:0; background:rgba(15,23,42,.45); display:none; align-items:center; justify-content:center; z-index:9999; }
                .intigo-modal { width:min(620px, 94vw); background:#fff; border-radius:14px; border:1px solid var(--intigo-border); box-shadow:0 20px 50px rgba(15,23,42,.22); }
                .intigo-modal-header { padding:14px 16px; border-bottom:1px solid var(--intigo-border-soft); display:flex; justify-content:space-between; align-items:center; background:#f8fafc; border-radius:14px 14px 0 0; }
                .intigo-modal-body { padding:16px; }
                .intigo-modal-open { overflow:hidden; }
                .intigo-form-row { margin-bottom:12px; }
                .intigo-form-row label { display:block; margin-bottom:6px; font-weight:600; color:var(--intigo-text); }
                .intigo-form-row select { width:100%; border:1px solid #c7d2dc; border-radius:9px; min-height:38px; padding:0 10px; background:#fff; }
            </style>

            <div class="intigo-kpis">
                <div class="intigo-kpi"><div class="intigo-kpi-label"><?php esc_html_e('Total orders', 'intigo-parcels'); ?></div><div class="intigo-kpi-value"><?php echo esc_html($metrics['total_orders']); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label"><?php esc_html_e('Orders in Intigo', 'intigo-parcels'); ?></div><div class="intigo-kpi-value"><?php echo esc_html($metrics['with_parcel']); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label"><?php esc_html_e('Need verification', 'intigo-parcels'); ?></div><div class="intigo-kpi-value"><?php echo esc_html($metrics['need_confirmation']); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label"><?php esc_html_e('Missing data', 'intigo-parcels'); ?></div><div class="intigo-kpi-value"><?php echo esc_html($metrics['missing_data']); ?></div></div>
            </div>
            <div class="intigo-charts">
                <div class="intigo-chart-card">
                    <h3 class="intigo-chart-title"><?php esc_html_e('Order Progress', 'intigo-parcels'); ?></h3>
                    <div class="intigo-bar-row">
                        <div class="intigo-bar-meta"><span><?php esc_html_e('Orders in Intigo', 'intigo-parcels'); ?></span><strong><?php echo esc_html($metrics['with_parcel']); ?></strong></div>
                        <div class="intigo-bar-track"><div class="intigo-bar-fill intigo-fill-blue" style="width:<?php echo esc_attr(round(($metrics['with_parcel'] / $total_orders_for_chart) * 100, 1)); ?>%;"></div></div>
                    </div>
                    <div class="intigo-bar-row">
                        <div class="intigo-bar-meta"><span><?php esc_html_e('Ready for shipment', 'intigo-parcels'); ?></span><strong><?php echo esc_html($metrics['ready_for_shipment']); ?></strong></div>
                        <div class="intigo-bar-track"><div class="intigo-bar-fill intigo-fill-green" style="width:<?php echo esc_attr(round(($metrics['ready_for_shipment'] / $total_orders_for_chart) * 100, 1)); ?>%;"></div></div>
                    </div>
                    <div class="intigo-bar-row">
                        <div class="intigo-bar-meta"><span><?php esc_html_e('Bordereau generated', 'intigo-parcels'); ?></span><strong><?php echo esc_html($metrics['with_bordereau']); ?></strong></div>
                        <div class="intigo-bar-track"><div class="intigo-bar-fill intigo-fill-green" style="width:<?php echo esc_attr(round(($metrics['with_bordereau'] / $total_orders_for_chart) * 100, 1)); ?>%;"></div></div>
                    </div>
                </div>
                <div class="intigo-chart-card">
                    <h3 class="intigo-chart-title"><?php esc_html_e('Verification Funnel', 'intigo-parcels'); ?></h3>
                    <div class="intigo-bar-row">
                        <div class="intigo-bar-meta"><span><?php esc_html_e('Verified', 'intigo-parcels'); ?></span><strong><?php echo esc_html($metrics['verified']); ?></strong></div>
                        <div class="intigo-bar-track"><div class="intigo-bar-fill intigo-fill-green" style="width:<?php echo esc_attr(round(($metrics['verified'] / $total_orders_for_chart) * 100, 1)); ?>%;"></div></div>
                    </div>
                    <div class="intigo-bar-row">
                        <div class="intigo-bar-meta"><span><?php esc_html_e('Need confirmation', 'intigo-parcels'); ?></span><strong><?php echo esc_html($metrics['need_confirmation']); ?></strong></div>
                        <div class="intigo-bar-track"><div class="intigo-bar-fill intigo-fill-yellow" style="width:<?php echo esc_attr(round(($metrics['need_confirmation'] / $total_orders_for_chart) * 100, 1)); ?>%;"></div></div>
                    </div>
                    <div class="intigo-bar-row">
                        <div class="intigo-bar-meta"><span><?php esc_html_e('Missing data', 'intigo-parcels'); ?></span><strong><?php echo esc_html($metrics['missing_data']); ?></strong></div>
                        <div class="intigo-bar-track"><div class="intigo-bar-fill intigo-fill-gray" style="width:<?php echo esc_attr(round(($metrics['missing_data'] / $total_orders_for_chart) * 100, 1)); ?>%;"></div></div>
                    </div>
                </div>
            </div>

            <div class="intigo-card">
            <div class="intigo-orders-head">
                <h2><?php esc_html_e('Orders', 'intigo-parcels'); ?></h2>
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <input type="hidden" name="action" value="intigo_detect_addresses">
                    <?php wp_nonce_field('intigo_detect_addresses'); ?>
                    <small><?php esc_html_e('Matches the addresses of orders not sent yet to Intigo delivery zones.', 'intigo-parcels'); ?></small>
                    <button type="submit" class="button"><?php esc_html_e('Detect addresses', 'intigo-parcels'); ?></button>
                </form>
            </div>
            <div class="intigo-table-wrap">
            <table class="widefat striped">
                <thead>
                    <tr>
                        <th><?php esc_html_e('Order', 'intigo-parcels'); ?></th>
                        <th><?php esc_html_e('Status', 'intigo-parcels'); ?></th>
                        <th><?php esc_html_e('Total', 'intigo-parcels'); ?></th>
                        <th><?php esc_html_e('Destination', 'intigo-parcels'); ?></th>
                        <th><?php esc_html_e('Package', 'intigo-parcels'); ?></th>
                        <th><?php esc_html_e('Parcel NID', 'intigo-parcels'); ?></th>
                        <th><?php esc_html_e('Intigo Metadata', 'intigo-parcels'); ?></th>
                        <th><?php esc_html_e('Actions', 'intigo-parcels'); ?></th>
                        <th style="min-width:240px;"><?php esc_html_e('Notes', 'intigo-parcels'); ?></th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($orders as $order): ?>
                    <?php
                    ob_start();
                    try {
                    $order_id = $order->get_id();
                    $nid = (string) $order->get_meta('_intigo_parcel_nid');
                    $bordereau_url = wp_nonce_url(admin_url('admin-post.php?action=intigo_order_action&op=bordereau&order_id=' . $order_id), 'intigo_order_action_' . $order_id . '_bordereau');
                    $sync_url = wp_nonce_url(admin_url('admin-post.php?action=intigo_order_action&op=sync_update&order_id=' . $order_id), 'intigo_order_action_' . $order_id . '_sync_update');
                    $cancel_url = wp_nonce_url(admin_url('admin-post.php?action=intigo_order_action&op=cancel&order_id=' . $order_id), 'intigo_order_action_' . $order_id . '_cancel');
                    $relance_url = wp_nonce_url(admin_url('admin-post.php?action=intigo_order_action&op=relance&order_id=' . $order_id), 'intigo_order_action_' . $order_id . '_relance');
                    $delay_url = wp_nonce_url(admin_url('admin-post.php?action=intigo_order_action&op=report_delay&order_id=' . $order_id), 'intigo_order_action_' . $order_id . '_report_delay');
                    $download_url = wp_nonce_url(admin_url('admin-post.php?action=intigo_download_bordereau&order_id=' . $order_id), 'intigo_download_bordereau_' . $order_id);
                    $stored_bordereau_url = (string) $order->get_meta('_intigo_bordereau_url');
                    $print_url = $stored_bordereau_url !== '' ? $stored_bordereau_url : '';
                    $zone = Intigo_Address_Resolver::display_state($order);
                    $pkg = (string) $order->get_meta('_intigo_package_size');
                    $api_target = (string) $order->get_meta('_intigo_api_target_used');
                    $last_status = (string) $order->get_meta('_intigo_last_status');
                    $last_sync = (string) $order->get_meta('_intigo_last_sync_at');
                    $last_error = (string) $order->get_meta('_intigo_last_error');
                    $last_attempt_at = (string) $order->get_meta('_intigo_last_attempt_at');
                    $ops_status = $this->compute_automatic_ops_status($zone['city_id'] > 0 ? (string) $zone['city_id'] : '', $zone['district_id'] > 0 ? (string) $zone['district_id'] : '', $pkg, $nid, $stored_bordereau_url);
                    $tags = $nid !== '' ? $this->build_order_tags('', '', $pkg, $nid, $ops_status) : [];
                    $has_parcel_in_intigo = ($nid !== '');
                    $can_generate_bordereau = $has_parcel_in_intigo;
                    ?>
                    <tr data-intigo-order="<?php echo esc_attr($order_id); ?>">
                        <td>
                            <a href="<?php echo esc_url($order->get_edit_order_url()); ?>">#<?php echo esc_html($order->get_order_number()); ?></a>
                            <?php if ($this->is_order_new($order_id)): ?>
                                <span class="intigo-pill intigo-pill-info"><?php esc_html_e('NEW', 'intigo-parcels'); ?></span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo esc_html(wc_get_order_status_name($order->get_status())); ?></td>
                        <td><?php echo wp_kses_post($order->get_formatted_order_total()); ?></td>
                        <td class="intigo-zone-cell"><?php echo $this->zone_cell_html($order, $zone); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside. ?></td>
                        <td><?php echo esc_html($pkg !== '' ? strtoupper($pkg) : '—'); ?></td>
                        <td><?php echo $nid !== '' ? esc_html($nid) : '<span style="color:#777;">—</span>'; ?></td>
                        <td>
                            <div><small><?php esc_html_e('API:', 'intigo-parcels'); ?> <?php echo esc_html($api_target !== '' ? $api_target : '—'); ?></small></div>
                            <div><small><?php esc_html_e('Last status:', 'intigo-parcels'); ?> <?php echo esc_html($last_status !== '' ? $last_status : '—'); ?></small></div>
                            <div><small><?php esc_html_e('Last sync:', 'intigo-parcels'); ?> <?php echo esc_html($last_sync !== '' ? $last_sync : '—'); ?></small></div>
                            <div style="margin-top:4px; display:flex; gap:4px; flex-wrap:wrap;">
                                <?php if ($nid !== ''): ?>
                                    <span class="intigo-pill intigo-pill-ok"><?php esc_html_e('Parcel Created', 'intigo-parcels'); ?></span>
                                <?php else: ?>
                                    <span class="intigo-pill intigo-pill-warn"><?php esc_html_e('Not Sent', 'intigo-parcels'); ?></span>
                                <?php endif; ?>
                                <?php foreach ($tags as $tag): ?>
                                    <span class="intigo-pill <?php echo esc_attr($tag['class']); ?>"><?php echo esc_html($tag['label']); ?></span>
                                <?php endforeach; ?>
                            </div>
                        </td>
                        <td>
                            <div class="intigo-actions">
                                <span class="intigo-send-slot"><?php echo $this->send_button_html($order, $zone); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside. ?></span>
                                <?php if ($has_parcel_in_intigo): ?>
                                    <span title="<?php esc_attr_e('This parcel is already in Intigo. Please edit it on the Intigo website.', 'intigo-parcels'); ?>"><button
                                        type="button"
                                        class="button button-small"
                                        disabled
                                        title="<?php esc_attr_e('This parcel is already in Intigo. Please edit it on the Intigo website.', 'intigo-parcels'); ?>"
                                    ><?php esc_html_e('Edit', 'intigo-parcels'); ?></button></span>
                                <?php else: ?>
                                    <button
                                        type="button"
                                        class="button button-small intigo-open-zone-modal"
                                        <?php foreach ($this->edit_button_data($order, $zone) as $data_key => $data_value) {
                                            echo ' data-' . esc_attr(strtolower(preg_replace('/([A-Z])/', '-$1', $data_key))) . '="' . esc_attr($data_value) . '"';
                                        } ?>
                                    ><?php esc_html_e('Edit', 'intigo-parcels'); ?></button>
                                <?php endif; ?>
                                <?php if ($can_generate_bordereau): ?>
                                    <a class="button button-small" href="<?php echo esc_url($bordereau_url); ?>"><?php esc_html_e('Generate Bordereau', 'intigo-parcels'); ?></a>
                                <?php else: ?>
                                    <span title="<?php esc_attr_e('Send the order to Intigo first.', 'intigo-parcels'); ?>"><button type="button" class="button button-small" disabled title="<?php esc_attr_e('Send the order to Intigo first.', 'intigo-parcels'); ?>"><?php esc_html_e('Generate Bordereau', 'intigo-parcels'); ?></button></span>
                                <?php endif; ?>
                            <button
                                type="button"
                                class="button button-small intigo-open-actions-modal"
                                data-order-id="<?php echo esc_attr($order_id); ?>"
                                data-sync-url="<?php echo esc_url($sync_url); ?>"
                                data-relance-url="<?php echo esc_url($relance_url); ?>"
                                data-delay-url="<?php echo esc_url($delay_url); ?>"
                                data-cancel-url="<?php echo esc_url($cancel_url); ?>"
                                data-has-nid="<?php echo esc_attr($nid !== '' ? '1' : '0'); ?>"
                            ><?php esc_html_e('More Actions', 'intigo-parcels'); ?></button>
                            <?php if ($stored_bordereau_url !== ''): ?>
                                <a class="button button-small button-primary" href="<?php echo esc_url($download_url); ?>"><?php esc_html_e('Download', 'intigo-parcels'); ?></a>
                                <a class="button button-small" target="_blank" rel="noopener noreferrer" href="<?php echo esc_url($print_url); ?>"><?php esc_html_e('Print', 'intigo-parcels'); ?></a>
                            <?php endif; ?>
                            </div>
                        </td>
                        <td class="intigo-notes-cell" style="vertical-align:top; max-width:320px;">
                            <?php if ($last_error !== '' && $nid === ''): ?>
                                <div style="padding:8px 10px; background:#fef2f2; border:1px solid #fecaca; border-radius:8px; color:#991b1b; font-size:12px;">
                                    <div style="display:flex; align-items:center; gap:6px; font-weight:700; margin-bottom:4px;">
                                        <span style="display:inline-flex; width:18px; height:18px; border-radius:50%; background:#dc2626; color:#fff; align-items:center; justify-content:center; font-size:11px; flex:0 0 auto;">!</span>
                                        <?php esc_html_e('Auto-push failed', 'intigo-parcels'); ?>
                                    </div>
                                    <div style="color:#7f1d1d; word-break:break-word;"><?php echo esc_html($last_error); ?></div>
                                    <?php if ($last_attempt_at !== ''): ?>
                                        <div style="color:#a16f6f; font-size:11px; margin-top:4px;"><?php echo esc_html($last_attempt_at); ?></div>
                                    <?php endif; ?>
                                </div>
                            <?php elseif ($nid !== ''): ?>
                                <div style="padding:8px 10px; background:#ecfdf5; border:1px solid #a7f3d0; border-radius:8px; color:#065f46; font-size:12px;">
                                    <div style="display:flex; align-items:center; gap:6px; font-weight:700; margin-bottom:2px;">
                                        <span style="display:inline-flex; width:18px; height:18px; border-radius:50%; background:#16a34a; color:#fff; align-items:center; justify-content:center; font-size:11px; flex:0 0 auto;">✓</span>
                                        <?php esc_html_e('Sent to Intigo', 'intigo-parcels'); ?>
                                    </div>
                                    <?php if ($last_attempt_at !== ''): ?>
                                        <div style="color:#047857; font-size:11px;"><?php
                                        /* translators: %s: date and time of the last push attempt */
                                        echo esc_html(sprintf(__('at %s', 'intigo-parcels'), $last_attempt_at));
                                        ?></div>
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <span style="color:#94a3b8; font-size:12px;">—</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php
                        echo ob_get_clean(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped above.
                    } catch (\Throwable $e) {
                        ob_end_clean();
                        $row_order_id = is_object($order) && method_exists($order, 'get_id') ? intval($order->get_id()) : 0;
                        $this->add_log('manage_orders_row_error', 'order_id=' . $row_order_id . '; ' . get_class($e) . ': ' . $e->getMessage() . ' @ ' . basename($e->getFile()) . ':' . $e->getLine());
                        ?>
                        <tr class="intigo-row-error"><td colspan="9"><span class="intigo-pill intigo-pill-warn">#<?php echo esc_html($row_order_id); ?></span> <?php /* translators: %s: technical error message. */ echo esc_html(sprintf(__('This order could not be displayed: %s', 'intigo-parcels'), $e->getMessage())); ?></td></tr>
                        <?php
                    }
                    ?>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
            <?php if ($total_pages > 1): ?>
                <?php
                $base_url = admin_url('admin.php?page=intigo-manage-orders');
                $from = (($current_page - 1) * $per_page) + 1;
                $to = min($total_items, $current_page * $per_page);
                ?>
                <div style="display:flex; align-items:center; justify-content:space-between; gap:10px; margin-top:12px; flex-wrap:wrap;">
                    <small style="color:#50575e;"><?php
                        /* translators: %1$d: first order number shown, %2$d: last order number shown, %3$d: total number of orders */
                        echo esc_html(sprintf(__('Showing %1$d-%2$d of %3$d orders', 'intigo-parcels'), $from, $to, $total_items));
                    ?></small>
                    <div style="display:flex; gap:6px; align-items:center;">
                        <?php if ($current_page > 1): ?>
                            <a class="button button-small" href="<?php echo esc_url(add_query_arg('paged', $current_page - 1, $base_url)); ?>"><?php esc_html_e('Previous', 'intigo-parcels'); ?></a>
                        <?php else: ?>
                            <button class="button button-small" disabled><?php esc_html_e('Previous', 'intigo-parcels'); ?></button>
                        <?php endif; ?>
                        <span style="min-width:90px; text-align:center;"><?php
                            /* translators: %1$d: current page number, %2$d: total number of pages */
                            echo esc_html(sprintf(__('Page %1$d / %2$d', 'intigo-parcels'), $current_page, $total_pages));
                        ?></span>
                        <?php if ($current_page < $total_pages): ?>
                            <a class="button button-small" href="<?php echo esc_url(add_query_arg('paged', $current_page + 1, $base_url)); ?>"><?php esc_html_e('Next', 'intigo-parcels'); ?></a>
                        <?php else: ?>
                            <button class="button button-small" disabled><?php esc_html_e('Next', 'intigo-parcels'); ?></button>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
            </div>

        </div>
        <?php $this->render_zone_assets(); ?>
        <div id="intigo-zone-modal" class="intigo-zm-backdrop" hidden>
            <div class="intigo-zm" role="dialog" aria-modal="true" aria-labelledby="intigo-zm-title">
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>" id="intigo-zm-form" novalidate>
                    <input type="hidden" name="action" value="intigo_order_action">
                    <input type="hidden" name="op" value="save_metadata">
                    <input type="hidden" name="order_id" id="intigo-zm-order-id" value="">
                    <?php wp_nonce_field('intigo_order_action_meta_edit', '_wpnonce'); ?>
                    <div class="intigo-zm-header">
                        <h2 id="intigo-zm-title"></h2>
                        <button type="button" class="intigo-zm-close" data-zm-close aria-label="<?php esc_attr_e('Close', 'intigo-parcels'); ?>"><span class="dashicons dashicons-no-alt" aria-hidden="true"></span></button>
                    </div>
                    <div class="intigo-zm-body">
                        <div class="intigo-zm-card">
                            <div class="intigo-zm-card-title"><?php esc_html_e('Address typed in WooCommerce', 'intigo-parcels'); ?></div>
                            <div class="intigo-zm-typed-name" id="intigo-zm-typed-name"></div>
                            <div id="intigo-zm-typed-street"></div>
                            <div id="intigo-zm-typed-place"></div>
                            <div id="intigo-zm-typed-phone"></div>
                        </div>
                        <div class="intigo-zm-detect" id="intigo-zm-detect-box">
                            <span class="intigo-zone-badge" id="intigo-zm-badge"></span>
                            <div class="intigo-zm-detect-text">
                                <div id="intigo-zm-zone-path" style="color:var(--intigo-text); font-weight:500;"></div>
                                <div id="intigo-zm-reason"></div>
                            </div>
                        </div>
                        <div class="intigo-zm-field">
                            <label for="intigo-zm-search"><?php esc_html_e('Search a quartier, cité or délégation…', 'intigo-parcels'); ?></label>
                            <input type="text" id="intigo-zm-search" placeholder="<?php esc_attr_e('e.g. La Marsa, Ennasr, Sahloul', 'intigo-parcels'); ?>">
                            <span class="intigo-zm-hint" id="intigo-zm-search-hint"><?php esc_html_e('Type at least 2 letters, then pick a result: the three fields below are filled for you.', 'intigo-parcels'); ?></span>
                        </div>
                        <div class="intigo-zm-grid">
                            <div class="intigo-zm-field">
                                <label for="intigo-zm-city"><?php esc_html_e('Governorate', 'intigo-parcels'); ?> *</label>
                                <select id="intigo-zm-city" name="intigo_city_id"></select>
                                <span class="intigo-zp-msg" id="intigo-zm-city-msg" hidden></span>
                            </div>
                            <div class="intigo-zm-field">
                                <label for="intigo-zm-district"><?php esc_html_e('Délégation', 'intigo-parcels'); ?> <span class="intigo-zm-optional"><?php esc_html_e('(optional)', 'intigo-parcels'); ?></span></label>
                                <select id="intigo-zm-district" name="intigo_district_id"></select>
                                <span class="intigo-zp-msg" id="intigo-zm-district-msg" hidden></span>
                            </div>
                            <div class="intigo-zm-field">
                                <label for="intigo-zm-neighborhood"><?php esc_html_e('Quartier (optional)', 'intigo-parcels'); ?></label>
                                <select id="intigo-zm-neighborhood" name="intigo_neighborhood_id"></select>
                                <span class="intigo-zp-msg" id="intigo-zm-neighborhood-msg" hidden></span>
                            </div>
                        </div>
                        <span class="intigo-zm-hint is-accent" id="intigo-zm-district-hint" style="margin:-4px 0 10px;" hidden><?php esc_html_e('Leave empty: Intigo will find the délégation in the address.', 'intigo-parcels'); ?></span>
                        <div class="intigo-zm-field">
                            <label for="intigo-zm-address"><?php esc_html_e('Delivery address', 'intigo-parcels'); ?></label>
                            <textarea id="intigo-zm-address" name="intigo_address" rows="2" maxlength="500"></textarea>
                        </div>
                        <div class="intigo-zm-grid-2">
                            <div class="intigo-zm-field">
                                <label for="intigo-zm-phone"><?php esc_html_e('Phone', 'intigo-parcels'); ?> *</label>
                                <input type="tel" id="intigo-zm-phone" name="intigo_phone" placeholder="<?php esc_attr_e('e.g. 20123456', 'intigo-parcels'); ?>">
                            </div>
                            <div class="intigo-zm-field">
                                <label for="intigo-zm-package"><?php esc_html_e('Package size', 'intigo-parcels'); ?></label>
                                <select id="intigo-zm-package" name="intigo_package_size">
                                    <option value=""><?php esc_html_e('Automatic (from the products)', 'intigo-parcels'); ?></option>
                                    <option value="S">S</option>
                                    <option value="M">M</option>
                                    <option value="L">L</option>
                                    <option value="XL">XL</option>
                                </select>
                            </div>
                        </div>
                        <div class="intigo-zm-grid-2">
                            <div class="intigo-zm-field">
                                <label for="intigo-zm-reference"><?php esc_html_e('Reference (cid)', 'intigo-parcels'); ?> <span class="intigo-zm-optional"><?php esc_html_e('(optional)', 'intigo-parcels'); ?></span></label>
                                <input type="text" id="intigo-zm-reference" name="intigo_reference" maxlength="<?php echo esc_attr(Intigo_Order_Service::REFERENCE_MAX); ?>">
                                <span class="intigo-zm-hint"><?php esc_html_e('Your own reference for this parcel (sent to Intigo as cid).', 'intigo-parcels'); ?></span>
                            </div>
                            <div class="intigo-zm-field">
                                <label for="intigo-zm-notes"><?php esc_html_e('Notes / delivery instructions', 'intigo-parcels'); ?> <span class="intigo-zm-optional"><?php esc_html_e('(optional)', 'intigo-parcels'); ?></span></label>
                                <textarea id="intigo-zm-notes" name="intigo_notes" rows="2" maxlength="<?php echo esc_attr(Intigo_Order_Service::NOTES_MAX); ?>"></textarea>
                                <span class="intigo-zm-hint" id="intigo-zm-notes-count"></span>
                            </div>
                        </div>
                    </div>
                    <div class="intigo-zm-footer">
                        <span class="intigo-zm-why" id="intigo-zm-why" aria-live="polite"></span>
                        <button type="button" class="button" data-zm-close><?php esc_html_e('Cancel', 'intigo-parcels'); ?></button>
                        <button type="submit" class="button" name="then" value="" id="intigo-zm-save"><?php esc_html_e('Save', 'intigo-parcels'); ?></button>
                        <button type="submit" class="button button-primary" name="then" value="send" id="intigo-zm-save-send"><?php esc_html_e('Save and send to Intigo', 'intigo-parcels'); ?></button>
                    </div>
                </form>
            </div>
        </div>
        <div id="intigo-actions-modal-backdrop" class="intigo-modal-backdrop" aria-hidden="true">
            <div class="intigo-modal" role="dialog" aria-modal="true" aria-labelledby="intigoActionsModalTitle">
                <div class="intigo-modal-header">
                    <strong id="intigoActionsModalTitle"><?php esc_html_e('Order Actions', 'intigo-parcels'); ?></strong>
                    <button type="button" class="button-link" id="intigo-actions-modal-close"><?php esc_html_e('Close', 'intigo-parcels'); ?></button>
                </div>
                <div class="intigo-modal-body">
                    <p style="margin-top:0;"><?php esc_html_e('Select an action, then click Run.', 'intigo-parcels'); ?></p>
                    <div class="intigo-form-row">
                        <label for="intigo_modal_action_select"><?php esc_html_e('Action', 'intigo-parcels'); ?></label>
                        <select id="intigo_modal_action_select" class="intigo-action-select">
                            <option value=""><?php esc_html_e('Select action...', 'intigo-parcels'); ?></option>
                        </select>
                    </div>
                    <button type="button" class="button button-primary" id="intigo_modal_action_run"><?php esc_html_e('Run', 'intigo-parcels'); ?></button>
                </div>
            </div>
        </div>
        <script id="intigo-manage-orders-js">
        (function() {
            var T = <?php echo wp_json_encode([
                /* translators: %s: WooCommerce order number. */
                'title' => __('Order #%s — Intigo delivery zone', 'intigo-parcels'),
                /* translators: %s: phone number typed by the customer. */
                'phoneLine' => __('Phone: %s', 'intigo-parcels'),
                'noAddress' => __('No address typed on this order.', 'intigo-parcels'),
                'whyGovernorate' => __('Choose the governorate to save.', 'intigo-parcels'),
                'whyDelegation' => __('Choose the délégation, or type the delivery address, to save.', 'intigo-parcels'),
                'whyDelegationList' => __('The délégation list is not loaded: click Retry.', 'intigo-parcels'),
                'whyDetecting' => __('Detecting the address…', 'intigo-parcels'),
                'detectingShort' => __('Detecting…', 'intigo-parcels'),
                'whyPhone' => __('Add the phone number to save.', 'intigo-parcels'),
                'whyLoading' => __('Loading the Intigo zone list…', 'intigo-parcels'),
                'selectAction' => __('Select action...', 'intigo-parcels'),
                'syncWithIntigo' => __('Synchronize with Intigo', 'intigo-parcels'),
                'requestRelance' => __('Request Relance', 'intigo-parcels'),
                'reportDelay' => __('Report Delay', 'intigo-parcels'),
                'cancelParcel' => __('Cancel Parcel', 'intigo-parcels'),
            ]); ?>;
            var ajaxUrl = <?php echo wp_json_encode(admin_url('admin-ajax.php')); ?>;
            var lookupNonce = <?php echo wp_json_encode(wp_create_nonce('intigo_lookup_nonce')); ?>;

            /* ---------- Edit window ---------- */
            var backdrop = document.getElementById('intigo-zone-modal');
            if (backdrop && window.IntigoZonePicker && window.IntigoLocationAutocomplete) {
                if (backdrop.parentNode !== document.body) document.body.appendChild(backdrop);
                var dialog = backdrop.querySelector('.intigo-zm');
                var form = document.getElementById('intigo-zm-form');
                var $ = function(id) { return document.getElementById(id); };
                var saveBtn = $('intigo-zm-save');
                var saveSendBtn = $('intigo-zm-save-send');
                var why = $('intigo-zm-why');
                var phone = $('intigo-zm-phone');
                var search = $('intigo-zm-search');
                var hint = $('intigo-zm-search-hint');
                var hintDefault = hint.textContent;
                var lastTrigger = null;
                var zoneState = { loading: false, detecting: false };

                var addressField = $('intigo-zm-address');
                var districtHint = $('intigo-zm-district-hint');
                var updateCounter = window.IntigoCharCounter($('intigo-zm-notes'), $('intigo-zm-notes-count'));
                var touched = false;
                var openFor = '';

                var picker = window.IntigoZonePicker({
                    city: $('intigo-zm-city'), district: $('intigo-zm-district'), neighborhood: $('intigo-zm-neighborhood'),
                    msgs: { city: $('intigo-zm-city-msg'), district: $('intigo-zm-district-msg'), neighborhood: $('intigo-zm-neighborhood-msg') },
                    ajaxUrl: ajaxUrl, nonce: lookupNonce,
                    onChange: function() { refreshSave(); }
                });
                ['intigo-zm-city', 'intigo-zm-district', 'intigo-zm-neighborhood'].forEach(function(id) {
                    $(id).addEventListener('change', function() { touched = true; });
                });
                var ac = window.IntigoLocationAutocomplete({
                    input: search, ajaxUrl: ajaxUrl, nonce: lookupNonce,
                    onPick: function(item) {
                        touched = true;
                        hint.textContent = hintDefault;
                        zoneState.loading = true;
                        refreshSave();
                        picker.setIds(item.city_id, item.district_id, item.neighborhood_id).then(function(ok) {
                            zoneState.loading = false;
                            refreshSave();
                            if (ok) { hint.textContent = window.IntigoZoneI18n.filled; }
                        });
                    }
                });

                function refreshSave() {
                    var s = picker.state();
                    var districtSel = $('intigo-zm-district');
                    var msg = '';
                    if (zoneState.detecting && !touched) msg = T.whyDetecting;
                    else if (zoneState.loading) msg = T.whyLoading;
                    else if (!s.cityId) msg = T.whyGovernorate;
                    else if (!s.districtId && districtSel.disabled) msg = T.whyDelegationList;
                    else if (!s.districtId && !String(addressField.value || '').trim()) msg = T.whyDelegation;
                    else if (!String(phone.value || '').trim()) msg = T.whyPhone;
                    districtHint.hidden = !(s.cityId && !s.districtId && !districtSel.disabled && !zoneState.loading);
                    why.textContent = msg;
                    saveBtn.disabled = msg !== '';
                    saveSendBtn.disabled = msg !== '';
                    saveBtn.title = msg;
                    saveSendBtn.title = msg;
                }
                phone.addEventListener('input', refreshSave);
                addressField.addEventListener('input', refreshSave);

                function setText(id, text) { var el = $(id); el.textContent = text || ''; el.hidden = !text; }
                function showZone(badgeLabel, badgeClass, path, reason) {
                    var badge = $('intigo-zm-badge');
                    badge.className = 'intigo-zone-badge ' + (badgeClass || '');
                    badge.textContent = badgeLabel || '';
                    setText('intigo-zm-zone-path', path);
                    setText('intigo-zm-reason', reason);
                }

                /** A detection result: refresh the row (cell, Send button, Edit data) and, if open, the window. */
                function applyDetection(orderId, z) {
                    var row = document.querySelector('tr[data-intigo-order="' + orderId + '"]');
                    if (row) {
                        var cell = row.querySelector('.intigo-zone-cell');
                        if (cell) cell.innerHTML = z.cellHtml;
                        var slot = row.querySelector('.intigo-send-slot');
                        if (slot) slot.innerHTML = z.sendHtml;
                        var edit = row.querySelector('.intigo-open-zone-modal');
                        if (edit && z.data) Object.keys(z.data).forEach(function(k) { edit.dataset[k] = z.data[k]; });
                    }
                    if (openFor !== String(orderId) || backdrop.hidden) return;
                    zoneState.detecting = false;
                    $('intigo-zm-detect-box').classList.remove('is-detecting');
                    showZone(z.badge, z.badgeClass, z.zonePath, z.reason);
                    if (!touched) {
                        zoneState.loading = true;
                        refreshSave();
                        picker.setIds(z.cityId || '', z.districtId || '', z.neighborhoodId || '').then(function() {
                            zoneState.loading = false;
                            refreshSave();
                        });
                    } else {
                        refreshSave();
                    }
                }
                function detect(orderId) {
                    return window.IntigoDetectZone(ajaxUrl, lookupNonce, orderId).then(function(z) {
                        applyDetection(orderId, z);
                        return z;
                    });
                }

                function openModal(btn) {
                    lastTrigger = btn;
                    var d = btn.dataset;
                    openFor = String(d.orderId || '');
                    touched = false;
                    $('intigo-zm-order-id').value = d.orderId || '';
                    $('intigo-zm-title').textContent = T.title.replace('%s', d.orderNumber || d.orderId || '');
                    setText('intigo-zm-typed-name', d.typedName);
                    setText('intigo-zm-typed-street', d.typedStreet || (!d.typedPlace ? T.noAddress : ''));
                    setText('intigo-zm-typed-place', d.typedPlace);
                    setText('intigo-zm-typed-phone', d.typedPhone ? T.phoneLine.replace('%s', d.typedPhone) : '');
                    showZone(d.badge, d.badgeClass, d.zonePath, d.reason);
                    phone.value = d.phone || '';
                    $('intigo-zm-package').value = d.packageSize || '';
                    addressField.value = d.address || '';
                    $('intigo-zm-reference').value = d.reference || '';
                    $('intigo-zm-notes').value = d.notes || '';
                    updateCounter();
                    search.value = '';
                    hint.textContent = hintDefault;
                    zoneState.detecting = d.tier === '';
                    zoneState.loading = true;
                    refreshSave();
                    picker.setIds(d.cityId, d.districtId, d.neighborhoodId).then(function() {
                        zoneState.loading = false;
                        refreshSave();
                    });
                    if (zoneState.detecting) {
                        // Never detected (e.g. an order from before 0.4.0): detect it now.
                        $('intigo-zm-detect-box').classList.add('is-detecting');
                        setText('intigo-zm-reason', T.whyDetecting);
                        var orderId = openFor;
                        detect(orderId).catch(function(err) {
                            if (openFor !== orderId) return;
                            zoneState.detecting = false;
                            $('intigo-zm-detect-box').classList.remove('is-detecting');
                            setText('intigo-zm-reason', (err && err.message) ? err.message : window.IntigoZoneI18n.detectFailed);
                            refreshSave();
                        });
                    }
                    backdrop.hidden = false;
                    document.body.classList.add('intigo-zm-open');
                    setTimeout(function() { search.focus(); }, 30);
                }
                function closeModal() {
                    if (backdrop.hidden) return;
                    ac.close();
                    backdrop.hidden = true;
                    document.body.classList.remove('intigo-zm-open');
                    if (lastTrigger) lastTrigger.focus();
                }
                document.querySelectorAll('.intigo-open-zone-modal').forEach(function(btn) {
                    btn.addEventListener('click', function() { openModal(btn); });
                });
                backdrop.querySelectorAll('[data-zm-close]').forEach(function(el) { el.addEventListener('click', closeModal); });
                backdrop.addEventListener('mousedown', function(e) { if (e.target === backdrop) closeModal(); });
                form.addEventListener('submit', function(e) {
                    refreshSave();
                    var submitter = e.submitter || document.activeElement;
                    if (saveBtn.disabled || (submitter && submitter.disabled)) { e.preventDefault(); return; }
                    saveBtn.disabled = true;
                    saveSendBtn.disabled = true;
                    if (submitter && submitter.name) {
                        var h = document.createElement('input');
                        h.type = 'hidden'; h.name = submitter.name; h.value = submitter.value;
                        form.appendChild(h);
                    }
                });
                dialog.addEventListener('keydown', function(e) {
                    if (e.key !== 'Tab') return;
                    var f = Array.prototype.filter.call(dialog.querySelectorAll('button, input, select, a[href], [tabindex]:not([tabindex="-1"])'), function(el) {
                        return !el.disabled && !el.hidden && el.offsetParent !== null;
                    });
                    if (!f.length) return;
                    var first = f[0], last = f[f.length - 1];
                    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
                    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
                });
                document.addEventListener('keydown', function(e) {
                    if (e.key === 'Escape' && !backdrop.hidden) closeModal();
                });

                /* ---------- Background detection of the rows never detected ---------- */
                // One after another, at most 25 per page view; rendering the page stays read-only.
                var pending = Array.prototype.filter.call(document.querySelectorAll('.intigo-open-zone-modal'), function(btn) {
                    return btn.dataset.tier === '';
                }).slice(0, 25);
                (function next() {
                    var btn = pending.shift();
                    if (!btn) return;
                    var row = btn.closest('tr');
                    var badge = row ? row.querySelector('.intigo-zone-cell .intigo-zone-badge') : null;
                    if (badge) { badge.textContent = T.detectingShort; badge.classList.add('is-detecting'); }
                    detect(btn.dataset.orderId).then(next, function() {
                        if (badge) { badge.textContent = btn.dataset.badge || ''; badge.classList.remove('is-detecting'); }
                        next();
                    });
                })();
            }

            /* ---------- More actions window ---------- */
            var actionsBackdrop = document.getElementById('intigo-actions-modal-backdrop');
            var actionsCloseBtn = document.getElementById('intigo-actions-modal-close');
            var actionsSelect = document.getElementById('intigo_modal_action_select');
            var actionsRunBtn = document.getElementById('intigo_modal_action_run');
            if (!actionsBackdrop || !actionsSelect) return;
            if (actionsBackdrop.parentNode !== document.body) document.body.appendChild(actionsBackdrop);
            function addActionOption(value, label) {
                var opt = document.createElement('option');
                opt.value = value;
                opt.textContent = label;
                actionsSelect.appendChild(opt);
            }
            function openActionsModal(btn) {
                actionsSelect.innerHTML = '';
                addActionOption('', T.selectAction);
                addActionOption(btn.getAttribute('data-sync-url') || '', T.syncWithIntigo);
                if ((btn.getAttribute('data-has-nid') || '') === '1') {
                    addActionOption(btn.getAttribute('data-relance-url') || '', T.requestRelance);
                    addActionOption(btn.getAttribute('data-delay-url') || '', T.reportDelay);
                    addActionOption(btn.getAttribute('data-cancel-url') || '', T.cancelParcel);
                }
                actionsBackdrop.style.display = 'flex';
                document.body.classList.add('intigo-modal-open');
            }
            function closeActionsModal() {
                actionsBackdrop.style.display = 'none';
                document.body.classList.remove('intigo-modal-open');
            }
            document.querySelectorAll('.intigo-open-actions-modal').forEach(function(btn) {
                btn.addEventListener('click', function() { openActionsModal(btn); });
            });
            if (actionsRunBtn) {
                actionsRunBtn.addEventListener('click', function() {
                    if (actionsSelect.value) window.location.href = actionsSelect.value;
                });
            }
            if (actionsCloseBtn) actionsCloseBtn.addEventListener('click', closeActionsModal);
            actionsBackdrop.addEventListener('click', function(e) { if (e.target === actionsBackdrop) closeActionsModal(); });
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && actionsBackdrop.style.display === 'flex') closeActionsModal();
            });
        })();
        </script>
        <?php
    }

    public function render_logs() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('Unauthorized', 'intigo-parcels'));
        }
        $logs = $this->get_logs();
        $total = count($logs);
        $per_page = self::LOGS_PER_PAGE;
        $total_pages = max(1, (int) ceil($total / $per_page));
        $current_page = isset($_GET['lpaged']) ? max(1, intval($_GET['lpaged'])) : 1;
        if ($current_page > $total_pages) { $current_page = $total_pages; }
        $offset = ($current_page - 1) * $per_page;
        $page_logs = $total > 0 ? array_slice($logs, $offset, $per_page) : [];
        $base_url = admin_url('admin.php?page=intigo-logs');
        $range_from = $total === 0 ? 0 : $offset + 1;
        $range_to = min($offset + $per_page, $total);
        ?>
        <div class="wrap">
            <?php $this->render_responsive_styles(); ?>
            <?php $this->render_interface_nav('intigo-logs'); ?>
            <?php $this->render_snackbar(); ?>
            <?php
                $this->render_page_header(
                    __('Activity Log', 'intigo-parcels'),
                    /* translators: %d: maximum number of log entries kept */
                    sprintf(__('Latest %d plugin actions and messages &mdash; useful for debugging and audits.', 'intigo-parcels'), intval(self::MAX_LOGS)),
                    __('History', 'intigo-parcels')
                );
            ?>
            <?php if (empty($logs)): ?>
                <div class="intigo-card">
                    <div class="intigo-empty">
                        <div class="intigo-empty-icon"><span class="dashicons dashicons-list-view"></span></div>
                        <div class="intigo-empty-title"><?php esc_html_e('No activity yet', 'intigo-parcels'); ?></div>
                        <div><?php esc_html_e('Plugin actions and API calls will appear here once you start using Intigo.', 'intigo-parcels'); ?></div>
                    </div>
                </div>
            <?php else: ?>
                <div class="intigo-logs-meta" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px; margin: 0 0 12px 0; color:var(--intigo-muted); font-size:12.5px;">
                    <span><?php
                        echo sprintf(
                            /* translators: %1$s: range of entries shown (e.g. 1–25), %2$s: total number of entries, %3$s: maximum number of entries kept */
                            esc_html__('Showing %1$s of %2$s entries (max %3$s retained).', 'intigo-parcels'),
                            '<strong style="color:var(--intigo-text);">' . esc_html($range_from) . '&ndash;' . esc_html($range_to) . '</strong>',
                            '<strong style="color:var(--intigo-text);">' . esc_html($total) . '</strong>',
                            esc_html(self::MAX_LOGS)
                        );
                    ?></span>
                    <span><?php
                        echo sprintf(
                            /* translators: %1$s: current page number, %2$s: total number of pages */
                            esc_html__('Page %1$s of %2$s', 'intigo-parcels'),
                            '<strong style="color:var(--intigo-text);">' . esc_html($current_page) . '</strong>',
                            '<strong style="color:var(--intigo-text);">' . esc_html($total_pages) . '</strong>'
                        );
                    ?></span>
                </div>
                <div class="intigo-table-wrap">
                    <table class="widefat striped">
                        <thead>
                            <tr>
                                <th style="width:170px;"><?php esc_html_e('Time', 'intigo-parcels'); ?></th>
                                <th style="width:160px;"><?php esc_html_e('Actor', 'intigo-parcels'); ?></th>
                                <th style="width:200px;"><?php esc_html_e('Action', 'intigo-parcels'); ?></th>
                                <th><?php esc_html_e('Context', 'intigo-parcels'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($page_logs as $log):
                                $action = (string) ($log['action'] ?? '');
                                $is_error = stripos($action, 'fail') !== false || stripos($action, 'error') !== false;
                                $is_success = stripos($action, 'success') !== false || stripos($action, 'created') !== false;
                                $pill_class = 'intigo-pill-muted';
                                if ($is_error) { $pill_class = 'intigo-pill-warn'; }
                                elseif ($is_success) { $pill_class = 'intigo-pill-ok'; }
                                ?>
                                <tr>
                                    <td><code style="background:#f1f5f9; color:#475569; padding:2px 6px; border-radius:5px; font-size:11.5px;"><?php echo esc_html((string) ($log['time'] ?? '')); ?></code></td>
                                    <td><?php echo esc_html((string) ($log['actor'] ?? 'system')); ?></td>
                                    <td><span class="intigo-pill <?php echo esc_attr($pill_class); ?>"><?php echo esc_html($action); ?></span></td>
                                    <td><small style="color:#64748b;"><?php echo esc_html((string) ($log['context'] ?? '')); ?></small></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php if ($total_pages > 1): ?>
                    <nav class="intigo-pagination" aria-label="<?php esc_attr_e('Logs pagination', 'intigo-parcels'); ?>">
                        <?php
                            $prev_disabled = $current_page <= 1;
                            $next_disabled = $current_page >= $total_pages;
                            $prev_url = add_query_arg('lpaged', max(1, $current_page - 1), $base_url);
                            $next_url = add_query_arg('lpaged', min($total_pages, $current_page + 1), $base_url);
                            $first_url = add_query_arg('lpaged', 1, $base_url);
                            $last_url = add_query_arg('lpaged', $total_pages, $base_url);

                            $window = 2;
                            $start = max(1, $current_page - $window);
                            $end = min($total_pages, $current_page + $window);
                            if ($start > 1) { echo '<a class="intigo-page-btn" href="' . esc_url($first_url) . '">1</a>'; if ($start > 2) { echo '<span class="intigo-page-ellipsis">&hellip;</span>'; } }
                        ?>
                        <a class="intigo-page-btn intigo-page-nav <?php echo $prev_disabled ? 'is-disabled' : ''; ?>" <?php echo $prev_disabled ? '' : 'href="' . esc_url($prev_url) . '"'; ?> aria-label="<?php esc_attr_e('Previous page', 'intigo-parcels'); ?>"><span class="dashicons dashicons-arrow-left-alt2"></span> <?php esc_html_e('Previous', 'intigo-parcels'); ?></a>
                        <?php for ($i = $start; $i <= $end; $i++):
                            $active = $i === $current_page ? 'is-active' : '';
                            $url = add_query_arg('lpaged', $i, $base_url);
                            ?>
                            <a class="intigo-page-btn <?php echo esc_attr($active); ?>" href="<?php echo esc_url($url); ?>"><?php echo esc_html($i); ?></a>
                        <?php endfor; ?>
                        <a class="intigo-page-btn intigo-page-nav <?php echo $next_disabled ? 'is-disabled' : ''; ?>" <?php echo $next_disabled ? '' : 'href="' . esc_url($next_url) . '"'; ?> aria-label="<?php esc_attr_e('Next page', 'intigo-parcels'); ?>"><?php esc_html_e('Next', 'intigo-parcels'); ?> <span class="dashicons dashicons-arrow-right-alt2"></span></a>
                        <?php if ($end < $total_pages): if ($end < $total_pages - 1) { echo '<span class="intigo-page-ellipsis">&hellip;</span>'; } ?>
                            <a class="intigo-page-btn" href="<?php echo esc_url($last_url); ?>"><?php echo esc_html($total_pages); ?></a>
                        <?php endif; ?>
                    </nav>
                <?php endif; ?>
            <?php endif; ?>
        </div>
        <?php
    }

    public function render_docs() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('Unauthorized', 'intigo-parcels'));
        }
        ?>
        <div class="wrap">
            <?php $this->render_responsive_styles(); ?>
            <?php $this->render_interface_nav('intigo-docs'); ?>
            <?php $this->render_snackbar(); ?>
            <?php $this->render_page_header(__('Documentation', 'intigo-parcels'), __('How the Intigo plugin works, best practices, tag meanings, and troubleshooting tips.', 'intigo-parcels'), __('Help center', 'intigo-parcels')); ?>
            <style>
                .intigo-docs-grid { display:grid; grid-template-columns: repeat(2, 1fr); gap:14px; }
                @media (max-width: 900px) { .intigo-docs-grid { grid-template-columns: 1fr; } }
                .intigo-doc-card { background:#fff; border:1px solid var(--intigo-border); border-radius: var(--intigo-radius-lg); padding:20px; box-shadow: var(--intigo-shadow-sm); position:relative; }
                .intigo-doc-card .intigo-doc-icon { width:40px; height:40px; border-radius:10px; background:var(--intigo-primary-soft); color:var(--intigo-primary); display:flex; align-items:center; justify-content:center; margin-bottom:12px; }
                .intigo-doc-card .intigo-doc-icon .dashicons { font-size:20px; width:20px; height:20px; }
                .intigo-doc-card h2 { margin:0 0 8px 0; font-size:15px; font-weight:600; color:var(--intigo-text); }
                .intigo-doc-card p, .intigo-doc-card li { color:var(--intigo-text-soft); font-size:13.5px; line-height:1.6; }
                .intigo-doc-card ol, .intigo-doc-card ul { margin:8px 0 0 18px; padding:0; }
                .intigo-doc-card li { margin-bottom:6px; }
                .intigo-doc-card .intigo-doc-tag { display:inline-block; padding:2px 8px; background:#f1f5f9; color:#0f172a; border-radius:6px; font-size:12px; font-weight:600; margin-right:6px; }
                .intigo-doc-card.intigo-doc-help { background: linear-gradient(180deg, #f0f7ff 0%, #fff 100%); border-color:#bfdbfe; }
            </style>
            <div class="intigo-docs-grid">
                <div class="intigo-doc-card">
                    <div class="intigo-doc-icon"><span class="dashicons dashicons-flag"></span></div>
                    <h2><?php esc_html_e('Getting started', 'intigo-parcels'); ?></h2>
                    <ol>
                        <li><?php echo wp_kses_post(__('Open <strong>Intigo &rarr; Settings</strong>.', 'intigo-parcels')); ?></li>
                        <li><?php echo wp_kses_post(__('Paste your <strong>API key</strong>.', 'intigo-parcels')); ?></li>
                        <li><?php echo wp_kses_post(__('Pick <strong>Sandbox</strong> for testing or <strong>Production</strong> for live operations.', 'intigo-parcels')); ?></li>
                        <li><?php echo wp_kses_post(__('Save and confirm the <em>API connected</em> pill at the top.', 'intigo-parcels')); ?></li>
                    </ol>
                    <p style="margin-top:12px;"><?php echo wp_kses_post(__('<strong>Order flow:</strong> WooCommerce orders appear in <strong>Manage Orders</strong>. Complete metadata (city, district, neighborhood, package), send to Intigo, then generate and download the bordereau.', 'intigo-parcels')); ?></p>
                </div>

                <div class="intigo-doc-card">
                    <div class="intigo-doc-icon"><span class="dashicons dashicons-yes-alt"></span></div>
                    <h2><?php esc_html_e('Best practices', 'intigo-parcels'); ?></h2>
                    <ul>
                        <li><?php echo wp_kses_post(__('Validate end-to-end in <strong>Sandbox</strong> before switching to Production.', 'intigo-parcels')); ?></li>
                        <li><?php esc_html_e('Generate the bordereau only after a parcel NID is assigned.', 'intigo-parcels'); ?></li>
                        <li><?php echo wp_kses_post(__('Review the <strong>Activity Log</strong> regularly for failures.', 'intigo-parcels')); ?></li>
                        <li><?php esc_html_e('Keep city/district metadata complete to avoid missing-data status.', 'intigo-parcels'); ?></li>
                    </ul>
                </div>

                <div class="intigo-doc-card" style="grid-column: 1 / -1; background: linear-gradient(180deg, #f0f7ff 0%, #fff 100%); border-color:#bfdbfe;">
                    <div class="intigo-doc-icon"><span class="dashicons dashicons-update-alt"></span></div>
                    <h2><?php esc_html_e('Automatic Send to Intigo', 'intigo-parcels'); ?></h2>
                    <p><?php echo wp_kses_post(__('When <strong>Order Processing Mode</strong> is set to <strong>Automatic</strong>, every WooCommerce order placed with the Intigo Delivery shipping method is pushed to Intigo\'s parcel API automatically &mdash; no admin click required.', 'intigo-parcels')); ?></p>

                    <h3 style="margin:14px 0 6px 0; font-size:13.5px; color:#0f172a;"><?php esc_html_e('How it works end-to-end', 'intigo-parcels'); ?></h3>
                    <ol>
                        <li><?php echo wp_kses_post(__('Customer at checkout picks <strong>Intigo Delivery (Small / Medium / Large / Extra large)</strong> &mdash; the size determines the shipping cost.', 'intigo-parcels')); ?></li>
                        <li><?php echo wp_kses_post(__('A modal pops up titled <em>Confirm your delivery details</em>, pre-filled from the customer\'s WooCommerce billing.', 'intigo-parcels')); ?></li>
                        <li><?php echo wp_kses_post(__('Customer confirms recipient, phone, country, address, and picks <strong>Intigo city &rarr; district &rarr; neighborhood</strong> from cascading dropdowns served by Intigo\'s region API.', 'intigo-parcels')); ?></li>
                        <li><?php echo wp_kses_post(__('Customer clicks <strong>Save delivery info</strong>; the modal closes; the cart total reflects the chosen size.', 'intigo-parcels')); ?></li>
                        <li><?php echo wp_kses_post(__('Customer clicks <strong>Place Order</strong>. Server-side validation enforces that all required Intigo fields are filled &mdash; otherwise the order is rejected with a clear inline error.', 'intigo-parcels')); ?></li>
                        <li><?php echo wp_kses_post(__('Once the order status reaches <em>Processing</em> (immediate for COD; after payment confirmation for cards), the plugin pushes the parcel to <code>/v3/parcels/</code> on the active environment URL.', 'intigo-parcels')); ?></li>
                        <li><?php echo wp_kses_post(__('On success, the parcel <strong>NID</strong> is stored on the order, an order note is added (<em>"Intigo parcel created: NID-XXXX"</em>), and the Manage Orders <strong>Notes</strong> column shows a green <strong>Sent to Intigo ✓</strong>.', 'intigo-parcels')); ?></li>
                        <li><?php echo wp_kses_post(__('On failure, the API error is stored on the order and shown in the Manage Orders <strong>Notes</strong> column in red, plus added as an order note for the audit trail.', 'intigo-parcels')); ?></li>
                    </ol>

                    <h3 style="margin:14px 0 6px 0; font-size:13.5px; color:#0f172a;"><?php echo wp_kses_post(__('Trigger events (idempotent &mdash; will not double-push)', 'intigo-parcels')); ?></h3>
                    <ul>
                        <li><code>woocommerce_store_api_checkout_order_processed</code> &mdash; <?php esc_html_e('Blocks-checkout primary path.', 'intigo-parcels'); ?></li>
                        <li><code>woocommerce_order_status_processing</code> &mdash; <?php esc_html_e('classic + COD primary path.', 'intigo-parcels'); ?></li>
                        <li><code>woocommerce_order_status_completed</code> &mdash; <?php esc_html_e('safety net.', 'intigo-parcels'); ?></li>
                        <li><code>woocommerce_payment_complete</code> &mdash; <?php esc_html_e('fires for any gateway when payment is confirmed.', 'intigo-parcels'); ?></li>
                        <li><code>woocommerce_thankyou</code> &mdash; <?php esc_html_e('final fallback when the customer reaches the order-received page.', 'intigo-parcels'); ?></li>
                    </ul>
                    <p style="margin-top:8px;"><?php echo wp_kses_post(__('Each event funnels through <code>Intigo_Order_Service::maybe_auto_create_from_order_event($order_id)</code>, which checks the Automatic toggle, confirms the order uses Intigo Delivery, skips orders in failed/cancelled/draft state, skips if a NID is already assigned (or the idempotency meta is set), and otherwise calls <code>create_single_for_order($order)</code>.', 'intigo-parcels')); ?></p>

                    <h3 style="margin:14px 0 6px 0; font-size:13.5px; color:#0f172a;"><?php esc_html_e('Phone normalization', 'intigo-parcels'); ?></h3>
                    <p><?php echo wp_kses_post(__('Intigo\'s API rejects phones containing non-digit characters. The plugin auto-strips them before sending: <code>+216 25 24 92 15</code> &rarr; <code>21625249215</code>, <code>0021625249215</code> &rarr; <code>21625249215</code>. Whatever the customer types is normalized to digits-only.', 'intigo-parcels')); ?></p>

                    <h3 style="margin:14px 0 6px 0; font-size:13.5px; color:#0f172a;"><?php esc_html_e('If the auto-push fails', 'intigo-parcels'); ?></h3>
                    <ul>
                        <li><?php echo wp_kses_post(__('Open <strong>Manage Orders</strong> &mdash; the failing order shows the API error in the <strong>Notes</strong> column on the right.', 'intigo-parcels')); ?></li>
                        <li><?php echo wp_kses_post(__('Or open the order in WC and read the <strong>Order notes</strong> sidebar for the full request/response.', 'intigo-parcels')); ?></li>
                        <li><?php echo wp_kses_post(__('Click <strong>Send to Intigo</strong> from Manage Orders to retry once you\'ve fixed the underlying issue.', 'intigo-parcels')); ?></li>
                    </ul>

                    <h3 style="margin:14px 0 6px 0; font-size:13.5px; color:#0f172a;"><?php esc_html_e('Switching back to Manual mode', 'intigo-parcels'); ?></h3>
                    <p><?php echo wp_kses_post(__('Set <strong>Settings &rarr; Order processing</strong> to <em>Manual</em>. New orders will sit in Manage Orders with all metadata pre-filled, and the seller clicks <strong>Send to Intigo</strong> when ready.', 'intigo-parcels')); ?></p>
                </div>

                <div class="intigo-doc-card" style="grid-column: 1 / -1;">
                    <div class="intigo-doc-icon"><span class="dashicons dashicons-tag"></span></div>
                    <h2><?php esc_html_e('Tag meanings (Manage Orders)', 'intigo-parcels'); ?></h2>
                    <ul style="list-style:none; margin-left:0; display:grid; grid-template-columns: repeat(2, 1fr); gap:10px 24px;">
                        <li><span class="intigo-doc-tag"><?php esc_html_e('NEW', 'intigo-parcels'); ?></span> <?php esc_html_e('Newly created order, not yet reviewed.', 'intigo-parcels'); ?></li>
                        <li><span class="intigo-doc-tag"><?php esc_html_e('Not Sent', 'intigo-parcels'); ?></span> <?php esc_html_e('No Intigo parcel created yet for this order.', 'intigo-parcels'); ?></li>
                        <li><span class="intigo-doc-tag"><?php esc_html_e('Parcel Created', 'intigo-parcels'); ?></span> <?php esc_html_e('Parcel exists in Intigo with a NID.', 'intigo-parcels'); ?></li>
                        <li><span class="intigo-doc-tag"><?php esc_html_e('Missing Data', 'intigo-parcels'); ?></span> <?php esc_html_e('Required metadata is incomplete.', 'intigo-parcels'); ?></li>
                        <li><span class="intigo-doc-tag"><?php esc_html_e('Need Verification', 'intigo-parcels'); ?></span> <?php esc_html_e('Metadata exists but needs review.', 'intigo-parcels'); ?></li>
                        <li><span class="intigo-doc-tag"><?php esc_html_e('Verified', 'intigo-parcels'); ?></span> <?php echo wp_kses_post(__('Metadata complete &mdash; ready for Intigo actions.', 'intigo-parcels')); ?></li>
                        <li><span class="intigo-doc-tag"><?php esc_html_e('Ready for Shipment', 'intigo-parcels'); ?></span> <?php esc_html_e('Parcel created and verified.', 'intigo-parcels'); ?></li>
                        <li><span class="intigo-doc-tag"><?php esc_html_e('Bordereau Generated', 'intigo-parcels'); ?></span> <?php esc_html_e('Bordereau URL is available.', 'intigo-parcels'); ?></li>
                    </ul>
                </div>

                <div class="intigo-doc-card">
                    <div class="intigo-doc-icon"><span class="dashicons dashicons-sos"></span></div>
                    <h2><?php esc_html_e('Troubleshooting', 'intigo-parcels'); ?></h2>
                    <ul>
                        <li><?php echo wp_kses_post(__('<strong>Cannot load cities/districts:</strong> verify API key and environment in Settings.', 'intigo-parcels')); ?></li>
                        <li><?php echo wp_kses_post(__('<strong>"Send to Intigo" disabled:</strong> required metadata is missing &mdash; use the <em>Edit</em> button.', 'intigo-parcels')); ?></li>
                        <li><?php echo wp_kses_post(__('<strong>Bordereau action disabled:</strong> the parcel must exist in Intigo first.', 'intigo-parcels')); ?></li>
                        <li><?php echo wp_kses_post(__('<strong>Login or health failures:</strong> verify API key and connectivity.', 'intigo-parcels')); ?></li>
                    </ul>
                </div>

                <div class="intigo-doc-card intigo-doc-help">
                    <div class="intigo-doc-icon"><span class="dashicons dashicons-email-alt"></span></div>
                    <h2><?php esc_html_e('Need help?', 'intigo-parcels'); ?></h2>
                    <p><?php esc_html_e('Reach the Intigo team for support, account changes, or API key requests.', 'intigo-parcels'); ?></p>
                    <p style="margin-top:10px;"><a class="button button-primary" href="mailto:hello@intigo.tn"><?php
                        /* translators: %s: support email address */
                        echo esc_html(sprintf(__('Email %s', 'intigo-parcels'), 'hello@intigo.tn'));
                    ?></a></p>
                </div>
            </div>
        </div>
        <?php
    }

    public function register_order_meta_box() {
        add_meta_box(
            'intigo_shipment_meta',
            __('Intigo Shipment', 'intigo-parcels'),
            [$this, 'render_order_meta_box'],
            'shop_order',
            'side',
            'default'
        );
    }

    public function register_order_meta_box_hpos() {
        // add_meta_boxes_{screen} passes the ORDER, not a screen id: always target the
        // HPOS order editor screen explicitly.
        $target = function_exists('wc_get_page_screen_id') ? wc_get_page_screen_id('shop-order') : 'woocommerce_page_wc-orders';
        add_meta_box(
            'intigo_shipment_meta',
            __('Intigo Shipment', 'intigo-parcels'),
            [$this, 'render_order_meta_box_hpos'],
            $target,
            'side',
            'default'
        );
    }

    public function render_order_meta_box($post) {
        $order_id = $post->ID;
        $this->render_order_meta_box_fields($order_id);
    }

    public function render_order_meta_box_hpos($object_or_order) {
        $order_id = 0;
        if (is_object($object_or_order) && method_exists($object_or_order, 'get_id')) {
            $order_id = intval($object_or_order->get_id());
        } elseif (is_object($object_or_order) && isset($object_or_order->ID)) {
            $order_id = intval($object_or_order->ID);
        }
        if ($order_id <= 0 && isset($_GET['id'])) {
            $order_id = intval($_GET['id']);
        }
        if ($order_id <= 0) {
            echo '<p>' . esc_html__('Unable to resolve order ID for Intigo Shipment.', 'intigo-parcels') . '</p>';
            return;
        }
        $this->render_order_meta_box_fields($order_id);
    }

    private function render_order_meta_box_fields($order_id) {
        $order = wc_get_order($order_id);
        if (!$order instanceof WC_Order) {
            return;
        }
        $zone = Intigo_Address_Resolver::display_state($order);
        $badge = $this->zone_badge($zone['tier'], $zone);
        $zone_path = $this->format_zone_path($zone['city_name'], $zone['district_name'], $zone['neighborhood_name']);
        $package_size = strtoupper((string) $order->get_meta('_intigo_package_size'));
        $parcel_nid = (string) $order->get_meta('_intigo_parcel_nid');
        $bordereau_url = (string) $order->get_meta('_intigo_bordereau_url');
        $ids = [
            $zone['city_id'] > 0 ? (string) $zone['city_id'] : '',
            $zone['district_id'] > 0 ? (string) $zone['district_id'] : '',
            $zone['neighborhood_id'] > 0 ? (string) $zone['neighborhood_id'] : '',
        ];
        $detect_url = wp_nonce_url(admin_url('admin-post.php?action=intigo_order_action&op=detect&order_id=' . intval($order_id)), 'intigo_order_action_' . intval($order_id) . '_detect');
        $confirm_url = wp_nonce_url(admin_url('admin-post.php?action=intigo_order_action&op=confirm_zone&order_id=' . intval($order_id)), 'intigo_order_action_' . intval($order_id) . '_confirm_zone');
        $needs_detect = $zone['tier'] === '' && $parcel_nid === '';
        $address_text = $this->order_service->delivery_address_text($order);
        $reference = (string) $order->get_meta('_intigo_reference');
        $notes = (string) $order->get_meta('_intigo_notes');

        wp_nonce_field('intigo_order_meta_nonce', 'intigo_order_meta_nonce_field');
        $this->render_zone_assets();
        ?>
        <style>
            #intigo-mb .intigo-mb-status { border:1px solid #e2e8f0; background:#f8fafc; border-radius:10px; padding:10px; margin-bottom:12px; font-size:12.5px; line-height:1.45; }
            #intigo-mb .intigo-mb-path { color:#0f172a; font-weight:600; margin-top:6px; }
            #intigo-mb .intigo-mb-reason { color:#475569; margin-top:2px; }
            #intigo-mb .intigo-mb-reason.is-review { color:#92400e; }
            #intigo-mb .intigo-mb-reason.is-blocked { color:#be123c; }
            #intigo-mb .intigo-mb-actions { display:flex; gap:6px; flex-wrap:wrap; margin-top:8px; }
            #intigo-mb .intigo-mb-field { margin:0 0 10px 0; }
            #intigo-mb .intigo-mb-field label { display:block; font-weight:600; margin-bottom:4px; }
            #intigo-mb .intigo-mb-field input[type=text], #intigo-mb .intigo-mb-field select, #intigo-mb .intigo-mb-field textarea { width:100%; max-width:none; min-height:34px; border:1px solid #cbd5e1; border-radius:8px; box-sizing:border-box; }
            #intigo-mb .intigo-mb-field textarea { padding:6px 8px; resize:vertical; line-height:1.4; }
            #intigo-mb .intigo-mb-field input:focus, #intigo-mb .intigo-mb-field select:focus, #intigo-mb .intigo-mb-field textarea:focus { border-color:#4F46E5; box-shadow:0 0 0 2px rgba(79,70,229,.15); outline:none; }
            #intigo-mb .intigo-mb-optional { font-weight:400; color:#64748b; }
            #intigo-mb .intigo-mb-hint[hidden], #intigo-mb .intigo-mb-reason[hidden] { display:none; }
            #intigo-mb .intigo-mb-hint { display:block; color:#64748b; font-size:12px; margin-top:3px; }
        </style>
        <div id="intigo-mb">
            <input type="hidden" name="intigo_zone_original" value="<?php echo esc_attr(implode('|', $ids)); ?>">
            <div class="intigo-mb-status">
                <span class="intigo-zone-badge <?php echo esc_attr($badge['class']); ?>" id="intigo_mb_badge"><?php echo esc_html($badge['label']); ?></span>
                <div class="intigo-mb-path" id="intigo_mb_path"><?php echo esc_html($zone_path !== '' ? $zone_path : '—'); ?></div>
                <?php if ($zone['reason_text'] !== ''): ?>
                    <div class="intigo-mb-reason is-<?php echo esc_attr($zone['tier'] !== '' ? $zone['tier'] : 'none'); ?>" id="intigo_mb_reason"><?php echo esc_html($zone['reason_text']); ?></div>
                <?php elseif ($zone['tier'] === ''): ?>
                    <div class="intigo-mb-reason" id="intigo_mb_reason"><?php echo esc_html($needs_detect ? __('Detecting the address…', 'intigo-parcels') : __('The address has not been matched to an Intigo zone yet.', 'intigo-parcels')); ?></div>
                <?php else: ?>
                    <div class="intigo-mb-reason" id="intigo_mb_reason" hidden></div>
                <?php endif; ?>
                <?php if ($parcel_nid === '' && $zone['tier'] !== 'manual'): ?>
                    <div class="intigo-mb-actions">
                        <?php if ($zone['tier'] === 'review'): ?>
                            <a class="button button-small button-primary" href="<?php echo esc_url($confirm_url); ?>"><?php esc_html_e('Confirm', 'intigo-parcels'); ?></a>
                        <?php endif; ?>
                        <a class="button button-small" href="<?php echo esc_url($detect_url); ?>" title="<?php esc_attr_e('Match the saved order address to an Intigo delivery zone', 'intigo-parcels'); ?>"><?php esc_html_e('Detect', 'intigo-parcels'); ?></a>
                    </div>
                <?php endif; ?>
            </div>

            <p class="intigo-mb-field">
                <label for="intigo_location_search"><?php esc_html_e('Search a quartier, cité or délégation…', 'intigo-parcels'); ?></label>
                <input type="text" id="intigo_location_search" placeholder="<?php esc_attr_e('e.g. La Marsa, Ennasr, Sahloul', 'intigo-parcels'); ?>">
                <span class="intigo-mb-hint" id="intigo_location_hint"><?php esc_html_e('Pick a result to fill the fields below, or choose them yourself. A zone chosen here is kept as is.', 'intigo-parcels'); ?></span>
            </p>
            <p class="intigo-mb-field">
                <label for="intigo_city_select"><?php esc_html_e('Governorate', 'intigo-parcels'); ?></label>
                <select id="intigo_city_select" name="intigo_city_id"></select>
                <span class="intigo-zp-msg" id="intigo_city_msg" hidden></span>
            </p>
            <p class="intigo-mb-field">
                <label for="intigo_district_select"><?php esc_html_e('Délégation', 'intigo-parcels'); ?> <span class="intigo-mb-optional"><?php esc_html_e('(optional)', 'intigo-parcels'); ?></span></label>
                <select id="intigo_district_select" name="intigo_district_id"></select>
                <span class="intigo-zp-msg" id="intigo_district_msg" hidden></span>
                <span class="intigo-mb-hint" id="intigo_district_hint" hidden><?php esc_html_e('Leave empty: Intigo will find the délégation in the address.', 'intigo-parcels'); ?></span>
            </p>
            <p class="intigo-mb-field">
                <label for="intigo_neighborhood_select"><?php esc_html_e('Quartier (optional)', 'intigo-parcels'); ?></label>
                <select id="intigo_neighborhood_select" name="intigo_neighborhood_id"></select>
                <span class="intigo-zp-msg" id="intigo_neighborhood_msg" hidden></span>
            </p>
            <p class="intigo-mb-field">
                <label for="intigo_address_text"><?php esc_html_e('Delivery address', 'intigo-parcels'); ?></label>
                <textarea id="intigo_address_text" name="intigo_address" rows="3" maxlength="500"><?php echo esc_textarea($address_text); ?></textarea>
                <span class="intigo-mb-hint"><?php esc_html_e('Sent to Intigo as the delivery address. Intigo reads the délégation from it when none is chosen.', 'intigo-parcels'); ?></span>
            </p>
            <p class="intigo-mb-field">
                <label for="intigo_package_size"><?php esc_html_e('Package size', 'intigo-parcels'); ?></label>
                <select id="intigo_package_size" name="intigo_package_size">
                    <option value="" <?php selected($package_size, ''); ?>><?php esc_html_e('Automatic (from the products)', 'intigo-parcels'); ?></option>
                    <?php foreach (['S', 'M', 'L', 'XL'] as $size): ?>
                        <option value="<?php echo esc_attr($size); ?>" <?php selected($package_size, $size); ?>><?php echo esc_html($size); ?></option>
                    <?php endforeach; ?>
                </select>
            </p>
            <p class="intigo-mb-field">
                <label for="intigo_reference"><?php esc_html_e('Reference (cid)', 'intigo-parcels'); ?> <span class="intigo-mb-optional"><?php esc_html_e('(optional)', 'intigo-parcels'); ?></span></label>
                <input type="text" id="intigo_reference" name="intigo_reference" maxlength="<?php echo esc_attr(Intigo_Order_Service::REFERENCE_MAX); ?>" value="<?php echo esc_attr($reference); ?>">
                <span class="intigo-mb-hint"><?php esc_html_e('Your own reference for this parcel (sent to Intigo as cid).', 'intigo-parcels'); ?></span>
            </p>
            <p class="intigo-mb-field">
                <label for="intigo_notes"><?php esc_html_e('Notes / delivery instructions', 'intigo-parcels'); ?> <span class="intigo-mb-optional"><?php esc_html_e('(optional)', 'intigo-parcels'); ?></span></label>
                <textarea id="intigo_notes" name="intigo_notes" rows="2" maxlength="<?php echo esc_attr(Intigo_Order_Service::NOTES_MAX); ?>"><?php echo esc_textarea($notes); ?></textarea>
                <span class="intigo-mb-hint" id="intigo_notes_count"></span>
            </p>

            <?php if ($parcel_nid !== ''): ?>
                <p class="description"><?php esc_html_e('Parcel NID:', 'intigo-parcels'); ?> <strong><?php echo esc_html($parcel_nid); ?></strong></p>
            <?php endif; ?>
            <?php if ($bordereau_url !== ''):
                $download_url = wp_nonce_url(
                    admin_url('admin-post.php?action=intigo_download_bordereau&order_id=' . intval($order_id)),
                    'intigo_download_bordereau_' . intval($order_id)
                );
                ?>
                <p><a class="button button-primary" href="<?php echo esc_url($download_url); ?>"><?php esc_html_e('Download Bordereau', 'intigo-parcels'); ?></a></p>
            <?php else: ?>
                <p class="description"><?php esc_html_e('Generate bordereau from Order Actions first, then download it here.', 'intigo-parcels'); ?></p>
            <?php endif; ?>
        </div>
        <script>
        (function() {
            if (!window.IntigoZonePicker || !window.IntigoLocationAutocomplete) return;
            var ajaxUrl = <?php echo wp_json_encode(admin_url('admin-ajax.php')); ?>;
            var nonce = <?php echo wp_json_encode(wp_create_nonce('intigo_lookup_nonce')); ?>;
            var ids = <?php echo wp_json_encode($ids); ?>;
            var orderId = <?php echo (int) $order_id; ?>;
            var needsDetect = <?php echo $needs_detect ? 'true' : 'false'; ?>;
            var $ = function(id) { return document.getElementById(id); };
            var hint = $('intigo_location_hint');
            var hintDefault = hint ? hint.textContent : '';
            var districtHint = $('intigo_district_hint');
            var touched = false;
            var picker = window.IntigoZonePicker({
                city: $('intigo_city_select'),
                district: $('intigo_district_select'),
                neighborhood: $('intigo_neighborhood_select'),
                msgs: { city: $('intigo_city_msg'), district: $('intigo_district_msg'), neighborhood: $('intigo_neighborhood_msg') },
                ajaxUrl: ajaxUrl, nonce: nonce,
                onChange: function(s) { if (districtHint) districtHint.hidden = !(s.cityId && !s.districtId && !$('intigo_district_select').disabled); }
            });
            ['intigo_city_select', 'intigo_district_select', 'intigo_neighborhood_select'].forEach(function(id) {
                $(id).addEventListener('change', function() { touched = true; });
            });
            window.IntigoLocationAutocomplete({
                input: $('intigo_location_search'),
                ajaxUrl: ajaxUrl, nonce: nonce,
                onPick: function(item) {
                    touched = true;
                    if (hint) hint.textContent = hintDefault;
                    picker.setIds(item.city_id, item.district_id, item.neighborhood_id).then(function(ok) {
                        if (ok && hint) hint.textContent = window.IntigoZoneI18n.filled;
                    });
                }
            });
            window.IntigoCharCounter($('intigo_notes'), $('intigo_notes_count'));
            picker.setIds(ids[0], ids[1], ids[2]);
            if (needsDetect) {
                window.IntigoDetectZone(ajaxUrl, nonce, orderId).then(function(z) {
                    var badge = $('intigo_mb_badge'), reason = $('intigo_mb_reason');
                    badge.className = 'intigo-zone-badge ' + z.badgeClass;
                    badge.textContent = z.badge;
                    $('intigo_mb_path').textContent = z.zonePath || '—';
                    reason.className = 'intigo-mb-reason is-' + (z.tier || 'none');
                    reason.textContent = z.reason || '';
                    reason.hidden = !z.reason;
                    // What the box now shows: saving it unchanged is not a choice by hand.
                    var orig = document.querySelector('#intigo-mb input[name="intigo_zone_original"]');
                    if (orig) orig.value = [z.cityId || '', z.districtId || '', z.neighborhoodId || ''].map(function(v) { return v ? String(v) : ''; }).join('|');
                    if (!touched) picker.setIds(z.cityId || '', z.districtId || '', z.neighborhoodId || '');
                }).catch(function(err) {
                    var reason = $('intigo_mb_reason');
                    reason.textContent = (err && err.message) ? err.message : window.IntigoZoneI18n.detectFailed;
                    reason.className = 'intigo-mb-reason is-blocked';
                    reason.hidden = false;
                });
            }
        })();
        </script>
        <?php
    }

    public function save_order_meta_box($post_id, $post) {
        if (!isset($_POST['intigo_order_meta_nonce_field']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['intigo_order_meta_nonce_field'])), 'intigo_order_meta_nonce')) {
            return;
        }
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        if (!$post || $post->post_type !== 'shop_order') {
            return;
        }
        if (!current_user_can('edit_post', $post_id) && !current_user_can('edit_shop_orders') && !current_user_can('manage_woocommerce')) {
            return;
        }
        $this->persist_intigo_order_meta_from_post($post_id);
    }

    public function save_order_meta_box_from_order_id($order_id) {
        $order_id = intval($order_id);
        if ($order_id <= 0) {
            return;
        }
        if (!isset($_POST['intigo_order_meta_nonce_field']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['intigo_order_meta_nonce_field'])), 'intigo_order_meta_nonce')) {
            return;
        }
        if (!current_user_can('edit_post', $order_id) && !current_user_can('edit_shop_orders') && !current_user_can('manage_woocommerce')) {
            return;
        }
        $this->persist_intigo_order_meta_from_post($order_id);
    }

    private function persist_intigo_order_meta_from_post($order_id) {
        // Once per order per request: the $order->save() below fires the save hooks again,
        // and the form data is still in $_POST, so without this guard the save loops until PHP crashes.
        static $persisted = [];
        if (isset($persisted[$order_id])) {
            return;
        }
        $persisted[$order_id] = true;
        $order = wc_get_order($order_id);
        if (!$order instanceof WC_Order) {
            return;
        }
        $city_id = isset($_POST['intigo_city_id']) ? intval($_POST['intigo_city_id']) : 0;
        $district_id = isset($_POST['intigo_district_id']) ? intval($_POST['intigo_district_id']) : 0;
        $neighborhood_id = isset($_POST['intigo_neighborhood_id']) ? intval($_POST['intigo_neighborhood_id']) : 0;
        $original = isset($_POST['intigo_zone_original']) ? sanitize_text_field(wp_unslash($_POST['intigo_zone_original'])) : '';
        $package_size = isset($_POST['intigo_package_size']) ? strtoupper(sanitize_text_field(wp_unslash($_POST['intigo_package_size']))) : '';

        $changed = false;
        // Only an explicit, complete choice that differs from what the box showed is
        // the merchant's pick. Empty selects (list not loaded yet, lookup failed)
        // never wipe the stored zone.
        // A quartier that was not posted (its list still loading, so the select was
        // disabled) is not a change either: only a governorate/délégation that differs,
        // or a quartier actually picked, is.
        $orig = array_pad(explode('|', $original), 3, '');
        $picked = $city_id > 0 && $district_id > 0 && (
            (string) $city_id !== $orig[0] || (string) $district_id !== $orig[1]
            || ($neighborhood_id > 0 && (string) $neighborhood_id !== $orig[2])
        );
        // The governorate alone, with the délégation list loaded and deliberately left
        // empty (a select still loading is disabled, so not posted at all): Intigo will
        // find the délégation in the address. Only when it differs from what was shown.
        $governorate_only = !$picked && $city_id > 0 && isset($_POST['intigo_district_id'])
            && sanitize_text_field(wp_unslash($_POST['intigo_district_id'])) === ''
            && ((string) $city_id !== $orig[0] || $orig[1] !== '');
        $has_nid = (string) $order->get_meta('_intigo_parcel_nid') !== '';
        $texts_changed = $this->apply_shipment_texts(
            $order,
            isset($_POST['intigo_address']) ? sanitize_textarea_field(wp_unslash($_POST['intigo_address'])) : null,
            isset($_POST['intigo_reference']) ? sanitize_text_field(wp_unslash($_POST['intigo_reference'])) : null,
            isset($_POST['intigo_notes']) ? sanitize_textarea_field(wp_unslash($_POST['intigo_notes'])) : null
        );
        if ($texts_changed) {
            $changed = true;
        }
        if (($picked || $governorate_only) && !$has_nid) {
            $resolver = new Intigo_Address_Resolver($this->api_client);
            if ($governorate_only && $this->order_service->delivery_address_text($order) === '') {
                self::queue_notice(__('The Intigo zone was not saved: choose the délégation, or type the delivery address so Intigo can find it.', 'intigo-parcels'), 'error');
            } elseif ($resolver->mark_manual($order, $city_id, $district_id, $neighborhood_id, $governorate_only ? 'merchant_city_only' : 'merchant_selected', null, $governorate_only)) {
                $changed = true;
            } else {
                self::queue_notice(__('The Intigo zone was not saved: the délégation does not belong to the governorate, or the Intigo zone list could not be loaded. Please pick it again.', 'intigo-parcels'), 'error');
            }
        }
        $before_size = (string) $order->get_meta('_intigo_package_size');
        if (in_array($package_size, ['S', 'M', 'L', 'XL'], true)) {
            $order->update_meta_data('_intigo_package_size', $package_size);
        } elseif ($package_size === '' && isset($_POST['intigo_package_size'])) {
            $order->delete_meta_data('_intigo_package_size');
        }
        if ((string) $order->get_meta('_intigo_package_size') !== $before_size) {
            $changed = true;
        }
        if ($changed) {
            $order->save();
            self::queue_notice(__('Intigo shipment details saved.', 'intigo-parcels'), 'success');
        }
    }

    /**
     * woocommerce_process_shop_order_meta, priority 45 — after WooCommerce saved
     * the addresses (40), before the "Order actions" box runs (50): an order
     * typed in or edited by the merchant gets its zone (re)detected, unless the
     * zone was set by hand or the parcel already exists.
     */
    public function detect_zone_after_admin_save($order_id, $order_or_post = null) {
        static $running = [];
        $order_id = intval($order_id);
        if ($order_id <= 0 || isset($running[$order_id])) {
            return;
        }
        if (!current_user_can('edit_shop_orders') && !current_user_can('manage_woocommerce')) {
            return;
        }
        $running[$order_id] = true;
        try {
            // A fresh instance: the one WooCommerce passes predates the Intigo box's own
            // save (priority 10), and writing through it would duplicate meta rows.
            $order = wc_get_order($order_id);
            if (!$order instanceof WC_Order || (string) $order->get_meta('_intigo_parcel_nid') !== '') {
                return;
            }
            if ((string) $order->get_meta('_intigo_zone_tier') === 'manual') {
                return;
            }
            $country = strtoupper((string) ($order->get_shipping_country() ?: $order->get_billing_country()));
            if ($country !== '' && $country !== 'TN') {
                return;
            }
            $resolver = new Intigo_Address_Resolver($this->api_client);
            $state = $resolver->prepare_for_send($order);
            if (!empty($state['skipped'])) {
                return;
            }
            list($type, $message) = $this->zone_outcome_message($order, $state);
            self::queue_notice($message, $type);
        } catch (\Throwable $e) {
            $this->add_log('zone_detect_failed', 'order_id=' . $order_id . '; ' . $e->getMessage());
        }
    }

    /**
     * Zone lookups for the admin pickers. Always the full list of the parent
     * (never filtered by address text), from the 24 h regions cache.
     */
    private function send_regions_json($res, $log_action, $context) {
        if (empty($res['ok'])) {
            $this->add_log($log_action, $context . '; ' . (string) ($res['error'] ?? ''));
            wp_send_json_error(['message' => __('The Intigo zone list could not be loaded.', 'intigo-parcels')], 502);
        }
        wp_send_json_success(array_values($res['items']));
    }

    private function check_lookup_request() {
        check_ajax_referer('intigo_lookup_nonce');
        if (!current_user_can('edit_shop_orders') && !current_user_can('manage_woocommerce')) {
            wp_send_json_error(['message' => __('Unauthorized', 'intigo-parcels')], 403);
        }
    }

    public function ajax_get_cities() {
        $this->check_lookup_request();
        $this->send_regions_json($this->api_client->get_cities_cached(), 'lookup_cities_failed', 'cities');
    }

    public function ajax_get_districts() {
        $this->check_lookup_request();
        $city_id = isset($_GET['city_id']) ? intval($_GET['city_id']) : 0;
        if ($city_id <= 0) {
            wp_send_json_error(['message' => __('city_id is required', 'intigo-parcels')], 400);
        }
        $this->send_regions_json($this->api_client->get_districts_cached($city_id), 'lookup_districts_failed', 'city_id=' . $city_id);
    }

    public function ajax_get_neighborhoods() {
        $this->check_lookup_request();
        $district_id = isset($_GET['district_id']) ? intval($_GET['district_id']) : 0;
        if ($district_id <= 0) {
            wp_send_json_error(['message' => __('district_id is required', 'intigo-parcels')], 400);
        }
        $this->send_regions_json($this->api_client->get_neighborhoods_cached($district_id), 'lookup_neighborhoods_failed', 'district_id=' . $district_id);
    }

    /**
     * Free-text zone search for the admin autocomplete: the public location
     * service, keeping only rows with a governorate AND a délégation (a pick
     * must fill both selects). Results are cached 10 minutes per query.
     */
    public function ajax_search_locations() {
        $this->check_lookup_request();
        $query = isset($_GET['q']) ? trim(sanitize_text_field(wp_unslash($_GET['q']))) : '';
        $len = function_exists('mb_strlen') ? mb_strlen($query) : strlen($query);
        if ($len < 2) {
            wp_send_json_success([]);
        }
        $cache_key = 'intigo_ls2_' . md5(strtolower($query)); // ls2: ranked results
        $cached = get_transient($cache_key);
        if (is_array($cached)) {
            wp_send_json_success($cached);
        }
        $res = $this->api_client->search_locations($query);
        if (empty($res['ok'])) {
            $this->add_log('lookup_locations_failed', 'q=' . $query . '; ' . (string) ($res['error'] ?? ''));
            wp_send_json_error(['message' => __('The address search service did not answer.', 'intigo-parcels')], 502);
        }
        $out = [];
        $seen = [];
        foreach ($res['items'] as $row) {
            if (intval($row['city_id']) <= 0 || intval($row['district_id']) <= 0 || $row['city_name'] === '' || $row['district_name'] === '') {
                continue;
            }
            $key = intval($row['district_id']) . ':' . intval($row['neighborhood_id']);
            if (isset($seen[$key])) {
                continue;
            }
            $seen[$key] = true;
            $out[] = [
                'city_id' => intval($row['city_id']),
                'city_name' => (string) $row['city_name'],
                'district_id' => intval($row['district_id']),
                'district_name' => (string) $row['district_name'],
                'neighborhood_id' => intval($row['neighborhood_id']),
                'neighborhood_name' => intval($row['neighborhood_id']) > 0 ? (string) $row['neighborhood_name'] : '',
            ];
        }
        $out = $this->rank_location_suggestions($query, $out);
        set_transient($cache_key, $out, 10 * MINUTE_IN_SECONDS);
        wp_send_json_success($out);
    }

    /**
     * The search service ranks fuzzily ("marsa" → "El Marja" before "La Marsa").
     * Re-rank by how the typed text matches: exact délégation/quartier name, then a
     * name starting with it, then containing it. Fuzzy-only rows are kept only when
     * nothing matches literally (typos). At most 15 rows.
     */
    private function rank_location_suggestions($query, array $rows) {
        $q = Intigo_API_Client::squash_name($query);
        if ($q === '') {
            return array_slice($rows, 0, 15);
        }
        $score_name = function ($name) use ($q) {
            $squashed = Intigo_API_Client::squash_name($name);
            if ($squashed === '') {
                return 9;
            }
            if ($squashed === $q) {
                return 0;
            }
            foreach (explode(' ', Intigo_API_Client::normalize_name($name)) as $word) {
                if ($word !== '' && strpos($word, $q) === 0) {
                    return 1;
                }
            }
            if (strpos($squashed, $q) === 0) {
                return 1;
            }
            return strpos($squashed, $q) !== false ? 2 : 9;
        };
        foreach ($rows as $i => $row) {
            $district = $score_name($row['district_name']);
            $neighborhood = $row['neighborhood_name'] !== '' ? $score_name($row['neighborhood_name']) : 9;
            $city = $score_name($row['city_name']);
            // A délégation-level row that matches exactly beats its quartiers.
            $best = min($district * 2, $neighborhood * 2 + 1, $city * 2 + 2);
            $rows[$i]['_score'] = $best;
            $rows[$i]['_pos'] = $i;
        }
        $literal = array_filter($rows, function ($row) {
            return $row['_score'] < 18;
        });
        if (!empty($literal)) {
            $rows = $literal;
        }
        usort($rows, function ($a, $b) {
            // Same match quality: the délégation itself before its quartiers.
            return [$a['_score'], $a['neighborhood_id'] > 0 ? 1 : 0, $a['_pos']] <=> [$b['_score'], $b['neighborhood_id'] > 0 ? 1 : 0, $b['_pos']];
        });
        $rows = array_slice(array_values($rows), 0, 15);
        foreach ($rows as $i => $row) {
            unset($rows[$i]['_score'], $rows[$i]['_pos']);
        }
        return $rows;
    }

    public function handle_download_bordereau() {
        if (!$this->is_intigo_logged_in()) {
            $this->add_log('download_bordereau_blocked', 'not_logged_in');
            $this->redirect_with_notice('intigo-dashboard', __('Please login to Intigo first.', 'intigo-parcels'), 'warning');
            exit;
        }
        if (!current_user_can('edit_shop_orders') && !current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('Unauthorized', 'intigo-parcels'));
        }
        $order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;
        if ($order_id <= 0) {
            wp_die(esc_html__('Invalid order id', 'intigo-parcels'));
        }
        check_admin_referer('intigo_download_bordereau_' . $order_id);

        $order = wc_get_order($order_id);
        if (!$order) {
            /* translators: %d: WooCommerce order ID */
            $this->redirect_back_with_notice('intigo-manage-orders', sprintf(__('Order #%d not found.', 'intigo-parcels'), $order_id), 'error');
            exit;
        }

        $url = (string) $order->get_meta('_intigo_bordereau_url');
        if ($url === '') {
            /* translators: %d: WooCommerce order ID */
            $this->redirect_back_with_notice('intigo-manage-orders', sprintf(__('Order #%d: no bordereau yet. Generate the bordereau first.', 'intigo-parcels'), $order_id), 'error');
            exit;
        }
        $this->add_log('download_bordereau_requested', 'order_id=' . $order_id);

        $res = wp_remote_get($url, ['timeout' => 60]);
        if (is_wp_error($res)) {
            $this->add_log('download_bordereau_failed', 'order_id=' . $order_id . '; error=' . $res->get_error_message());
            /* translators: 1: WooCommerce order ID, 2: error message */
            $this->redirect_back_with_notice('intigo-manage-orders', sprintf(__('Order #%1$d: bordereau download failed: %2$s', 'intigo-parcels'), $order_id, $res->get_error_message()), 'error');
            exit;
        }

        $code = wp_remote_retrieve_response_code($res);
        if ($code < 200 || $code >= 300) {
            $this->add_log('download_bordereau_failed', 'order_id=' . $order_id . '; http=' . intval($code));
            /* translators: 1: WooCommerce order ID, 2: HTTP status code */
            $this->redirect_back_with_notice('intigo-manage-orders', sprintf(__('Order #%1$d: bordereau download failed (HTTP %2$d). Try generating the bordereau again.', 'intigo-parcels'), $order_id, intval($code)), 'error');
            exit;
        }

        $body = wp_remote_retrieve_body($res);
        if ($body === '') {
            $this->add_log('download_bordereau_failed', 'order_id=' . $order_id . '; empty_body');
            /* translators: %d: WooCommerce order ID */
            $this->redirect_back_with_notice('intigo-manage-orders', sprintf(__('Order #%d: bordereau download failed: Intigo returned an empty file.', 'intigo-parcels'), $order_id), 'error');
            exit;
        }

        $filename_nid = (string) $order->get_meta('_intigo_parcel_nid');
        if ($filename_nid === '') {
            $filename_nid = 'order-' . $order_id;
        }
        $filename = 'bordereau-' . sanitize_file_name($filename_nid) . '.html';

        nocache_headers();
        header('Content-Type: text/html; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        echo $body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        exit;
    }

    public function handle_intigo_order_action() {
        if (!$this->is_intigo_logged_in()) {
            $this->add_log('order_action_blocked', 'not_logged_in');
            $this->redirect_with_notice('intigo-dashboard', __('Please login to Intigo first.', 'intigo-parcels'), 'warning');
            exit;
        }
        if (!current_user_can('edit_shop_orders') && !current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('Unauthorized', 'intigo-parcels'));
        }
        $order_id = isset($_REQUEST['order_id']) ? intval($_REQUEST['order_id']) : 0;
        $op = isset($_REQUEST['op']) ? sanitize_text_field(wp_unslash($_REQUEST['op'])) : '';
        if ($order_id <= 0 || $op === '') {
            wp_die(esc_html__('Invalid request', 'intigo-parcels'));
        }
        if ($op === 'save_metadata') {
            check_admin_referer('intigo_order_action_meta_edit');
        } else {
            check_admin_referer('intigo_order_action_' . $order_id . '_' . $op);
        }
        $order = wc_get_order($order_id);
        if (!$order) {
            /* translators: %d: WooCommerce order ID */
            $this->redirect_with_notice('intigo-manage-orders', sprintf(__('Order #%d not found.', 'intigo-parcels'), $order_id), 'error');
            exit;
        }

        $notice = __('Action completed', 'intigo-parcels');
        $notice_type = 'success';
        if ($op === 'create') {
            $result = $this->order_service->create_single_for_order($order, true);
            if (!empty($result['ok'])) {
                list($notice_type, $notice) = $this->created_notice($order_id, $result);
                $this->add_log('order_create_parcel', 'order_id=' . $order_id . '; nid=' . $result['nid'] . (!empty($result['by_name']) ? '; by_name=' . ($result['district_fallback'] !== '' ? $result['district_fallback'] : 'matched') : ''));
            } else {
                $reason = $result['message'] ?? __('unknown error', 'intigo-parcels');
                /* translators: 1: WooCommerce order ID, 2: failure reason */
                $notice = sprintf(__('Order #%1$d was not sent to Intigo: %2$s', 'intigo-parcels'), $order_id, $reason);
                $notice_type = (($result['code'] ?? '') === 'already_created') ? 'warning' : 'error';
                $this->add_log('order_create_parcel_failed', 'order_id=' . $order_id . '; code=' . ($result['code'] ?? '') . '; error=' . ($result['message'] ?? ''));
            }
        } elseif ($op === 'bordereau') {
            $result = $this->order_service->generate_bordereau_for_order($order);
            if (!empty($result['ok'])) {
                /* translators: 1: WooCommerce order ID, 2: Intigo parcel NID */
                $notice = sprintf(__('Order #%1$d: bordereau generated for parcel %2$s. You can now download or print it.', 'intigo-parcels'), $order_id, $result['nid']);
                $this->add_log('order_generate_bordereau', 'order_id=' . $order_id . '; nid=' . $result['nid']);
            } else {
                $reason = $result['message'] ?? __('unknown error', 'intigo-parcels');
                /* translators: 1: WooCommerce order ID, 2: failure reason */
                $notice = sprintf(__('Order #%1$d: bordereau not generated: %2$s', 'intigo-parcels'), $order_id, $reason);
                $notice_type = 'error';
                $this->add_log('order_generate_bordereau_failed', 'order_id=' . $order_id . '; error=' . ($result['message'] ?? ''));
            }
        } elseif ($op === 'sync_update') {
            $nid = (string) $order->get_meta('_intigo_parcel_nid');
            if ($nid === '') {
                $notice = __('Sync skipped: create parcel in Intigo first.', 'intigo-parcels');
                $notice_type = 'warning';
            } else {
                $sync_res = $this->order_service->update_parcel_for_order($order);
                if (!empty($sync_res['ok'])) {
                    /* translators: %d: WooCommerce order ID */
                    $notice = sprintf(__('Order #%d: synchronized with Intigo.', 'intigo-parcels'), $order_id);
                    $this->add_log('order_sync_update', 'order_id=' . $order_id);
                } else {
                    if (!empty($sync_res['locked'])) {
                        /* translators: %d: WooCommerce order ID */
                        $notice = sprintf(__('Order #%d: parcel is locked in Intigo (already delivered or return). Sync is skipped.', 'intigo-parcels'), $order_id);
                        $notice_type = 'warning';
                        $this->add_log('order_sync_update_locked', 'order_id=' . $order_id . '; error=' . ($sync_res['message'] ?? 'locked'));
                    } else {
                        $sync_error = $sync_res['message'] ?? __('unknown error', 'intigo-parcels');
                        /* translators: %1$d: WooCommerce order ID, %2$s: error message */
                        $notice = sprintf(__('Sync failed for order #%1$d: %2$s', 'intigo-parcels'), $order_id, $sync_error);
                        $notice_type = 'error';
                        $this->add_log('order_sync_update_failed', 'order_id=' . $order_id . '; error=' . ($sync_res['message'] ?? 'unknown'));
                    }
                }
            }
        } elseif ($op === 'cancel') {
            $nid = (string) $order->get_meta('_intigo_parcel_nid');
            if ($nid === '') {
                $notice = __('Cancel skipped: no Intigo parcel ID found.', 'intigo-parcels');
                $notice_type = 'warning';
            } else {
                $res = $this->api_client->cancel_parcel($nid);
                if (!empty($res['ok'])) {
                    /* translators: %d: WooCommerce order ID */
                    $notice = sprintf(__('Order #%d: parcel cancelled successfully.', 'intigo-parcels'), $order_id);
                    $this->add_log('order_cancel', 'order_id=' . $order_id . '; nid=' . $nid);
                } else {
                    /* translators: 1: WooCommerce order ID, 2: error message returned by Intigo */
                    $notice = sprintf(__('Cancel failed for order #%1$d: %2$s', 'intigo-parcels'), $order_id, $this->order_service->humanize_api_error($res));
                    $notice_type = 'error';
                    $this->add_log('order_cancel_failed', 'order_id=' . $order_id . '; nid=' . $nid);
                }
            }
        } elseif ($op === 'relance') {
            $nid = (string) $order->get_meta('_intigo_parcel_nid');
            if ($nid === '') {
                $notice = __('Relance skipped: no Intigo parcel ID found.', 'intigo-parcels');
                $notice_type = 'warning';
            } else {
                $res = $this->api_client->relance_parcel($nid, false);
                if (!empty($res['ok'])) {
                    /* translators: %d: WooCommerce order ID */
                    $notice = sprintf(__('Order #%d: relance requested.', 'intigo-parcels'), $order_id);
                    $this->add_log('order_relance', 'order_id=' . $order_id . '; nid=' . $nid);
                } else {
                    /* translators: 1: WooCommerce order ID, 2: error message returned by Intigo */
                    $notice = sprintf(__('Relance failed for order #%1$d: %2$s', 'intigo-parcels'), $order_id, $this->order_service->humanize_api_error($res));
                    $notice_type = 'error';
                    $this->add_log('order_relance_failed', 'order_id=' . $order_id . '; nid=' . $nid);
                }
            }
        } elseif ($op === 'report_delay') {
            $nid = (string) $order->get_meta('_intigo_parcel_nid');
            if ($nid === '') {
                $notice = __('Report delay skipped: no Intigo parcel ID found.', 'intigo-parcels');
                $notice_type = 'warning';
            } else {
                $res = $this->api_client->report_delay($nid, 'Reported from WooCommerce Intigo plugin');
                if (!empty($res['ok'])) {
                    /* translators: %d: WooCommerce order ID */
                    $notice = sprintf(__('Order #%d: delay reported successfully.', 'intigo-parcels'), $order_id);
                    $this->add_log('order_report_delay', 'order_id=' . $order_id . '; nid=' . $nid);
                } else {
                    /* translators: 1: WooCommerce order ID, 2: error message returned by Intigo */
                    $notice = sprintf(__('Report delay failed for order #%1$d: %2$s', 'intigo-parcels'), $order_id, $this->order_service->humanize_api_error($res));
                    $notice_type = 'error';
                    $this->add_log('order_report_delay_failed', 'order_id=' . $order_id . '; nid=' . $nid);
                }
            }
        } elseif ($op === 'detect') {
            list($notice_type, $notice) = $this->detect_order_zone($order, !empty($_REQUEST['force']));
            $this->add_log('order_zone_detect', 'order_id=' . $order_id . '; tier=' . (string) $order->get_meta('_intigo_zone_tier'));
            $this->redirect_back_with_notice('intigo-manage-orders', $notice, $notice_type);
            exit;
        } elseif ($op === 'confirm_zone') {
            list($notice_type, $notice) = $this->confirm_order_zone($order);
            $this->add_log('order_zone_confirm', 'order_id=' . $order_id . '; result=' . $notice_type);
            $this->redirect_back_with_notice('intigo-manage-orders', $notice, $notice_type);
            exit;
        } elseif ($op === 'save_metadata') {
            $city_id = isset($_REQUEST['intigo_city_id']) ? intval($_REQUEST['intigo_city_id']) : 0;
            $district_id = isset($_REQUEST['intigo_district_id']) ? intval($_REQUEST['intigo_district_id']) : 0;
            $neighborhood_id = isset($_REQUEST['intigo_neighborhood_id']) ? intval($_REQUEST['intigo_neighborhood_id']) : 0;
            $phone = isset($_REQUEST['intigo_phone']) ? sanitize_text_field(wp_unslash($_REQUEST['intigo_phone'])) : '';
            $package_size = isset($_REQUEST['intigo_package_size']) ? strtoupper(sanitize_text_field(wp_unslash($_REQUEST['intigo_package_size']))) : '';
            $then_send = isset($_REQUEST['then']) && $_REQUEST['then'] === 'send';
            $texts = [
                'address' => isset($_REQUEST['intigo_address']) ? sanitize_textarea_field(wp_unslash($_REQUEST['intigo_address'])) : null,
                'reference' => isset($_REQUEST['intigo_reference']) ? sanitize_text_field(wp_unslash($_REQUEST['intigo_reference'])) : null,
                'notes' => isset($_REQUEST['intigo_notes']) ? sanitize_textarea_field(wp_unslash($_REQUEST['intigo_notes'])) : null,
            ];
            list($notice_type, $notice) = $this->save_order_zone($order, $city_id, $district_id, $neighborhood_id, $phone, $package_size, $texts);
            $this->add_log($notice_type === 'success' ? 'order_metadata_saved' : 'order_metadata_save_failed', 'order_id=' . $order_id . '; city=' . $city_id . '; district=' . $district_id);
            if ($notice_type === 'success' && $then_send) {
                $order = wc_get_order($order_id);
                $result = $this->order_service->create_single_for_order($order, true);
                if (!empty($result['ok'])) {
                    list($notice_type, $notice) = $this->created_notice($order_id, $result);
                    $this->add_log('order_create_parcel', 'order_id=' . $order_id . '; nid=' . $result['nid']);
                } else {
                    /* translators: 1: WooCommerce order ID, 2: failure reason */
                    $notice = sprintf(__('Order #%1$d: the zone was saved but the order was not sent to Intigo: %2$s', 'intigo-parcels'), $order_id, $result['message'] ?? '');
                    $notice_type = 'error';
                    $this->add_log('order_create_parcel_failed', 'order_id=' . $order_id . '; code=' . ($result['code'] ?? ''));
                }
            }
        }

        $this->redirect_with_notice('intigo-manage-orders', $notice, $notice_type);
        exit;
    }

    /* ---------------- Delivery zone: labels, actions, batch detection ---------------- */

    /** Badge of a zone tier ('' = not detected yet). */
    private function zone_badge($tier, array $zone = null) {
        // Governorate chosen by hand without délégation: sendable by hand only (by name).
        if ((string) $tier === 'manual' && $zone !== null && intval($zone['city_id'] ?? 0) > 0 && intval($zone['district_id'] ?? 0) <= 0
            && ($zone['reason'] ?? '') !== 'intigo_by_name') {
            return ['label' => __('Send by hand', 'intigo-parcels'), 'class' => 'is-ready'];
        }
        switch ((string) $tier) {
            case 'resolved':
            case 'manual':
                return ['label' => __('Ready', 'intigo-parcels'), 'class' => 'is-ready'];
            case 'review':
                return ['label' => __('To check', 'intigo-parcels'), 'class' => 'is-review'];
            case 'blocked':
                return ['label' => __('Incomplete address', 'intigo-parcels'), 'class' => 'is-blocked'];
        }
        return ['label' => __('Not detected', 'intigo-parcels'), 'class' => 'is-none'];
    }

    /**
     * Inside of the Manage Orders "Destination" cell: badge, zone, reason,
     * Confirm/Detect, typed address. Also returned by the detect AJAX call so a
     * row can be refreshed without reloading the page.
     */
    private function zone_cell_html(WC_Order $order, array $zone) {
        $order_id = $order->get_id();
        $has_nid = (string) $order->get_meta('_intigo_parcel_nid') !== '';
        $badge = $this->zone_badge($zone['tier'], $zone);
        $zone_path = $this->format_zone_path($zone['city_name'], $zone['district_name'], $zone['neighborhood_name']);
        $typed = $this->typed_address($order);
        $detect_url = wp_nonce_url(admin_url('admin-post.php?action=intigo_order_action&op=detect&order_id=' . $order_id), 'intigo_order_action_' . $order_id . '_detect');
        $confirm_url = wp_nonce_url(admin_url('admin-post.php?action=intigo_order_action&op=confirm_zone&order_id=' . $order_id), 'intigo_order_action_' . $order_id . '_confirm_zone');
        ob_start();
        ?>
        <span class="intigo-zone-badge <?php echo esc_attr($badge['class']); ?>"><?php echo esc_html($badge['label']); ?></span>
        <div class="intigo-zone-path"><?php echo esc_html($zone_path !== '' ? $zone_path : '—'); ?></div>
        <?php if ($zone['reason_text'] !== '' && in_array($zone['tier'], ['review', 'blocked'], true)): ?>
            <div class="intigo-zone-reason is-<?php echo esc_attr($zone['tier']); ?>"><?php echo esc_html($zone['reason_text']); ?></div>
        <?php elseif ($zone['tier'] === 'manual' && $zone['reason_text'] !== ''): ?>
            <div class="intigo-zone-reason is-muted"><?php echo esc_html($zone['reason_text']); ?></div>
        <?php endif; ?>
        <?php if (!$has_nid && in_array($zone['tier'], ['review', '', 'blocked'], true)): ?>
            <div class="intigo-zone-actions">
                <?php if ($zone['tier'] === 'review' && $zone['district_id'] > 0): ?>
                    <a class="button button-small button-primary" href="<?php echo esc_url($confirm_url); ?>" title="<?php esc_attr_e('Keep this zone and mark the order ready to send', 'intigo-parcels'); ?>"><?php esc_html_e('Confirm', 'intigo-parcels'); ?></a>
                <?php elseif ($zone['tier'] !== 'review'): ?>
                    <a class="button button-small" href="<?php echo esc_url($detect_url); ?>" title="<?php esc_attr_e('Match the order address to an Intigo delivery zone', 'intigo-parcels'); ?>"><?php esc_html_e('Detect', 'intigo-parcels'); ?></a>
                <?php endif; ?>
            </div>
        <?php endif; ?>
        <?php if ($typed['line'] !== ''): ?>
            <div class="intigo-zone-typed" title="<?php esc_attr_e('Address as typed in WooCommerce', 'intigo-parcels'); ?>"><?php echo esc_html($typed['line']); ?></div>
        <?php endif; ?>
        <?php
        return trim((string) ob_get_clean());
    }

    /** "Send to Intigo": a link when the order can be sent (with its ids or by name), else a disabled button with the reason. */
    private function send_button_html(WC_Order $order, array $zone) {
        $order_id = $order->get_id();
        $nid = (string) $order->get_meta('_intigo_parcel_nid');
        $by_name = $nid === '' && !$zone['ready'] && $zone['tier'] !== '' && $this->order_service->by_name_ok($order, $zone);
        if ($nid === '' && ($zone['ready'] || $by_name)) {
            $create_url = wp_nonce_url(admin_url('admin-post.php?action=intigo_order_action&op=create&order_id=' . $order_id), 'intigo_order_action_' . $order_id . '_create');
            $title = $by_name ? __('Intigo will find the délégation in the address', 'intigo-parcels') : '';
            return '<a class="button button-small button-primary" href="' . esc_url($create_url) . '"' . ($title !== '' ? ' title="' . esc_attr($title) . '"' : '') . '>' . esc_html__('Send to Intigo', 'intigo-parcels') . '</a>';
        }
        $why = $this->send_blocked_reason($zone, $nid);
        return '<span title="' . esc_attr($why) . '"><button type="button" class="button button-small" disabled aria-disabled="true" title="' . esc_attr($why) . '">' . esc_html__('Send to Intigo', 'intigo-parcels') . '</button></span>';
    }

    /** data-* of the Edit button (camelCase keys, as the JS reads them from dataset). */
    private function edit_button_data(WC_Order $order, array $zone) {
        $badge = $this->zone_badge($zone['tier'], $zone);
        $typed = $this->typed_address($order);
        $pkg = strtoupper((string) $order->get_meta('_intigo_package_size'));
        $phone = trim((string) $order->get_meta('_intigo_phone'));
        if ($phone === '') {
            $phone = trim((string) $order->get_billing_phone());
        }
        if ($phone === '' && method_exists($order, 'get_shipping_phone')) {
            $phone = trim((string) $order->get_shipping_phone());
        }
        return [
            'orderId' => (string) $order->get_id(),
            'orderNumber' => (string) $order->get_order_number(),
            'cityId' => $zone['city_id'] > 0 ? (string) $zone['city_id'] : '',
            'districtId' => $zone['district_id'] > 0 ? (string) $zone['district_id'] : '',
            'neighborhoodId' => $zone['neighborhood_id'] > 0 ? (string) $zone['neighborhood_id'] : '',
            'tier' => (string) $zone['tier'],
            'badge' => $badge['label'],
            'badgeClass' => $badge['class'],
            'zonePath' => $this->format_zone_path($zone['city_name'], $zone['district_name'], $zone['neighborhood_name']),
            'reason' => (string) $zone['reason_text'],
            'ready' => $zone['ready'] ? '1' : '0',
            'phone' => $phone,
            'packageSize' => in_array($pkg, ['S', 'M', 'L', 'XL'], true) ? $pkg : '',
            'typedName' => $typed['name'],
            'typedStreet' => $typed['street'],
            'typedPlace' => $typed['place'],
            'typedPhone' => $typed['phone'],
            'address' => $this->order_service->delivery_address_text($order),
            'reference' => (string) $order->get_meta('_intigo_reference'),
            'notes' => (string) $order->get_meta('_intigo_notes'),
        ];
    }

    /**
     * Detect the zone of an order that was never detected (Edit window, order
     * page, Manage Orders background pass). Never overwrites a zone chosen by
     * hand, a legacy zone or a sent parcel: those return their stored state.
     *
     * @return array display_state() + detected (bool)
     */
    public function detect_state_for_order(WC_Order $order) {
        $zone = Intigo_Address_Resolver::display_state($order);
        $detected = false;
        if ($zone['tier'] === '' && (string) $order->get_meta('_intigo_parcel_nid') === '') {
            (new Intigo_Address_Resolver($this->api_client))->resolve_order($order, false);
            $order = wc_get_order($order->get_id());
            $zone = Intigo_Address_Resolver::display_state($order);
            $detected = true;
        }
        $zone['detected'] = $detected;
        return [$order, $zone];
    }

    /** AJAX intigo_detect_order_zone: detect one order, answer with everything a row or the Edit window shows. */
    public function ajax_detect_order_zone() {
        $this->check_lookup_request();
        $order_id = isset($_POST['order_id']) ? intval($_POST['order_id']) : 0;
        $order = $order_id > 0 ? wc_get_order($order_id) : null;
        if (!$order instanceof WC_Order) {
            wp_send_json_error(['message' => __('Order not found.', 'intigo-parcels')], 404);
        }
        try {
            list($order, $zone) = $this->detect_state_for_order($order);
        } catch (\Throwable $e) {
            $this->add_log('zone_detect_failed', 'order_id=' . $order_id . '; ' . $e->getMessage());
            wp_send_json_error(['message' => __('The address could not be detected. Try again in a moment.', 'intigo-parcels')], 500);
        }
        if ($zone['detected']) {
            $this->add_log('order_zone_detect', 'order_id=' . $order_id . '; tier=' . $zone['tier'] . '; via=ajax');
        }
        $badge = $this->zone_badge($zone['tier'], $zone);
        $nid = (string) $order->get_meta('_intigo_parcel_nid');
        wp_send_json_success([
            'tier' => $zone['tier'],
            'detected' => $zone['detected'],
            'ready' => $zone['ready'],
            'byName' => $nid === '' && !$zone['ready'] && $this->order_service->by_name_ok($order, $zone),
            'cityId' => $zone['city_id'],
            'districtId' => $zone['district_id'],
            'neighborhoodId' => $zone['neighborhood_id'],
            'badge' => $badge['label'],
            'badgeClass' => $badge['class'],
            'zonePath' => $this->format_zone_path($zone['city_name'], $zone['district_name'], $zone['neighborhood_name']),
            'reason' => $zone['reason_text'],
            'cellHtml' => $this->zone_cell_html($order, $zone),
            'sendHtml' => $this->send_button_html($order, $zone),
            'data' => $this->edit_button_data($order, $zone),
        ]);
    }

    /** "Tunis › El Menzah › Mutuelle Ville" ('' when there is no governorate). */
    private function format_zone_path($city, $district, $neighborhood = '') {
        $parts = array_values(array_filter([trim((string) $city), trim((string) $district), trim((string) $neighborhood)], 'strlen'));
        return implode(' › ', $parts);
    }

    /** The address as typed in WooCommerce (shipping, else billing), for display. */
    private function typed_address(WC_Order $order) {
        $pick = function ($field) use ($order) {
            $ship = 'get_shipping_' . $field;
            $bill = 'get_billing_' . $field;
            $v = method_exists($order, $ship) ? trim((string) $order->$ship()) : '';
            return $v !== '' ? $v : (method_exists($order, $bill) ? trim((string) $order->$bill()) : '');
        };
        $name = trim($pick('first_name') . ' ' . $pick('last_name'));
        $street = trim($pick('address_1') . ' ' . $pick('address_2'));
        $state = $pick('state');
        $country = $pick('country');
        if ($state !== '' && function_exists('WC') && WC()->countries) {
            $states = WC()->countries->get_states($country !== '' ? $country : 'TN');
            if (is_array($states) && isset($states[$state])) {
                $state = html_entity_decode((string) $states[$state], ENT_QUOTES, 'UTF-8');
            }
        }
        $place = implode(', ', array_values(array_filter([$pick('city'), $state, $pick('postcode')], 'strlen')));
        $phone = trim((string) $order->get_billing_phone());
        if ($phone === '' && method_exists($order, 'get_shipping_phone')) {
            $phone = trim((string) $order->get_shipping_phone());
        }
        return [
            'name' => $name,
            'street' => $street,
            'place' => $place,
            'phone' => $phone,
            'line' => implode(', ', array_values(array_filter([$street, $place], 'strlen'))),
        ];
    }

    /** Why "Send to Intigo" is disabled for this row ('' when it is enabled). */
    private function send_blocked_reason(array $zone, $nid) {
        if ((string) $nid !== '') {
            /* translators: %s: Intigo parcel NID. */
            return sprintf(__('Already sent to Intigo (NID %s).', 'intigo-parcels'), $nid);
        }
        if ($zone['ready']) {
            return '';
        }
        if ($zone['tier'] === 'manual' && $zone['city_id'] > 0 && $zone['district_id'] <= 0) {
            return __('Add the delivery address with Edit: Intigo needs it to find the délégation.', 'intigo-parcels');
        }
        switch ($zone['tier']) {
            case 'review':
                return __('The address match needs your confirmation: click Confirm, or pick the zone with Edit.', 'intigo-parcels');
            case 'blocked':
                $why = $zone['reason_text'] !== '' ? $zone['reason_text'] : __('The Intigo delivery zone of this address is unknown.', 'intigo-parcels');
                /* translators: %s: why the address could not be matched to an Intigo zone. */
                return sprintf(__('Incomplete address: %s Pick the zone with Edit.', 'intigo-parcels'), $why);
            case '':
                return __('The address has not been matched to an Intigo zone yet: click Detect, or pick the zone with Edit.', 'intigo-parcels');
        }
        return __('Pick the governorate and the délégation with Edit.', 'intigo-parcels');
    }

    /** [notice type, message] describing a freshly detected zone. */
    private function zone_outcome_message(WC_Order $order, array $state) {
        $id = $order->get_id();
        $path = $this->format_zone_path($state['city_name'] ?? '', $state['district_name'] ?? '', $state['neighborhood_name'] ?? '');
        $reason = Intigo_Address_Resolver::reason_message((string) ($state['reason'] ?? ''), (array) ($state['alternatives'] ?? []));
        switch ((string) ($state['tier'] ?? '')) {
            case 'resolved':
            case 'manual':
                /* translators: 1: WooCommerce order ID, 2: Intigo zone, e.g. "Tunis › El Menzah". */
                return ['success', sprintf(__('Order #%1$d: address matched to %2$s. Ready to send.', 'intigo-parcels'), $id, $path)];
            case 'review':
                /* translators: 1: WooCommerce order ID, 2: Intigo zone, e.g. "Tunis › El Menzah". */
                return ['warning', sprintf(__('Order #%1$d: nearest zone %2$s — check it, then click Confirm.', 'intigo-parcels'), $id, $path)];
        }
        /* translators: 1: WooCommerce order ID, 2: what is missing in the address. */
        return ['error', sprintf(__('Order #%1$d: incomplete address — %2$s', 'intigo-parcels'), $id, $reason !== '' ? $reason : __('the Intigo delivery zone is unknown.', 'intigo-parcels'))];
    }

    /**
     * "Detect": match the order address to a zone. A zone chosen by hand is kept
     * unless $force. Returns [notice type, message].
     */
    public function detect_order_zone(WC_Order $order, $force = false) {
        $id = $order->get_id();
        if ((string) $order->get_meta('_intigo_parcel_nid') !== '') {
            /* translators: %d: WooCommerce order ID. */
            return ['info', sprintf(__('Order #%d is already in Intigo; its zone is no longer changed here.', 'intigo-parcels'), $id)];
        }
        if (!$force && (string) $order->get_meta('_intigo_zone_tier') === 'manual') {
            /* translators: %d: WooCommerce order ID. */
            return ['info', sprintf(__('Order #%d: the zone was chosen by hand and was kept.', 'intigo-parcels'), $id)];
        }
        $state = (new Intigo_Address_Resolver($this->api_client))->resolve_order($order, (bool) $force);
        return $this->zone_outcome_message($order, $state);
    }

    /** "Confirm": a `review` zone becomes the merchant's choice. Returns [notice type, message]. */
    public function confirm_order_zone(WC_Order $order) {
        $id = $order->get_id();
        $zone = Intigo_Address_Resolver::display_state($order);
        if ($zone['ready']) {
            /* translators: %d: WooCommerce order ID. */
            return ['info', sprintf(__('Order #%d is already ready to send.', 'intigo-parcels'), $id)];
        }
        if ($zone['tier'] !== 'review' || $zone['city_id'] <= 0 || $zone['district_id'] <= 0) {
            /* translators: %d: WooCommerce order ID. */
            return ['error', sprintf(__('Order #%d: there is no complete zone to confirm. Pick the governorate and the délégation with Edit.', 'intigo-parcels'), $id)];
        }
        $names = [
            'city_name' => $zone['city_name'],
            'district_name' => $zone['district_name'],
            'neighborhood_name' => $zone['neighborhood_name'],
        ];
        if ($names['city_name'] === '' || $names['district_name'] === '') {
            $names = null; // Look the names up.
        }
        $resolver = new Intigo_Address_Resolver($this->api_client);
        if (!$resolver->mark_manual($order, $zone['city_id'], $zone['district_id'], $zone['neighborhood_id'], 'merchant_confirmed', $names)) {
            /* translators: %d: WooCommerce order ID. */
            return ['error', sprintf(__('Order #%d: the zone could not be checked against the Intigo zone list. Try again in a moment.', 'intigo-parcels'), $id)];
        }
        $order->save();
        $path = $this->format_zone_path($zone['city_name'], $zone['district_name'], $zone['neighborhood_name']);
        /* translators: 1: WooCommerce order ID, 2: Intigo zone, e.g. "Tunis › El Menzah". */
        return ['success', sprintf(__('Order #%1$d: zone %2$s confirmed. Ready to send.', 'intigo-parcels'), $id, $path)];
    }

    /** [notice type, message] after a parcel was created by a person. */
    private function created_notice($order_id, array $result) {
        if (!empty($result['by_name'])) {
            /* translators: 1: WooCommerce order ID, 2: failure reason. */
            return [!empty($result['warning']) ? 'warning' : 'success', sprintf(__('Order #%1$d: %2$s', 'intigo-parcels'), $order_id, $result['message'])];
        }
        /* translators: 1: WooCommerce order ID, 2: Intigo parcel NID */
        return ['success', sprintf(__('Order #%1$d: parcel sent to Intigo — NID %2$s', 'intigo-parcels'), $order_id, $result['nid'])];
    }

    /**
     * Delivery address text, reference (cid) and notes of the Edit window and the
     * order box. null = not posted (left alone). The address is only stored when
     * it differs from what was shown (the order's own address by default), so an
     * untouched field never changes what is sent. Does NOT save. Returns true on change.
     */
    private function apply_shipment_texts(WC_Order $order, $address, $reference, $notes) {
        $changed = false;
        $squash = function ($t) {
            return trim(preg_replace('/\s+/u', ' ', (string) $t));
        };
        $cut = function ($t, $max) {
            return function_exists('mb_substr') ? mb_substr($t, 0, $max) : substr($t, 0, $max);
        };
        if ($address !== null && $squash($address) !== $squash($this->order_service->delivery_address_text($order))) {
            $address = $cut(trim((string) $address), 500);
            if ($address === '') {
                $order->delete_meta_data('_intigo_address');
            } else {
                $order->update_meta_data('_intigo_address', $address);
            }
            $changed = true;
        }
        $fields = [
            '_intigo_reference' => [$reference, Intigo_Order_Service::REFERENCE_MAX],
            '_intigo_notes' => [$notes, Intigo_Order_Service::NOTES_MAX],
        ];
        foreach ($fields as $meta_key => $field) {
            list($value, $max) = $field;
            if ($value === null) {
                continue;
            }
            $value = $cut(trim((string) $value), $max);
            if ($value === (string) $order->get_meta($meta_key)) {
                continue;
            }
            if ($value === '') {
                $order->delete_meta_data($meta_key);
            } else {
                $order->update_meta_data($meta_key, $value);
            }
            $changed = true;
        }
        return $changed;
    }

    /**
     * The Edit window's save: zone chosen by hand (governorate alone lets Intigo
     * find the délégation in the address), phone, package size, address text,
     * reference, notes. Returns [notice type, message].
     */
    public function save_order_zone(WC_Order $order, $city_id, $district_id, $neighborhood_id, $phone, $package_size, array $texts = []) {
        $id = $order->get_id();
        $phone = trim((string) $phone);
        $texts = array_merge(['address' => null, 'reference' => null, 'notes' => null], $texts);
        $governorate_only = intval($district_id) <= 0;
        $address_after = $texts['address'] !== null ? trim((string) $texts['address']) : $this->order_service->delivery_address_text($order);
        if (intval($city_id) <= 0) {
            /* translators: %d: WooCommerce order ID. */
            return ['error', sprintf(__('Order #%d was not saved: choose the governorate and the délégation.', 'intigo-parcels'), $id)];
        }
        if ($governorate_only && $address_after === '') {
            /* translators: %d: WooCommerce order ID. */
            return ['error', sprintf(__('Order #%d was not saved: choose the délégation, or type the delivery address so Intigo can find it.', 'intigo-parcels'), $id)];
        }
        if ($phone === '') {
            /* translators: %d: WooCommerce order ID. */
            return ['error', sprintf(__('Order #%d was not saved: the phone number is required.', 'intigo-parcels'), $id)];
        }
        if ((string) $order->get_meta('_intigo_parcel_nid') !== '') {
            /* translators: %d: WooCommerce order ID. */
            return ['error', sprintf(__('Order #%d is already in Intigo; its zone is no longer changed here.', 'intigo-parcels'), $id)];
        }
        $resolver = new Intigo_Address_Resolver($this->api_client);
        if (!$resolver->mark_manual($order, $city_id, $district_id, $neighborhood_id, $governorate_only ? 'merchant_city_only' : 'merchant_selected', null, $governorate_only)) {
            /* translators: %d: WooCommerce order ID. */
            return ['error', sprintf(__('Order #%d was not saved: the délégation does not belong to the governorate, or the Intigo zone list could not be loaded. Please pick it again.', 'intigo-parcels'), $id)];
        }
        $this->apply_shipment_texts($order, $texts['address'], $texts['reference'], $texts['notes']);
        $package_size = strtoupper((string) $package_size);
        if (in_array($package_size, ['S', 'M', 'L', 'XL'], true)) {
            $order->update_meta_data('_intigo_package_size', $package_size);
        } elseif ($package_size === '') {
            $order->delete_meta_data('_intigo_package_size');
        }
        $order->set_billing_phone($phone);
        $order->save();
        if ($governorate_only) {
            /* translators: 1: WooCommerce order ID, 2: governorate name. */
            return ['success', sprintf(__('Order #%1$d saved: governorate %2$s. When you send it, Intigo will find the délégation in the address.', 'intigo-parcels'), $id, (string) $order->get_meta('_intigo_city_name'))];
        }
        $path = $this->format_zone_path($order->get_meta('_intigo_city_name'), $order->get_meta('_intigo_zone_district_name'), $order->get_meta('_intigo_zone_neighborhood_name'));
        /* translators: 1: WooCommerce order ID, 2: Intigo zone, e.g. "Tunis › El Menzah". */
        return ['success', sprintf(__('Order #%1$d saved: delivery zone %2$s. Ready to send.', 'intigo-parcels'), $id, $path)];
    }

    /**
     * "Detect addresses": detect the zone of recent orders not sent yet whose
     * zone is unknown, incomplete, or older than their address — at most $max
     * orders within $budget seconds. Zones chosen by hand are never touched.
     *
     * @return array{ready: int, review: int, blocked: int, remaining: int}
     */
    public function detect_addresses_batch($max = 25, $budget = 20.0) {
        $counts = ['ready' => 0, 'review' => 0, 'blocked' => 0, 'remaining' => 0];
        $orders = wc_get_orders([
            'type' => 'shop_order',
            'limit' => 100,
            'orderby' => 'date',
            'order' => 'DESC',
            'status' => array_diff(array_keys(wc_get_order_statuses()), ['wc-cancelled', 'wc-refunded', 'wc-failed', 'wc-checkout-draft']),
        ]);
        $resolver = new Intigo_Address_Resolver($this->api_client);
        $started = microtime(true);
        $done = 0;
        foreach ((array) $orders as $order) {
            if (!$order instanceof WC_Order || (string) $order->get_meta('_intigo_parcel_nid') !== '') {
                continue;
            }
            $tier = (string) $order->get_meta('_intigo_zone_tier');
            if ($tier === 'manual') {
                continue;
            }
            if (in_array($tier, ['resolved', 'review'], true) && !$resolver->address_changed($order)) {
                continue;
            }
            $country = strtoupper((string) ($order->get_shipping_country() ?: $order->get_billing_country()));
            if ($country !== '' && $country !== 'TN') {
                continue;
            }
            if ($done >= $max || (microtime(true) - $started) > $budget) {
                $counts['remaining']++;
                continue;
            }
            $done++;
            try {
                $state = $resolver->prepare_for_send($order);
            } catch (\Throwable $e) {
                $this->add_log('zone_detect_failed', 'order_id=' . $order->get_id() . '; ' . $e->getMessage());
                $counts['blocked']++;
                continue;
            }
            $t = (string) ($state['tier'] ?? '');
            if (in_array($t, ['resolved', 'manual'], true)) {
                $counts['ready']++;
            } elseif ($t === 'review') {
                $counts['review']++;
            } else {
                $counts['blocked']++;
            }
        }
        return $counts;
    }

    public function handle_detect_addresses() {
        if (!current_user_can('edit_shop_orders') && !current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('Unauthorized', 'intigo-parcels'));
        }
        check_admin_referer('intigo_detect_addresses');
        $c = $this->detect_addresses_batch();
        $this->add_log('detect_addresses', 'ready=' . $c['ready'] . '; review=' . $c['review'] . '; blocked=' . $c['blocked'] . '; remaining=' . $c['remaining']);
        if ($c['ready'] + $c['review'] + $c['blocked'] === 0) {
            $this->redirect_with_notice('intigo-manage-orders', __('No address to detect: every order not sent yet already has its zone.', 'intigo-parcels'), 'info');
            exit;
        }
        /* translators: 1: orders ready to send, 2: orders whose zone must be checked, 3: orders with an incomplete address. */
        $message = sprintf(__('Addresses detected: %1$d ready, %2$d to check, %3$d incomplete.', 'intigo-parcels'), $c['ready'], $c['review'], $c['blocked']);
        $details = [];
        if ($c['remaining'] > 0) {
            /* translators: %d: number of orders not processed yet. */
            $details[] = sprintf(__('%d more orders are waiting: click "Detect addresses" again.', 'intigo-parcels'), $c['remaining']);
        }
        $type = ($c['review'] + $c['blocked']) > 0 ? 'warning' : 'success';
        $this->redirect_with_notice('intigo-manage-orders', $message, $type, $details);
        exit;
    }

    /**
     * Shared, dependency-free zone widgets, printed once per page:
     *  - IntigoLocationAutocomplete: search box → floating result list;
     *  - IntigoZonePicker: governorate → délégation → quartier selects.
     * Used by the Manage Orders Edit window and the order-edit "Intigo Shipment" box.
     */
    private function render_zone_assets() {
        static $printed = false;
        if ($printed) {
            return;
        }
        $printed = true;
        $i18n = [
            'searching' => __('Searching…', 'intigo-parcels'),
            'noMatch' => __('No match — pick the governorate and délégation below.', 'intigo-parcels'),
            'searchError' => __('The address search did not answer.', 'intigo-parcels'),
            'retry' => __('Retry', 'intigo-parcels'),
            'filled' => __('Zone filled from search. Check it, then save.', 'intigo-parcels'),
            'loading' => __('Loading…', 'intigo-parcels'),
            'chooseGovernorate' => __('Choose the governorate', 'intigo-parcels'),
            'chooseDelegation' => __('Choose the délégation', 'intigo-parcels'),
            'noQuartier' => __('No quartier (optional)', 'intigo-parcels'),
            'governorateFirst' => __('Choose the governorate first', 'intigo-parcels'),
            'delegationFirst' => __('Choose the délégation first', 'intigo-parcels'),
            'noQuartierListed' => __('No quartier listed for this délégation', 'intigo-parcels'),
            'listError' => __('The Intigo zone list could not be loaded.', 'intigo-parcels'),
            'unavailable' => __('Unavailable', 'intigo-parcels'),
            'results' => __('Search results', 'intigo-parcels'),
            'detecting' => __('Detecting the address…', 'intigo-parcels'),
            'detectFailed' => __('The address could not be detected. Try again in a moment.', 'intigo-parcels'),
            /* translators: 1: characters typed, 2: maximum number of characters. */
            'counter' => __('%1$d / %2$d characters', 'intigo-parcels'),
        ];
        // The governorates, from the 24 h cache only (rendering never calls the API):
        // the governorate list is usable at once; when the cache is empty the pickers load it.
        $seed_cities = $this->api_client->peek_cities_cached();
        ?>
        <style>
            .intigo-zone-badge { display:inline-flex; align-items:center; gap:6px; padding:3px 10px; border-radius:999px; font-size:11.5px; font-weight:600; line-height:1.5; border:1px solid transparent; white-space:nowrap; }
            .intigo-zone-badge::before { content:''; width:7px; height:7px; border-radius:50%; background:currentColor; }
            .intigo-zone-badge.is-ready { background:#ecfdf5; color:#047857; border-color:#a7f3d0; }
            .intigo-zone-badge.is-ready::before { background:#10b981; }
            .intigo-zone-badge.is-review { background:#fffbeb; color:#92400e; border-color:#fde68a; }
            .intigo-zone-badge.is-review::before { background:#f59e0b; }
            .intigo-zone-badge.is-blocked { background:#fff1f2; color:#be123c; border-color:#fecdd3; }
            .intigo-zone-badge.is-blocked::before { background:#e11d48; }
            .intigo-zone-badge.is-none { background:#f1f5f9; color:#475569; border-color:#e2e8f0; }
            .intigo-zone-badge.is-none::before { background:#94a3b8; }
            .intigo-zp-msg { display:block; font-size:12px; color:#be123c; margin-top:4px; }
            .intigo-zp-msg[hidden] { display:none; }
            .intigo-zp-msg button { color:#4F46E5; text-decoration:underline; background:none; border:0; padding:0; cursor:pointer; font-size:12px; }
            .intigo-ac-panel { position:fixed; z-index:100050; box-sizing:border-box; background:#fff; border:1px solid #cbd5e1; border-radius:10px; box-shadow:0 14px 34px rgba(15,23,42,.18); overflow-y:auto; overscroll-behavior:contain; padding:4px; font-size:13px; }
            .intigo-ac-panel[hidden] { display:none; }
            .intigo-ac-status { padding:8px 10px; color:#64748b; }
            .intigo-ac-status.is-error { color:#be123c; }
            .intigo-ac-status button { margin-inline-start:6px; color:#4F46E5; text-decoration:underline; background:none; border:0; padding:0; cursor:pointer; font-size:13px; }
            .intigo-ac-list { list-style:none; margin:0; padding:0; }
            .intigo-ac-opt { margin:0; padding:8px 10px; border-radius:7px; cursor:pointer; color:#0f172a; line-height:1.4; }
            .intigo-ac-opt.is-active { background:#eef2ff; color:#312e81; }
            .intigo-ac-opt mark { background:#e0e7ff; color:inherit; font-weight:600; border-radius:3px; padding:0 1px; }
            @media (hover: hover) { .intigo-ac-opt:hover { background:#f5f3ff; } }
        </style>
        <script>
        (function() {
            if (window.IntigoLocationAutocomplete) return;
            var T = window.IntigoZoneI18n = <?php echo wp_json_encode($i18n); ?>;
            var seedCities = <?php echo wp_json_encode(is_array($seed_cities) ? array_values($seed_cities) : null); ?>;
            var uid = 0;

            /**
             * Detect the zone of one order (only when it was never detected; the server
             * never overwrites a zone chosen by hand). One request per order per page,
             * shared by the background pass, the Edit window and the order box.
             */
            var detections = {};
            window.IntigoDetectZone = function(ajaxUrl, nonce, orderId) {
                var key = String(orderId);
                if (detections[key]) return detections[key];
                var body = new FormData();
                body.append('action', 'intigo_detect_order_zone');
                body.append('order_id', key);
                body.append('_wpnonce', nonce);
                detections[key] = fetch(ajaxUrl, { method: 'POST', credentials: 'same-origin', body: body })
                    .then(function(r) { return r.json(); })
                    .then(function(data) {
                        if (!data || !data.success || !data.data) {
                            throw new Error(data && data.data && data.data.message ? data.data.message : T.detectFailed);
                        }
                        return data.data;
                    })
                    .catch(function(err) {
                        delete detections[key]; // a later try may work
                        throw err;
                    });
                return detections[key];
            };

            /** "12 / 250 characters" under a field with a maxlength. */
            window.IntigoCharCounter = function(field, out) {
                if (!field || !out) return function() {};
                var max = parseInt(field.getAttribute('maxlength'), 10) || 0;
                function update() {
                    out.textContent = T.counter.replace('%1$d', String(field.value.length)).replace('%2$d', String(max));
                }
                field.addEventListener('input', update);
                update();
                return update;
            };

            function fold(s) {
                s = String(s || '');
                if (s.normalize) s = s.normalize('NFD').replace(/[̀-ͯ]/g, '');
                return s.toLowerCase();
            }
            function highlighted(text, query) {
                var frag = document.createDocumentFragment();
                var folded = '', map = [];
                for (var i = 0; i < text.length; i++) {
                    var f = fold(text.charAt(i));
                    for (var k = 0; k < f.length; k++) { folded += f.charAt(k); map.push(i); }
                }
                var q = fold(query).replace(/\s+/g, ' ').trim();
                var pos = q ? folded.indexOf(q) : -1;
                if (pos < 0) { frag.appendChild(document.createTextNode(text)); return frag; }
                var start = map[pos], end = map[pos + q.length - 1] + 1;
                frag.appendChild(document.createTextNode(text.slice(0, start)));
                var m = document.createElement('mark');
                m.textContent = text.slice(start, end);
                frag.appendChild(m);
                frag.appendChild(document.createTextNode(text.slice(end)));
                return frag;
            }
            function zoneLabel(item) {
                var gov = ' (' + (item.city_name || '') + ')';
                return item.neighborhood_name
                    ? item.neighborhood_name + ' — ' + item.district_name + gov
                    : item.district_name + gov;
            }

            /**
             * Location autocomplete. opts: input, ajaxUrl, nonce, onPick(item).
             * Returns { close() }.
             */
            window.IntigoLocationAutocomplete = function(opts) {
                var input = opts.input;
                if (!input) return { close: function() {} };
                var id = 'intigo-ac-' + (++uid);
                var panel = document.createElement('div');
                panel.className = 'intigo-ac-panel';
                panel.hidden = true;
                var status = document.createElement('div');
                status.className = 'intigo-ac-status';
                status.setAttribute('aria-live', 'polite');
                var list = document.createElement('ul');
                list.className = 'intigo-ac-list';
                list.id = id + '-list';
                list.setAttribute('role', 'listbox');
                list.setAttribute('aria-label', T.results);
                panel.appendChild(status);
                panel.appendChild(list);
                document.body.appendChild(panel);
                // A mousedown inside the panel must not blur the input (the pick is on click).
                panel.addEventListener('mousedown', function(e) { e.preventDefault(); });

                input.setAttribute('role', 'combobox');
                input.setAttribute('aria-autocomplete', 'list');
                input.setAttribute('aria-expanded', 'false');
                input.setAttribute('aria-controls', list.id);
                input.setAttribute('autocomplete', 'off');

                var items = [], active = -1, timer = null, controller = null, seq = 0, lastQuery = '', open = false;

                function place() {
                    var r = input.getBoundingClientRect();
                    var below = window.innerHeight - r.bottom - 12;
                    var above = r.top - 12;
                    var up = below < 180 && above > below;
                    var maxH = Math.max(120, Math.min(300, up ? above : below));
                    panel.style.left = Math.max(8, r.left) + 'px';
                    panel.style.width = Math.min(r.width, window.innerWidth - 16) + 'px';
                    panel.style.maxHeight = maxH + 'px';
                    if (up) {
                        panel.style.top = '';
                        panel.style.bottom = (window.innerHeight - r.top + 4) + 'px';
                    } else {
                        panel.style.bottom = '';
                        panel.style.top = (r.bottom + 4) + 'px';
                    }
                }
                function show() {
                    if (!open) {
                        open = true;
                        panel.hidden = false;
                        input.setAttribute('aria-expanded', 'true');
                        window.addEventListener('scroll', place, true);
                        window.addEventListener('resize', place);
                    }
                    place();
                }
                function close() {
                    if (!open) return;
                    open = false;
                    panel.hidden = true;
                    input.setAttribute('aria-expanded', 'false');
                    input.removeAttribute('aria-activedescendant');
                    window.removeEventListener('scroll', place, true);
                    window.removeEventListener('resize', place);
                }
                function setStatus(text, isError, retry) {
                    status.textContent = text || '';
                    status.className = 'intigo-ac-status' + (isError ? ' is-error' : '');
                    status.hidden = !text;
                    if (retry) {
                        var b = document.createElement('button');
                        b.type = 'button';
                        b.textContent = T.retry;
                        b.addEventListener('click', function() { search(lastQuery); input.focus(); });
                        status.appendChild(b);
                    }
                }
                function setActive(i) {
                    var opts2 = list.children;
                    if (active >= 0 && opts2[active]) { opts2[active].classList.remove('is-active'); opts2[active].setAttribute('aria-selected', 'false'); }
                    active = i;
                    if (active >= 0 && opts2[active]) {
                        opts2[active].classList.add('is-active');
                        opts2[active].setAttribute('aria-selected', 'true');
                        input.setAttribute('aria-activedescendant', opts2[active].id);
                        opts2[active].scrollIntoView({ block: 'nearest' });
                    } else {
                        input.removeAttribute('aria-activedescendant');
                    }
                }
                function render(query) {
                    list.innerHTML = '';
                    active = -1;
                    input.removeAttribute('aria-activedescendant');
                    if (!items.length) { setStatus(T.noMatch); show(); return; }
                    setStatus('');
                    items.forEach(function(item, i) {
                        var li = document.createElement('li');
                        li.className = 'intigo-ac-opt';
                        li.id = id + '-opt-' + i;
                        li.setAttribute('role', 'option');
                        li.setAttribute('aria-selected', 'false');
                        li.appendChild(highlighted(zoneLabel(item), query));
                        li.addEventListener('click', function() { pick(i); });
                        list.appendChild(li);
                    });
                    show();
                }
                function pick(i) {
                    var item = items[i];
                    if (!item) return;
                    input.value = zoneLabel(item);
                    lastQuery = input.value;
                    items = [];
                    list.innerHTML = '';
                    close();
                    if (opts.onPick) opts.onPick(item);
                }
                function search(q) {
                    lastQuery = q;
                    if (controller) controller.abort();
                    controller = window.AbortController ? new AbortController() : null;
                    var mine = ++seq;
                    list.innerHTML = '';
                    items = [];
                    setStatus(T.searching);
                    show();
                    var url = opts.ajaxUrl + '?action=intigo_search_locations&q=' + encodeURIComponent(q) + '&_wpnonce=' + encodeURIComponent(opts.nonce);
                    fetch(url, { credentials: 'same-origin', signal: controller ? controller.signal : undefined })
                        .then(function(r) { return r.json(); })
                        .then(function(data) {
                            if (mine !== seq) return;
                            if (!data || !data.success || !Array.isArray(data.data)) {
                                throw new Error(data && data.data && data.data.message ? data.data.message : '');
                            }
                            items = data.data;
                            if (document.activeElement === input || open) render(q);
                        })
                        .catch(function(err) {
                            if ((err && err.name === 'AbortError') || mine !== seq) return;
                            list.innerHTML = '';
                            items = [];
                            setStatus((err && err.message) ? err.message : T.searchError, true, true);
                            show();
                        });
                }
                input.addEventListener('input', function() {
                    clearTimeout(timer);
                    var q = String(input.value || '').trim();
                    if (q.length < 2) {
                        if (controller) controller.abort();
                        seq++;
                        items = [];
                        list.innerHTML = '';
                        close();
                        return;
                    }
                    timer = setTimeout(function() { search(q); }, 250);
                });
                input.addEventListener('keydown', function(e) {
                    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
                        if (!items.length) return;
                        e.preventDefault();
                        if (!open) { show(); }
                        var n = items.length;
                        setActive(e.key === 'ArrowDown' ? (active + 1) % n : (active <= 0 ? n - 1 : active - 1));
                    } else if (e.key === 'Enter') {
                        // Never submit the surrounding form (the whole order!) from the search box.
                        e.preventDefault();
                        if (open && items.length) pick(active >= 0 ? active : 0);
                    } else if (e.key === 'Escape') {
                        if (open) {
                            e.preventDefault();
                            e.stopPropagation();
                            close();
                        }
                    } else if (e.key === 'Tab') {
                        close();
                    }
                });
                input.addEventListener('focus', function() {
                    if (String(input.value || '').trim().length >= 2 && items.length) render(lastQuery);
                });
                input.addEventListener('blur', function() {
                    setTimeout(function() { if (document.activeElement !== input) close(); }, 120);
                });
                document.addEventListener('pointerdown', function(e) {
                    if (open && e.target !== input && !panel.contains(e.target)) close();
                }, true);
                return { close: close };
            };

            /**
             * Governorate → délégation → quartier selects. opts: city, district,
             * neighborhood (selects), msgs {city, district, neighborhood}, ajaxUrl,
             * nonce, onChange(). Returns { setIds(c, d, n) → Promise<bool>, state() }.
             */
            var listCache = {};
            if (Array.isArray(seedCities) && seedCities.length) listCache['city:0'] = seedCities;
            window.IntigoZonePicker = function(opts) {
                var sel = { city: opts.city, district: opts.district, neighborhood: opts.neighborhood };
                var msgs = opts.msgs || {};
                var actions = { city: 'intigo_get_cities', district: 'intigo_get_districts', neighborhood: 'intigo_get_neighborhoods' };
                var params = { city: '', district: 'city_id', neighborhood: 'district_id' };
                var placeholder = { city: T.chooseGovernorate, district: T.chooseDelegation, neighborhood: T.noQuartier };
                var ctrls = {};
                var gen = 0;
                var target = { c: '', d: '', n: '' };

                function option(select, value, label) {
                    var o = document.createElement('option');
                    o.value = value;
                    o.textContent = label;
                    select.appendChild(o);
                }
                function message(kind, text, withRetry) {
                    var el = msgs[kind];
                    if (!el) return;
                    el.textContent = text || '';
                    el.hidden = !text;
                    if (text && withRetry) {
                        el.appendChild(document.createTextNode(' '));
                        var b = document.createElement('button');
                        b.type = 'button';
                        b.textContent = T.retry;
                        b.addEventListener('click', function() { setIds(target.c, target.d, target.n); });
                        el.appendChild(b);
                    }
                }
                function waiting(kind, text) {
                    if (ctrls[kind]) ctrls[kind].abort();
                    var s = sel[kind];
                    s.innerHTML = '';
                    option(s, '', text);
                    s.value = '';
                    s.disabled = true;
                    message(kind, '');
                }
                function fill(kind, items, selectedId) {
                    var s = sel[kind];
                    s.innerHTML = '';
                    option(s, '', kind === 'neighborhood' && !items.length ? T.noQuartierListed : placeholder[kind]);
                    items.forEach(function(it) { option(s, String(it.id), it.name); });
                    s.value = selectedId ? String(selectedId) : '';
                    if (s.value !== (selectedId ? String(selectedId) : '')) s.value = '';
                    s.disabled = kind === 'neighborhood' && !items.length;
                    message(kind, '');
                }
                function load(kind, parentId, selectedId) {
                    var key = kind + ':' + (parentId || 0);
                    if (listCache[key]) {
                        fill(kind, listCache[key], selectedId);
                        return Promise.resolve(true);
                    }
                    waiting(kind, T.loading);
                    var c = window.AbortController ? new AbortController() : null;
                    ctrls[kind] = c;
                    var url = opts.ajaxUrl + '?action=' + actions[kind]
                        + (params[kind] ? '&' + params[kind] + '=' + encodeURIComponent(parentId) : '')
                        + '&_wpnonce=' + encodeURIComponent(opts.nonce);
                    return fetch(url, { credentials: 'same-origin', signal: c ? c.signal : undefined })
                        .then(function(r) { return r.json(); })
                        .then(function(data) {
                            if (!data || !data.success || !Array.isArray(data.data)) {
                                throw new Error(data && data.data && data.data.message ? data.data.message : '');
                            }
                            listCache[key] = data.data;
                            fill(kind, data.data, selectedId);
                            return true;
                        })
                        .catch(function(err) {
                            if (err && err.name === 'AbortError') return false;
                            var s = sel[kind];
                            s.innerHTML = '';
                            option(s, '', T.unavailable);
                            s.disabled = true;
                            message(kind, (err && err.message) ? err.message : T.listError, true);
                            return false;
                        });
                }
                function changed() { if (opts.onChange) opts.onChange(state()); }
                function setIds(c, d, n) {
                    var g = ++gen;
                    target = { c: String(c || ''), d: String(d || ''), n: String(n || '') };
                    waiting('district', T.governorateFirst);
                    waiting('neighborhood', T.delegationFirst);
                    changed();
                    return load('city', 0, target.c).then(function(ok) {
                        if (g !== gen) return false;
                        if (!ok || !sel.city.value) { changed(); return ok; }
                        return load('district', sel.city.value, target.d).then(function(ok2) {
                            if (g !== gen) return false;
                            changed();
                            if (!ok2 || !sel.district.value) { return ok2; }
                            return load('neighborhood', sel.district.value, target.n).then(function(ok3) {
                                if (g !== gen) return false;
                                changed();
                                return ok3;
                            });
                        });
                    });
                }
                function text(s) { return s.value && s.selectedIndex >= 0 ? s.options[s.selectedIndex].textContent : ''; }
                function state() {
                    return {
                        cityId: sel.city.value, districtId: sel.district.value, neighborhoodId: sel.neighborhood.value,
                        cityName: text(sel.city), districtName: text(sel.district), neighborhoodName: text(sel.neighborhood)
                    };
                }
                sel.city.addEventListener('change', function() { setIds(sel.city.value, '', ''); });
                sel.district.addEventListener('change', function() { setIds(sel.city.value, sel.district.value, ''); });
                sel.neighborhood.addEventListener('change', function() { target.n = sel.neighborhood.value; changed(); });
                // Governorates already known (cache or an earlier load): selectable at once.
                if (listCache['city:0']) fill('city', listCache['city:0'], '');
                else waiting('city', T.loading);
                waiting('district', T.governorateFirst);
                waiting('neighborhood', T.delegationFirst);
                return { setIds: setIds, state: state };
            };
        })();
        </script>
        <?php
    }

    public function handle_intigo_login() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('Unauthorized', 'intigo-parcels'));
        }
        check_admin_referer('intigo_login');
        $label = isset($_POST['intigo_login_label']) ? sanitize_text_field(wp_unslash($_POST['intigo_login_label'])) : '';
        $api_key = isset($_POST['intigo_login_api_key']) ? sanitize_text_field(wp_unslash($_POST['intigo_login_api_key'])) : '';
        if ($api_key === '') {
            $this->add_log('login_failed', 'missing_api_key');
            $this->redirect_with_notice('intigo-dashboard', __('API key is required to login.', 'intigo-parcels'), 'error');
            exit;
        }

        $settings = $this->api_client->get_settings();
        $settings['api_key'] = $api_key;
        update_option(Intigo_API_Client::OPTION_KEY, $settings);
        $health = $this->check_health();
        if (!$health['ok']) {
            $this->add_log('login_failed', $health['message']);
            /* translators: %s: error message */
            $this->redirect_with_notice('intigo-dashboard', sprintf(__('Login failed: %s', 'intigo-parcels'), $health['message']), 'error');
            exit;
        }

        update_option(self::OPTION_AUTH, [
            'logged_in' => 'yes',
            'label' => $label !== '' ? $label : wp_get_current_user()->display_name,
            'user_id' => get_current_user_id(),
            'logged_at' => current_time('mysql'),
        ]);
        $this->add_log('login_success', 'user_id=' . get_current_user_id());
        $this->redirect_with_notice('intigo-dashboard', __('Logged in to Intigo successfully.', 'intigo-parcels'), 'success');
        exit;
    }

    public function handle_intigo_logout() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('Unauthorized', 'intigo-parcels'));
        }
        check_admin_referer('intigo_logout');
        delete_option(self::OPTION_AUTH);
        $this->add_log('logout', 'user_id=' . get_current_user_id());
        $this->redirect_with_notice('intigo-dashboard', __('Logged out from Intigo.', 'intigo-parcels'), 'info');
        exit;
    }

    private function render_login_interface($message = '') {
        $notice = $this->get_notice_message();
        ?>
        <div class="wrap">
            <?php $this->render_snackbar(); ?>
            <style>
                .intigo-login-shell { display:flex; justify-content:center; padding:32px 16px; }
                .intigo-login-card { width:100%; max-width:480px; background:#fff; border:1px solid #e2e8f0; border-radius:18px; box-shadow:0 18px 48px rgba(15,23,42,.08); overflow:hidden; }
                .intigo-login-header { padding:28px 28px 20px 28px; text-align:center; background:linear-gradient(180deg, #f0f7ff 0%, #fff 100%); border-bottom:1px solid #f1f5f9; }
                .intigo-login-mark { width:56px; height:56px; margin:0 auto 12px auto; border-radius:14px; background:#2271b1; color:#fff; display:flex; align-items:center; justify-content:center; box-shadow:0 6px 16px rgba(34,113,177,.30); }
                .intigo-login-mark .dashicons { font-size:30px; width:30px; height:30px; }
                .intigo-login-title { margin:0; font-size:20px; font-weight:700; color:#0f172a; }
                .intigo-login-sub { margin:6px 0 0 0; color:#475569; font-size:13px; }
                .intigo-login-body { padding:24px 28px 28px 28px; }
                .intigo-login-row { margin-bottom:14px; }
                .intigo-login-row label { display:block; font-size:13px; font-weight:600; color:#0f172a; margin-bottom:6px; }
                .intigo-login-row input { width:100%; min-height:40px; padding:0 12px; border:1px solid #c7d2dc; border-radius:10px; font-size:14px; background:#fbfdff; }
                .intigo-login-row input:focus { border-color:#2271b1; box-shadow:0 0 0 3px rgba(34,113,177,.15); outline:none; background:#fff; }
                .intigo-login-row .intigo-login-hint { color:#64748b; font-size:12px; margin-top:6px; }
                .intigo-login-submit { width:100%; padding:12px 16px; background:#2271b1; color:#fff; border:0; border-radius:10px; font-size:14px; font-weight:600; cursor:pointer; transition:background .15s ease; }
                .intigo-login-submit:hover { background:#1d63a0; }
                .intigo-login-notice { margin:0 28px 20px 28px; padding:10px 12px; border-radius:10px; background:#fff7e6; border:1px solid #fde68a; color:#92400e; font-size:13px; }
                .intigo-login-foot { padding:14px 28px; background:#f8fafc; color:#64748b; font-size:12px; text-align:center; border-top:1px solid #f1f5f9; }
                .intigo-login-foot a { color:#2271b1; text-decoration:none; }
                .intigo-login-foot a:hover { text-decoration:underline; }
            </style>
            <div class="intigo-login-shell">
                <div class="intigo-login-card">
                    <div class="intigo-login-header">
                        <div class="intigo-login-mark"><span class="dashicons dashicons-location-alt"></span></div>
                        <h1 class="intigo-login-title"><?php esc_html_e('Sign in to Intigo', 'intigo-parcels'); ?></h1>
                        <p class="intigo-login-sub"><?php esc_html_e('Connect this WooCommerce store so you can create parcels, bordereaux and sync orders.', 'intigo-parcels'); ?></p>
                    </div>
                    <?php if ($message !== ''): ?>
                        <div class="intigo-login-notice"><?php echo esc_html($message); ?></div>
                    <?php endif; ?>
                    <div class="intigo-login-body">
                        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                            <input type="hidden" name="action" value="intigo_login">
                            <?php wp_nonce_field('intigo_login'); ?>
                            <div class="intigo-login-row">
                                <label for="intigo_login_label"><?php esc_html_e('Display name', 'intigo-parcels'); ?></label>
                                <input id="intigo_login_label" name="intigo_login_label" type="text" placeholder="<?php esc_attr_e('e.g. Operations Team', 'intigo-parcels'); ?>" autocomplete="off">
                                <div class="intigo-login-hint"><?php esc_html_e('Shown in audit logs and notices. Optional.', 'intigo-parcels'); ?></div>
                            </div>
                            <div class="intigo-login-row">
                                <label for="intigo_login_api_key"><?php esc_html_e('Intigo API key', 'intigo-parcels'); ?></label>
                                <input id="intigo_login_api_key" name="intigo_login_api_key" type="password" required placeholder="<?php esc_attr_e('Paste your API key', 'intigo-parcels'); ?>" autocomplete="off">
                                <div class="intigo-login-hint"><?php esc_html_e('Find this in your Intigo partner dashboard. Keep it secret.', 'intigo-parcels'); ?></div>
                            </div>
                            <button type="submit" class="intigo-login-submit"><?php esc_html_e('Sign in', 'intigo-parcels'); ?></button>
                        </form>
                    </div>
                    <div class="intigo-login-foot">
                        <?php esc_html_e('Need a key? Contact your Intigo partner manager.', 'intigo-parcels'); ?>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    private function is_intigo_logged_in() {
        $auth = get_option(self::OPTION_AUTH, []);
        return is_array($auth) && (($auth['logged_in'] ?? 'no') === 'yes');
    }

    private function get_intigo_login_label() {
        $auth = get_option(self::OPTION_AUTH, []);
        if (is_array($auth) && !empty($auth['label'])) {
            return (string) $auth['label'];
        }
        $u = wp_get_current_user();
        return $u && !empty($u->display_name) ? (string) $u->display_name : __('User', 'intigo-parcels');
    }

    private function render_processing_mode_banner() {
        $settings = $this->api_client->get_settings();
        $is_auto = ($settings['auto_create_on_paid'] ?? 'no') === 'yes';
        $settings_url = admin_url('admin.php?page=intigo-parcels-settings');
        if ($is_auto) {
            echo '<div class="intigo-alert intigo-alert--info">'
                . '<span class="intigo-alert-icon"><span class="dashicons dashicons-update-alt"></span></span>'
                . '<span class="intigo-alert-body">' . wp_kses_post(__('<strong>Mode: Automatic.</strong> Orders are pushed to Intigo automatically when WooCommerce marks them as <em>Processing</em>.', 'intigo-parcels')) . '</span>'
                . '<span class="intigo-alert-actions"><a class="button button-small" href="' . esc_url($settings_url) . '">' . esc_html__('Change mode', 'intigo-parcels') . '</a></span>'
                . '</div>';
            return;
        }
        echo '<div class="intigo-alert intigo-alert--warn">'
            . '<span class="intigo-alert-icon"><span class="dashicons dashicons-visibility"></span></span>'
            . '<span class="intigo-alert-body">' . wp_kses_post(__('<strong>Mode: Manual.</strong> Review each order below and click <strong>Send to Intigo</strong> when you are ready to ship.', 'intigo-parcels')) . '</span>'
            . '<span class="intigo-alert-actions"><a class="button button-small" href="' . esc_url($settings_url) . '">' . esc_html__('Change mode', 'intigo-parcels') . '</a></span>'
            . '</div>';
    }

    private function render_environment_badge() {
        $settings = $this->api_client->get_settings();
        $mode = ($settings['environment_mode'] ?? 'sandbox') === 'production' ? 'production' : 'sandbox';
        if ($mode === 'sandbox') {
            echo '<div class="intigo-alert intigo-alert--warn">'
                . '<span class="intigo-alert-icon"><span class="dashicons dashicons-warning"></span></span>'
                . '<span class="intigo-alert-body">' . wp_kses_post(__('<strong>Testing mode.</strong> Sandbox environment is active &mdash; no live shipments are produced.', 'intigo-parcels')) . '</span>'
                . '</div>';
            return;
        }
        echo '<div class="intigo-alert intigo-alert--success">'
            . '<span class="intigo-alert-icon"><span class="dashicons dashicons-yes"></span></span>'
            . '<span class="intigo-alert-body">' . wp_kses_post(__('<strong>Production mode.</strong> Live environment &mdash; real shipments may be created.', 'intigo-parcels')) . '</span>'
            . '</div>';
    }

    private function render_page_header($title, $subtitle = '', $eyebrow = '', $extra_pills = '') {
        $settings = $this->api_client->get_settings();
        $env = ($settings['environment_mode'] ?? 'sandbox') === 'production' ? 'production' : 'sandbox';
        $health = $this->check_health();
        $health_class = $health['ok'] ? 'intigo-pill-ok' : 'intigo-pill-err';
        $health_label = $health['ok'] ? __('API connected', 'intigo-parcels') : __('API issue', 'intigo-parcels');
        $env_class = $env === 'production' ? 'intigo-pill-info' : 'intigo-pill-warn';
        $env_label = $env === 'production' ? __('Production', 'intigo-parcels') : __('Sandbox', 'intigo-parcels');
        ?>
        <div class="intigo-hero">
            <div class="intigo-hero-text">
                <?php if ($eyebrow !== ''): ?>
                    <span class="intigo-hero-eyebrow"><?php echo esc_html($eyebrow); ?></span>
                <?php endif; ?>
                <h1><?php echo esc_html($title); ?></h1>
                <?php if ($subtitle !== ''): ?>
                    <p><?php echo wp_kses_post($subtitle); ?></p>
                <?php endif; ?>
            </div>
            <div class="intigo-hero-meta">
                <span class="intigo-pill-status <?php echo esc_attr($health_class); ?>" title="<?php echo esc_attr($health['message']); ?>">
                    <span class="intigo-dot"></span><?php echo esc_html($health_label); ?>
                </span>
                <span class="intigo-pill-status <?php echo esc_attr($env_class); ?>">
                    <span class="intigo-dot"></span><?php echo esc_html($env_label); ?>
                </span>
                <span class="intigo-pill-status intigo-pill-version" title="<?php esc_attr_e('Installed plugin version', 'intigo-parcels'); ?>">
                    <span class="dashicons dashicons-tag" style="font-size:14px; width:14px; height:14px;"></span>v<?php echo esc_html(defined('INTIGO_PARCELS_VERSION') ? INTIGO_PARCELS_VERSION : ''); ?>
                </span>
                <?php if ($extra_pills !== ''): ?>
                    <?php echo $extra_pills; ?>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

    /**
     * Queue a one-shot notice for the current user. It is shown on the next admin
     * page that renders notices (Intigo pages as a toast, WooCommerce order screens
     * as a standard WP notice) and then discarded. Stored server-side, so long error
     * texts never travel in the URL.
     *
     * @param string   $message Plain text (escaped on output).
     * @param string   $type    success | error | warning | info.
     * @param string[] $details Optional extra lines (plain text), e.g. per-order failures.
     */
    public static function queue_notice($message, $type = 'info', $details = []) {
        $user_id = get_current_user_id();
        $message = trim((string) $message);
        if ($user_id <= 0 || $message === '') {
            return;
        }
        $key = self::NOTICE_TRANSIENT_PREFIX . $user_id;
        $notices = get_transient($key);
        if (!is_array($notices)) {
            $notices = [];
        }
        $notices[] = [
            'message' => $message,
            'type' => in_array($type, ['success', 'error', 'warning', 'info'], true) ? $type : 'info',
            'details' => array_values(array_filter(array_map('strval', (array) $details), 'strlen')),
        ];
        set_transient($key, array_slice($notices, -20), 10 * MINUTE_IN_SECONDS);
    }

    /**
     * Return and clear the current user's queued notices.
     */
    public static function take_notices() {
        $user_id = get_current_user_id();
        if ($user_id <= 0) {
            return [];
        }
        $key = self::NOTICE_TRANSIENT_PREFIX . $user_id;
        $notices = get_transient($key);
        if ($notices !== false) {
            delete_transient($key);
        }
        return is_array($notices) ? $notices : [];
    }

    /**
     * Notices for this Intigo page view: the queued ones plus the legacy
     * `intigo_notice` URL parameter (still honoured for old links/redirects).
     * Cached per request so several callers can read them.
     */
    private function get_page_notices() {
        if ($this->page_notices !== null) {
            return $this->page_notices;
        }
        $notices = self::take_notices();
        $legacy = isset($_GET['intigo_notice']) ? sanitize_text_field(wp_unslash($_GET['intigo_notice'])) : '';
        if ($legacy !== '') {
            $type = isset($_GET['intigo_notice_type']) ? sanitize_text_field(wp_unslash($_GET['intigo_notice_type'])) : 'info';
            $notices[] = [
                'message' => $legacy,
                'type' => in_array($type, ['success', 'error', 'warning', 'info'], true) ? $type : 'info',
                'details' => [],
            ];
        }
        $this->page_notices = $notices;
        return $notices;
    }

    private function get_notice_message() {
        $notices = $this->get_page_notices();
        return empty($notices) ? '' : (string) $notices[0]['message'];
    }

    private function redirect_with_notice($page, $message, $type = 'info', $details = []) {
        self::queue_notice($message, $type, $details);
        wp_safe_redirect(add_query_arg([
            'page' => $page,
        ], admin_url('admin.php')));
    }

    /**
     * Redirect back where the user came from (e.g. the order-edit screen), falling
     * back to an Intigo page, carrying a one-shot notice.
     */
    private function redirect_back_with_notice($fallback_page, $message, $type = 'info') {
        self::queue_notice($message, $type);
        $referer = wp_get_referer();
        wp_safe_redirect($referer ? $referer : add_query_arg(['page' => $fallback_page], admin_url('admin.php')));
    }

    /**
     * admin_notices: show queued Intigo notices on WooCommerce order screens (list
     * and edit, HPOS and legacy storage) as standard WP notices. Intigo's own pages
     * use the toast from render_snackbar() instead.
     */
    public function render_order_screen_notices($screen_id = null) {
        // admin_notices passes '' (do_action() with no argument), not null.
        if (!is_string($screen_id) || $screen_id === '') {
            $screen = function_exists('get_current_screen') ? get_current_screen() : null;
            $screen_id = $screen ? (string) $screen->id : '';
        }
        if (!in_array($screen_id, ['woocommerce_page_wc-orders', 'shop_order', 'edit-shop_order'], true)) {
            return;
        }
        foreach (self::take_notices() as $notice) {
            $type = in_array($notice['type'] ?? '', ['success', 'error', 'warning', 'info'], true) ? $notice['type'] : 'info';
            echo '<div class="notice notice-' . esc_attr($type) . ' is-dismissible"><p><strong>Intigo:</strong> ' . esc_html((string) ($notice['message'] ?? '')) . '</p>';
            if (!empty($notice['details'])) {
                echo '<ul style="list-style:disc; margin:0 0 8px 20px;">';
                foreach ((array) $notice['details'] as $line) {
                    echo '<li>' . esc_html((string) $line) . '</li>';
                }
                echo '</ul>';
            }
            echo '</div>';
        }
    }

    private function render_snackbar() {
        $notices = $this->get_page_notices();
        if (empty($notices)) {
            return;
        }
        $styles = [
            'info' => ['#2271b1', 'dashicons-info-outline', __('Notice', 'intigo-parcels')],
            'success' => ['#16a34a', 'dashicons-yes-alt', __('Success', 'intigo-parcels')],
            'error' => ['#dc2626', 'dashicons-warning', __('Error', 'intigo-parcels')],
            'warning' => ['#d97706', 'dashicons-warning', __('Heads up', 'intigo-parcels')],
        ];
        ?>
        <style>
            #intigo-snackbar-stack { position:fixed; right:24px; bottom:24px; z-index:100100; display:flex; flex-direction:column; gap:10px; align-items:flex-end; }
            .intigo-snackbar { position:relative; min-width:300px; max-width:440px; background:#0f172a; color:#fff; padding:0; border-radius:14px; box-shadow:0 18px 48px rgba(15,23,42,.35); overflow:hidden; transform:translateY(16px); opacity:0; transition: transform .3s cubic-bezier(.2,.9,.3,1.2), opacity .25s ease; }
            .intigo-snackbar.is-visible { transform:translateY(0); opacity:1; }
            .intigo-snackbar .intigo-sn-rail { position:absolute; left:0; top:0; bottom:0; width:4px; background:var(--intigo-sn-color); }
            .intigo-snackbar .intigo-sn-inner { display:flex; gap:12px; padding:14px 16px 14px 20px; align-items:flex-start; }
            .intigo-snackbar .intigo-sn-icon { flex:0 0 auto; width:28px; height:28px; border-radius:50%; background:var(--intigo-sn-color); display:flex; align-items:center; justify-content:center; color:#fff; }
            .intigo-snackbar .intigo-sn-icon .dashicons { font-size:16px; width:16px; height:16px; }
            .intigo-snackbar .intigo-sn-text { flex:1 1 auto; min-width:0; }
            .intigo-snackbar .intigo-sn-title { display:block; font-weight:600; font-size:13px; margin-bottom:2px; color:#fff; }
            .intigo-snackbar .intigo-sn-msg { display:block; font-size:13px; color:#cbd5e1; line-height:1.45; word-break:break-word; }
            .intigo-snackbar .intigo-sn-details { margin:6px 0 0 16px; padding:0; list-style:disc; font-size:12px; color:#cbd5e1; max-height:180px; overflow:auto; }
            .intigo-snackbar .intigo-sn-close { flex:0 0 auto; background:transparent; border:0; color:#94a3b8; cursor:pointer; padding:4px; line-height:0; border-radius:6px; }
            .intigo-snackbar .intigo-sn-close:hover { color:#fff; background:rgba(255,255,255,.06); }
            .intigo-snackbar .intigo-sn-progress { height:2px; background:rgba(255,255,255,.08); position:relative; }
            .intigo-snackbar .intigo-sn-progress::after { content:''; position:absolute; left:0; top:0; bottom:0; width:100%; background:var(--intigo-sn-color); transform-origin:left; animation: intigoSnTick 6s linear forwards; }
            @keyframes intigoSnTick { from { transform:scaleX(1); } to { transform:scaleX(0); } }
            @media (max-width: 600px) { #intigo-snackbar-stack { right:12px; left:12px; bottom:12px; align-items:stretch; } .intigo-snackbar { max-width:none; min-width:0; } }
        </style>
        <div id="intigo-snackbar-stack">
            <?php foreach ($notices as $notice): ?>
                <?php
                $type = isset($styles[$notice['type'] ?? '']) ? $notice['type'] : 'info';
                list($rail_color, $icon, $title) = $styles[$type];
                // Success/info fade out on their own; errors and warnings stay until dismissed so they can be read.
                $sticky = in_array($type, ['error', 'warning'], true);
                ?>
                <div class="intigo-snackbar" style="--intigo-sn-color:<?php echo esc_attr($rail_color); ?>;" role="<?php echo $sticky ? 'alert' : 'status'; ?>" aria-live="<?php echo $sticky ? 'assertive' : 'polite'; ?>" data-autohide="<?php echo $sticky ? '0' : '1'; ?>">
                    <span class="intigo-sn-rail"></span>
                    <div class="intigo-sn-inner">
                        <span class="intigo-sn-icon"><span class="dashicons <?php echo esc_attr($icon); ?>"></span></span>
                        <div class="intigo-sn-text">
                            <span class="intigo-sn-title"><?php echo esc_html($title); ?></span>
                            <span class="intigo-sn-msg"><?php echo esc_html((string) ($notice['message'] ?? '')); ?></span>
                            <?php if (!empty($notice['details'])): ?>
                                <ul class="intigo-sn-details">
                                    <?php foreach ((array) $notice['details'] as $line): ?>
                                        <li><?php echo esc_html((string) $line); ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>
                        </div>
                        <button type="button" class="intigo-sn-close" aria-label="<?php esc_attr_e('Dismiss', 'intigo-parcels'); ?>"><span class="dashicons dashicons-no-alt"></span></button>
                    </div>
                    <?php if (!$sticky): ?>
                        <div class="intigo-sn-progress"></div>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
        <script>
        (function() {
            const stack = document.getElementById('intigo-snackbar-stack');
            if (!stack) return;
            stack.querySelectorAll('.intigo-snackbar').forEach(function(sb) {
                requestAnimationFrame(() => sb.classList.add('is-visible'));
                const close = () => {
                    sb.classList.remove('is-visible');
                    setTimeout(() => { if (sb.parentNode) sb.parentNode.removeChild(sb); }, 320);
                };
                const btn = sb.querySelector('.intigo-sn-close');
                if (btn) btn.addEventListener('click', close);
                if (sb.getAttribute('data-autohide') === '1') setTimeout(close, 6000);
            });
        })();
        </script>
        <?php
    }

    private function render_interface_nav($current_page) {
        $items = [
            'intigo-dashboard' => ['label' => __('Dashboard', 'intigo-parcels'), 'icon' => 'dashicons-chart-area'],
            'intigo-manage-orders' => ['label' => __('Manage Orders', 'intigo-parcels'), 'icon' => 'dashicons-cart'],
            'intigo-logs' => ['label' => __('Logs', 'intigo-parcels'), 'icon' => 'dashicons-list-view'],
            'intigo-docs' => ['label' => __('Documentation', 'intigo-parcels'), 'icon' => 'dashicons-book-alt'],
            'intigo-parcels-settings' => ['label' => __('Settings', 'intigo-parcels'), 'icon' => 'dashicons-admin-generic'],
        ];
        $new_count = $this->get_new_orders_count();
        ?>
        <style>
            .intigo-nav { display:flex; gap:2px; flex-wrap:wrap; margin:6px 0 18px 0; padding:0; border-bottom:1px solid #e2e8f0; }
            .intigo-nav a { display:inline-flex; align-items:center; gap:8px; padding:10px 14px; border-radius:8px 8px 0 0; color:#475569; font-weight:600; font-size:13px; text-decoration:none; border:1px solid transparent; border-bottom:0; position:relative; bottom:-1px; transition:color .15s ease, background .15s ease; }
            .intigo-nav a:hover { color:#0f172a; background:#f8fafc; }
            .intigo-nav a.is-active { color:#0f172a; background:#fff; border-color:#e2e8f0; }
            .intigo-nav a.is-active::after { content:''; position:absolute; left:14px; right:14px; bottom:1px; height:2px; background:#2271b1; border-radius:2px; }
            .intigo-nav a .dashicons { width:16px; height:16px; font-size:16px; }
            .intigo-nav-badge { display:inline-flex; align-items:center; justify-content:center; min-width:20px; height:20px; padding:0 6px; background:#2271b1; color:#fff; border-radius:999px; font-size:11px; font-weight:700; }
            @media (max-width: 600px) { .intigo-nav a { padding:8px 10px; font-size:12px; } }
        </style>
        <nav class="intigo-nav" aria-label="<?php esc_attr_e('Intigo sections', 'intigo-parcels'); ?>">
            <?php foreach ($items as $slug => $item):
                $is_active = $slug === $current_page;
                $url = admin_url('admin.php?page=' . $slug);
                ?>
                <a class="<?php echo $is_active ? 'is-active' : ''; ?>" href="<?php echo esc_url($url); ?>">
                    <span class="dashicons <?php echo esc_attr($item['icon']); ?>"></span>
                    <?php echo esc_html($item['label']); ?>
                    <?php if ($slug === 'intigo-manage-orders' && $new_count > 0): ?>
                        <span class="intigo-nav-badge" title="<?php
                            /* translators: %d: number of new orders */
                            echo esc_attr(sprintf(__('%d new orders', 'intigo-parcels'), $new_count));
                        ?>"><?php echo esc_html($new_count); ?></span>
                    <?php endif; ?>
                </a>
            <?php endforeach; ?>
        </nav>
        <?php
    }

    private function render_responsive_styles() {
        ?>
        <style>
            :root {
                --intigo-primary: #2271b1;
                --intigo-primary-hover: #1d63a0;
                --intigo-primary-soft: #eff6ff;
                --intigo-success: #047857;
                --intigo-success-soft: #ecfdf5;
                --intigo-warn: #92400e;
                --intigo-warn-soft: #fff7e6;
                --intigo-danger: #b91c1c;
                --intigo-danger-soft: #fef2f2;
                --intigo-info: #1d4ed8;
                --intigo-info-soft: #eff6ff;
                --intigo-text: #0f172a;
                --intigo-text-soft: #475569;
                --intigo-muted: #64748b;
                --intigo-border: #e2e8f0;
                --intigo-border-soft: #f1f5f9;
                --intigo-bg: #f8fafc;
                --intigo-card-bg: #ffffff;
                --intigo-radius-sm: 8px;
                --intigo-radius: 12px;
                --intigo-radius-lg: 16px;
                --intigo-shadow-sm: 0 1px 2px rgba(15,23,42,.04);
                --intigo-shadow: 0 4px 14px rgba(15,23,42,.06);
                --intigo-shadow-lg: 0 18px 48px rgba(15,23,42,.10);
            }

            /* Vertical rhythm — give every top-level block room to breathe */
            .wrap .intigo-hero,
            .wrap .intigo-alert,
            .wrap .intigo-card,
            .wrap .intigo-kpis,
            .wrap .intigo-charts,
            .wrap .intigo-table-wrap,
            .wrap .intigo-section,
            .wrap .intigo-tech,
            .wrap .intigo-docs-grid,
            .wrap .intigo-logs-meta,
            .wrap .intigo-pagination,
            .wrap .intigo-save-bar { margin-bottom: 20px; }
            .wrap .intigo-hero + .intigo-alert,
            .wrap .intigo-alert + .intigo-alert { margin-top:0; }

            /* Page header (hero) */
            .wrap .intigo-hero { display:flex; justify-content:space-between; align-items:flex-start; gap:16px; margin: 6px 0 20px 0; padding:18px 22px; background: linear-gradient(180deg, #ffffff 0%, #fbfdff 100%); border:1px solid var(--intigo-border); border-radius: var(--intigo-radius-lg); box-shadow: var(--intigo-shadow-sm); flex-wrap:wrap; }
            .wrap .intigo-hero-text { min-width:0; flex:1 1 320px; }
            .wrap .intigo-hero-eyebrow { display:inline-block; font-size:11px; font-weight:700; letter-spacing:.06em; color:var(--intigo-primary); text-transform:uppercase; margin:0 0 4px 0; }
            .wrap .intigo-hero h1 { margin:0; padding:0; font-size:22px; font-weight:700; color:var(--intigo-text); line-height:1.25; }
            .wrap .intigo-hero p { margin:6px 0 0 0; color:var(--intigo-muted); font-size:13.5px; max-width:680px; }
            .wrap .intigo-hero-meta { display:flex; flex-wrap:wrap; gap:8px; align-items:center; }

            /* Pills */
            .intigo-pill-status { display:inline-flex; align-items:center; gap:8px; padding:6px 12px; border-radius:999px; font-size:12.5px; font-weight:600; border:1px solid transparent; line-height:1; white-space:nowrap; }
            .intigo-pill-status .intigo-dot { width:7px; height:7px; border-radius:50%; background:currentColor; box-shadow:0 0 0 4px rgba(0,0,0,.05); }
            .intigo-pill-ok { background:var(--intigo-success-soft); color:var(--intigo-success); border-color:#a7f3d0; }
            .intigo-pill-err { background:var(--intigo-danger-soft); color:var(--intigo-danger); border-color:#fecaca; }
            .intigo-pill-warn { background:var(--intigo-warn-soft); color:var(--intigo-warn); border-color:#fde68a; }
            .intigo-pill-info { background:var(--intigo-info-soft); color:var(--intigo-info); border-color:#bfdbfe; }
            .intigo-pill-version { background:#f1f5f9; color:#475569; border-color:#e2e8f0; font-variant-numeric:tabular-nums; }
            .intigo-pill-neutral { background:#f1f5f9; color:var(--intigo-text-soft); border-color:var(--intigo-border); }

            /* Inline alerts */
            .intigo-alert { display:flex; gap:12px; align-items:flex-start; padding:12px 14px; border-radius: var(--intigo-radius); border:1px solid var(--intigo-border); background:#fff; margin:10px 0; }
            .intigo-alert .intigo-alert-icon { flex:0 0 auto; width:22px; height:22px; border-radius:50%; display:flex; align-items:center; justify-content:center; color:#fff; margin-top:1px; }
            .intigo-alert .intigo-alert-icon .dashicons { font-size:14px; width:14px; height:14px; }
            .intigo-alert .intigo-alert-body { min-width:0; flex:1 1 auto; color:var(--intigo-text); font-size:13.5px; line-height:1.5; }
            .intigo-alert .intigo-alert-body strong { color:var(--intigo-text); }
            .intigo-alert .intigo-alert-actions { flex:0 0 auto; }
            .intigo-alert--info { border-color:#bfdbfe; background:var(--intigo-info-soft); }
            .intigo-alert--info .intigo-alert-icon { background:var(--intigo-info); }
            .intigo-alert--success { border-color:#a7f3d0; background:var(--intigo-success-soft); }
            .intigo-alert--success .intigo-alert-icon { background:var(--intigo-success); }
            .intigo-alert--warn { border-color:#fde68a; background:var(--intigo-warn-soft); }
            .intigo-alert--warn .intigo-alert-icon { background:#dba617; }
            .intigo-alert--error { border-color:#fecaca; background:var(--intigo-danger-soft); }
            .intigo-alert--error .intigo-alert-icon { background:var(--intigo-danger); }

            /* Cards */
            .wrap .intigo-card,
            .wrap .intigo-chart-card { box-sizing: border-box; }
            .wrap .intigo-card { width: 100%; max-width: none; background:var(--intigo-card-bg); border:1px solid var(--intigo-border); border-radius: var(--intigo-radius-lg); padding:18px 20px; box-shadow: var(--intigo-shadow-sm); }
            .wrap .intigo-card table.widefat { width: 100% !important; min-width: 100%; }
            .wrap .intigo-card-title { margin:0 0 4px 0; font-size:15px; font-weight:600; color:var(--intigo-text); }
            .wrap .intigo-card-sub { margin:0 0 14px 0; color:var(--intigo-muted); font-size:13px; }

            /* KPIs */
            .wrap .intigo-kpis { display: grid; grid-template-columns: repeat(4, minmax(160px, 1fr)); gap: 10px; }
            .wrap .intigo-kpi { background: linear-gradient(180deg, #fff, #fbfdff); border:1px solid var(--intigo-border); border-radius: var(--intigo-radius); padding:14px 16px; transition: box-shadow .15s ease, transform .15s ease; }
            .wrap .intigo-kpi:hover { box-shadow: var(--intigo-shadow); transform: translateY(-1px); }
            .wrap .intigo-kpi-label { font-size:12px; color:var(--intigo-muted); margin-bottom:6px; font-weight:500; letter-spacing:.02em; }
            .wrap .intigo-kpi-value { font-size:22px; font-weight:700; color:var(--intigo-text); line-height:1.1; }

            /* Charts */
            .wrap .intigo-charts { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
            .wrap .intigo-chart-card { background:#fff; border:1px solid var(--intigo-border); border-radius: var(--intigo-radius); padding:16px; box-shadow: var(--intigo-shadow-sm); }
            .wrap .intigo-chart-title { margin:0 0 12px 0; font-size:13px; font-weight:600; color:var(--intigo-text); }
            .wrap .intigo-bar-row { margin-bottom:10px; }
            .wrap .intigo-bar-meta { display:flex; justify-content:space-between; font-size:12.5px; color:var(--intigo-text-soft); margin-bottom:5px; }
            .wrap .intigo-bar-track { width:100%; height:8px; border-radius:999px; background:#eef2f6; overflow:hidden; }
            .wrap .intigo-bar-fill { height:100%; border-radius:999px; transition: width .4s ease; }
            .wrap .intigo-fill-blue { background: linear-gradient(90deg, #2271b1, #4f9bd8); }
            .wrap .intigo-fill-green { background: linear-gradient(90deg, #16a34a, #4ade80); }
            .wrap .intigo-fill-yellow { background: linear-gradient(90deg, #dba617, #facc15); }
            .wrap .intigo-fill-gray { background: linear-gradient(90deg, #94a3b8, #cbd5e1); }

            /* Tables */
            .wrap .widefat { width: 100%; display: block; overflow-x: auto; -webkit-overflow-scrolling: touch; border:0 !important; background:transparent; }
            .wrap .intigo-table-wrap { background:#fff; border:1px solid var(--intigo-border); border-radius: var(--intigo-radius); overflow:hidden; }
            .wrap .intigo-table-wrap .widefat thead th { background:#f8fafc; font-weight:600; color:var(--intigo-text); border-bottom:1px solid var(--intigo-border); padding:12px 14px; }
            .wrap .intigo-table-wrap .widefat tbody td { padding:12px 14px; border-bottom:1px solid var(--intigo-border-soft); color:var(--intigo-text-soft); }
            .wrap .intigo-table-wrap .widefat tbody tr:last-child td { border-bottom:0; }
            .wrap .intigo-table-wrap .widefat tbody tr:hover td { background:#fbfdff; }

            /* Buttons (subtle polish that respects WP defaults) */
            .wrap .button { border-radius:8px; font-weight:500; }
            .wrap .button-primary { background:var(--intigo-primary); border-color:var(--intigo-primary); }
            .wrap .button-primary:hover, .wrap .button-primary:focus { background:var(--intigo-primary-hover); border-color:var(--intigo-primary-hover); }

            /* Pagination */
            .wrap .intigo-pagination { display:flex; flex-wrap:wrap; gap:6px; align-items:center; padding:8px 0; }
            .wrap .intigo-page-btn { display:inline-flex; align-items:center; gap:4px; min-width:36px; height:34px; padding:0 12px; border-radius:8px; border:1px solid var(--intigo-border); background:#fff; color:var(--intigo-text-soft); font-size:13px; font-weight:600; text-decoration:none; transition: background .15s ease, color .15s ease, border-color .15s ease, box-shadow .15s ease; justify-content:center; }
            .wrap .intigo-page-btn:hover { background:#f8fafc; color:var(--intigo-text); border-color:#cbd5e1; }
            .wrap .intigo-page-btn.is-active { background:var(--intigo-primary); color:#fff; border-color:var(--intigo-primary); box-shadow: 0 4px 10px rgba(34,113,177,.18); }
            .wrap .intigo-page-btn.is-active:hover { background:var(--intigo-primary-hover); color:#fff; }
            .wrap .intigo-page-btn.is-disabled { opacity:.45; pointer-events:none; }
            .wrap .intigo-page-btn .dashicons { font-size:16px; width:16px; height:16px; }
            .wrap .intigo-page-ellipsis { padding:0 4px; color:var(--intigo-muted); font-weight:600; }

            /* Empty state */
            .wrap .intigo-empty { padding:36px 20px; text-align:center; color:var(--intigo-muted); }
            .wrap .intigo-empty-icon { width:48px; height:48px; margin:0 auto 10px auto; border-radius:50%; background:#f1f5f9; display:flex; align-items:center; justify-content:center; color:var(--intigo-text-soft); }
            .wrap .intigo-empty-icon .dashicons { font-size:24px; width:24px; height:24px; }
            .wrap .intigo-empty-title { font-size:14px; font-weight:600; color:var(--intigo-text); margin-bottom:4px; }

            /* Modal carryover */
            .intigo-modal { max-height: 90vh; overflow: auto; }

            /* Pills used in tables */
            .intigo-pill { display:inline-block; padding:3px 10px; border-radius:999px; font-size:11px; font-weight:600; line-height:1.4; }
            .intigo-pill-ok { background:#dcfce7; color:#166534; }
            .intigo-pill-warn { background:#fef3c7; color:#92400e; }
            .intigo-pill-info { background:#dbeafe; color:#1e3a8a; }
            .intigo-pill-muted { background:#f1f5f9; color:#374151; }

            @media (max-width: 1200px) {
                .wrap .intigo-kpis { grid-template-columns: repeat(3, minmax(160px, 1fr)); }
            }
            @media (max-width: 900px) {
                .wrap .intigo-kpis { grid-template-columns: repeat(2, minmax(140px, 1fr)); }
                .wrap .intigo-charts { grid-template-columns: 1fr; }
                .wrap .intigo-hero { padding:16px 18px; }
            }
            @media (max-width: 600px) {
                .wrap .intigo-kpis { grid-template-columns: 1fr; }
                .wrap .button { width: 100%; text-align: center; margin-bottom: 6px; }
                .wrap .widefat thead th, .wrap .widefat tbody td { font-size: 12px; }
                .intigo-modal { width: 94vw; }
                .intigo-modal-header { flex-wrap: wrap; gap: 8px; }
                .wrap .intigo-hero h1 { font-size:18px; }
            }
        </style>
        <?php
    }

    private function is_order_new($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) {
            return false;
        }
        return (string) $order->get_meta('_intigo_seen_at') === '';
    }

    private function get_new_orders_count() {
        if (!function_exists('wc_get_orders')) {
            return 0;
        }
        $orders = wc_get_orders(['type' => 'shop_order', 'limit' => 50, 'orderby' => 'date', 'order' => 'DESC']);
        $count = 0;
        foreach ($orders as $order) {
            if (!$order || !method_exists($order, 'get_id')) {
                continue;
            }
            if ((string) $order->get_meta('_intigo_seen_at') === '') {
                $count++;
            }
        }
        return $count;
    }

    private function mark_orders_as_seen($orders) {
        foreach ($orders as $order) {
            if (!$order || !method_exists($order, 'get_id')) {
                continue;
            }
            if ((string) $order->get_meta('_intigo_seen_at') === '') {
                $order->update_meta_data('_intigo_seen_at', current_time('mysql'));
                $order->save_meta_data();
            }
        }
    }

    public function render_manage_orders_shortcode() {
        if (!is_user_logged_in()) {
            return '<p>' . esc_html__('Please login to access Intigo manage orders.', 'intigo-parcels') . '</p>';
        }
        if (!current_user_can('manage_woocommerce')) {
            return '<p>' . esc_html__('You do not have permission to access Intigo manage orders.', 'intigo-parcels') . '</p>';
        }
        $url = admin_url('admin.php?page=intigo-manage-orders');
        return '<p><a class="button" href="' . esc_url($url) . '">' . esc_html__('Open Intigo Manage Orders', 'intigo-parcels') . '</a></p>';
    }

    private function compute_automatic_ops_status($city_id, $district_id, $package_size, $nid, $bordereau_url) {
        // The package size is not required: it is resolved from the products at send time.
        // A parcel sent by name has no délégation id here, and needs none any more.
        if ((string) $nid === '' && ((string) $city_id === '' || (string) $district_id === '')) {
            return 'missing_data';
        }
        if ((string) $nid === '' && (string) $bordereau_url === '') {
            return 'verified';
        }
        if ((string) $nid !== '' && (string) $bordereau_url === '') {
            return 'need_confirmation';
        }
        return 'ready_for_shipment';
    }

    private function build_order_tags($city_id, $district_id, $package_size, $nid, $ops_status) {
        $tags = [];
        $ops_status_label = '';
        $ops_status_class = 'intigo-pill-muted';
        if ($ops_status === 'verified') {
            $ops_status_label = __('Verified', 'intigo-parcels');
            $ops_status_class = 'intigo-pill-ok';
        } elseif ($ops_status === 'ready_for_shipment') {
            $ops_status_label = __('Ready For Shipment', 'intigo-parcels');
            $ops_status_class = 'intigo-pill-info';
        } elseif ($ops_status === 'missing_data') {
            $ops_status_label = __('Missing Data', 'intigo-parcels');
            $ops_status_class = 'intigo-pill-warn';
        } elseif ($ops_status === 'need_confirmation') {
            $ops_status_label = __('Need Confirmation', 'intigo-parcels');
            $ops_status_class = 'intigo-pill-muted';
        }
        if ($ops_status_label !== '') {
            $tags[] = ['label' => $ops_status_label, 'class' => $ops_status_class];
        }
        return $tags;
    }

    private function get_intigo_zone_status() {
        if (!class_exists('WC_Shipping_Zones')) {
            return ['ok' => false, 'reason' => 'WooCommerce shipping not available.', 'with' => [], 'without' => []];
        }
        $with = [];
        $without = [];
        $entries = [];
        foreach (WC_Shipping_Zones::get_zones() as $zd) {
            $entries[] = ['id' => intval($zd['zone_id']), 'name' => (string) $zd['zone_name']];
        }
        $entries[] = ['id' => 0, 'name' => __('Locations not covered by your other zones', 'intigo-parcels')];
        foreach ($entries as $entry) {
            $zone = WC_Shipping_Zones::get_zone($entry['id']);
            if (!$zone) {
                continue;
            }
            $found = false;
            foreach ($zone->get_shipping_methods(false) as $method) {
                if (isset($method->id) && $method->id === 'intigo_delivery') {
                    $found = true;
                    break;
                }
            }
            if ($found) {
                $with[] = $entry;
            } else {
                $without[] = $entry;
            }
        }
        return ['ok' => true, 'with' => $with, 'without' => $without];
    }

    public function handle_add_to_zones() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die(esc_html__('Unauthorized', 'intigo-parcels'));
        }
        check_admin_referer('intigo_add_to_zones');
        if (!class_exists('WC_Shipping_Zones')) {
            $this->redirect_with_notice('intigo-parcels-settings', __('WooCommerce is not active.', 'intigo-parcels'), 'error');
            exit;
        }
        $added = 0;
        $skipped = 0;
        $entries = [];
        foreach (WC_Shipping_Zones::get_zones() as $zd) {
            $entries[] = intval($zd['zone_id']);
        }
        $entries[] = 0;
        foreach ($entries as $zone_id) {
            $zone = WC_Shipping_Zones::get_zone($zone_id);
            if (!$zone) {
                continue;
            }
            $already = false;
            foreach ($zone->get_shipping_methods(false) as $method) {
                if (isset($method->id) && $method->id === 'intigo_delivery') {
                    $already = true;
                    break;
                }
            }
            if ($already) {
                $skipped++;
                continue;
            }
            $zone->add_shipping_method('intigo_delivery');
            $added++;
        }
        $this->add_log('shipping_zones_attached', 'added=' . $added . '; skipped=' . $skipped);
        $msg = $added > 0
            /* translators: %1$d: number of zones Intigo Delivery was added to, %2$d: number of zones that already had it */
            ? sprintf(__('Added Intigo Delivery to %1$d zone(s). %2$d already had it.', 'intigo-parcels'), $added, $skipped)
            : __('Intigo Delivery is already on every zone.', 'intigo-parcels');
        $type = $added > 0 ? 'success' : 'info';
        $this->redirect_with_notice('intigo-parcels-settings', $msg, $type);
        exit;
    }

    private function check_health() {
        $settings = $this->api_client->get_settings();
        $base = rtrim((string) ($settings['primary_base_url'] ?? ''), '/');
        if ($base === '') {
            return ['ok' => false, 'message' => __('Primary Base URL is not configured', 'intigo-parcels')];
        }
        $health_url = preg_replace('#/api$#', '', $base) . '/health';
        $res = wp_remote_get($health_url, ['timeout' => 10]);
        if (is_wp_error($res)) {
            /* translators: %s: error message */
            return ['ok' => false, 'message' => sprintf(__('Health check failed: %s', 'intigo-parcels'), $res->get_error_message())];
        }
        $code = wp_remote_retrieve_response_code($res);
        if ($code >= 200 && $code < 300) {
            /* translators: %s: health-check URL */
            return ['ok' => true, 'message' => sprintf(__('Connected (%s)', 'intigo-parcels'), $health_url)];
        }
        /* translators: %1$d: HTTP status code, %2$s: health-check URL */
        return ['ok' => false, 'message' => sprintf(__('Health check HTTP %1$d (%2$s)', 'intigo-parcels'), $code, $health_url)];
    }

    private function compute_dashboard_metrics($orders) {
        $metrics = [
            'total_orders' => count($orders),
            'with_parcel' => 0,
            'with_bordereau' => 0,
            'missing_data' => 0,
            'verified' => 0,
            'need_confirmation' => 0,
            'ready_for_shipment' => 0,
            'total_sales' => 0.0,
            'avg_order_value' => 0.0,
            'coverage_rate' => 0.0,
            'ready_rate' => 0.0,
            'bordereau_rate' => 0.0,
        ];
        foreach ($orders as $metrics_order) {
            $metrics['total_sales'] += floatval($metrics_order->get_total());
            $m_nid = (string) $metrics_order->get_meta('_intigo_parcel_nid');
            $m_bordereau = (string) $metrics_order->get_meta('_intigo_bordereau_url');
            $m_city = (string) $metrics_order->get_meta('_intigo_city_id');
            $m_district = (string) $metrics_order->get_meta('_intigo_district_id');
            $m_package = (string) $metrics_order->get_meta('_intigo_package_size');
            if ($m_nid !== '') {
                $metrics['with_parcel']++;
            }
            if ($m_bordereau !== '') {
                $metrics['with_bordereau']++;
            }
            $m_status = $this->compute_automatic_ops_status($m_city, $m_district, $m_package, $m_nid, $m_bordereau);
            if (isset($metrics[$m_status])) {
                $metrics[$m_status]++;
            }
        }
        if ($metrics['total_orders'] > 0) {
            $metrics['avg_order_value'] = round($metrics['total_sales'] / $metrics['total_orders'], 2);
            $metrics['coverage_rate'] = round(($metrics['with_parcel'] / $metrics['total_orders']) * 100, 1);
            $metrics['ready_rate'] = round(($metrics['ready_for_shipment'] / $metrics['total_orders']) * 100, 1);
            $metrics['bordereau_rate'] = round(($metrics['with_bordereau'] / $metrics['total_orders']) * 100, 1);
        }
        return $metrics;
    }

    private function add_log($action, $context = '') {
        $logs = get_option(self::OPTION_LOGS, []);
        if (!is_array($logs)) {
            $logs = [];
        }
        $user = wp_get_current_user();
        $actor = ($user && !empty($user->user_login)) ? $user->user_login : 'system';
        array_unshift($logs, [
            'time' => current_time('mysql'),
            'actor' => $actor,
            'action' => sanitize_text_field((string) $action),
            'context' => sanitize_text_field((string) $context),
        ]);
        if (count($logs) > self::MAX_LOGS) {
            $logs = array_slice($logs, 0, self::MAX_LOGS);
        }
        update_option(self::OPTION_LOGS, $logs, false);
    }

    private function get_logs() {
        $logs = get_option(self::OPTION_LOGS, []);
        if (!is_array($logs)) {
            return [];
        }
        if (count($logs) > self::MAX_LOGS) {
            $logs = array_slice($logs, 0, self::MAX_LOGS);
            update_option(self::OPTION_LOGS, $logs, false);
        }
        return $logs;
    }
}

