<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Deterministic, offline matcher for Tunisian delivery zones (port of the
 * PrestaShop module's IntigoZoneIndex).
 *
 * The free-text guesser ranks by fuzzy similarity, so it answers "Sfax" for
 * "Tunis" and "Le Kef" for a Tunis street whose only common token is "1er".
 * This class matches EXACTLY against Intigo's own place names
 * (data/intigo-zones.php) instead:
 *
 *  1. SQUASHED comparison — normalise, then drop every non-alphanumeric.
 *     Intigo stores "Mutuelle Ville"; customers write "Mutuelleville". Squashed,
 *     both are `mutuelleville`. No fuzziness, so it can't wander.
 *  2. The governorate comes from a FIELD (state or city), never from street
 *     text. Street text is only searched for the délégation/cité, and only
 *     inside the governorate already established.
 *
 * Names only: the ids sent to Intigo are always re-resolved live through the
 * regions API, so a server-side renumbering can't ship a stale zone.
 */
class Intigo_Zone_Index {
    /** Shortest squashed name we will look for inside free text. */
    const MIN_MATCH_LEN = 6;

    /** @var array|null */
    private static $data = null;

    /** city key => [city name, [district key => [district name, [neighborhood keys]]]] */
    public static function data() {
        if (self::$data === null) {
            $file = dirname(__DIR__) . '/data/intigo-zones.php';
            $d = is_readable($file) ? include $file : null;
            self::$data = is_array($d) ? $d : [];
        }
        return self::$data;
    }

    /** "Mutuelle-Ville " → "mutuelleville", "El Menzah 6" → "elmenzah6". */
    public static function squash($text) {
        return Intigo_API_Client::squash_name($text);
    }

    /** Display name of a governorate key ('' when unknown). */
    public static function city_name($city_key) {
        $data = self::data();
        return isset($data[$city_key]) ? (string) $data[$city_key][0] : '';
    }

    /**
     * Match a governorate from ONE address field (state or city). Tolerates a
     * leading article ("Le Kef" → kef) and a single typo ("Arianna", "Manouba"
     * → mannouba) — safe because no two governorate names are within two edits,
     * and an ambiguous hit is rejected.
     *
     * Returns the canonical city key, or '' when the field names no governorate.
     */
    public static function match_city_field($value) {
        $key = self::squash($value);
        if ($key === '') {
            return '';
        }
        $data = self::data();
        if (isset($data[$key])) {
            return $key;
        }
        $stripped = preg_replace('/^(le|la|el|grand|gouvernoratde|gouvernorat)/', '', $key);
        if ($stripped !== $key && $stripped !== '' && isset($data[$stripped])) {
            return $stripped;
        }
        if (strlen($key) >= 4) {
            $hit = '';
            foreach (array_keys($data) as $ck) {
                if (abs(strlen($ck) - strlen($key)) <= 1 && levenshtein($ck, $key) <= 1) {
                    if ($hit !== '') {
                        return '';
                    }
                    $hit = $ck;
                }
            }
            if ($hit !== '') {
                return $hit;
            }
        }
        return '';
    }

    /**
     * Look for a délégation or cité named verbatim in $text.
     *
     * $city_key scopes the search to one governorate — strongly preferred, since
     * hundreds of cité names repeat across governorates. Unscoped, a match is only
     * returned when every hit lies in a single governorate.
     *
     * The LONGEST match wins ("elmenzah6" beats "elmenzah"; a cité beats the
     * délégation containing it).
     *
     * @return array|null ['city_key','city','district','neighborhood','matched','scoped']
     *                    ('neighborhood' is a squashed key, '' for a délégation hit)
     */
    public static function match_zone($text, $city_key = '') {
        $hay = self::squash($text);
        if ($hay === '') {
            return null;
        }
        $data = self::data();
        $scope = ($city_key !== '' && isset($data[$city_key])) ? [$city_key => $data[$city_key]] : $data;

        $best = null;
        $cities_hit = [];
        foreach ($scope as $ck => $crow) {
            foreach ($crow[1] as $dkey => $drow) {
                // A place named exactly like its governorate ("Sousse", "Ben Arous")
                // is not evidence: "Rue de Sousse" only restates the governorate.
                if ($dkey !== $ck && strlen($dkey) >= self::MIN_MATCH_LEN && strpos($hay, $dkey) !== false) {
                    $cities_hit[$ck] = true;
                    if ($best === null || strlen($dkey) > $best['len']) {
                        $best = ['city_key' => $ck, 'city' => $crow[0], 'district' => $drow[0],
                                 'neighborhood' => '', 'matched' => $dkey, 'len' => strlen($dkey)];
                    }
                }
                foreach ($drow[1] as $nkey) {
                    if ($nkey !== $ck && strlen($nkey) >= self::MIN_MATCH_LEN && strpos($hay, $nkey) !== false) {
                        $cities_hit[$ck] = true;
                        if ($best === null || strlen($nkey) > $best['len']) {
                            $best = ['city_key' => $ck, 'city' => $crow[0], 'district' => $drow[0],
                                     'neighborhood' => $nkey, 'matched' => $nkey, 'len' => strlen($nkey)];
                        }
                    }
                }
            }
        }
        if ($best === null) {
            return null;
        }
        // Unscoped and places in two governorates are named: refuse rather than pick.
        if ($city_key === '' && count($cities_hit) > 1) {
            return null;
        }
        $best['scoped'] = ($city_key !== '');
        unset($best['len']);
        return $best;
    }
}
