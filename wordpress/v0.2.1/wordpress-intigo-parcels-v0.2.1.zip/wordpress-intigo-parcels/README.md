# Intigo Parcels for WooCommerce

A WordPress plugin that connects WooCommerce stores to the Intigo delivery network. Customers pick **Intigo Delivery** at checkout, fill in the Intigo-specific delivery zone (city / district / neighborhood), and on order placement the parcel is either pushed to Intigo automatically or queued for the seller to send manually from the admin dashboard.

Since 0.2.1, the **package size** is assigned by the seller per product — Intigo's S/M/L/XL grid is a fixed contract from Intigo, and the customer never sees a size choice at checkout. See [§ Package size resolution](#package-size-resolution) below.

- **Plugin slug**: `wordpress-intigo-parcels`
- **Version**: 0.2.1
- **Tested with**: WordPress 6.9, WooCommerce 10.7 (Blocks checkout + classic shortcode)
- **HPOS**: fully compatible (High-Performance Order Storage)

---

## What this plugin does

1. **Adds Intigo Delivery as a WooCommerce shipping method.** Customers see one shipping rate. The package size is taken from the per-product assignment the seller made in the product editor, aggregated across the cart by max-rank. Pricing per size is configurable in Settings.
2. **Pops up a modal at checkout** the moment a customer selects Intigo Delivery, asking them to confirm their recipient name, phone, country, street address, and to pick the Intigo city → district → neighborhood from cascading dropdowns served by Intigo's region API.
3. **Validates that all required Intigo fields are filled** before the customer can place the order.
4. **Saves the customer's selections to order meta** in HPOS-correct storage (`_intigo_recipient_name`, `_intigo_phone`, `_intigo_address`, `_intigo_country`, `_intigo_city_id`, `_intigo_district_id`, `_intigo_neighborhood_id`, `_intigo_package_size`, plus human-readable `_intigo_*_name` fields).
5. **In Automatic mode**, pushes the parcel to Intigo on the same request the order is created (idempotent — won't double-push).
6. **In Manual mode**, the order shows up in *Intigo → Manage Orders* with all metadata pre-filled; the seller clicks **Send to Intigo** when ready.
7. **Generates and downloads bordereaux** once a parcel is created, plus per-parcel actions (sync, cancel, relance, report delay).
8. **Syncs parcel status hourly** via WP-cron and surfaces the result in Manage Orders.
9. **Logs every API call and admin action** to a paginated activity log retained for the latest 200 entries.

---

## Install

1. **Zip the plugin folder** (or download the release zip from `releases/`).
2. WP Admin → **Plugins → Add New → Upload Plugin** → choose the zip → **Install Now → Activate**.
3. The plugin adds a top-level **Intigo** menu in the WP admin sidebar.

### Required prerequisites

- WooCommerce active.
- A valid **Intigo API key** for sandbox or production (request from your Intigo account manager).

---

## Setup walkthrough

### 1. Connect the API

**Intigo → Settings → Connection**:

- **Environment** — pick *Sandbox* (testing, no real shipments) or *Production* (live).
- **API key** — paste the key. Keep it secret.
- **Fallback adapter** — leave on; safe no-op when the primary endpoint is reachable.

The pill at the top of the page should read **API connected** (green). If it reads **API issue**, the key/environment is wrong.

### 2. Pick the order processing mode

**Intigo → Settings → Order processing**:

- **Automatic** — every paid Intigo Delivery order pushes to Intigo by itself, no admin action.
- **Manual** — orders sit in *Manage Orders* until the admin clicks **Send to Intigo**.

You can switch back and forth at any time.

### 3. Assign each product to an Intigo size

Open any product (**Products → Edit**) and in the right sidebar use the **Intigo Delivery** box to pick *Small / Medium / Large / Extra large* for that product. Save.

Products you don't tag fall back to **Default package size** under *Intigo → Settings → Defaults*.

### 4. Configure shipping pricing

**Intigo → Settings → Shipping pricing**:

Four price inputs — one per package size (S, M, L, XL). Defaults: 1, 6, 7, 8 in your store currency. The customer sees ONE of these at checkout (whichever the resolver picked for the cart).

The first time you visit the section, a yellow **Setup status** card appears showing every WooCommerce shipping zone and which ones currently have Intigo Delivery attached. Click **Add to all zones** to attach Intigo Delivery to every zone (including the catch-all "Locations not covered…") in one click.

If the Add-to-all-zones helper doesn't appear (zone state is fine), the card turns green and shows the list of zones already covered.

### 5. Test with a sandbox order

1. Switch the storefront to use a Tunisian shipping address (Intigo is Tunisia-only).
2. Add a tagged product to the cart, go to checkout.
3. In the shipping methods you should see **one** row — *Intigo Delivery — X dt* — at the price for the resolved size.
4. Select Intigo Delivery — a modal pops up titled **"Confirm your delivery details"** with your billing pre-filled.
5. Pick the Intigo city → district → optional neighborhood → click **Save delivery info**.
6. Click **Place Order**.

In Automatic mode the parcel is created in Intigo immediately. In Manual mode it waits for you in *Intigo → Manage Orders*.

---

## Automatic Send to Intigo — how it works

The automatic-push pipeline fires on every order creation event WC raises, with idempotency to prevent duplicates:

1. **`woocommerce_store_api_checkout_update_order_from_request`** — Blocks-checkout hook. Validates that the customer filled the modal completely; throws a customer-visible error if any required field is missing. Then writes the modal data to `_intigo_*` order meta in one save.
2. **`woocommerce_checkout_create_order`** — classic-shortcode equivalent of the above.
3. **`woocommerce_order_status_processing`** — fires when COD orders auto-process or paid card orders transition. Reads order meta and pushes to Intigo.
4. **`woocommerce_order_status_completed`**, **`woocommerce_payment_complete`**, **`woocommerce_thankyou`** — three additional safety-net hooks that catch the rare cases where status changes don't fire as expected.
5. **`woocommerce_store_api_checkout_order_processed`** — Blocks-only post-creation hook; runs `maybe_auto_create_from_order_event` once more for same-request push.

All five paths funnel through `Intigo_Order_Service::maybe_auto_create_from_order_event($order_id)`, which:

- Aborts if the **Order Processing Mode** setting is *Manual*.
- Confirms the order has an `intigo_delivery` shipping line item.
- Skips orders in `failed`, `cancelled`, `refunded`, `checkout-draft`.
- Skips if `_intigo_parcel_nid` is already set (already pushed) or `_intigo_idem_*` meta is present.
- Otherwise calls `create_single_for_order($order)` which validates the payload, POSTs to Intigo's `/v3/parcels/` endpoint, and on success writes `_intigo_parcel_nid` + `_intigo_api_target_used` + the idempotency meta and adds an **order note** with the assigned NID.
- On failure, writes `_intigo_last_error` + `_intigo_last_attempt_at` order meta and adds an order note with the full API response.

### Where to see the result

- **Intigo → Manage Orders**: every order shows a **Notes** column on the right with one of three states:
  - **Sent to Intigo ✓** with timestamp.
  - **Auto-push failed !** with the exact API error and timestamp.
  - **—** if neither has happened yet.
- **WC → Orders → click order → Order notes panel**: full audit log of every plugin action against that order, including the full API request/response when something goes wrong.
- **Intigo → Activity Log**: paginated list (25 per page, max 200 retained) of every plugin event — API calls, admin clicks, validation failures.

### Phone normalization

Intigo's API rejects phone values that contain non-digit characters. The plugin auto-cleans the phone before sending:

- `+216 25 24 92 15` → `21625249215`
- `(216) 25-24-92-15` → `21625249215`
- `0021625249215` → `21625249215` (strips international `00` prefix)
- `25249215` (already-clean local) → unchanged

So whatever format the customer types, the API receives a clean digits-only string.

---

## Manual mode — sending an order to Intigo from the admin

1. **Intigo → Manage Orders** lists every WooCommerce order with Intigo metadata at-a-glance.
2. The **status pill** column shows: *Verified* (data complete, not yet sent), *Ready for Shipment* (parcel created), *Need Verification* (parcel exists but bordereau not generated), *Missing Data* (some Intigo field is empty).
3. Click **Edit** to open the metadata modal — same cascading city/district/neighborhood pickers as the customer's modal, plus phone override.
4. Click **Send to Intigo** — the parcel is created via the same endpoint as the auto-push.
5. Click **Generate Bordereau** once the NID is set; **Download** opens the bordereau as a PDF, **Print** opens it in a new tab.
6. The **More Actions** dropdown exposes per-parcel actions: synchronize, request relance, report delay, cancel parcel.

---

## Package size resolution

> Added in 0.2.1. Replaces the customer-picks-at-checkout model from 0.2.0.

### Why this exists

Intigo's **S / M / L / XL** is a logistics contract Intigo defines (cm/kg per bucket and the price per bucket per zone). It is **not** a shopping concept — customers don't know the grid, and they have no business choosing it.

In 0.2.x the customer chose the size from a 4-row shipping menu at checkout. Two structural problems:

1. **The customer doesn't know.** They guessed.
2. **Built-in revenue leak.** If "Small" looked plausible the customer picked it to pay less; Intigo charged the seller for the *actual* size at pickup; the seller ate the difference, every order.

In 0.2.1 the seller assigns each product to one of Intigo's fixed buckets, and the customer sees one shipping price.

### The waterfall — first source with an answer wins

```
1. Per-order admin override     (WC → Orders → edit → Package Size)
        ↓ not set
2. Per-product seller assignment (Products → edit → Intigo Delivery box)
        ↓ not set
3. Plugin-wide default           (Intigo → Settings → Defaults)
```

For multi-item carts: take the **MAX by rank** (S < M < L < XL). The parcel needs to physically contain the biggest item; tighter fit is a follow-up problem.

### Where things live

| What | Where | Saves to |
|---|---|---|
| Per-product size assignment | **Products → edit → side box "Intigo Delivery"** | `_intigo_product_size` product meta |
| Plugin-wide default | **Intigo → Settings → Defaults → Default package size** | `default_package_size` in `intigo_parcels_settings` option |
| Per-order one-off override | **WC → Orders → edit → Package Size** dropdown in the Intigo Shipment box | `_intigo_package_size` order meta |

### What 0.2.1 deliberately does NOT have

- **No mode toggle.** Customer-picks behavior is gone, not optional. The 4-row menu was a structural mistake.
- **No editable cm/kg threshold table.** Intigo defines what each bucket means; the seller doesn't redefine it.
- **No auto-derive from WooCommerce dimensions.** Without an authoritative published Intigo grid in the plugin, mapping `35×25×15 cm, 1.8 kg` to a bucket is guessing — the same guessing problem we just removed from the customer side. Sellers know which bucket their products fit; that knowledge belongs in the per-product field.

If a future Intigo release publishes an official grid the plugin can hardcode, layer 3 (auto-derive) can come back — but it would read from a constant, not a configurable table.

---

## Compatibility

- **HPOS (High-Performance Order Storage)**: fully supported. All meta reads/writes go through `$order->get_meta()` / `$order->update_meta_data()` + `$order->save()`, so the plugin works whether HPOS or legacy CPT storage is enabled.
- **Blocks Checkout**: yes — modal is rendered via `wp_footer`, customer state persists in `WC()->session`, validation hooks into `woocommerce_store_api_checkout_update_order_from_request`. The Blocks store API integration is automatic; no React build is required.
- **Classic Shortcode Checkout** (`[woocommerce_checkout]`): also supported via the matching classic hooks.
- **WPML / multi-language**: strings are wrapped with the `intigo-parcels` text domain.

---

## Settings reference

All settings live under `intigo_parcels_settings` option key:

| Key | Default | Description |
|---|---|---|
| `environment_mode` | `sandbox` | `sandbox` or `production` |
| `api_key` | *(empty)* | Intigo API key |
| `fallback_enabled` | `yes` | Try the legacy fallback URL when the primary fails |
| `auto_create_on_paid` | `no` | `yes` = Automatic mode, `no` = Manual mode |
| `default_package_size` | `S` | Layer-3 fallback in the size waterfall (used when a product has no `_intigo_product_size`) |
| `size_price_s` | `1` | Shipping cost for Small (in store currency) |
| `size_price_m` | `6` | Medium |
| `size_price_l` | `7` | Large |
| `size_price_xl` | `8` | Extra large |

Per-product:

| Meta key | Where | Description |
|---|---|---|
| `_intigo_product_size` | Product post meta | Layer-2 assignment read by `Intigo_Size_Resolver`. Empty = "use plugin default". |

---

## Hooks & filters reference

### Provided actions you can listen to

| Action | When | Args |
|---|---|---|
| `woocommerce_order_action_intigo_create_parcel` | Admin clicks Send to Intigo | `$order` |
| `woocommerce_order_action_intigo_generate_bordereau` | Admin clicks Generate Bordereau | `$order` |
| `intigo_parcels_status_sync_cron` | Hourly status sync cron | none |

### WooCommerce hooks the plugin uses

- `woocommerce_shipping_methods` filter — registers `intigo_delivery`
- `woocommerce_after_order_notes` — renders modal hidden inputs (classic checkout)
- `wp_footer` — renders the modal HTML on every checkout (Blocks + classic)
- `woocommerce_store_api_checkout_update_order_from_request` — Blocks order create
- `woocommerce_store_api_checkout_order_processed` — Blocks post-create cleanup
- `woocommerce_checkout_create_order` — classic order create
- `woocommerce_after_checkout_validation` — classic validation
- `woocommerce_order_status_processing` / `_completed`, `woocommerce_payment_complete`, `woocommerce_thankyou` — auto-push triggers

---

## Troubleshooting

### "Missing Data" tag on a freshly placed order

- **HPOS storage**: confirmed the meta is being written via `$order->update_meta_data()` (not `update_post_meta`). If you've added custom code that uses `update_post_meta` against an HPOS order, the meta won't persist. Open the order and check whether the standard order edit screen shows the city/district/package fields populated.

### Auto-push doesn't fire

1. **Settings → Order processing → Automatic** is selected.
2. **Settings → top pill** says **API connected** (green).
3. Open the order and check the **Order notes** panel for any *"Intigo parcel creation failed: …"* line — that's the API's exact error.
4. Check the **Notes** column in Manage Orders — the latest error is shown there too.

### "Phone must be at least 8 digits"

Intigo's validator counts only digit characters. The plugin already normalizes phones (strips `+`, spaces, hyphens, leading `00`). If you still see this error, the phone column on the order has fewer than 8 actual digits — fix the customer's phone and click **Send to Intigo**.

### 404 on `/v3/parcels/`

The Intigo endpoint path or environment is wrong. Confirm with Intigo:
- Sandbox base: `https://dev-api.intigo.net/api`
- Production base: `https://api.intigo.net/api`

### Modal doesn't appear at checkout

- Hard-refresh the checkout page (`Ctrl+Shift+R`) to bust the inline-JS cache.
- Open DevTools → Console → reload checkout. Any red errors?
- View page source and search for `intigo-modal-backdrop` — if missing, neither `wp_footer` nor `woocommerce_after_order_notes` fired (rare; usually a theme that strips footer hooks).

---

## Changelog

### 0.2.1 — 2026-05-06

- **Seller-owned package size.** Intigo's S/M/L/XL grid is a fixed contract from Intigo, so the customer no longer picks at checkout. The seller assigns each product to a bucket on the product edit screen.
- **Single shipping rate at checkout.** Customer sees one *Intigo Delivery — X TND* row instead of four. Eliminates the under-pricing leak from 0.2.0 where customers picked Small to save and the seller paid Large at pickup.
- **New `Intigo_Size_Resolver`** runs a 3-layer waterfall: per-order admin override → per-product seller assignment → plugin default. Multi-item carts aggregate by max-rank (S < M < L < XL).
- **Per-product Intigo Delivery box** on the product edit screen (side panel): dropdown *Use default / S / M / L / XL*. Saves to `_intigo_product_size` product meta.
- **Hardened order push fallback.** When `_intigo_package_size` is empty (e.g. orders imported by other plugins), `order_to_payload()` consults the resolver before the global default — so bulk-create still gets the right size for free.
- **Removed since 0.2.0:** the 4-row shipping menu and any UI that exposed cm/kg thresholds (those are Intigo's call, not the seller's).

### 0.2.0 — 2026-05-05

- Customer-facing modal at checkout for Intigo zone + recipient confirmation.
- Cascading city / district / neighborhood pickers fed by Intigo's region API.
- Four shipping rates (S / M / L / XL) per zone, configurable pricing.
- HPOS-compatible meta storage and reads.
- Auto-push pipeline with five trigger events and idempotency.
- WooCommerce Blocks checkout support (Store API hooks).
- Phone normalization (strips non-digit chars before API call).
- Manage Orders **Notes** column showing per-order push status / errors.
- Setup status card in Settings with one-click "Add to all zones".
- Activity log paginated at 25 entries, max 200 retained.
- Documentation page with troubleshooting, tag reference, and bilingual quick guide.

### 0.1.0 — initial release

- Single + batch parcel creation from order actions.
- Bordereau URL generation.
- Hourly status sync.
- Optional auto-create on order paid event.

---

## Support

- Email: hello@intigo.tn
- For bugs, include: WP version, WC version, the **Notes** column error string, and the order's notes panel content.
