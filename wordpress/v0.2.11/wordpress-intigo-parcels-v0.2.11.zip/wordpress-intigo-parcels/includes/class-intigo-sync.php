<?php

if (!defined('ABSPATH')) {
    exit;
}

class Intigo_Sync {
    private $api;

    public function __construct($api_client) {
        $this->api = $api_client;
    }

    public function register_hooks() {
        add_action('intigo_parcels_status_sync_cron', [$this, 'run_status_sync']);
    }

    public function run_status_sync() {
        $orders = wc_get_orders([
            'type' => 'shop_order',
            'limit' => 50,
            'meta_key' => '_intigo_parcel_nid',
            'meta_compare' => 'EXISTS',
            'orderby' => 'date',
            'order' => 'DESC',
        ]);

        if (empty($orders)) {
            return;
        }

        $order_by_nid = [];
        $nids = [];
        foreach ($orders as $order) {
            $nid = get_post_meta($order->get_id(), '_intigo_parcel_nid', true);
            if ($nid) {
                $order_by_nid[$nid] = $order;
                $nids[] = $nid;
            }
        }

        if (empty($nids)) {
            return;
        }

        $res = $this->api->status_bulk($nids);
        if (empty($res['ok']) || empty($res['data']['parcels'])) {
            return;
        }

        foreach ($res['data']['parcels'] as $parcel) {
            if (empty($parcel['nid']) || !isset($order_by_nid[$parcel['nid']])) {
                continue;
            }

            $order = $order_by_nid[$parcel['nid']];
            $status = intval($parcel['status'] ?? 0);
            update_post_meta($order->get_id(), '_intigo_last_status', $status);
            update_post_meta($order->get_id(), '_intigo_last_sync_at', current_time('mysql'));

            if ($status === 5000 && $order->get_status() !== 'completed') {
                $order->update_status('completed', 'Intigo status sync: delivered');
            } elseif ($status >= 9000) {
                $order->add_order_note('Intigo status sync: canceled parcel');
            }
        }
    }
}

