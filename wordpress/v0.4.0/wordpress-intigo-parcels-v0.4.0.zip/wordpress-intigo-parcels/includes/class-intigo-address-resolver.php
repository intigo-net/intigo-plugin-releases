<?php

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Free-text WooCommerce address → Intigo zone (city / district / neighborhood
 * ids) with a confidence tier. Port of the PrestaShop IntigoAddressResolver.
 *
 *   resolved  a governorate was STATED (state or city field) AND a délégation
 *             or cité inside it is written verbatim in the street, with live
 *             ids that belong together → safe to send
 *   review    the nearest zone, but inferred / guesser-only / unverified →
 *             one human glance before sending
 *   blocked   nothing usable (the governorate id is kept when it was stated)
 *
 * Rules paid for in production: the governorate never comes from street text,
 * the fuzzy guesser is always fenced to the stated governorate, and nothing
 * ever falls back to "the first city" or "the first district" of a list.
 */
class Intigo_Address_Resolver {
    const TIER_RESOLVED = 'resolved';
    const TIER_REVIEW = 'review';
    const TIER_BLOCKED = 'blocked';

    /** @var Intigo_API_Client */
    private $api;

    public function __construct(Intigo_API_Client $api) {
        $this->api = $api;
    }

    /**
     * Resolve an address. Input keys: address_1, address_2, city, state,
     * postcode, country (a state CODE or name — it is only read as text).
     * No persistence; network only through the api client (cached regions,
     * bounded guesser calls).
     *
     * @return array tier, city_id, district_id, neighborhood_id, city_name,
     *               district_name, neighborhood_name, reason, rule, alternatives
     *               (the two governorate names when city and state disagree)
     */
    public function resolve(array $a) {
        $f = [];
        foreach (['address_1', 'address_2', 'city', 'state', 'postcode', 'country'] as $k) {
            $f[$k] = isset($a[$k]) ? trim((string) $a[$k]) : '';
        }
        $street = trim($f['address_1'] . ' ' . $f['address_2']);

        $country = strtoupper($f['country']);
        if ($country !== '' && $country !== 'TN') {
            return $this->result(self::TIER_BLOCKED, 'not_tunisia', '');
        }
        if ($street === '' && $f['city'] === '' && $f['state'] === '') {
            return $this->result(self::TIER_BLOCKED, 'empty_address', '');
        }

        // 1. The governorate, from a FIELD only (state or city) — never the street.
        $state_key = Intigo_Zone_Index::match_city_field($f['state']);
        $city_field_key = Intigo_Zone_Index::match_city_field($f['city']);
        if ($state_key !== '' && $city_field_key !== '' && $state_key !== $city_field_key) {
            return $this->resolve_conflict($f, $street, $city_field_key, $state_key);
        }
        $city_key = $state_key !== '' ? $state_key : $city_field_key;
        $city_from = $state_key !== '' ? 'state' : ($city_field_key !== '' ? 'city' : '');

        // Where the délégation may be written: the street, plus the OTHER field when
        // it isn't itself a governorate (customers put the délégation in City or
        // State as often as in the street). Never the field that gave the
        // governorate: most governorates have a same-named place, which would fake
        // a délégation match.
        $pieces = [$street];
        $field_zone = null;
        if ($city_key !== '') {
            $other = $city_from === 'state' ? 'city' : 'state';
            if ($f[$other] !== '' && Intigo_Zone_Index::match_city_field($f[$other]) === '') {
                $pieces[] = $f[$other];
            }
        } else {
            // No governorate, but a field naming a délégation ("La Marsa" in City)
            // determines it when the name is unique to one governorate — derived,
            // not stated, so it never reaches `resolved` on its own.
            foreach (['city', 'state'] as $k) {
                $field_zone = Intigo_Zone_Index::match_zone($f[$k], '');
                if ($field_zone !== null) {
                    $city_key = $field_zone['city_key'];
                    $city_from = 'field_district';
                    break;
                }
            }
        }

        $gov = null;
        if ($city_key !== '') {
            $gov = $this->live_city($city_key);
            if ($gov['reason'] !== '') {
                return $this->result(self::TIER_BLOCKED, $gov['reason'], 'city_field_' . $city_from, $gov);
            }
        }

        // 2. Exact délégation/cité, fenced to the governorate; longest match wins.
        $m = $this->best_match($pieces, $city_key);
        if ($m === null && $field_zone !== null) {
            $m = $field_zone;
        }
        if ($m !== null) {
            $local = $this->resolve_local($m, $city_from, $gov);
            if ($local !== null) {
                return $local;
            }
            // Gazetteer name not in the live list (renamed at Intigo) → guesser.
        }

        // 3. The guesser, fenced. Only worth asking when the address says more
        //    than the governorate itself — otherwise its answer is a pure guess.
        if ($gov !== null && !$this->has_locality(implode(' ', $pieces), $city_key)) {
            return $this->result(self::TIER_BLOCKED, 'governorate_only', 'city_field_' . $city_from, $gov);
        }
        return $this->resolve_with_guesser($f, $street, $gov !== null ? [$gov] : [], $city_from, '');
    }

    /**
     * City and State name two DIFFERENT governorates ("Ben Arous" / "tunis").
     * Neither is trusted blindly: the one the street corroborates with an exact
     * délégation/cité wins; otherwise the guesser, fenced to both, gives the
     * nearest zone — never better than `review`.
     */
    private function resolve_conflict(array $f, $street, $city_field_key, $state_key) {
        $govs = [];
        foreach (['city' => $city_field_key, 'state' => $state_key] as $from => $key) {
            $g = $this->live_city($key);
            if ($g['reason'] === 'api_unavailable') {
                return $this->result(self::TIER_BLOCKED, 'api_unavailable', 'conflicting_governorates');
            }
            if ($g['reason'] === '') {
                $g['key'] = $key;
                $govs[$from] = $g;
            }
        }
        $alternatives = [Intigo_Zone_Index::city_name($city_field_key), Intigo_Zone_Index::city_name($state_key)];

        $hits = [];
        foreach ($govs as $from => $g) {
            $m = Intigo_Zone_Index::match_zone($street, $g['key']);
            if ($m !== null) {
                $hits[$from] = $m;
            }
        }
        if (!empty($hits)) {
            // Longest (most specific) corroboration first.
            uasort($hits, function ($x, $y) {
                return strlen($y['matched']) - strlen($x['matched']);
            });
            foreach ($hits as $from => $m) {
                $local = $this->resolve_local($m, $from, $govs[$from]);
                if ($local === null) {
                    continue;
                }
                if ($local['tier'] === self::TIER_BLOCKED) {
                    return $local;
                }
                // Both governorates corroborated: we still can't tell — review.
                if (count($hits) > 1) {
                    $local['tier'] = self::TIER_REVIEW;
                    $local['reason'] = 'conflicting_governorates';
                }
                $local['rule'] = 'conflict_street_' . $from;
                $local['alternatives'] = $alternatives;
                return $local;
            }
        }

        $r = $this->resolve_with_guesser($f, $street, array_values($govs), 'conflict', 'conflicting_governorates');
        $r['alternatives'] = $alternatives;
        return $r;
    }

    /** Longest exact match across several texts, each searched on its own. */
    private function best_match(array $pieces, $city_key) {
        $best = null;
        foreach ($pieces as $text) {
            $m = Intigo_Zone_Index::match_zone($text, $city_key);
            if ($m !== null && ($best === null || strlen($m['matched']) > strlen($best['matched']))) {
                $best = $m;
            }
        }
        return $best;
    }

    /**
     * Names matched in the gazetteer → live ids. Returns null when the live
     * district list doesn't carry the name (caller falls back to the guesser);
     * a blocked api_unavailable result when the regions API can't be read.
     */
    private function resolve_local(array $m, $city_from, $gov) {
        if ($gov === null) {
            $gov = $this->live_city($m['city_key']);
            if ($gov['reason'] !== '') {
                return $this->result(self::TIER_BLOCKED, $gov['reason'], 'exact_local_unscoped', $gov);
            }
        }
        $dres = $this->api->get_districts_cached($gov['city_id']);
        if (empty($dres['ok'])) {
            return $this->result(self::TIER_BLOCKED, 'api_unavailable', 'exact_local', $gov);
        }
        $district_id = $this->api->district_id_by_name($gov['city_id'], $m['district']);
        if ($district_id <= 0 || !$this->api->district_belongs_to_city($district_id, $gov['city_id'])) {
            return null;
        }
        $district_name = $this->live_name($dres['items'], $district_id, $m['district']);

        $neighborhood_id = 0;
        $neighborhood_name = '';
        if ($m['neighborhood'] !== '') {
            $nres = $this->api->get_neighborhoods_cached($district_id);
            if (!empty($nres['ok'])) {
                foreach ($nres['items'] as $n) {
                    if (Intigo_Zone_Index::squash($n['name']) === $m['neighborhood']) {
                        $neighborhood_id = intval($n['id']);
                        $neighborhood_name = (string) $n['name'];
                        break;
                    }
                }
            }
        }

        $stated = !empty($m['scoped']) && in_array($city_from, ['state', 'city'], true);
        if ($stated) {
            $rule = 'exact_local_' . $city_from;
        } elseif ($city_from === 'field_district') {
            $rule = 'exact_local_field_district';
        } else {
            $rule = 'exact_local_unscoped';
        }
        return $this->result(
            $stated ? self::TIER_RESOLVED : self::TIER_REVIEW,
            $stated ? '' : 'governorate_not_stated',
            $rule,
            [
                'city_id' => $gov['city_id'],
                'city_name' => $gov['city_name'],
                'district_id' => $district_id,
                'district_name' => $district_name,
                'neighborhood_id' => $neighborhood_id,
                'neighborhood_name' => $neighborhood_name,
            ]
        );
    }

    /**
     * Fallback on the fuzzy guesser. With governorates in $govs its rows are
     * fenced to them; the result is never better than `review`. $force_reason,
     * when set, replaces the reason of every outcome (used for conflicts).
     */
    private function resolve_with_guesser(array $f, $street, array $govs, $city_from, $force_reason) {
        $one_gov = count($govs) === 1 ? $govs[0] : null;
        $blocked_rule = $one_gov !== null ? 'city_field_' . $city_from : ($force_reason !== '' ? 'conflicting_governorates' : '');
        $blocked = function ($reason) use ($force_reason, $blocked_rule, $one_gov) {
            return $this->result(self::TIER_BLOCKED, $force_reason !== '' ? $force_reason : $reason, $blocked_rule, $one_gov);
        };
        $city_text = $f['city'] !== '' ? $f['city'] : $f['state'];
        $clean = $this->clean_address($street);

        // Cleanest query first: the locality after a postcode, the cleaned street
        // + city, then the bare city. With a fenced governorate, a query that is
        // only the governorate's name is dropped: whatever it returns can only be
        // picked uncorroborated — a guess at the délégation.
        $queries = [];
        $postal_text = trim($street . ' ' . $f['postcode'] . ' ' . $city_text);
        foreach ([$this->locality_after_postal($postal_text), trim($clean . ' ' . $city_text), $city_text] as $q) {
            $q = trim((string) $q);
            if ($q === '' || in_array($q, $queries, true)) {
                continue;
            }
            if (!empty($govs) && Intigo_Zone_Index::match_city_field($q) !== '') {
                continue;
            }
            $queries[] = $q;
        }
        if (empty($queries)) {
            return $blocked('no_match');
        }

        $candidates = [];
        $seen = [];
        $reachable = false;
        foreach ($queries as $q) {
            $r = $this->api->search_locations($q);
            if (empty($r['ok'])) {
                continue;
            }
            $reachable = true;
            foreach ((array) $r['items'] as $it) {
                $key = intval($it['neighborhood_id']) . '|' . Intigo_Zone_Index::squash($it['district_name']);
                if (!isset($seen[$key])) {
                    $seen[$key] = true;
                    $candidates[] = $it;
                }
            }
        }
        if (!$reachable) {
            return $blocked('guesser_unavailable');
        }
        if (empty($candidates)) {
            return $blocked(!empty($govs) ? 'governorate_only' : 'no_match');
        }

        // The fence: with a known governorate the guesser may not leave it, so a
        // Tunis address can never become Sfax whatever the index ranks first.
        if (!empty($govs)) {
            $inside = [];
            foreach ($candidates as $it) {
                if ($this->gov_for_row($govs, $it) !== null) {
                    $inside[] = $it;
                }
            }
            if (empty($inside)) {
                return $blocked('outside_stated_city');
            }
            $candidates = $inside;
        }

        // Selection, strongest signal first. Corroboration is looked for in the
        // street and in any field that is NOT a governorate — a City "Ben Arous"
        // would otherwise "confirm" the délégation Ben Arous.
        $said = $clean;
        foreach (['city', 'state'] as $k) {
            if ($f[$k] !== '' && Intigo_Zone_Index::match_city_field($f[$k]) === '') {
                $said .= ' ' . $f[$k];
            }
        }
        $haystack = ' ' . Intigo_API_Client::normalize_name($said) . ' ';
        $ps_city = Intigo_API_Client::normalize_name($city_text);
        $chosen = null;
        $rule = '';
        foreach ($candidates as $it) {
            $d = Intigo_API_Client::normalize_name($it['district_name']);
            if (strlen($d) >= 4 && strpos($haystack, ' ' . $d . ' ') !== false) {
                $chosen = $it;
                $rule = 'district_text';
                break;
            }
        }
        if ($chosen === null) {
            foreach ($candidates as $it) {
                $n = Intigo_API_Client::normalize_name($it['neighborhood_name']);
                if (strlen($n) >= 5 && strpos($haystack, ' ' . $n . ' ') !== false) {
                    $chosen = $it;
                    $rule = 'neighborhood_text';
                    break;
                }
            }
        }
        if ($chosen === null && $ps_city !== '') {
            foreach ($candidates as $it) {
                if (Intigo_API_Client::normalize_name($it['city_name']) === $ps_city) {
                    $chosen = $it;
                    $rule = 'city_equal';
                    break;
                }
            }
        }
        if ($chosen === null) {
            // Nothing the customer wrote corroborates a candidate. Fenced, the
            // guesser's top hit is at least in a stated governorate; unfenced it
            // is a pure guess and is refused.
            if (empty($govs)) {
                return $blocked('no_match');
            }
            $chosen = $candidates[0];
            $rule = 'governorate_best';
        }

        // Guesser names → live ids. The guesser's own ids are only trusted when
        // the live regions confirm them.
        $city = !empty($govs) ? $this->gov_for_row($govs, $chosen) : null;
        if ($city === null) {
            $cres = $this->api->get_cities_cached();
            if (empty($cres['ok'])) {
                return $blocked('api_unavailable');
            }
            $city = [
                'city_id' => $this->api->city_id_by_name($chosen['city_name']),
                'city_name' => (string) $chosen['city_name'],
            ];
        }
        $district_id = 0;
        if ($city['city_id'] > 0) {
            $district_id = $this->api->district_id_by_name($city['city_id'], $chosen['district_name']);
            if ($district_id <= 0 && $this->api->district_belongs_to_city($chosen['district_id'], $city['city_id'])) {
                $district_id = intval($chosen['district_id']);
            }
        }
        $neighborhood_id = 0;
        if ($district_id > 0 && trim((string) $chosen['neighborhood_name']) !== '') {
            $neighborhood_id = $this->api->neighborhood_id_by_name($district_id, $chosen['neighborhood_name']);
        }
        $verified = ($city['city_id'] > 0 && $district_id > 0);
        $reason = $force_reason !== '' ? $force_reason : ($verified ? 'nearest_match' : 'nearest_unverified');

        return $this->result(self::TIER_REVIEW, $reason, $rule, [
            'city_id' => $city['city_id'],
            'city_name' => $city['city_name'],
            'district_id' => $district_id,
            'district_name' => (string) $chosen['district_name'],
            'neighborhood_id' => $neighborhood_id,
            'neighborhood_name' => $neighborhood_id > 0 ? (string) $chosen['neighborhood_name'] : '',
        ]);
    }

    /** The fenced governorate a guesser row belongs to, or null. */
    private function gov_for_row(array $govs, array $row) {
        $name = Intigo_Zone_Index::squash($row['city_name']);
        foreach ($govs as $g) {
            if ($name !== '' && $name === Intigo_Zone_Index::squash($g['city_name'])) {
                return $g;
            }
        }
        return null;
    }

    /**
     * Governorate key → live city id. 'reason' is '' on success, api_unavailable
     * when the cities list can't be read, unknown_city when Intigo doesn't list it.
     */
    private function live_city($city_key) {
        $name = Intigo_Zone_Index::city_name($city_key);
        $out = ['city_id' => 0, 'city_name' => $name, 'reason' => ''];
        $res = $this->api->get_cities_cached();
        if (empty($res['ok'])) {
            $out['reason'] = 'api_unavailable';
            return $out;
        }
        foreach ($res['items'] as $c) {
            if (Intigo_Zone_Index::squash($c['name']) === $city_key
                || Intigo_Zone_Index::squash($c['name']) === Intigo_Zone_Index::squash($name)) {
                $out['city_id'] = intval($c['id']);
                $out['city_name'] = (string) $c['name'];
                return $out;
            }
        }
        $out['reason'] = 'unknown_city';
        return $out;
    }

    private function live_name($items, $id, $fallback) {
        foreach ((array) $items as $it) {
            if (intval($it['id']) === intval($id)) {
                return (string) $it['name'];
            }
        }
        return (string) $fallback;
    }

    /**
     * Does the street say anything beyond the governorate / country? "Tunis" or
     * "Tunis, Tunisie" does not; "Rue de Marseille, Tunis" does.
     */
    private function has_locality($street, $city_key) {
        $words = explode(' ', Intigo_API_Client::normalize_name($this->clean_address($street)));
        $gov_words = $city_key !== '' ? explode(' ', Intigo_API_Client::normalize_name(Intigo_Zone_Index::city_name($city_key))) : [];
        $noise = array_merge($gov_words, [$city_key, 'tunisie', 'tunisia', 'tn', 'gouvernorat', 'de']);
        foreach ($words as $w) {
            if ($w !== '' && !ctype_digit($w) && !in_array($w, $noise, true)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Strip building-reference pairs ("immeuble X", "appt 3", "n° 12") and 4-digit
     * postcodes. Bare 1-2 digit numbers stay: "Charguia 2", "El Menzah 6".
     */
    private function clean_address($address) {
        $s = (string) $address;
        $s = preg_replace('/\bn[\x{00b0}o]?\.?\s*\d+\b/iu', ' ', $s);
        $s = preg_replace(
            '/\b(immeuble|imm|appartement|appart|appt|apt|bloc|block|etage|etg|esc|escalier|residence|res)\b\.?\s*[\w\x{00b0}]+/iu',
            ' ',
            (string) $s
        );
        $s = preg_replace('/\b\d{4}\b/u', ' ', (string) $s);
        $s = preg_replace('/[,;]+/', ' ', (string) $s);
        return trim(preg_replace('/\s+/', ' ', (string) $s));
    }

    /** The place name after a 4-digit postcode ("… 2091 El Menzah 6" → "El Menzah 6"). */
    private function locality_after_postal($text) {
        if (!preg_match('/\b\d{4}\b(.+)$/u', (string) $text, $m)) {
            return '';
        }
        $after = preg_split('/[,;]/', trim($m[1]));
        return $this->clean_address($after[0]);
    }

    private function result($tier, $reason, $rule, $zone = null) {
        $zone = is_array($zone) ? $zone : [];
        $r = [
            'tier' => $tier,
            'city_id' => isset($zone['city_id']) ? intval($zone['city_id']) : 0,
            'district_id' => isset($zone['district_id']) ? intval($zone['district_id']) : 0,
            'neighborhood_id' => isset($zone['neighborhood_id']) ? intval($zone['neighborhood_id']) : 0,
            'city_name' => isset($zone['city_name']) ? (string) $zone['city_name'] : '',
            'district_name' => isset($zone['district_name']) ? (string) $zone['district_name'] : '',
            'neighborhood_name' => isset($zone['neighborhood_name']) ? (string) $zone['neighborhood_name'] : '',
            'reason' => (string) $reason,
            'rule' => (string) $rule,
            'alternatives' => [],
        ];
        if ($tier === self::TIER_BLOCKED) {
            // A blocked zone is never sendable; only the stated governorate survives.
            $r['district_id'] = 0;
            $r['neighborhood_id'] = 0;
            $r['district_name'] = '';
            $r['neighborhood_name'] = '';
        }
        return $r;
    }

    /**
     * Resolve an order's address and store the result as order meta (one save).
     * Shipping address first, billing field-by-field when a shipping field is
     * empty. Skipped — returning the stored state with 'skipped' => true — when a
     * parcel already exists or the zone was set by hand, unless $force.
     */
    public function resolve_order(WC_Order $order, $force = false) {
        if (!$force) {
            if ((string) $order->get_meta('_intigo_parcel_nid') !== '') {
                return $this->stored_state($order, 'parcel_exists');
            }
            if ((string) $order->get_meta('_intigo_zone_tier') === 'manual') {
                return $this->stored_state($order, 'manual');
            }
            if ($this->adopt_legacy_zone($order)) {
                $state = $this->stored_state($order, 'legacy');
                $state['skipped'] = true;
                return $state;
            }
        }

        $address = $this->order_address($order);
        $result = $this->resolve($address);

        $ids = [
            '_intigo_city_id' => $result['city_id'],
            '_intigo_district_id' => $result['district_id'],
            '_intigo_neighborhood_id' => $result['neighborhood_id'],
        ];
        foreach ($ids as $key => $id) {
            // Same convention as the admin save path: a missing id is no meta.
            if ($id > 0) {
                $order->update_meta_data($key, $id);
            } else {
                $order->delete_meta_data($key);
            }
        }
        $names = [
            '_intigo_city_name' => $result['city_name'],
            '_intigo_zone_district_name' => $result['district_name'],
            '_intigo_zone_neighborhood_name' => $result['neighborhood_name'],
        ];
        foreach ($names as $key => $name) {
            if ($name !== '') {
                $order->update_meta_data($key, $name);
            } else {
                $order->delete_meta_data($key);
            }
        }
        $order->update_meta_data('_intigo_zone_tier', $result['tier']);
        $order->update_meta_data('_intigo_zone_reason', $result['reason']);
        $order->update_meta_data('_intigo_zone_rule', $result['rule']);
        if (!empty($result['alternatives'])) {
            $order->update_meta_data('_intigo_zone_alternatives', implode('|', $result['alternatives']));
        } else {
            $order->delete_meta_data('_intigo_zone_alternatives');
        }
        $order->update_meta_data('_intigo_zone_resolved_at', gmdate('c'));
        $order->update_meta_data('_intigo_zone_address_hash', self::hash_address($address));
        $order->save();

        $result['skipped'] = false;
        return $result;
    }

    /** Fingerprint of the address a zone was detected from. */
    private static function hash_address(array $address) {
        return md5(json_encode(array_map('strval', $address)));
    }

    /** True when the order's address differs from the one the stored zone came from. */
    public function address_changed(WC_Order $order) {
        return (string) $order->get_meta('_intigo_zone_address_hash') !== self::hash_address($this->order_address($order));
    }

    /**
     * Store a zone chosen by a person (customer at checkout, merchant in the
     * admin) as tier `manual`: the resolver never overwrites it. Names come from
     * $names when given (the checkout form knows them), else from the cached
     * regions lists. Does NOT save — the caller saves once.
     *
     * @param string $reason customer_selected | merchant_selected | merchant_confirmed
     * @return bool false when the ids do not form a known zone (nothing written)
     */
    public function mark_manual(WC_Order $order, $city_id, $district_id, $neighborhood_id, $reason, array $names = null) {
        $city_id = intval($city_id);
        $district_id = intval($district_id);
        $neighborhood_id = intval($neighborhood_id);
        if ($city_id <= 0 || $district_id <= 0) {
            return false;
        }
        if ($names === null) {
            $names = $this->api->zone_names($city_id, $district_id, $neighborhood_id);
            if ($names['city_name'] === '' || $names['district_name'] === '') {
                return false;
            }
            if ($neighborhood_id > 0 && $names['neighborhood_name'] === '') {
                $neighborhood_id = 0;
            }
        }
        $order->update_meta_data('_intigo_city_id', $city_id);
        $order->update_meta_data('_intigo_district_id', $district_id);
        if ($neighborhood_id > 0) {
            $order->update_meta_data('_intigo_neighborhood_id', $neighborhood_id);
        } else {
            $order->delete_meta_data('_intigo_neighborhood_id');
        }
        $name_keys = [
            '_intigo_city_name' => 'city_name',
            '_intigo_zone_district_name' => 'district_name',
            '_intigo_zone_neighborhood_name' => 'neighborhood_name',
        ];
        foreach ($name_keys as $meta_key => $k) {
            $name = isset($names[$k]) ? trim((string) $names[$k]) : '';
            if ($name !== '' && !($k === 'neighborhood_name' && $neighborhood_id <= 0)) {
                $order->update_meta_data($meta_key, $name);
            } else {
                $order->delete_meta_data($meta_key);
            }
        }
        $order->update_meta_data('_intigo_zone_tier', 'manual');
        $order->update_meta_data('_intigo_zone_reason', (string) $reason);
        $order->update_meta_data('_intigo_zone_rule', 'manual');
        $order->delete_meta_data('_intigo_zone_alternatives');
        $order->update_meta_data('_intigo_zone_resolved_at', gmdate('c'));
        return true;
    }

    /**
     * Orders from before 0.4.0 carry zone ids but no tier. Never re-guess them:
     * - names stored next to the ids: only the checkout form did that → customer's choice;
     * - a neighborhood id: only a person ever picked one (old automatic lookups
     *   never set it) → merchant's choice;
     * - bare city + district ids: may come from the old guessing (which could
     *   send "Tunis" to Sfax) → kept, but "to check" until confirmed.
     *
     * @return array|null ['tier' => ..., 'reason' => ...] or null when not a legacy zone.
     */
    private static function legacy_zone(WC_Order $order) {
        if ((string) $order->get_meta('_intigo_zone_tier') !== ''
            || intval($order->get_meta('_intigo_city_id')) <= 0
            || intval($order->get_meta('_intigo_district_id')) <= 0) {
            return null;
        }
        if ((string) $order->get_meta('_intigo_city_name') !== '' || (string) $order->get_meta('_intigo_district_name') !== '') {
            return ['tier' => 'manual', 'reason' => 'customer_selected'];
        }
        if (intval($order->get_meta('_intigo_neighborhood_id')) > 0) {
            return ['tier' => 'manual', 'reason' => 'merchant_selected'];
        }
        return ['tier' => self::TIER_REVIEW, 'reason' => 'legacy_unverified'];
    }

    /**
     * Store the legacy classification (see legacy_zone()) with the zone names
     * looked up from the cached regions. Saves the order. Returns true when applied.
     */
    private function adopt_legacy_zone(WC_Order $order) {
        $legacy = self::legacy_zone($order);
        if ($legacy === null) {
            return false;
        }
        $city_id = intval($order->get_meta('_intigo_city_id'));
        $district_id = intval($order->get_meta('_intigo_district_id'));
        $neighborhood_id = intval($order->get_meta('_intigo_neighborhood_id'));
        $names = [
            'city_name' => (string) $order->get_meta('_intigo_city_name'),
            'district_name' => (string) $order->get_meta('_intigo_district_name'),
            'neighborhood_name' => (string) $order->get_meta('_intigo_neighborhood_name'),
        ];
        $lookups = [
            'city_name' => [$this->api->get_cities_cached(), $city_id],
            'district_name' => [$this->api->get_districts_cached($city_id), $district_id],
            'neighborhood_name' => [$neighborhood_id > 0 ? $this->api->get_neighborhoods_cached($district_id) : ['items' => []], $neighborhood_id],
        ];
        foreach ($lookups as $key => $lookup) {
            if ($names[$key] !== '' || empty($lookup[0]['items'])) {
                continue;
            }
            foreach ($lookup[0]['items'] as $item) {
                if (is_array($item) && intval($item['id'] ?? 0) === $lookup[1]) {
                    $names[$key] = (string) ($item['name'] ?? '');
                    break;
                }
            }
        }
        if ($legacy['tier'] === 'manual') {
            $this->mark_manual($order, $city_id, $district_id, $neighborhood_id, $legacy['reason'], $names);
        } else {
            $order->update_meta_data('_intigo_zone_tier', $legacy['tier']);
            $order->update_meta_data('_intigo_zone_reason', $legacy['reason']);
            $order->update_meta_data('_intigo_zone_rule', 'legacy');
            $order->update_meta_data('_intigo_city_name', $names['city_name']);
            $order->update_meta_data('_intigo_zone_district_name', $names['district_name']);
            if ($names['neighborhood_name'] !== '') {
                $order->update_meta_data('_intigo_zone_neighborhood_name', $names['neighborhood_name']);
            }
            $order->update_meta_data('_intigo_zone_resolved_at', gmdate('c'));
            // The address has not changed since this zone was kept: only a later edit re-detects it.
            $order->update_meta_data('_intigo_zone_address_hash', self::hash_address($this->order_address($order)));
        }
        $order->save();
        return true;
    }

    /**
     * Bring the stored zone up to date just before a send: legacy checkout
     * choices become `manual`, undetected orders and orders whose address
     * changed since detection are (re)detected, manual zones are kept.
     * May save the order. Returns the zone state (stored_state() shape).
     */
    public function prepare_for_send(WC_Order $order) {
        if ((string) $order->get_meta('_intigo_parcel_nid') !== '') {
            return $this->stored_state($order, 'parcel_exists');
        }
        $tier = (string) $order->get_meta('_intigo_zone_tier');
        if ($tier === 'manual') {
            return $this->stored_state($order, 'manual');
        }
        if ($this->adopt_legacy_zone($order)) {
            return $this->stored_state($order, 'legacy');
        }
        if ($tier === '' || $this->address_changed($order)) {
            $state = $this->resolve_order($order, false);
            $state['skipped'] = false;
            return $state;
        }
        return $this->stored_state($order, 'up_to_date');
    }

    /**
     * What the admin screens show for an order's zone — read-only, no network,
     * no save. 'tier' is '' for "not detected yet".
     *
     * @return array tier, reason, reason_text, city_id, district_id, neighborhood_id,
     *               city_name, district_name, neighborhood_name, ready
     */
    public static function display_state(WC_Order $order) {
        $tier = (string) $order->get_meta('_intigo_zone_tier');
        $reason = (string) $order->get_meta('_intigo_zone_reason');
        $legacy = self::legacy_zone($order);
        if ($legacy !== null) {
            $tier = $legacy['tier'];
            $reason = $legacy['reason'];
        }
        $pick = function ($keys) use ($order) {
            foreach ($keys as $k) {
                $v = trim((string) $order->get_meta($k));
                if ($v !== '') {
                    return $v;
                }
            }
            return '';
        };
        $state = [
            'tier' => $tier,
            'reason' => $reason,
            'reason_text' => self::reason_message($reason, array_values(array_filter(explode('|', (string) $order->get_meta('_intigo_zone_alternatives'))))),
            'city_id' => intval($order->get_meta('_intigo_city_id')),
            'district_id' => intval($order->get_meta('_intigo_district_id')),
            'neighborhood_id' => intval($order->get_meta('_intigo_neighborhood_id')),
            'city_name' => $pick(['_intigo_city_name']),
            'district_name' => $pick(['_intigo_zone_district_name', '_intigo_district_name']),
            'neighborhood_name' => $pick(['_intigo_zone_neighborhood_name', '_intigo_neighborhood_name']),
        ];
        if ($state['neighborhood_id'] <= 0) {
            $state['neighborhood_name'] = '';
        }
        $state['ready'] = in_array($tier, [self::TIER_RESOLVED, 'manual'], true) && $state['city_id'] > 0 && $state['district_id'] > 0;
        return $state;
    }

    /** The resolver input for an order: shipping, billing field-by-field as fallback. */
    private function order_address(WC_Order $order) {
        $ship = [
            'address_1' => (string) $order->get_shipping_address_1(),
            'address_2' => (string) $order->get_shipping_address_2(),
            'city' => (string) $order->get_shipping_city(),
            'state' => (string) $order->get_shipping_state(),
            'postcode' => (string) $order->get_shipping_postcode(),
            'country' => (string) $order->get_shipping_country(),
        ];
        $bill = [
            'address_1' => (string) $order->get_billing_address_1(),
            'address_2' => (string) $order->get_billing_address_2(),
            'city' => (string) $order->get_billing_city(),
            'state' => (string) $order->get_billing_state(),
            'postcode' => (string) $order->get_billing_postcode(),
            'country' => (string) $order->get_billing_country(),
        ];
        // The street lines travel as a pair: a shipping line 1 with the billing
        // line 2 would describe an address nobody wrote.
        if (trim($ship['address_1']) === '' && trim($ship['address_2']) === '') {
            $ship['address_1'] = $bill['address_1'];
            $ship['address_2'] = $bill['address_2'];
        }
        foreach (['city', 'state', 'postcode', 'country'] as $k) {
            if (trim($ship[$k]) === '') {
                $ship[$k] = $bill[$k];
            }
        }
        // WooCommerce stores the state as a code; hand the resolver its name.
        if ($ship['state'] !== '' && function_exists('WC') && WC()->countries) {
            $states = WC()->countries->get_states($ship['country'] !== '' ? $ship['country'] : 'TN');
            if (is_array($states) && isset($states[$ship['state']])) {
                $ship['state'] = html_entity_decode((string) $states[$ship['state']], ENT_QUOTES, 'UTF-8');
            }
        }
        return $ship;
    }

    private function stored_state(WC_Order $order, $why) {
        return [
            'tier' => (string) $order->get_meta('_intigo_zone_tier'),
            'city_id' => intval($order->get_meta('_intigo_city_id')),
            'district_id' => intval($order->get_meta('_intigo_district_id')),
            'neighborhood_id' => intval($order->get_meta('_intigo_neighborhood_id')),
            'city_name' => (string) $order->get_meta('_intigo_city_name'),
            'district_name' => (string) $order->get_meta('_intigo_zone_district_name'),
            'neighborhood_name' => (string) $order->get_meta('_intigo_zone_neighborhood_name'),
            'reason' => (string) $order->get_meta('_intigo_zone_reason'),
            'rule' => (string) $order->get_meta('_intigo_zone_rule'),
            'alternatives' => array_values(array_filter(explode('|', (string) $order->get_meta('_intigo_zone_alternatives')))),
            'skipped' => true,
            'skip_reason' => $why,
        ];
    }

    /**
     * Merchant-facing explanation of a reason code ('' for none / unknown).
     * $alternatives: the two governorate names of a conflicting_governorates
     * result (its 'alternatives' key).
     */
    public static function reason_message($reason, array $alternatives = []) {
        switch ((string) $reason) {
            case 'conflicting_governorates':
                if (count($alternatives) >= 2) {
                    /* translators: 1: governorate named in the City field, 2: governorate named in the State field. */
                    return sprintf(__('City and state name two different governorates (%1$s / %2$s). Check which one is right.', 'intigo-parcels'), $alternatives[0], $alternatives[1]);
                }
                return __('City and state name two different governorates. Check which one is right.', 'intigo-parcels');
            case 'empty_address':
                return __('The address is empty. Add the street, the délégation and the governorate.', 'intigo-parcels');
            case 'not_tunisia':
                return __('The delivery address is outside Tunisia. Intigo only delivers in Tunisia.', 'intigo-parcels');
            case 'api_unavailable':
                return __('The Intigo zone list could not be loaded. Try again in a moment.', 'intigo-parcels');
            case 'guesser_unavailable':
                return __('The address search service did not answer. Try again in a moment, or pick the zone by hand.', 'intigo-parcels');
            case 'unknown_city':
                return __('The governorate is not in the Intigo zone list. Pick the zone by hand.', 'intigo-parcels');
            case 'governorate_only':
                return __('Only the governorate was found. Add the délégation to the street address.', 'intigo-parcels');
            case 'outside_stated_city':
                return __('The places named in the street are not in the governorate given. Check the governorate or add the délégation.', 'intigo-parcels');
            case 'no_match':
                return __('No Intigo délégation found in this address. Add the délégation or cité name (e.g. "La Marsa").', 'intigo-parcels');
            case 'governorate_not_stated':
                return __('The governorate was deduced from the délégation, not given — please check before sending.', 'intigo-parcels');
            case 'nearest_match':
                return __('Nearest match — please check before sending.', 'intigo-parcels');
            case 'nearest_unverified':
                return __('Nearest match, not confirmed by the Intigo zone list — please pick the délégation before sending.', 'intigo-parcels');
            case 'customer_selected':
                return __('Zone chosen by the customer at checkout.', 'intigo-parcels');
            case 'merchant_selected':
                return __('Zone chosen by hand in the admin.', 'intigo-parcels');
            case 'legacy_unverified':
                return __('Zone set by an earlier version of the plugin — please confirm it before sending.', 'intigo-parcels');
            case 'merchant_confirmed':
                return __('Detected zone confirmed by hand.', 'intigo-parcels');
        }
        return '';
    }
}
