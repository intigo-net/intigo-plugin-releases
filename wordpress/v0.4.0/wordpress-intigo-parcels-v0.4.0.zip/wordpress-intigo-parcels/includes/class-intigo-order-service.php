<?php

if (!defined('ABSPATH')) {
    exit;
}

class Intigo_Order_Service {
    private $api;

    public function __construct($api_client) {
        $this->api = $api_client;
    }

    public function register_hooks() {
        add_filter('woocommerce_order_actions', [$this, 'register_order_actions']);
        add_filter('bulk_actions-edit-shop_order', [$this, 'register_bulk_action']);
        add_filter('handle_bulk_actions-edit-shop_order', [$this, 'handle_bulk_action'], 10, 3);
        // HPOS orders list (WooCommerce > Orders when custom order tables are on).
        add_filter('bulk_actions-woocommerce_page_wc-orders', [$this, 'register_bulk_action']);
        add_filter('handle_bulk_actions-woocommerce_page_wc-orders', [$this, 'handle_bulk_action'], 10, 3);
        add_action('woocommerce_order_action_intigo_create_parcel', [$this, 'handle_order_action_create']);
        add_action('woocommerce_order_action_intigo_generate_bordereau', [$this, 'handle_order_action_bordereau']);
        add_action('woocommerce_order_status_processing', [$this, 'maybe_auto_create_from_order_event']);
        add_action('woocommerce_order_status_completed', [$this, 'maybe_auto_create_from_order_event']);
        add_action('woocommerce_payment_complete', [$this, 'maybe_auto_create_from_order_event']);
        add_action('woocommerce_thankyou', [$this, 'maybe_auto_create_from_order_event']);
        add_action('woocommerce_process_shop_order_meta', [$this, 'maybe_sync_after_order_edit'], 30, 1);
    }

    public function register_order_actions($actions) {
        $actions['intigo_create_parcel'] = __('Intigo: Create Parcel', 'intigo-parcels');
        $actions['intigo_generate_bordereau'] = __('Intigo: Generate Bordereau', 'intigo-parcels');
        return $actions;
    }

    public function register_bulk_action($actions) {
        $actions['intigo_create_parcels_batch'] = __('Intigo: Create Parcels (Batch)', 'intigo-parcels');
        return $actions;
    }

    public function handle_bulk_action($redirect_to, $action, $post_ids) {
        if ($action !== 'intigo_create_parcels_batch') {
            return $redirect_to;
        }

        // One create per order (same path as "Send to Intigo"): the batch endpoint's
        // response can't be mapped back to orders reliably, and per-order creates give
        // each order its NID, idempotency guard, notes and a per-order success/failure.
        $created = 0;
        $to_check = 0;
        $failures = [];
        foreach ((array) $post_ids as $order_id) {
            $order = wc_get_order($order_id);
            if (!$order) {
                $failures[] = '#' . intval($order_id) . ': ' . __('Order not found.', 'intigo-parcels');
                continue;
            }
            $result = $this->create_single_for_order($order);
            if (!empty($result['ok'])) {
                $created++;
            } else {
                if (($result['code'] ?? '') === 'needs_review') {
                    $to_check++;
                }
                $failures[] = '#' . $order->get_id() . ': ' . ($result['message'] ?? '');
            }
        }

        if (class_exists('Intigo_Admin')) {
            /* translators: 1: number of orders sent to Intigo, 2: number of orders whose address must be checked, 3: number of orders that failed for another reason. */
            $summary = sprintf(__('%1$d sent to Intigo, %2$d to check, %3$d in error.', 'intigo-parcels'), $created, $to_check, count($failures) - $to_check);
            Intigo_Admin::queue_notice($summary, empty($failures) ? 'success' : ($created > 0 ? 'warning' : 'error'), $failures);
        }
        return add_query_arg(['intigo_batch_created' => $created], $redirect_to);
    }

    /**
     * "Intigo: Create Parcel" from the order-edit "Order actions" box: create, then
     * leave a one-shot notice for the edit screen WooCommerce redirects back to.
     */
    public function handle_order_action_create($order) {
        $result = $this->create_single_for_order($order);
        $this->queue_result_notice($order, $result);
        return $result;
    }

    /**
     * "Intigo: Generate Bordereau" from the order-edit "Order actions" box.
     */
    public function handle_order_action_bordereau($order) {
        $result = $this->generate_bordereau_for_order($order);
        $this->queue_result_notice($order, $result);
        return $result;
    }

    private function queue_result_notice($order, $result) {
        if (!class_exists('Intigo_Admin') || !is_array($result)) {
            return;
        }
        $order_id = $order instanceof WC_Order ? $order->get_id() : 0;
        if (!empty($result['ok'])) {
            if (($result['code'] ?? '') === 'bordereau_generated') {
                /* translators: 1: WooCommerce order ID, 2: Intigo parcel NID */
                $message = sprintf(__('Order #%1$d: bordereau generated for parcel %2$s. You can now download or print it.', 'intigo-parcels'), $order_id, $result['nid']);
            } else {
                /* translators: 1: WooCommerce order ID, 2: Intigo parcel NID */
                $message = sprintf(__('Order #%1$d: parcel sent to Intigo — NID %2$s', 'intigo-parcels'), $order_id, $result['nid']);
            }
            Intigo_Admin::queue_notice($message, 'success');
            return;
        }
        /* translators: 1: WooCommerce order ID, 2: failure reason. */
        $message = sprintf(__('Order #%1$d: %2$s', 'intigo-parcels'), $order_id, $result['message'] ?? '');
        Intigo_Admin::queue_notice($message, ($result['code'] ?? '') === 'already_created' ? 'warning' : 'error');
    }

    /**
     * Result shape shared by create_single_for_order() and generate_bordereau_for_order().
     */
    private function result($ok, $code, $message, $nid = '', $extra = []) {
        return array_merge([
            'ok' => (bool) $ok,
            'nid' => (string) $nid,
            'message' => (string) $message,
            'code' => (string) $code,
        ], $extra);
    }

    /** Record a refused/failed create like API errors so Manage Orders shows it (auto-push included). */
    private function record_failure($order, $message) {
        $order->update_meta_data('_intigo_last_error', $message);
        $order->update_meta_data('_intigo_last_attempt_at', current_time('mysql'));
        $order->save();
        /* translators: %s: error message. */
        $order->add_order_note(sprintf(__('Intigo parcel creation failed: %s', 'intigo-parcels'), $message));
    }

    public function resolver() {
        return new Intigo_Address_Resolver($this->api);
    }

    /**
     * Only a zone that is `resolved` (confident detection) or `manual` (chosen
     * or confirmed by a person) is ever sent. Undetected orders and orders whose
     * address changed are detected first. Returns null when the order may be
     * sent, else a failed result (code needs_review | address_incomplete).
     */
    public function zone_gate($order) {
        $state = $this->resolver()->prepare_for_send($order);
        $tier = (string) ($state['tier'] ?? '');
        $has_ids = intval($state['city_id'] ?? 0) > 0 && intval($state['district_id'] ?? 0) > 0;
        if (in_array($tier, ['resolved', 'manual'], true) && $has_ids) {
            return null;
        }
        if ($tier === 'review') {
            return $this->result(false, 'needs_review', __('The address match needs your confirmation. Open the order in Intigo → Manage Orders and click Confirm, or pick the zone.', 'intigo-parcels'));
        }
        $reason = Intigo_Address_Resolver::reason_message((string) ($state['reason'] ?? ''), (array) ($state['alternatives'] ?? []));
        if ($reason === '') {
            $reason = __('The Intigo delivery zone of this address is unknown. Pick the governorate and the délégation in Intigo → Manage Orders → Edit.', 'intigo-parcels');
        }
        /* translators: %s: why the address could not be matched to an Intigo zone. */
        return $this->result(false, 'address_incomplete', sprintf(__('Incomplete address: %s', 'intigo-parcels'), $reason));
    }

    /**
     * Create the Intigo parcel for an order.
     *
     * @return array{ok: bool, nid: string, message: string, code: string}
     *   code: created | already_created | needs_review | address_incomplete | validation | api_error | invalid_order.
     *   message is human-readable and safe to show to the merchant (escape on output).
     */
    public function create_single_for_order($order) {
        if (!$order instanceof WC_Order) {
            return $this->result(false, 'invalid_order', __('Order not found.', 'intigo-parcels'));
        }
        $this->hydrate_intigo_meta_from_request($order);
        $key = $this->idempotency_key($order, 'manual_create');
        if ($order->get_meta('_intigo_idem_' . md5($key)) !== '') {
            $order->add_order_note(__('Intigo create skipped: parcel already created for this order (idempotency). Use "Intigo: Force Create Parcel" to create another one.', 'intigo-parcels'));
            $existing_nid = (string) $order->get_meta('_intigo_parcel_nid');
            $message = $existing_nid !== ''
                /* translators: %s: Intigo parcel NID. */
                ? sprintf(__('Already sent to Intigo (NID %s). No new parcel was created.', 'intigo-parcels'), $existing_nid)
                : __('Already sent to Intigo. No new parcel was created.', 'intigo-parcels');
            return $this->result(false, 'already_created', $message, $existing_nid);
        }

        $zone_error = $this->zone_gate($order);
        if ($zone_error !== null) {
            $this->record_failure($order, $zone_error['message']);
            return $zone_error;
        }

        $payload = $this->order_to_payload($order);
        $validation_error = $this->validate_payload($payload);
        if ($validation_error !== null) {
            $this->record_failure($order, $validation_error);
            return $this->result(false, 'validation', $validation_error);
        }
        $res = $this->api->create_parcel($payload);

        if (!empty($res['ok']) && !empty($res['data']['nid'])) {
            $order->update_meta_data('_intigo_parcel_nid', sanitize_text_field($res['data']['nid']));
            $order->update_meta_data('_intigo_api_target_used', sanitize_text_field($res['adapter']));
            $order->update_meta_data('_intigo_idem_' . md5($key), 1);
            $order->delete_meta_data('_intigo_last_error');
            $order->update_meta_data('_intigo_last_attempt_at', current_time('mysql'));
            $order->save();
            /* translators: %s: Intigo parcel NID. */
            $order->add_order_note(sprintf(__('Intigo parcel created: %s', 'intigo-parcels'), $res['data']['nid']));
            $nid = sanitize_text_field($res['data']['nid']);
            /* translators: %s: Intigo parcel NID. */
            return $this->result(true, 'created', sprintf(__('Parcel sent to Intigo — NID %s', 'intigo-parcels'), $nid), $nid);
        }

        $error_text = $this->format_api_error($res);
        $human_error = $this->humanize_api_error($res);
        $order->update_meta_data('_intigo_last_error', $human_error);
        $order->update_meta_data('_intigo_last_attempt_at', current_time('mysql'));
        $order->save();
        /* translators: %s: error message. */
        $order->add_order_note(sprintf(__('Intigo parcel creation failed: %s', 'intigo-parcels'), $error_text));
        return $this->result(false, 'api_error', $human_error);
    }

    public function force_create_for_order($order) {
        if (!$order instanceof WC_Order) {
            return;
        }
        // Ignore idempotency for explicit force action.
        $order->delete_meta_data('_intigo_idem_' . md5($this->idempotency_key($order, 'manual_create')));
        $order->save();
        return $this->create_single_for_order($order);
    }

    public function update_parcel_for_order($order) {
        if (!$order instanceof WC_Order) {
            return ['ok' => false, 'message' => __('Invalid order instance', 'intigo-parcels')];
        }
        $this->hydrate_intigo_meta_from_request($order);

        $nid = $order->get_meta('_intigo_parcel_nid');
        if (empty($nid)) {
            $order->add_order_note(__('Intigo update failed: no parcel NID found. Create parcel first.', 'intigo-parcels'));
            return ['ok' => false, 'message' => __('No parcel NID found', 'intigo-parcels')];
        }

        $payload = $this->order_to_payload($order);
        $validation_error = $this->validate_payload($payload);
        if ($validation_error !== null) {
            /* translators: %s: error message. */
            $order->add_order_note(sprintf(__('Intigo update failed: %s', 'intigo-parcels'), $validation_error));
            return ['ok' => false, 'message' => $validation_error];
        }

        $res = $this->api->update_parcel($nid, $payload);
        if (!empty($res['ok'])) {
            /* translators: %s: Intigo parcel NID. */
            $order->add_order_note(sprintf(__('Intigo parcel updated successfully: %s', 'intigo-parcels'), $nid));
            return ['ok' => true, 'message' => __('Updated via PATCH', 'intigo-parcels'), 'response' => $res];
        }
        if ($this->is_parcel_locked_error($res)) {
            $msg = __('Parcel is locked in Intigo (already delivered or return). Updates are not allowed for this NID.', 'intigo-parcels');
            $order->update_meta_data('_intigo_sync_locked', 'yes');
            $order->save();
            /* translators: %s: reason the sync was skipped. */
            $order->add_order_note(sprintf(__('Intigo sync skipped: %s', 'intigo-parcels'), $msg));
            return ['ok' => false, 'locked' => true, 'message' => $msg, 'response' => ['patch' => $res]];
        }

        // Fallback sync strategy for parcels that are no longer patchable.
        $fallback_errors = [];

        $phone_res = $this->api->change_phone($nid, $payload['phone1'] ?? '');
        if (empty($phone_res['ok'])) {
            $fallback_errors[] = 'phone=' . $this->format_api_error($phone_res);
        }

        $addr_payload = [
            'address' => $payload['destination_address'] ?? '',
            'city_id' => intval($payload['destination_city_id'] ?? 0),
            'district_id' => intval($payload['destination_district_id'] ?? 0),
        ];
        if (!empty($payload['destination_neighborhood_id'])) {
            $addr_payload['neighborhood_id'] = intval($payload['destination_neighborhood_id']);
        }
        $addr_res = $this->api->change_address($nid, $addr_payload);
        if (empty($addr_res['ok'])) {
            $fallback_errors[] = 'address=' . $this->format_api_error($addr_res);
        }

        $price_res = $this->api->change_price($nid, floatval($payload['price'] ?? 0));
        if (empty($price_res['ok'])) {
            $fallback_errors[] = 'price=' . $this->format_api_error($price_res);
        }

        if (count($fallback_errors) < 3) {
            /* translators: %s: Intigo parcel NID. */
            $order->add_order_note(sprintf(__('Intigo parcel synchronized partially using fallback actions: %s', 'intigo-parcels'), $nid));
            return ['ok' => true, 'message' => __('Synchronized with fallback actions', 'intigo-parcels'), 'response' => [
                'patch' => $res,
                'phone' => $phone_res,
                'address' => $addr_res,
                'price' => $price_res,
            ]];
        }

        /* translators: %s: error message. */
        $order->add_order_note(sprintf(__('Intigo parcel update failed: %s', 'intigo-parcels'), $this->format_api_error($res)));
        /* translators: %s: API error details of the fallback actions. */
        $order->add_order_note(sprintf(__('Intigo fallback sync failed: %s', 'intigo-parcels'), implode(' | ', $fallback_errors)));
        return ['ok' => false, 'message' => implode(' | ', $fallback_errors), 'response' => [
            'patch' => $res,
            'phone' => $phone_res,
            'address' => $addr_res,
            'price' => $price_res,
        ]];
    }

    /**
     * Generate the bordereau (shipping label) for the order's parcel.
     *
     * @return array{ok: bool, nid: string, message: string, code: string, url: string}
     *   code: bordereau_generated | no_nid | api_error | invalid_order.
     */
    public function generate_bordereau_for_order($order) {
        if (!$order instanceof WC_Order) {
            return $this->result(false, 'invalid_order', __('Order not found.', 'intigo-parcels'), '', ['url' => '']);
        }

        $nid = $order->get_meta('_intigo_parcel_nid');
        if (empty($nid)) {
            $order->add_order_note(__('No Intigo parcel NID found for bordereau', 'intigo-parcels'));
            return $this->result(false, 'no_nid', __('This order has not been sent to Intigo yet. Send it first, then generate the bordereau.', 'intigo-parcels'), '', ['url' => '']);
        }

        $res = $this->api->generate_bordereau([$nid]);
        if (!empty($res['ok']) && !empty($res['data']['url'])) {
            $url = esc_url_raw($res['data']['url']);
            $order->update_meta_data('_intigo_bordereau_url', $url);
            $order->save();
            $order->add_order_note(__('Intigo bordereau URL generated', 'intigo-parcels'));
            /* translators: %s: Intigo parcel NID. */
            return $this->result(true, 'bordereau_generated', sprintf(__('Bordereau generated for parcel %s.', 'intigo-parcels'), $nid), $nid, ['url' => $url]);
        }
        /* translators: %s: error message. */
        $order->add_order_note(sprintf(__('Intigo bordereau generation failed: %s', 'intigo-parcels'), $this->format_api_error($res)));
        $message = !empty($res['ok'])
            ? __('Intigo did not return a bordereau link. Please try again.', 'intigo-parcels')
            : $this->humanize_api_error($res);
        return $this->result(false, 'api_error', $message, $nid, ['url' => '']);
    }

    public function maybe_auto_create_from_order_event($order_id) {
        $settings = $this->api->get_settings();
        if (($settings['auto_create_on_paid'] ?? 'no') !== 'yes') {
            return;
        }

        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }

        // Push Intigo Delivery orders, and orders without any shipping line (typically
        // typed in by the merchant in wp-admin). An order shipped by another carrier
        // is never pushed.
        $shipping_items = $order->get_items('shipping');
        if (!empty($shipping_items)) {
            $is_intigo = false;
            foreach ($shipping_items as $item) {
                if (is_object($item) && method_exists($item, 'get_method_id') && $item->get_method_id() === 'intigo_delivery') {
                    $is_intigo = true;
                    break;
                }
            }
            if (!$is_intigo) {
                return;
            }
        }

        // Skip orders that aren't in a "ready to ship" state.
        $status = $order->get_status();
        if (in_array($status, ['failed', 'cancelled', 'refunded', 'checkout-draft'], true)) {
            return;
        }

        // Idempotency — skip if we already pushed this order successfully.
        if ((string) $order->get_meta('_intigo_parcel_nid') !== '') {
            return;
        }
        $manual_key = $this->idempotency_key($order, 'manual_create');
        if ($order->get_meta('_intigo_idem_' . md5($manual_key)) !== '') {
            return;
        }

        $result = $this->create_single_for_order($order);

        // Admin changed the order status by hand (edit screen or list): tell them what happened.
        if (is_admin() && !wp_doing_ajax() && !wp_doing_cron() && current_user_can('edit_shop_orders')) {
            $this->queue_result_notice($order, $result);
        }
    }

    private function order_to_payload($order) {
        $intigo_name = trim((string) $order->get_meta('_intigo_recipient_name'));
        if ($intigo_name !== '') {
            $recipient_name = $intigo_name;
        } else {
            $recipient_name = trim($order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name());
            if ($recipient_name === '') {
                $recipient_name = trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());
            }
        }

        $phone = trim((string) $order->get_meta('_intigo_phone'));
        if ($phone === '') {
            $phone = trim((string) $order->get_billing_phone());
        }
        if ($phone === '' && method_exists($order, 'get_shipping_phone')) {
            $phone = trim((string) $order->get_shipping_phone());
        }
        $phone = $this->normalize_phone($phone);

        $destination_address = trim((string) $order->get_meta('_intigo_address'));
        if ($destination_address === '') {
            $destination_address = trim($order->get_shipping_address_1() . ' ' . $order->get_shipping_address_2());
            if ($destination_address === '') {
                $destination_address = trim($order->get_billing_address_1() . ' ' . $order->get_billing_address_2());
            }
        }

        $raw_package_size = (string) $order->get_meta('_intigo_package_size');
        if ($raw_package_size === '' && class_exists('Intigo_Size_Resolver')) {
            // Walk the size resolver: per-product override → auto-from-dimensions → plugin default.
            // This keeps bulk-create / API-only flows correct even when no Intigo Delivery rate
            // was chosen at checkout (e.g. orders imported from elsewhere).
            $raw_package_size = (new Intigo_Size_Resolver($this->api))->resolve_for_order($order);
        }
        if ($raw_package_size === '') {
            $settings = $this->api->get_settings();
            $raw_package_size = (string) ($settings['default_package_size'] ?? 'S');
        }
        $package_size = $this->normalize_package_size($raw_package_size);

        $payload = [
            'recipient_name' => $recipient_name,
            'phone1' => $phone,
            'destination_address' => $destination_address,
            'destination_city_id' => intval($order->get_meta('_intigo_city_id')),
            'destination_district_id' => intval($order->get_meta('_intigo_district_id')),
            'price' => floatval($order->get_total()),
            'package_size' => $package_size,
            'description' => $this->build_description($order),
            'can_open' => false,
        ];
        $neighborhood_id = intval($order->get_meta('_intigo_neighborhood_id'));
        if ($neighborhood_id > 0) {
            $payload['destination_neighborhood_id'] = $neighborhood_id;
        }
        return $payload;
    }

    /**
     * Build the parcel description sent to Intigo: the order reference plus the
     * product names (with quantity when > 1). Falls back to just the order
     * reference when there are no line items. Capped to a safe length.
     */
    private function build_description($order) {
        $order_ref = 'WooCommerce Order #' . $order->get_id();
        $parts = [];
        if (method_exists($order, 'get_items')) {
            foreach ($order->get_items() as $item) {
                if (!is_object($item) || !method_exists($item, 'get_name')) {
                    continue;
                }
                $name = trim((string) $item->get_name());
                if ($name === '') {
                    continue;
                }
                $qty = method_exists($item, 'get_quantity') ? (int) $item->get_quantity() : 1;
                $parts[] = $qty > 1 ? ($name . ' x' . $qty) : $name;
            }
        }
        if (empty($parts)) {
            return $order_ref;
        }
        $desc = $order_ref . ' - ' . implode(', ', $parts);
        // Keep within a safe length for the Intigo API.
        $max = 250;
        if (function_exists('mb_strlen') && mb_strlen($desc) > $max) {
            $desc = rtrim(mb_substr($desc, 0, $max - 1)) . '…';
        } elseif (strlen($desc) > $max) {
            $desc = rtrim(substr($desc, 0, $max - 1)) . '...';
        }
        return $desc;
    }

    private function idempotency_key($order, $event) {
        return sprintf('wp:%d:%d:%s:v1', get_current_blog_id(), $order->get_id(), $event);
    }

    private function validate_payload($payload) {
        if (empty($payload['recipient_name'])) {
            return __('Recipient name is missing: add a shipping or billing first/last name to the order.', 'intigo-parcels');
        }
        if (empty($payload['phone1'])) {
            return __('Phone number is missing: add a billing phone to the order.', 'intigo-parcels');
        }
        if (empty($payload['destination_address'])) {
            return __('Delivery address is missing: add a shipping address to the order.', 'intigo-parcels');
        }
        if (empty($payload['destination_city_id'])) {
            return __('Intigo city is missing: the order address could not be matched to an Intigo city. Pick the city in the Intigo shipment box of the order.', 'intigo-parcels');
        }
        if (empty($payload['destination_district_id'])) {
            return __('Intigo district is missing: the order address could not be matched to an Intigo district. Pick the district in the Intigo shipment box of the order.', 'intigo-parcels');
        }
        return null;
    }

    private function format_api_error($res) {
        if (!is_array($res)) {
            return __('unknown error', 'intigo-parcels');
        }
        $parts = [];
        if (isset($res['adapter'])) {
            $parts[] = 'adapter=' . $res['adapter'];
        }
        if (isset($res['code'])) {
            $parts[] = 'http=' . $res['code'];
        }
        if (!empty($res['url'])) {
            $parts[] = 'url=' . $res['url'];
        }
        if (!empty($res['error'])) {
            $parts[] = 'error=' . $res['error'];
        } elseif (!empty($res['data'])) {
            $parts[] = 'response=' . wp_json_encode($res['data']);
        }
        if (!empty($res['legacy_attempt'])) {
            $la = $res['legacy_attempt'];
            $sub = [];
            if (!empty($la['code'])) { $sub[] = 'http=' . $la['code']; }
            if (!empty($la['url'])) { $sub[] = 'url=' . $la['url']; }
            if (!empty($la['error'])) { $sub[] = 'error=' . $la['error']; }
            elseif (!empty($la['data'])) { $sub[] = 'response=' . wp_json_encode($la['data']); }
            if ($sub) { $parts[] = 'legacy(' . implode(' ', $sub) . ')'; }
        }
        return empty($parts) ? __('unknown error', 'intigo-parcels') : implode(' | ', $parts);
    }

    /**
     * Merchant-readable version of an API failure (the technical dump from
     * format_api_error() still goes to the order note for support).
     */
    public function humanize_api_error($res) {
        if (!is_array($res)) {
            return __('Intigo did not answer. Please try again.', 'intigo-parcels');
        }
        $code = isset($res['code']) ? intval($res['code']) : 0;
        if ($code === 0) {
            $detail = !empty($res['error']) ? (string) $res['error'] : __('no response', 'intigo-parcels');
            /* translators: %s: network error message. */
            return sprintf(__('Could not reach Intigo: %s', 'intigo-parcels'), $detail);
        }
        if ($code === 401 || $code === 403) {
            /* translators: %d: HTTP status code. */
            return sprintf(__('Intigo refused the API key (HTTP %d). Check the API key in the Intigo settings.', 'intigo-parcels'), $code);
        }

        $messages = [];
        $data = $res['data'] ?? null;
        if (is_array($data)) {
            foreach (['detail', 'message', 'error', 'errors', 'non_field_errors'] as $k) {
                if (isset($data[$k])) {
                    $messages = array_merge($messages, $this->flatten_error_messages($data[$k]));
                }
            }
            if (empty($messages)) {
                // DRF-style field errors: {"phone1": ["Ce champ est obligatoire."]}.
                foreach ($data as $field => $value) {
                    if ($field === 'raw_body' || $field === 'status' || $field === 'code') {
                        continue;
                    }
                    foreach ($this->flatten_error_messages($value) as $m) {
                        $messages[] = is_string($field) ? $field . ': ' . $m : $m;
                    }
                }
            }
        }
        if (empty($messages) && !empty($res['error'])) {
            $messages[] = (string) $res['error'];
        }

        $text = trim(wp_strip_all_tags(implode('; ', array_unique($messages))));
        if ($text === '') {
            /* translators: %d: HTTP status code. */
            return sprintf(__('Intigo returned an error (HTTP %d).', 'intigo-parcels'), $code);
        }
        if (function_exists('mb_strlen') && mb_strlen($text) > 300) {
            $text = rtrim(mb_substr($text, 0, 299)) . '…';
        }
        /* translators: 1: HTTP status code, 2: error message returned by Intigo. */
        return sprintf(__('Intigo rejected the request (HTTP %1$d): %2$s', 'intigo-parcels'), $code, $text);
    }

    private function flatten_error_messages($value) {
        if (is_string($value) || is_numeric($value)) {
            return [(string) $value];
        }
        if (!is_array($value)) {
            return [];
        }
        // FastAPI/pydantic validation item: {"loc": ["body", "phone1"], "msg": "Value error, ..."}.
        if (isset($value['msg']) && is_string($value['msg'])) {
            $msg = preg_replace('/^Value error,\s*/i', '', $value['msg']);
            $loc = isset($value['loc']) && is_array($value['loc']) ? end($value['loc']) : '';
            return [(is_string($loc) && $loc !== '' && $loc !== 'body') ? $loc . ': ' . $msg : $msg];
        }
        $out = [];
        foreach ($value as $v) {
            $out = array_merge($out, $this->flatten_error_messages($v));
        }
        return $out;
    }

    private function is_parcel_locked_error($res) {
        if (!is_array($res)) {
            return false;
        }
        $status = 0;
        if (isset($res['code'])) {
            $status = intval($res['code']);
        } elseif (isset($res['status'])) {
            $status = intval($res['status']);
        }
        if ($status !== 400 && $status !== 409) {
            return false;
        }
        $detail = '';
        if (isset($res['data']) && is_array($res['data']) && isset($res['data']['detail'])) {
            $detail = strtolower((string) $res['data']['detail']);
        } elseif (isset($res['error'])) {
            $detail = strtolower((string) $res['error']);
        }
        if ($detail === '') {
            return false;
        }
        return (strpos($detail, 'deja livre') !== false)
            || (strpos($detail, 'déjà livré') !== false)
            || (strpos($detail, 'en retour') !== false)
            || (strpos($detail, 'ne peut plus être modifié') !== false)
            || (strpos($detail, 'ne peut plus etre modifie') !== false);
    }

    private function normalize_phone($phone) {
        $digits = preg_replace('/\D+/', '', (string) $phone);
        if ($digits === null) {
            return '';
        }
        // Strip a leading "00" international prefix (e.g. 0021625249215 -> 21625249215).
        if (strpos($digits, '00') === 0) {
            $digits = substr($digits, 2);
        }
        return $digits;
    }

    private function normalize_package_size($raw) {
        $raw = trim((string) $raw);
        if ($raw === '') {
            return 1;
        }
        if (is_numeric($raw)) {
            return max(1, intval($raw));
        }
        $s = strtoupper($raw);
        $map = [
            'S' => 1,
            'SMALL' => 1,
            'M' => 2,
            'MEDIUM' => 2,
            'L' => 4,
            'LARGE' => 4,
            'XL' => 5,
            'EXTRALARGE' => 5,
        ];
        return $map[$s] ?? 1;
    }

    private function hydrate_intigo_meta_from_request($order) {
        if (!is_object($order) || !method_exists($order, 'get_id')) {
            return;
        }
        $order_id = intval($order->get_id());
        if ($order_id <= 0) {
            return;
        }

        // Only trust posted values when nonce is present and valid.
        if (
            !isset($_POST['intigo_order_meta_nonce_field']) ||
            !wp_verify_nonce(
                sanitize_text_field(wp_unslash($_POST['intigo_order_meta_nonce_field'])),
                'intigo_order_meta_nonce'
            )
        ) {
            return;
        }

        // The zone itself is saved (and marked as chosen by hand) by the Intigo box's
        // own save handler, before this runs; re-applying the posted ids here would
        // undo a re-detection made after an address edit.
        $package_size = isset($_POST['intigo_package_size']) ? strtoupper(sanitize_text_field(wp_unslash($_POST['intigo_package_size']))) : '';

        $dirty = false;
        if (in_array($package_size, ['S', 'M', 'L', 'XL'], true)) {
            $order->update_meta_data('_intigo_package_size', $package_size);
            $dirty = true;
        }
        if ($dirty) {
            $order->save();
        }
    }

    public function maybe_sync_after_order_edit($order_id) {
        $order_id = intval($order_id);
        if ($order_id <= 0) {
            return;
        }
        $order = wc_get_order($order_id);
        if (!$order instanceof WC_Order) {
            return;
        }
        $nid = (string) $order->get_meta('_intigo_parcel_nid');
        if ($nid === '') {
            return;
        }
        // Keep sync automatic when seller edits order in WooCommerce admin.
        $sync_res = $this->update_parcel_for_order($order);
        $sync_error = $sync_res['message'] ?? __('unknown error', 'intigo-parcels');
        if (empty($sync_res['ok'])) {
            /* translators: %s: sync error message. */
            $order->add_order_note(sprintf(__('Auto sync warning: %s', 'intigo-parcels'), $sync_error));
        }
        if (class_exists('Intigo_Admin')) {
            if (!empty($sync_res['ok'])) {
                /* translators: %s: Intigo parcel NID. */
                Intigo_Admin::queue_notice(sprintf(__('Intigo parcel %s updated with the order changes.', 'intigo-parcels'), $nid), 'success');
            } else {
                /* translators: 1: Intigo parcel NID, 2: failure reason. */
                Intigo_Admin::queue_notice(sprintf(__('Intigo parcel %1$s was not updated: %2$s', 'intigo-parcels'), $nid, $sync_error), !empty($sync_res['locked']) ? 'warning' : 'error');
            }
        }
    }
}

