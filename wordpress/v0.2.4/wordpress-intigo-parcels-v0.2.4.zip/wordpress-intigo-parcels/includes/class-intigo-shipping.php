<?php

if (!defined('ABSPATH')) {
    exit;
}

class Intigo_Shipping {
    const SESSION_KEY = 'intigo_checkout_data';
    const ALLOWED_SIZES = ['S', 'M', 'L', 'XL'];

    private $api;
    /** @var Intigo_Size_Resolver|null */
    private $size_resolver;

    public function __construct($api_client, $size_resolver = null) {
        $this->api = $api_client;
        $this->size_resolver = $size_resolver;
    }

    /**
     * Whether the checkout address-confirmation modal is enabled.
     * Defaults to true to preserve behavior for stores upgrading from before
     * this toggle existed. When false: no modal, no forced validation — the
     * Intigo zone is resolved from the standard WooCommerce address at push time.
     */
    private function is_modal_enabled() {
        $settings = $this->api->get_settings();
        return ($settings['checkout_modal_enabled'] ?? 'yes') !== 'no';
    }

    /** @return Intigo_Size_Resolver */
    public function size_resolver() {
        if (!$this->size_resolver instanceof Intigo_Size_Resolver) {
            $this->size_resolver = new Intigo_Size_Resolver($this->api);
        }
        return $this->size_resolver;
    }

    public function register_hooks() {
        add_action('woocommerce_shipping_init', [$this, 'load_method']);
        add_filter('woocommerce_shipping_methods', [$this, 'register_method']);

        add_action('wp_footer', [$this, 'render_intigo_form'], 5);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_checkout_assets']);

        add_action('wp_ajax_intigo_save_meta', [$this, 'ajax_save_meta']);
        add_action('wp_ajax_nopriv_intigo_save_meta', [$this, 'ajax_save_meta']);
        add_action('wp_ajax_intigo_get_meta', [$this, 'ajax_get_meta']);
        add_action('wp_ajax_nopriv_intigo_get_meta', [$this, 'ajax_get_meta']);
        add_action('wp_ajax_intigo_pub_cities', [$this, 'ajax_cities']);
        add_action('wp_ajax_nopriv_intigo_pub_cities', [$this, 'ajax_cities']);
        add_action('wp_ajax_intigo_pub_districts', [$this, 'ajax_districts']);
        add_action('wp_ajax_nopriv_intigo_pub_districts', [$this, 'ajax_districts']);
        add_action('wp_ajax_intigo_pub_neighborhoods', [$this, 'ajax_neighborhoods']);
        add_action('wp_ajax_nopriv_intigo_pub_neighborhoods', [$this, 'ajax_neighborhoods']);

        add_action('woocommerce_checkout_create_order', [$this, 'save_order_meta'], 10, 2);
        add_action('woocommerce_after_checkout_validation', [$this, 'validate_checkout_classic'], 10, 2);
        add_action('woocommerce_store_api_checkout_update_order_from_request', [$this, 'on_blocks_checkout'], 10, 2);
        add_action('woocommerce_store_api_checkout_order_processed', [$this, 'on_blocks_order_processed'], 10, 1);
    }

    public function load_method() {
        if (class_exists('Intigo_Shipping_Method')) {
            return;
        }
        require_once INTIGO_PARCELS_DIR . 'includes/class-intigo-shipping-method.php';
    }

    public function register_method($methods) {
        $methods['intigo_delivery'] = 'Intigo_Shipping_Method';
        return $methods;
    }

    public function get_size_prices() {
        $settings = $this->api->get_settings();
        return [
            'S' => floatval($settings['size_price_s'] ?? 1),
            'M' => floatval($settings['size_price_m'] ?? 6),
            'L' => floatval($settings['size_price_l'] ?? 7),
            'XL' => floatval($settings['size_price_xl'] ?? 8),
        ];
    }

    private function get_session_data() {
        if (!function_exists('WC') || !WC()->session) {
            return [];
        }
        $data = WC()->session->get(self::SESSION_KEY, []);
        return is_array($data) ? $data : [];
    }

    private function set_session_data($data) {
        if (!function_exists('WC') || !WC()->session) {
            return;
        }
        WC()->session->set(self::SESSION_KEY, $data);
    }

    private function clear_session_data() {
        if (!function_exists('WC') || !WC()->session) {
            return;
        }
        WC()->session->set(self::SESSION_KEY, []);
    }

    public function get_session_size() {
        $data = $this->get_session_data();
        $size = strtoupper((string) ($data['size'] ?? ''));
        return in_array($size, self::ALLOWED_SIZES, true) ? $size : '';
    }

    public function render_intigo_form() {
        if (!$this->is_modal_enabled()) {
            return;
        }
        if (!function_exists('is_checkout') || !is_checkout()) {
            return;
        }
        if (function_exists('is_order_received_page') && is_order_received_page()) {
            return;
        }
        if (!function_exists('WC')) {
            return;
        }

        $customer = WC()->customer;
        $first = $customer ? (string) $customer->get_billing_first_name() : '';
        $last  = $customer ? (string) $customer->get_billing_last_name() : '';
        $phone = $customer ? (string) $customer->get_billing_phone() : '';
        $addr  = $customer ? trim((string) $customer->get_billing_address_1() . ' ' . (string) $customer->get_billing_address_2()) : '';
        $country = $customer ? (string) $customer->get_billing_country() : '';
        $name = trim($first . ' ' . $last);

        $settings = $this->api->get_settings();
        $prices = $this->get_size_prices();
        $current_size = $this->get_session_size();
        if ($current_size === '') {
            $current_size = strtoupper((string) ($settings['default_package_size'] ?? 'S'));
        }

        $sizes = [
            'S'  => __('Small', 'intigo-parcels'),
            'M'  => __('Medium', 'intigo-parcels'),
            'L'  => __('Large', 'intigo-parcels'),
            'XL' => __('Extra large', 'intigo-parcels'),
        ];

        $countries = function_exists('WC') ? WC()->countries->get_countries() : [];
        if (empty($countries)) {
            $countries = ['TN' => 'Tunisia'];
        }
        if ($country === '') {
            $country = 'TN';
        }
        ?>
        <div id="intigo-checkout" data-prefill="<?php echo esc_attr(wp_json_encode([
            'name' => $name, 'phone' => $phone, 'address' => $addr, 'country' => $country,
        ])); ?>">
            <style>
                /* Inline summary banner — top-right, out of the way of Place Order button */
                #intigo-summary { position:fixed; right:20px; top:80px; z-index:99990; background:#fff; border:2px solid #2271b1; border-radius:14px; padding:0; box-shadow:0 12px 30px rgba(15,23,42,.18); width:min(360px, calc(100vw - 32px)); display:none; overflow:hidden; }
                .admin-bar #intigo-summary { top:112px; }
                @media (max-width: 600px) { #intigo-summary { right:12px; left:12px; top:auto; bottom:12px; width:auto; } }
                #intigo-summary[data-state="filled"] { display:block; }
                #intigo-summary[data-state="empty"] { display:block; border-color:#dba617; }
                #intigo-summary .intigo-sum-head { display:flex; justify-content:space-between; align-items:center; gap:10px; padding:12px 16px; background:linear-gradient(180deg, #f0f7ff 0%, #fff 100%); }
                #intigo-summary[data-state="empty"] .intigo-sum-head { background:linear-gradient(180deg, #fffbeb 0%, #fff 100%); }
                #intigo-summary .intigo-sum-title { display:flex; align-items:center; gap:10px; font-weight:700; font-size:14px; color:#0f172a; }
                #intigo-summary .intigo-sum-mark { width:28px; height:28px; border-radius:8px; background:#2271b1; color:#fff; display:flex; align-items:center; justify-content:center; font-weight:800; font-size:13px; }
                #intigo-summary[data-state="empty"] .intigo-sum-mark { background:#dba617; }
                #intigo-summary .intigo-sum-body { padding:10px 16px 14px 16px; display:none; }
                #intigo-summary[data-state="filled"] .intigo-sum-body { display:block; }
                #intigo-summary .intigo-sum-row { display:flex; flex-wrap:wrap; gap:4px 12px; font-size:12.5px; color:#475569; line-height:1.5; }
                #intigo-summary .intigo-sum-row strong { color:#0f172a; }
                #intigo-summary .intigo-sum-cta { padding:10px 16px 12px 16px; background:#fff7e6; color:#92400e; font-size:13px; display:flex; gap:8px; align-items:center; flex-wrap:wrap; }
                #intigo-summary[data-state="filled"] .intigo-sum-cta { display:none; }

                .intigo-btn { display:inline-flex; align-items:center; gap:6px; padding:8px 14px; border-radius:8px; font-weight:600; font-size:13px; cursor:pointer; border:1px solid #2271b1; background:#2271b1; color:#fff !important; text-decoration:none; transition:background .15s ease; line-height:1; }
                .intigo-btn:hover { background:#1d63a0; color:#fff !important; }
                .intigo-btn.is-ghost { background:#fff; color:#2271b1 !important; }
                .intigo-btn.is-ghost:hover { background:#eff6ff; color:#2271b1 !important; }
                .intigo-btn.is-warn { background:#dba617; border-color:#dba617; }
                .intigo-btn.is-warn:hover { background:#b58a14; }

                /* Modal */
                #intigo-modal-backdrop { position:fixed; inset:0; background:rgba(15,23,42,.55); display:none; align-items:flex-start; justify-content:center; z-index:99999; padding:24px 16px; overflow-y:auto; animation: intigo-fade .2s ease; }
                #intigo-modal-backdrop.is-open { display:flex; }
                @keyframes intigo-fade { from { opacity:0; } to { opacity:1; } }
                @keyframes intigo-rise { from { transform: translateY(20px); opacity:0; } to { transform: translateY(0); opacity:1; } }
                #intigo-modal { background:#fff; border-radius:18px; width: min(640px, 100%); box-shadow: 0 30px 70px rgba(15,23,42,.30); animation: intigo-rise .25s cubic-bezier(.2,.9,.3,1.2); margin: 24px auto; }
                #intigo-modal .intigo-md-head { padding: 22px 24px 16px 24px; border-bottom: 1px solid #f1f5f9; }
                #intigo-modal .intigo-md-eyebrow { display:inline-block; padding:3px 10px; background:#eff6ff; color:#2271b1; border-radius:999px; font-size:11px; font-weight:700; letter-spacing:.05em; text-transform:uppercase; margin-bottom:8px; }
                #intigo-modal h2 { margin:0; font-size:20px; font-weight:700; color:#0f172a; line-height:1.3; }
                #intigo-modal .intigo-md-sub { margin:6px 0 0 0; color:#64748b; font-size:13.5px; line-height:1.5; }
                #intigo-modal .intigo-md-body { padding: 20px 24px; }
                #intigo-modal .intigo-md-foot { padding: 16px 24px; border-top:1px solid #f1f5f9; display:flex; justify-content:flex-end; gap:8px; flex-wrap:wrap; background:#fbfdff; border-radius: 0 0 18px 18px; }
                #intigo-modal .intigo-md-close { background:transparent; border:0; color:#64748b; cursor:pointer; padding:6px; border-radius:6px; line-height:0; font-size:18px; }
                #intigo-modal .intigo-md-close:hover { color:#0f172a; background:#f1f5f9; }

                .intigo-form-grid { display:grid; grid-template-columns: 1fr 1fr; gap:12px; }
                .intigo-form-grid .span-2 { grid-column: 1 / -1; }
                @media (max-width:520px) { .intigo-form-grid { grid-template-columns: 1fr; } }
                .intigo-fld { display:flex; flex-direction:column; gap:5px; }
                .intigo-fld label { font-size:12px; font-weight:600; color:#0f172a; }
                .intigo-fld .req { color:#dc2626; margin-left:2px; }
                .intigo-fld input, .intigo-fld select { width:100%; min-height:40px; padding:0 12px; border:1px solid #c7d2dc; border-radius:9px; background:#fff; color:#0f172a; font-size:13.5px; box-sizing:border-box; }
                .intigo-fld input:focus, .intigo-fld select:focus { border-color:#2271b1; box-shadow:0 0 0 3px rgba(34,113,177,.15); outline:none; }
                .intigo-fld select:disabled { background:#f1f5f9; color:#94a3b8; cursor:not-allowed; }
                .intigo-fld.is-invalid input, .intigo-fld.is-invalid select { border-color:#dc2626; box-shadow:0 0 0 3px rgba(220,38,38,.12); }

                .intigo-form-section { margin-top:18px; }
                .intigo-form-section-label { display:block; font-size:11px; font-weight:700; letter-spacing:.05em; text-transform:uppercase; color:#64748b; margin-bottom:8px; }

                .intigo-size-grid { display:grid; grid-template-columns: repeat(2, 1fr); gap:8px; }
                @media (min-width: 480px) { .intigo-size-grid { grid-template-columns: repeat(4, 1fr); } }
                .intigo-size-card { display:flex; flex-direction:column; align-items:flex-start; gap:2px; padding:10px 12px; border:1px solid #e2e8f0; background:#fff; border-radius:10px; cursor:pointer; transition: border-color .15s ease, background .15s ease, box-shadow .15s ease; position:relative; }
                .intigo-size-card input { position:absolute; opacity:0; pointer-events:none; }
                .intigo-size-card:hover { border-color:#a7b9c9; }
                .intigo-size-card:has(input:checked) { border-color:#2271b1; background:#f0f7ff; box-shadow:0 0 0 3px rgba(34,113,177,.10); }
                .intigo-size-code { font-size:11px; font-weight:700; letter-spacing:.05em; color:#64748b; }
                .intigo-size-name { font-size:13.5px; font-weight:600; color:#0f172a; }
                .intigo-size-price { font-size:12.5px; font-weight:700; color:#2271b1; margin-top:2px; }

                .intigo-md-error { display:none; padding:10px 12px; background:#fef2f2; border:1px solid #fecaca; color:#b91c1c; font-size:13px; border-radius:9px; margin-bottom:12px; }
                .intigo-md-error.is-active { display:block; }
            </style>

            <!-- Inline floating summary -->
            <div id="intigo-summary" data-state="empty">
                <div class="intigo-sum-head">
                    <div class="intigo-sum-title">
                        <span class="intigo-sum-mark">i</span>
                        <span><?php esc_html_e('Intigo Delivery', 'intigo-parcels'); ?></span>
                    </div>
                    <button type="button" class="intigo-btn is-ghost" id="intigo-edit"><?php esc_html_e('Edit details', 'intigo-parcels'); ?></button>
                </div>
                <div class="intigo-sum-body">
                    <div class="intigo-sum-row" id="intigo-sum-content"></div>
                </div>
                <div class="intigo-sum-cta">
                    <span style="font-size:18px; line-height:0;">⚠</span>
                    <span><?php esc_html_e('Please complete your delivery details before placing the order.', 'intigo-parcels'); ?></span>
                    <button type="button" class="intigo-btn is-warn" id="intigo-open" style="margin-left:auto;"><?php esc_html_e('Complete delivery info', 'intigo-parcels'); ?></button>
                </div>
            </div>

            <!-- Modal -->
            <div id="intigo-modal-backdrop" role="dialog" aria-modal="true" aria-labelledby="intigo-md-title">
                <div id="intigo-modal">
                    <div class="intigo-md-head">
                        <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:12px;">
                            <div>
                                <span class="intigo-md-eyebrow"><?php esc_html_e('Intigo Delivery', 'intigo-parcels'); ?></span>
                                <h2 id="intigo-md-title"><?php esc_html_e('Confirm your delivery details', 'intigo-parcels'); ?></h2>
                                <p class="intigo-md-sub"><?php esc_html_e('Pick your Intigo zone and your package size — we pre-filled the rest from your billing.', 'intigo-parcels'); ?></p>
                            </div>
                            <button type="button" class="intigo-md-close" id="intigo-md-close" aria-label="<?php esc_attr_e('Close', 'intigo-parcels'); ?>">✕</button>
                        </div>
                    </div>
                    <div class="intigo-md-body">
                        <div class="intigo-md-error" id="intigo-md-error"></div>
                        <div class="intigo-form-grid">
                            <div class="intigo-fld span-2" data-key="name">
                                <label for="md_recipient_name"><?php esc_html_e('Recipient name', 'intigo-parcels'); ?><span class="req">*</span></label>
                                <input id="md_recipient_name" type="text" autocomplete="name">
                            </div>
                            <div class="intigo-fld" data-key="phone">
                                <label for="md_phone"><?php esc_html_e('Phone number', 'intigo-parcels'); ?><span class="req">*</span></label>
                                <input id="md_phone" type="tel" autocomplete="tel" placeholder="+216 …">
                            </div>
                            <div class="intigo-fld" data-key="country">
                                <label for="md_country"><?php esc_html_e('Country', 'intigo-parcels'); ?></label>
                                <select id="md_country">
                                    <?php foreach ($countries as $code => $label): ?>
                                        <option value="<?php echo esc_attr($code); ?>"><?php echo esc_html($label); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="intigo-fld span-2" data-key="address">
                                <label for="md_address"><?php esc_html_e('Street address', 'intigo-parcels'); ?><span class="req">*</span></label>
                                <input id="md_address" type="text" autocomplete="street-address">
                            </div>
                            <div class="intigo-fld" data-key="city">
                                <label for="md_city"><?php esc_html_e('Intigo city', 'intigo-parcels'); ?><span class="req">*</span></label>
                                <select id="md_city"><option value=""><?php esc_html_e('Loading…', 'intigo-parcels'); ?></option></select>
                            </div>
                            <div class="intigo-fld" data-key="district">
                                <label for="md_district"><?php esc_html_e('Intigo district', 'intigo-parcels'); ?><span class="req">*</span></label>
                                <select id="md_district" disabled><option value=""><?php esc_html_e('Pick a city first', 'intigo-parcels'); ?></option></select>
                            </div>
                            <div class="intigo-fld span-2" data-key="neighborhood">
                                <label for="md_neighborhood"><?php esc_html_e('Intigo neighborhood (optional)', 'intigo-parcels'); ?></label>
                                <select id="md_neighborhood" disabled><option value=""><?php esc_html_e('Pick a district first', 'intigo-parcels'); ?></option></select>
                            </div>
                        </div>

                    </div>
                    <div class="intigo-md-foot">
                        <button type="button" class="intigo-btn is-ghost" id="intigo-md-cancel"><?php esc_html_e('Cancel', 'intigo-parcels'); ?></button>
                        <button type="button" class="intigo-btn" id="intigo-md-save"><?php esc_html_e('Save delivery info', 'intigo-parcels'); ?></button>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    public function enqueue_checkout_assets() {
        if (!$this->is_modal_enabled()) {
            return;
        }
        if (!function_exists('is_checkout') || !is_checkout()) {
            return;
        }
        $handle = 'intigo-checkout-shipping';
        wp_register_script($handle, '', ['jquery'], INTIGO_PARCELS_VERSION, true);
        wp_enqueue_script($handle);
        $config = [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('intigo_checkout_nonce'),
        ];
        wp_add_inline_script($handle, 'window.IntigoCheckout = ' . wp_json_encode($config) . ';', 'before');
        wp_add_inline_script($handle, $this->build_inline_js(), 'after');
    }

    private function build_inline_js() {
        return <<<'JS'
(function($){
    if (!window.IntigoCheckout) return;
    var ajax = IntigoCheckout.ajax_url;
    var nonce = IntigoCheckout.nonce;

    var ready = function(cb){
        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', cb);
        } else {
            cb();
        }
    };

    ready(function(){
        var $root = $('#intigo-checkout');
        if (!$root.length) return;

        var prefill = {};
        try { prefill = JSON.parse($root.attr('data-prefill') || '{}'); } catch(e) {}

        // ---- AJAX helpers ----
        var get  = function(a, d){ return $.get(ajax, $.extend({ action: a, nonce: nonce }, d || {})); };
        var post = function(a, d){ return $.post(ajax, $.extend({ action: a, nonce: nonce }, d || {})); };

        var fillSelect = function($sel, items, placeholder, selectedId){
            $sel.empty();
            $sel.append($('<option/>').val('').text(placeholder));
            if (items && items.length) {
                items.forEach(function(it){
                    $sel.append($('<option/>').val(it.id).text(it.name));
                });
            }
            if (selectedId) $sel.val(String(selectedId));
        };

        var citiesCache = null;
        var loadCities = function(selectedId, cb){
            var $sel = $('#md_city');
            $sel.prop('disabled', true);
            fillSelect($sel, [], 'Loading cities…', '');
            var done = function(items){
                citiesCache = items;
                fillSelect($sel, items, 'Select a city', selectedId);
                $sel.prop('disabled', false);
                if (cb) cb();
            };
            if (citiesCache) { done(citiesCache); return; }
            get('intigo_pub_cities').done(function(res){
                done(res && res.success ? (res.data || []) : []);
            }).fail(function(){ done([]); });
        };
        var loadDistricts = function(cityId, selectedId, cb){
            var $sel = $('#md_district');
            if (!cityId) { $sel.prop('disabled', true); fillSelect($sel, [], 'Pick a city first', ''); if (cb) cb(); return; }
            $sel.prop('disabled', true);
            fillSelect($sel, [], 'Loading…', '');
            get('intigo_pub_districts', { city_id: cityId }).done(function(res){
                var items = res && res.success ? (res.data || []) : [];
                fillSelect($sel, items, 'Select a district', selectedId);
                $sel.prop('disabled', !items.length);
                if (cb) cb();
            }).fail(function(){ fillSelect($sel, [], 'Could not load', ''); if (cb) cb(); });
        };
        var loadNeighborhoods = function(districtId, selectedId, cb){
            var $sel = $('#md_neighborhood');
            if (!districtId) { $sel.prop('disabled', true); fillSelect($sel, [], 'Pick a district first', ''); if (cb) cb(); return; }
            $sel.prop('disabled', true);
            fillSelect($sel, [], 'Loading…', '');
            get('intigo_pub_neighborhoods', { district_id: districtId }).done(function(res){
                var items = res && res.success ? (res.data || []) : [];
                fillSelect($sel, items, items.length ? 'Optional' : 'No neighborhoods', selectedId);
                $sel.prop('disabled', !items.length);
                if (cb) cb();
            }).fail(function(){ fillSelect($sel, [], 'Could not load', ''); if (cb) cb(); });
        };

        // ---- Local state mirroring server session ----
        var state = { name:'', phone:'', address:'', country:'', city_id:0, district_id:0, neighborhood_id:0, city_name:'', district_name:'', neighborhood_name:'' };
        var loadState = function(cb){
            get('intigo_get_meta').done(function(res){
                if (res && res.success && res.data) {
                    state = $.extend(state, res.data);
                }
                if (cb) cb();
            }).fail(function(){ if (cb) cb(); });
        };
        var isFilled = function(s){
            return s.name && s.phone && s.address && s.city_id > 0 && s.district_id > 0;
        };

        // ---- Inline summary ----
        var escapeHtml = function(v){ return String(v == null ? '' : v).replace(/[&<>"']/g, function(c){ return ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]); }); };
        var renderSummary = function(){
            var $wrap = $('#intigo-summary');
            if (!isFilled(state)) {
                $wrap.attr('data-state', 'empty');
                return;
            }
            $wrap.attr('data-state', 'filled');
            var locParts = [];
            if (state.city_name) locParts.push(state.city_name);
            if (state.district_name) locParts.push(state.district_name);
            if (state.neighborhood_name) locParts.push(state.neighborhood_name);
            var html = '';
            html += '<span><strong>' + escapeHtml(state.name) + '</strong> · ' + escapeHtml(state.phone) + '</span>';
            if (state.address) html += '<span>' + escapeHtml(state.address) + '</span>';
            if (locParts.length) html += '<span>' + escapeHtml(locParts.join(' · ')) + '</span>';
            $('#intigo-sum-content').html(html);
        };

        // ---- Modal open/close ----
        var $backdrop = $('#intigo-modal-backdrop');
        var clearError = function(){ $('#intigo-md-error').removeClass('is-active').text(''); };
        var showError = function(msg){ $('#intigo-md-error').addClass('is-active').text(msg); };

        var openModal = function(){
            $('#md_recipient_name').val(state.name || prefill.name || '');
            $('#md_phone').val(state.phone || prefill.phone || '');
            $('#md_address').val(state.address || prefill.address || '');
            $('#md_country').val(state.country || prefill.country || 'TN');
            clearError();
            $('#intigo-modal .intigo-fld').removeClass('is-invalid');

            $backdrop.addClass('is-open');
            document.body.style.overflow = 'hidden';

            loadCities(state.city_id, function(){
                if (state.city_id) {
                    loadDistricts(state.city_id, state.district_id, function(){
                        if (state.district_id) loadNeighborhoods(state.district_id, state.neighborhood_id);
                    });
                }
            });
        };
        var closeModal = function(){
            $backdrop.removeClass('is-open');
            document.body.style.overflow = '';
        };

        var refreshCart = function(){
            // Classic checkout
            $(document.body).trigger('update_checkout');
            // Blocks checkout: re-select the same Intigo rate to force server-side recompute
            try {
                if (!(window.wp && wp.data)) return;
                var dispatch = wp.data.dispatch('wc/store/cart');
                var select = wp.data.select('wc/store/cart');
                if (!dispatch || !select) return;
                var cart = typeof select.getCartData === 'function' ? select.getCartData() : null;
                var didReselect = false;
                if (cart && cart.shippingRates && cart.shippingRates.length) {
                    cart.shippingRates.forEach(function(pkg){
                        var selected = (pkg.shipping_rates || []).filter(function(r){ return r.selected; })[0];
                        if (selected && (selected.method_id === 'intigo_delivery' || (selected.rate_id || '').indexOf('intigo_delivery') === 0)) {
                            if (typeof dispatch.selectShippingRate === 'function') {
                                dispatch.selectShippingRate(selected.rate_id, pkg.package_id);
                                didReselect = true;
                            }
                        }
                    });
                }
                if (!didReselect) {
                    if (typeof dispatch.invalidateResolutionForStore === 'function') dispatch.invalidateResolutionForStore();
                    if (typeof dispatch.invalidateResolutionForStoreSelector === 'function') dispatch.invalidateResolutionForStoreSelector('getCartData');
                }
            } catch (e) {}
        };

        // ---- Save modal ----
        var saveModal = function(){
            clearError();
            $('#intigo-modal .intigo-fld').removeClass('is-invalid');
            var name = ($('#md_recipient_name').val() || '').trim();
            var phone = ($('#md_phone').val() || '').trim();
            var address = ($('#md_address').val() || '').trim();
            var country = ($('#md_country').val() || '').trim();
            var cityId = parseInt($('#md_city').val(), 10) || 0;
            var districtId = parseInt($('#md_district').val(), 10) || 0;
            var neighId = parseInt($('#md_neighborhood').val(), 10) || 0;

            var problems = [];
            if (!name)          { $('#intigo-modal .intigo-fld[data-key="name"]').addClass('is-invalid'); problems.push('Recipient name'); }
            if (!phone)         { $('#intigo-modal .intigo-fld[data-key="phone"]').addClass('is-invalid'); problems.push('Phone'); }
            if (!address)       { $('#intigo-modal .intigo-fld[data-key="address"]').addClass('is-invalid'); problems.push('Address'); }
            if (cityId <= 0)    { $('#intigo-modal .intigo-fld[data-key="city"]').addClass('is-invalid'); problems.push('City'); }
            if (districtId <= 0){ $('#intigo-modal .intigo-fld[data-key="district"]').addClass('is-invalid'); problems.push('District'); }
            if (problems.length) { showError('Please fill in: ' + problems.join(', ') + '.'); return; }

            var cityName = $('#md_city option:selected').text();
            var districtName = $('#md_district option:selected').text();
            var neighName = $('#md_neighborhood option:selected').text();

            var payload = {
                name: name,
                phone: phone,
                address: address,
                country: country,
                city_id: cityId,
                district_id: districtId,
                neighborhood_id: neighId,
                city_name: cityName || '',
                district_name: districtName || '',
                neighborhood_name: neighId > 0 ? (neighName || '') : ''
            };

            post('intigo_save_meta', payload).done(function(res){
                if (res && res.success) {
                    state = $.extend(state, payload);
                    renderSummary();
                    refreshCart();
                    closeModal();
                } else {
                    showError((res && res.data && res.data.message) || 'Could not save. Please try again.');
                }
            }).fail(function(){
                showError('Could not save. Please check your connection.');
            });
        };

        // ---- Cascading dropdowns inside modal ----
        $(document.body).on('change', '#md_city', function(){
            var v = $(this).val();
            loadDistricts(v, '', function(){ loadNeighborhoods('', ''); });
        });
        $(document.body).on('change', '#md_district', function(){
            loadNeighborhoods($(this).val(), '');
        });

        // ---- Buttons ----
        $(document.body).on('click', '#intigo-edit, #intigo-open', function(e){ e.preventDefault(); openModal(); });
        $(document.body).on('click', '#intigo-md-close, #intigo-md-cancel', function(e){ e.preventDefault(); closeModal(); });
        $(document.body).on('click', '#intigo-md-save', function(e){ e.preventDefault(); saveModal(); });
        $(document.body).on('click', '#intigo-modal-backdrop', function(e){ if (e.target === this) closeModal(); });
        $(document).on('keydown', function(e){ if (e.key === 'Escape' && $backdrop.hasClass('is-open')) closeModal(); });

        // ---- Detect Intigo selection: classic + blocks ----
        var lastWasIntigo = false;
        var detectIntigo = function(){
            // Classic checkout radios
            var $checked = $('input[name^="shipping_method"]:checked');
            if ($checked.length) {
                return ($checked.val() || '').toString().indexOf('intigo_delivery') === 0;
            }
            // Blocks checkout via wp.data
            try {
                if (window.wp && wp.data && wp.data.select) {
                    var cartStore = wp.data.select('wc/store/cart');
                    if (cartStore && typeof cartStore.getCartData === 'function') {
                        var cart = cartStore.getCartData();
                        var pkgs = (cart && cart.shippingRates) || [];
                        for (var i = 0; i < pkgs.length; i++) {
                            var rates = (pkgs[i] && pkgs[i].shipping_rates) || [];
                            for (var j = 0; j < rates.length; j++) {
                                if (rates[j].selected && (rates[j].method_id === 'intigo_delivery' || (rates[j].rate_id || '').indexOf('intigo_delivery') === 0)) {
                                    return true;
                                }
                            }
                        }
                    }
                }
            } catch (e) {}
            return false;
        };

        var refreshVisibility = function(){
            var isIntigo = detectIntigo();
            $('#intigo-summary').toggle(isIntigo);
            if (isIntigo && !lastWasIntigo) {
                renderSummary();
                if (!isFilled(state)) {
                    setTimeout(openModal, 250);
                }
            }
            if (!isIntigo && $backdrop.hasClass('is-open')) {
                closeModal();
            }
            lastWasIntigo = isIntigo;
        };

        // Classic checkout listeners
        $(document.body).on('change', 'input[name^="shipping_method"]', refreshVisibility);
        $(document.body).on('updated_checkout', function(){
            refreshVisibility();
            renderSummary();
        });

        // Blocks checkout listener via wp.data subscribe
        var subscribed = false;
        var subscribeToBlocks = function(){
            if (subscribed) return;
            try {
                if (window.wp && wp.data && wp.data.subscribe) {
                    wp.data.subscribe(function(){
                        refreshVisibility();
                    });
                    subscribed = true;
                }
            } catch (e) {}
        };
        subscribeToBlocks();
        // Try again later in case wp.data loads after our script
        setTimeout(subscribeToBlocks, 500);
        setTimeout(subscribeToBlocks, 2000);

        // Initial load
        loadState(function(){
            renderSummary();
            refreshVisibility();
        });
    });
})(jQuery);
JS;
    }

    public function ajax_save_meta() {
        check_ajax_referer('intigo_checkout_nonce', 'nonce');

        $city_id = isset($_POST['city_id']) ? intval($_POST['city_id']) : 0;
        $district_id = isset($_POST['district_id']) ? intval($_POST['district_id']) : 0;
        if ($city_id <= 0 || $district_id <= 0) {
            wp_send_json_error(['message' => 'City and district are required.'], 400);
        }

        $data = [
            'name'              => isset($_POST['name'])              ? sanitize_text_field(wp_unslash($_POST['name'])) : '',
            'phone'             => isset($_POST['phone'])             ? sanitize_text_field(wp_unslash($_POST['phone'])) : '',
            'address'           => isset($_POST['address'])           ? sanitize_text_field(wp_unslash($_POST['address'])) : '',
            'country'           => isset($_POST['country'])           ? sanitize_text_field(wp_unslash($_POST['country'])) : '',
            'city_id'           => $city_id,
            'district_id'       => $district_id,
            'neighborhood_id'   => isset($_POST['neighborhood_id'])   ? intval($_POST['neighborhood_id']) : 0,
            'city_name'         => isset($_POST['city_name'])         ? sanitize_text_field(wp_unslash($_POST['city_name'])) : '',
            'district_name'     => isset($_POST['district_name'])     ? sanitize_text_field(wp_unslash($_POST['district_name'])) : '',
            'neighborhood_name' => isset($_POST['neighborhood_name']) ? sanitize_text_field(wp_unslash($_POST['neighborhood_name'])) : '',
        ];

        $this->set_session_data($data);
        wp_send_json_success(['data' => $data]);
    }

    public function ajax_get_meta() {
        check_ajax_referer('intigo_checkout_nonce', 'nonce');
        wp_send_json_success($this->get_session_data());
    }

    public function ajax_cities() {
        check_ajax_referer('intigo_checkout_nonce', 'nonce');
        $q = isset($_GET['q']) ? sanitize_text_field(wp_unslash($_GET['q'])) : '';
        $res = $this->api->fetch_cities($q);
        if (empty($res['ok'])) {
            wp_send_json_error(['message' => $res['error'] ?? 'lookup failed'], 502);
        }
        wp_send_json_success($res['items']);
    }

    public function ajax_districts() {
        check_ajax_referer('intigo_checkout_nonce', 'nonce');
        $city_id = isset($_GET['city_id']) ? intval($_GET['city_id']) : 0;
        $q = isset($_GET['q']) ? sanitize_text_field(wp_unslash($_GET['q'])) : '';
        $res = $this->api->fetch_districts($city_id, $q);
        if (empty($res['ok'])) {
            wp_send_json_error(['message' => $res['error'] ?? 'lookup failed'], 502);
        }
        wp_send_json_success($res['items']);
    }

    public function ajax_neighborhoods() {
        check_ajax_referer('intigo_checkout_nonce', 'nonce');
        $district_id = isset($_GET['district_id']) ? intval($_GET['district_id']) : 0;
        $res = $this->api->fetch_neighborhoods($district_id);
        if (empty($res['ok'])) {
            wp_send_json_error(['message' => $res['error'] ?? 'lookup failed'], 502);
        }
        wp_send_json_success($res['items']);
    }

    public function validate_checkout_classic($data, $errors) {
        if (!$this->is_modal_enabled()) {
            return;
        }
        if (!$this->is_intigo_chosen()) {
            return;
        }
        $session = $this->get_session_data();
        if (!$this->is_session_complete($session)) {
            $errors->add(
                'intigo_incomplete',
                __('Please complete your Intigo Delivery details (recipient, phone, address, city and district) before placing the order.', 'intigo-parcels')
            );
        }
    }

    public function on_blocks_checkout($order, $request) {
        if (!$this->is_modal_enabled()) {
            return;
        }
        if (!$this->order_has_intigo_shipping($order) && !$this->is_intigo_chosen()) {
            return;
        }
        $session = $this->get_session_data();
        if (!$this->is_session_complete($session)) {
            throw new \Exception(
                __('Please complete your Intigo Delivery details (recipient, phone, address, city and district) before placing the order.', 'intigo-parcels')
            );
        }
        // Validation passed — write meta to the order now so it lands in HPOS storage.
        $this->write_session_to_order($order, $session);
    }

    private function order_has_intigo_shipping($order) {
        if (!is_object($order) || !method_exists($order, 'get_items')) {
            return false;
        }
        foreach ($order->get_items('shipping') as $item) {
            if (!is_object($item) || !method_exists($item, 'get_method_id')) {
                continue;
            }
            if ($item->get_method_id() === 'intigo_delivery') {
                return true;
            }
        }
        return false;
    }

    private function order_chosen_size($order) {
        if (!is_object($order) || !method_exists($order, 'get_items')) {
            return '';
        }
        foreach ($order->get_items('shipping') as $item) {
            if (!is_object($item) || !method_exists($item, 'get_method_id')) {
                continue;
            }
            if ($item->get_method_id() !== 'intigo_delivery') {
                continue;
            }
            $size_meta = method_exists($item, 'get_meta') ? (string) $item->get_meta('intigo_package_size') : '';
            $candidate = strtoupper($size_meta);
            if (in_array($candidate, self::ALLOWED_SIZES, true)) {
                return $candidate;
            }
            if (method_exists($item, 'get_method_title')) {
                $title = strtoupper((string) $item->get_method_title());
                foreach (self::ALLOWED_SIZES as $code) {
                    if (strpos($title, '(' . $code . ')') !== false) {
                        return $code;
                    }
                }
            }
        }
        return '';
    }

    public function on_blocks_order_processed($order) {
        if (!is_object($order)) {
            return;
        }
        $this->clear_session_data();
        // Auto-create now happens reliably via Intigo_Order_Service hooks
        // (woocommerce_order_status_processing / completed, payment_complete, thankyou),
        // each idempotent on _intigo_parcel_nid + _intigo_idem_*. We still poke the
        // service here as a same-request fallback for shippable Blocks orders.
        if (!class_exists('Intigo_Order_Service')) {
            return;
        }
        $service = new Intigo_Order_Service($this->api);
        $service->maybe_auto_create_from_order_event($order->get_id());
    }

    private function write_session_to_order($order, $session) {
        if (!is_object($order) || empty($session)) {
            return;
        }
        if (!empty($session['name']))              { $order->update_meta_data('_intigo_recipient_name', $session['name']); }
        if (!empty($session['phone']))             { $order->update_meta_data('_intigo_phone', $session['phone']); }
        if (!empty($session['address']))           { $order->update_meta_data('_intigo_address', $session['address']); }
        if (!empty($session['country']))           { $order->update_meta_data('_intigo_country', $session['country']); }
        if (!empty($session['city_id']))           { $order->update_meta_data('_intigo_city_id', intval($session['city_id'])); }
        if (!empty($session['district_id']))       { $order->update_meta_data('_intigo_district_id', intval($session['district_id'])); }
        if (!empty($session['neighborhood_id']))   { $order->update_meta_data('_intigo_neighborhood_id', intval($session['neighborhood_id'])); }
        if (!empty($session['city_name']))         { $order->update_meta_data('_intigo_city_name', $session['city_name']); }
        if (!empty($session['district_name']))     { $order->update_meta_data('_intigo_district_name', $session['district_name']); }
        if (!empty($session['neighborhood_name'])) { $order->update_meta_data('_intigo_neighborhood_name', $session['neighborhood_name']); }
        $size = $this->order_chosen_size($order);
        if ($size === '') {
            $size = $this->get_chosen_size();
        }
        if ($size !== '') {
            $order->update_meta_data('_intigo_package_size', $size);
        }
        $order->save();
    }

    public function save_order_meta($order, $data) {
        if (!is_object($order) || !$this->is_intigo_chosen()) {
            return;
        }
        $session = $this->get_session_data();
        if (empty($session)) {
            return;
        }
        $this->write_session_to_order($order, $session);
        $this->clear_session_data();
    }

    private function get_chosen_size() {
        if (!function_exists('WC') || !WC()->session) {
            return '';
        }
        $chosen = WC()->session->get('chosen_shipping_methods');
        if (!is_array($chosen)) {
            return '';
        }
        foreach ($chosen as $method) {
            if (strpos((string) $method, 'intigo_delivery') !== 0) {
                continue;
            }
            $parts = explode(':', (string) $method);
            $candidate = strtoupper((string) end($parts));
            if (in_array($candidate, self::ALLOWED_SIZES, true)) {
                return $candidate;
            }
        }
        return '';
    }

    private function is_session_complete($s) {
        if (!is_array($s) || empty($s)) {
            return false;
        }
        if (empty($s['name']) || empty($s['phone']) || empty($s['address'])) {
            return false;
        }
        if (intval($s['city_id'] ?? 0) <= 0 || intval($s['district_id'] ?? 0) <= 0) {
            return false;
        }
        return true;
    }

    private function is_intigo_chosen() {
        if (!function_exists('WC') || !WC()->session) {
            return false;
        }
        $chosen = WC()->session->get('chosen_shipping_methods');
        if (!is_array($chosen)) {
            return false;
        }
        foreach ($chosen as $method) {
            if (strpos((string) $method, 'intigo_delivery') === 0) {
                return true;
            }
        }
        return false;
    }
}
