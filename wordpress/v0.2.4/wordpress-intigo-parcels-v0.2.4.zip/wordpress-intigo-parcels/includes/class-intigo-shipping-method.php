<?php

if (!defined('ABSPATH')) {
    exit;
}

if (!class_exists('WC_Shipping_Method')) {
    return;
}

class Intigo_Shipping_Method extends WC_Shipping_Method {
    public function __construct($instance_id = 0) {
        $this->id = 'intigo_delivery';
        $this->instance_id = absint($instance_id);
        $this->method_title = __('Intigo Delivery', 'intigo-parcels');
        $this->method_description = __('Door-to-door delivery via Intigo. The package size is assigned per product in the product editor; the customer sees a single shipping price at the matching rate.', 'intigo-parcels');
        $this->supports = [
            'shipping-zones',
            'instance-settings',
            'instance-settings-modal',
        ];
        $this->init();
    }

    public function init() {
        $this->init_form_fields();
        $this->init_settings();
        $this->title = $this->get_option('title', __('Intigo Delivery', 'intigo-parcels'));
        $this->enabled = $this->get_option('enabled', 'yes');
        add_action('woocommerce_update_options_shipping_' . $this->id, [$this, 'process_admin_options']);
    }

    public function init_form_fields() {
        $this->instance_form_fields = [
            'enabled' => [
                'title' => __('Enable', 'intigo-parcels'),
                'type' => 'checkbox',
                'label' => __('Enable this shipping method for this zone', 'intigo-parcels'),
                'default' => 'yes',
            ],
            'title' => [
                'title' => __('Method title', 'intigo-parcels'),
                'type' => 'text',
                'description' => __('Label customers see at checkout.', 'intigo-parcels'),
                'default' => __('Intigo Delivery', 'intigo-parcels'),
                'desc_tip' => true,
            ],
        ];
    }

    public function calculate_shipping($package = []) {
        if (!class_exists('Intigo_API_Client') || !class_exists('Intigo_Size_Resolver')) {
            return;
        }
        $api = new Intigo_API_Client();
        $settings = $api->get_settings();

        $sizes = [
            'S'  => floatval($settings['size_price_s']  ?? 1),
            'M'  => floatval($settings['size_price_m']  ?? 6),
            'L'  => floatval($settings['size_price_l']  ?? 7),
            'XL' => floatval($settings['size_price_xl'] ?? 8),
        ];

        // Intigo's S/M/L/XL grid is fixed by Intigo; the seller assigns each
        // product to a bucket on the product edit screen. The customer never
        // picks a size at checkout — we resolve it from the cart and emit a
        // single shipping rate at the matching price.
        $resolver = new Intigo_Size_Resolver($api);
        $resolved = $resolver->resolve_for_cart_package($package);
        $price    = isset($sizes[$resolved]) ? $sizes[$resolved] : $sizes['S'];

        $this->add_rate([
            'id'       => $this->get_rate_id($resolved),
            'label'    => $this->title,
            'cost'     => $price,
            'package'  => $package,
            'meta_data' => [
                'intigo_package_size' => $resolved,
            ],
        ]);
    }
}
