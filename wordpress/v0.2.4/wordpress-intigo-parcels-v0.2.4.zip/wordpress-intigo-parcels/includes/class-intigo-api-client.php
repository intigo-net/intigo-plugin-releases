<?php

if (!defined('ABSPATH')) {
    exit;
}

class Intigo_API_Client {
    const OPTION_KEY = 'intigo_parcels_settings';
    const SANDBOX_BASE_URL = 'https://dev-api.intigo.net/api';
    const PRODUCTION_BASE_URL = 'https://api.intigo.net/api';
    const LOCATION_QUERY_BASE_URL = 'https://intishop.dannous.shop/parcels/api/public/locations/?q=';

    public function get_settings() {
        $defaults = [
            // Environment switch
            'environment_mode' => 'sandbox',
            'api_key' => '',
            'fallback_enabled' => 'yes',
            'auto_create_on_paid' => 'no',
            // Whether the checkout address-confirmation modal is shown to customers.
            // 'yes' (default) = customer must confirm recipient + pick Intigo
            // city/district before placing the order. 'no' = no modal, no forced
            // validation; the Intigo zone is resolved from the standard WooCommerce
            // address at push time instead.
            'checkout_modal_enabled' => 'yes',
            // Used by Intigo_Size_Resolver as the layer-3 fallback when a product
            // hasn't been assigned a size yet.
            'default_package_size' => 'S',
            // Checkout shipping pricing per package size (Tunisian dinar).
            // The customer sees ONE of these (whichever the resolver picked for
            // the cart); they never pick a size themselves.
            'size_price_s' => 1,
            'size_price_m' => 6,
            'size_price_l' => 7,
            'size_price_xl' => 8,
        ];
        $settings = wp_parse_args(get_option(self::OPTION_KEY, []), $defaults);
        $mode = ($settings['environment_mode'] ?? 'sandbox') === 'production' ? 'production' : 'sandbox';
        $active_primary = $mode === 'production' ? self::PRODUCTION_BASE_URL : self::SANDBOX_BASE_URL;
        $settings['environment_mode'] = $mode;
        $settings['primary_base_url'] = $active_primary;
        // Keep fallback pointing to active environment API unless changed internally in code.
        $settings['legacy_base_url'] = $active_primary;
        return $settings;
    }

    private function request($method, $path, $payload = null, $adapter = 'primary') {
        $settings = $this->get_settings();
        $base = $adapter === 'legacy' ? $settings['legacy_base_url'] : $settings['primary_base_url'];
        $url = rtrim($base, '/') . '/' . ltrim($path, '/');

        $args = [
            'method' => strtoupper($method),
            'timeout' => 20,
            'headers' => [
                'Content-Type' => 'application/json',
                'X-API-KEY' => $settings['api_key'],
            ],
        ];
        if ($payload !== null) {
            $args['body'] = wp_json_encode($payload);
        }

        $res = wp_remote_request($url, $args);
        if (is_wp_error($res)) {
            return ['ok' => false, 'code' => 0, 'error' => $res->get_error_message(), 'adapter' => $adapter, 'url' => $url];
        }

        $code = wp_remote_retrieve_response_code($res);
        $body = wp_remote_retrieve_body($res);
        $json = json_decode($body, true);
        $data = is_array($json) ? $json : ['raw_body' => $body];

        if ($code >= 200 && $code < 300) {
            return ['ok' => true, 'code' => $code, 'data' => $data, 'adapter' => $adapter, 'url' => $url];
        }

        return ['ok' => false, 'code' => $code, 'data' => $data, 'adapter' => $adapter, 'url' => $url];
    }

    private function with_fallback($method, $primary_path, $payload = null, $legacy_path = null) {
        $settings = $this->get_settings();
        $primary = $this->request($method, $primary_path, $payload, 'primary');
        if ($primary['ok']) {
            return $primary;
        }

        if ($settings['fallback_enabled'] !== 'yes') {
            return $primary;
        }

        if ($primary['code'] === 401 || empty($legacy_path)) {
            return $primary;
        }

        // Skip the legacy fallback when it points at the same server as primary —
        // those endpoints belong to an unrelated legacy API and just produce noisy 404s.
        $primary_base = rtrim((string) ($settings['primary_base_url'] ?? ''), '/');
        $legacy_base = rtrim((string) ($settings['legacy_base_url'] ?? ''), '/');
        if ($primary_base !== '' && $primary_base === $legacy_base) {
            return $primary;
        }

        $legacy = $this->request($method, $legacy_path, $payload, 'legacy');
        if ($legacy['ok']) {
            return $legacy;
        }
        // Both failed — surface the primary error to the user (it's the real target),
        // but attach a summary of the legacy attempt for diagnostics.
        $primary['legacy_attempt'] = [
            'code' => $legacy['code'] ?? 0,
            'error' => $legacy['error'] ?? '',
            'data' => $legacy['data'] ?? null,
            'url' => $legacy['url'] ?? '',
        ];
        return $primary;
    }

    public function create_parcel($payload) {
        return $this->with_fallback('POST', '/v3/parcels/', $payload, '/expediteurs/api/parcel/create/');
    }

    public function create_parcels_batch($payload) {
        return $this->with_fallback('POST', '/v3/parcels/batch', $payload, '/expediteurs/api/parcels/batch/');
    }

    public function generate_bordereau($nids) {
        return $this->with_fallback('POST', '/v3/parcels/bordereau', ['nids' => $nids], null);
    }

    public function status_bulk($nids) {
        return $this->with_fallback('POST', '/v3/parcels/status', ['nids' => $nids], null);
    }

    public function update_parcel($nid, $payload) {
        $nid = rawurlencode((string) $nid);
        return $this->with_fallback('PATCH', '/v3/parcels/' . $nid, $payload, null);
    }

    public function cancel_parcel($nid) {
        $nid = rawurlencode((string) $nid);
        return $this->with_fallback('POST', '/v3/parcels/' . $nid . '/cancel', [], null);
    }

    public function relance_parcel($nid, $accept_fee = false) {
        $nid = rawurlencode((string) $nid);
        return $this->with_fallback('POST', '/v3/parcels/' . $nid . '/relance', ['accept_fee' => (bool) $accept_fee], null);
    }

    public function report_delay($nid, $reason = '') {
        $nid = rawurlencode((string) $nid);
        $payload = [];
        if (trim((string) $reason) !== '') {
            $payload['reason'] = (string) $reason;
        }
        return $this->with_fallback('POST', '/v3/parcels/' . $nid . '/report-delay', $payload, null);
    }

    public function change_phone($nid, $phone) {
        $nid = rawurlencode((string) $nid);
        return $this->with_fallback('POST', '/v3/parcels/' . $nid . '/change-phone', [
            'phone' => (string) $phone,
        ], null);
    }

    public function change_price($nid, $price) {
        $nid = rawurlencode((string) $nid);
        return $this->with_fallback('POST', '/v3/parcels/' . $nid . '/change-price', [
            'price' => floatval($price),
        ], null);
    }

    public function change_address($nid, $payload) {
        $nid = rawurlencode((string) $nid);
        return $this->with_fallback('POST', '/v3/parcels/' . $nid . '/change-address', $payload, null);
    }

    public function fetch_cities($query = '') {
        $settings = $this->get_settings();
        $base = rtrim((string) ($settings['primary_base_url'] ?? ''), '/');
        if ($base === '') {
            return ['ok' => false, 'error' => 'primary_base_url is not configured', 'items' => []];
        }
        $url = $base . '/v3/regions/cities';
        $items = $this->fetch_lookup_items_array($url, $settings);
        return $this->filter_lookup_items($items, $query);
    }

    public function fetch_districts($city_id, $query = '') {
        $settings = $this->get_settings();
        $city_id = intval($city_id);
        if ($city_id <= 0) {
            return ['ok' => false, 'error' => 'city_id is required', 'items' => []];
        }
        $base = rtrim((string) ($settings['primary_base_url'] ?? ''), '/');
        if ($base === '') {
            return ['ok' => false, 'error' => 'primary_base_url is not configured', 'items' => []];
        }
        $url = $base . '/v3/regions/cities/' . rawurlencode((string) $city_id) . '/districts';
        $items = $this->fetch_lookup_items_array($url, $settings);
        return $this->filter_lookup_items($items, $query);
    }

    public function fetch_neighborhoods($district_id) {
        $settings = $this->get_settings();
        $district_id = intval($district_id);
        if ($district_id <= 0) {
            return ['ok' => false, 'error' => 'district_id is required', 'items' => []];
        }
        $base = rtrim((string) ($settings['primary_base_url'] ?? ''), '/');
        if ($base === '') {
            return ['ok' => false, 'error' => 'primary_base_url is not configured', 'items' => []];
        }
        $url = $base . '/v3/regions/districts/' . rawurlencode((string) $district_id) . '/neighborhoods';
        $items = $this->fetch_lookup_items_array($url, $settings);
        return $items;
    }

    private function fetch_lookup_items_array($url, $settings) {
        $args = [
            'timeout' => 20,
            'headers' => [
                'Content-Type' => 'application/json',
                'X-API-KEY' => isset($settings['api_key']) ? $settings['api_key'] : '',
            ],
        ];
        $res = wp_remote_get($url, $args);
        if (is_wp_error($res)) {
            return ['ok' => false, 'error' => $res->get_error_message(), 'items' => []];
        }
        $code = wp_remote_retrieve_response_code($res);
        if (in_array($code, [301, 302, 307, 308, 404], true) && substr($url, -1) !== '/') {
            $retry = wp_remote_get($url . '/', $args);
            if (!is_wp_error($retry)) {
                $retry_code = wp_remote_retrieve_response_code($retry);
                if ($retry_code >= 200 && $retry_code < 300) {
                    $res = $retry;
                    $code = $retry_code;
                }
            }
        }
        if ($code < 200 || $code >= 300) {
            return ['ok' => false, 'error' => 'http=' . $code, 'items' => []];
        }
        $body = wp_remote_retrieve_body($res);
        $json = json_decode($body, true);
        $items = $this->extract_list($json);
        return ['ok' => true, 'items' => $items];
    }

    private function extract_list($json) {
        if (!is_array($json)) {
            return [];
        }
        $candidates = $json;
        if (isset($json['data']) && is_array($json['data'])) {
            $candidates = $json['data'];
        } elseif (isset($json['results']) && is_array($json['results'])) {
            $candidates = $json['results'];
        } elseif (isset($json['cities']) && is_array($json['cities'])) {
            $candidates = $json['cities'];
        } elseif (isset($json['districts']) && is_array($json['districts'])) {
            $candidates = $json['districts'];
        } elseif (isset($json['neighborhoods']) && is_array($json['neighborhoods'])) {
            $candidates = $json['neighborhoods'];
        }
        if (!is_array($candidates)) {
            return [];
        }
        $out = [];
        foreach ($candidates as $row) {
            if (!is_array($row)) {
                continue;
            }
            if (isset($row['id']) && isset($row['name'])) {
                $out[] = ['id' => intval($row['id']), 'name' => (string) $row['name']];
            }
        }
        return $out;
    }

    private function filter_lookup_items($result, $query) {
        if (empty($result['ok'])) {
            return $result;
        }
        $query = strtolower(trim((string) $query));
        if ($query === '') {
            return $result;
        }
        $result['items'] = array_values(array_filter($result['items'], function($item) use ($query) {
            return is_array($item) && isset($item['name']) && strpos(strtolower((string) $item['name']), $query) !== false;
        }));
        return $result;
    }

    public function resolve_city_id($city_name) {
        $settings = $this->get_settings();
        $city_name = trim((string) $city_name);
        if ($city_name === '') {
            return 0;
        }

        // Default strategy: try unified location query endpoint first.
        $location_rows = $this->search_locations($city_name);
        $location_city_id = $this->extract_city_id_from_locations($location_rows);
        if ($location_city_id > 0) {
            return $location_city_id;
        }

        $template = isset($settings['city_lookup_url']) ? trim((string) $settings['city_lookup_url']) : '';
        if ($template === '') {
            // Auto-derive from primary base URL.
            $template = rtrim((string) $settings['primary_base_url'], '/') . '/v3/regions/cities';
        }
        $url = str_replace('{city}', rawurlencode($city_name), $template);
        $res = wp_remote_get($url, [
            'timeout' => 20,
            'headers' => [
                'Content-Type' => 'application/json',
                'X-API-KEY' => $settings['api_key'],
            ],
        ]);
        if (is_wp_error($res)) {
            return 0;
        }
        $code = wp_remote_retrieve_response_code($res);
        if ($code < 200 || $code >= 300) {
            return 0;
        }
        $body = wp_remote_retrieve_body($res);
        $json = json_decode($body, true);
        return $this->extract_first_id($json);
    }

    public function resolve_district_id($district_name, $city_id = 0) {
        $settings = $this->get_settings();
        $district_name = trim((string) $district_name);
        if ($district_name === '') {
            return 0;
        }

        // Default strategy: try unified location query endpoint first.
        $location_rows = $this->search_locations($district_name);
        $location_district_id = $this->extract_district_id_from_locations($location_rows, intval($city_id));
        if ($location_district_id > 0) {
            return $location_district_id;
        }

        $template = isset($settings['district_lookup_url']) ? trim((string) $settings['district_lookup_url']) : '';
        if ($template === '') {
            if (intval($city_id) <= 0) {
                return 0;
            }
            // Auto-derive from primary base URL.
            $template = rtrim((string) $settings['primary_base_url'], '/') . '/v3/regions/cities/{city_id}/districts';
        }
        $url = str_replace('{district}', rawurlencode($district_name), $template);
        $url = str_replace('{city_id}', rawurlencode((string) intval($city_id)), $url);
        $res = wp_remote_get($url, [
            'timeout' => 20,
            'headers' => [
                'Content-Type' => 'application/json',
                'X-API-KEY' => $settings['api_key'],
            ],
        ]);
        if (is_wp_error($res)) {
            return 0;
        }
        $code = wp_remote_retrieve_response_code($res);
        if ($code < 200 || $code >= 300) {
            return 0;
        }
        $body = wp_remote_retrieve_body($res);
        $json = json_decode($body, true);
        return $this->extract_first_id($json);
    }

    private function extract_first_id($json) {
        // Accept common response shapes:
        // {id:1}, {data:[{id:1}]}, [{id:1}], {results:[{id:1}]}, {cities:[{id:1}]}, {districts:[{id:1}]}
        if (is_array($json) && isset($json['id'])) {
            return intval($json['id']);
        }
        $candidates = [];
        if (is_array($json)) {
            if (isset($json['data']) && is_array($json['data'])) {
                $candidates = $json['data'];
            } elseif (isset($json['results']) && is_array($json['results'])) {
                $candidates = $json['results'];
            } elseif (isset($json['cities']) && is_array($json['cities'])) {
                $candidates = $json['cities'];
            } elseif (isset($json['districts']) && is_array($json['districts'])) {
                $candidates = $json['districts'];
            } elseif (array_keys($json) === range(0, count($json) - 1)) {
                $candidates = $json;
            }
        }
        if (!empty($candidates) && is_array($candidates[0]) && isset($candidates[0]['id'])) {
            return intval($candidates[0]['id']);
        }
        return 0;
    }

    private function search_locations($query) {
        $query = trim((string) $query);
        if ($query === '') {
            return [];
        }
        $url = self::LOCATION_QUERY_BASE_URL . rawurlencode($query);
        $res = wp_remote_get($url, [
            'timeout' => 20,
            'headers' => [
                'Content-Type' => 'application/json',
            ],
        ]);
        if (is_wp_error($res)) {
            return [];
        }
        $code = wp_remote_retrieve_response_code($res);
        if ($code < 200 || $code >= 300) {
            return [];
        }
        $body = wp_remote_retrieve_body($res);
        $json = json_decode($body, true);
        if (!is_array($json)) {
            return [];
        }
        if (isset($json['results']) && is_array($json['results'])) {
            return $json['results'];
        }
        if (isset($json['data']) && is_array($json['data'])) {
            return $json['data'];
        }
        if (array_keys($json) === range(0, count($json) - 1)) {
            return $json;
        }
        return [];
    }

    private function extract_city_id_from_locations($rows) {
        if (!is_array($rows)) {
            return 0;
        }
        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }
            if (isset($row['city_id'])) {
                return intval($row['city_id']);
            }
            if (isset($row['city']) && is_array($row['city']) && isset($row['city']['id'])) {
                return intval($row['city']['id']);
            }
            if (isset($row['city']) && !is_array($row['city']) && is_numeric($row['city'])) {
                return intval($row['city']);
            }
        }
        return 0;
    }

    private function extract_district_id_from_locations($rows, $city_id = 0) {
        if (!is_array($rows)) {
            return 0;
        }
        $city_id = intval($city_id);
        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }
            $row_city_id = 0;
            if (isset($row['city_id'])) {
                $row_city_id = intval($row['city_id']);
            } elseif (isset($row['city']) && is_array($row['city']) && isset($row['city']['id'])) {
                $row_city_id = intval($row['city']['id']);
            } elseif (isset($row['city']) && !is_array($row['city']) && is_numeric($row['city'])) {
                $row_city_id = intval($row['city']);
            }

            if ($city_id > 0 && $row_city_id > 0 && $row_city_id !== $city_id) {
                continue;
            }

            if (isset($row['district_id'])) {
                return intval($row['district_id']);
            }
            if (isset($row['district']) && is_array($row['district']) && isset($row['district']['id'])) {
                return intval($row['district']['id']);
            }
            if (isset($row['district']) && !is_array($row['district']) && is_numeric($row['district'])) {
                return intval($row['district']);
            }
        }
        return 0;
    }
}

