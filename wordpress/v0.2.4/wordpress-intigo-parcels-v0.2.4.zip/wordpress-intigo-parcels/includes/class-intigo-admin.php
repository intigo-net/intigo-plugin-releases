<?php

if (!defined('ABSPATH')) {
    exit;
}

class Intigo_Admin {
    private $order_service;
    private $api_client;
    const META_OPS_STATUS = '_intigo_ops_status';
    const OPTION_AUTH = 'intigo_parcels_auth';
    const OPTION_LOGS = 'intigo_parcels_logs';
    const MAX_LOGS = 200;
    const LOGS_PER_PAGE = 25;

    public function __construct($order_service) {
        $this->order_service = $order_service;
        $this->api_client = new Intigo_API_Client();
    }

    public function register() {
        add_action('admin_menu', [$this, 'add_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('add_meta_boxes', [$this, 'register_order_meta_box']);
        add_action('add_meta_boxes_woocommerce_page_wc-orders', [$this, 'register_order_meta_box_hpos']);
        add_action('woocommerce_admin_order_data_after_order_details', [$this, 'render_hpos_inline_fields'], 20, 1);
        add_action('save_post_shop_order', [$this, 'save_order_meta_box'], 10, 2);
        add_action('woocommerce_process_shop_order_meta', [$this, 'save_order_meta_box_from_order_id'], 10, 1);
        add_action('woocommerce_update_order', [$this, 'save_order_meta_box_from_order_id'], 10, 1);
        add_action('wp_ajax_intigo_get_cities', [$this, 'ajax_get_cities']);
        add_action('wp_ajax_intigo_get_districts', [$this, 'ajax_get_districts']);
        add_action('wp_ajax_intigo_get_neighborhoods', [$this, 'ajax_get_neighborhoods']);
        add_action('wp_ajax_intigo_search_locations', [$this, 'ajax_search_locations']);
        add_action('admin_post_intigo_download_bordereau', [$this, 'handle_download_bordereau']);
        add_action('admin_post_intigo_order_action', [$this, 'handle_intigo_order_action']);
        add_action('admin_post_intigo_login', [$this, 'handle_intigo_login']);
        add_action('admin_post_intigo_logout', [$this, 'handle_intigo_logout']);
        add_action('admin_post_intigo_add_to_zones', [$this, 'handle_add_to_zones']);
        add_shortcode('intigo_manage_orders', [$this, 'render_manage_orders_shortcode']);
    }

    public function add_menu() {
        $new_orders_count = $this->get_new_orders_count();
        $manage_orders_label = 'Manage Orders';
        if ($new_orders_count > 0) {
            $manage_orders_label .= ' <span class="awaiting-mod count-' . intval($new_orders_count) . '"><span class="pending-count">' . intval($new_orders_count) . '</span></span>';
        }
        add_menu_page(
            'Intigo Dashboard',
            'Intigo',
            'manage_woocommerce',
            'intigo-dashboard',
            [$this, 'render_dashboard'],
            'dashicons-location-alt',
            56
        );
        add_submenu_page(
            'intigo-dashboard',
            'Dashboard',
            'Dashboard',
            'manage_woocommerce',
            'intigo-dashboard',
            [$this, 'render_dashboard']
        );
        add_submenu_page(
            'intigo-dashboard',
            'Manage Orders',
            $manage_orders_label,
            'manage_woocommerce',
            'intigo-manage-orders',
            [$this, 'render_panel']
        );
        add_submenu_page(
            'intigo-dashboard',
            'Logs',
            'Logs',
            'manage_woocommerce',
            'intigo-logs',
            [$this, 'render_logs']
        );

        add_submenu_page(
            'intigo-dashboard',
            'Documentation',
            'Documentation',
            'manage_woocommerce',
            'intigo-docs',
            [$this, 'render_docs']
        );

        add_submenu_page(
            'intigo-dashboard',
            'Intigo Settings',
            'Settings',
            'manage_woocommerce',
            'intigo-parcels-settings',
            [$this, 'render_settings']
        );
    }

    public function register_settings() {
        register_setting('intigo_parcels_group', Intigo_API_Client::OPTION_KEY);
    }

    public function render_settings() {
        $settings = get_option(Intigo_API_Client::OPTION_KEY, []);
        $health = $this->check_health();
        $opt = Intigo_API_Client::OPTION_KEY;
        $env_mode = ($settings['environment_mode'] ?? 'sandbox') === 'production' ? 'production' : 'sandbox';
        $auto_mode = ($settings['auto_create_on_paid'] ?? 'no') === 'yes';
        $fallback_on = ($settings['fallback_enabled'] ?? 'yes') === 'yes';
        $modal_on = ($settings['checkout_modal_enabled'] ?? 'yes') === 'yes';
        $pkg = (string) ($settings['default_package_size'] ?? 'S');
        $api_key = (string) ($settings['api_key'] ?? '');
        $price_s = isset($settings['size_price_s']) ? (string) $settings['size_price_s'] : '1';
        $price_m = isset($settings['size_price_m']) ? (string) $settings['size_price_m'] : '6';
        $price_l = isset($settings['size_price_l']) ? (string) $settings['size_price_l'] : '7';
        $price_xl = isset($settings['size_price_xl']) ? (string) $settings['size_price_xl'] : '8';
        $currency_symbol = function_exists('get_woocommerce_currency_symbol') ? get_woocommerce_currency_symbol() : '';
        ?>
        <div class="wrap">
            <?php $this->render_responsive_styles(); ?>
            <?php $this->render_interface_nav('intigo-parcels-settings'); ?>
            <?php $this->render_snackbar(); ?>
            <?php $this->render_page_header('Settings', 'Configure how this WooCommerce store connects to and behaves with Intigo.', 'Configuration'); ?>
            <style>
                .intigo-settings { max-width: 880px; }

                .intigo-section { background:#fff; border:1px solid #e2e8f0; border-radius:14px; padding:0; margin:0 0 16px 0; box-shadow:0 1px 2px rgba(15,23,42,.04); }
                .intigo-section-head { padding:16px 20px 0 20px; }
                .intigo-section-title { margin:0; font-size:15px; font-weight:600; color:#0f172a; }
                .intigo-section-sub { margin:4px 0 0 0; color:#64748b; font-size:13px; }
                .intigo-section-body { padding:16px 20px 20px 20px; }

                .intigo-field { display:grid; grid-template-columns: 220px 1fr; gap:16px; padding:14px 0; border-top:1px solid #f1f5f9; align-items:start; }
                .intigo-field:first-child { border-top:0; padding-top:6px; }
                .intigo-field-label { font-weight:600; color:#0f172a; font-size:13px; }
                .intigo-field-hint { color:#64748b; font-size:12px; margin-top:4px; }
                .intigo-field-input input[type=text],
                .intigo-field-input input[type=password],
                .intigo-field-input select { min-width: 320px; max-width:100%; min-height:36px; border-radius:8px; border:1px solid #c7d2dc; padding:0 10px; }
                .intigo-field-input input[type=text]:focus,
                .intigo-field-input input[type=password]:focus,
                .intigo-field-input select:focus { border-color:#2271b1; box-shadow:0 0 0 3px rgba(34,113,177,.15); outline:none; }

                .intigo-segmented { display:inline-flex; padding:3px; background:#f1f5f9; border-radius:10px; gap:2px; }
                .intigo-segmented label { cursor:pointer; padding:7px 14px; border-radius:8px; font-size:13px; font-weight:600; color:#475569; transition:background .15s ease, color .15s ease; }
                .intigo-segmented input { position:absolute; opacity:0; pointer-events:none; }
                .intigo-segmented label:has(input:checked) { background:#fff; color:#0f172a; box-shadow:0 1px 2px rgba(15,23,42,.08); }

                .intigo-switch { display:inline-flex; align-items:center; gap:10px; cursor:pointer; user-select:none; }
                .intigo-switch input { position:absolute; opacity:0; pointer-events:none; }
                .intigo-switch .intigo-switch-track { width:38px; height:22px; background:#cbd5e1; border-radius:999px; position:relative; transition:background .15s ease; }
                .intigo-switch .intigo-switch-thumb { position:absolute; top:2px; left:2px; width:18px; height:18px; background:#fff; border-radius:50%; transition:transform .15s ease; box-shadow:0 1px 2px rgba(15,23,42,.2); }
                .intigo-switch:has(input:checked) .intigo-switch-track { background:#2271b1; }
                .intigo-switch:has(input:checked) .intigo-switch-thumb { transform:translateX(16px); }
                .intigo-switch-label { font-size:13px; color:#0f172a; font-weight:600; }

                .intigo-mode-cards { display:grid; grid-template-columns: 1fr 1fr; gap:10px; }
                .intigo-mode-card { display:flex; gap:12px; align-items:flex-start; padding:14px; border:1px solid #e2e8f0; border-radius:12px; background:#fff; cursor:pointer; transition:border-color .15s ease, background .15s ease, box-shadow .15s ease; }
                .intigo-mode-card:hover { border-color:#a7b9c9; }
                .intigo-mode-card:has(input:checked) { border-color:#2271b1; background:#f0f7ff; box-shadow:0 0 0 3px rgba(34,113,177,.10); }
                .intigo-mode-card input { margin-top:3px; }
                .intigo-mode-card .intigo-mode-title { display:block; font-size:14px; font-weight:600; color:#0f172a; }
                .intigo-mode-card .intigo-mode-desc { display:block; color:#475569; font-size:13px; margin-top:2px; line-height:1.45; }
                @media (max-width: 720px) { .intigo-mode-cards { grid-template-columns: 1fr; } .intigo-field { grid-template-columns: 1fr; } }

                .intigo-key-wrap { position:relative; display:inline-flex; align-items:center; gap:6px; max-width:100%; }
                .intigo-key-wrap input { padding-right:38px !important; min-width:380px; }
                .intigo-key-toggle { position:absolute; right:6px; top:50%; transform:translateY(-50%); background:transparent; border:0; padding:6px; cursor:pointer; color:#64748b; }
                .intigo-key-toggle:hover { color:#0f172a; }

                .intigo-package-grid { display:inline-grid; grid-template-columns: repeat(4, 1fr); gap:6px; }
                .intigo-package-grid label { padding:10px 16px; border:1px solid #e2e8f0; border-radius:10px; cursor:pointer; text-align:center; font-weight:700; color:#475569; min-width:54px; transition:border-color .15s ease, background .15s ease, color .15s ease; }
                .intigo-package-grid input { position:absolute; opacity:0; pointer-events:none; }
                .intigo-package-grid label:has(input:checked) { border-color:#2271b1; background:#f0f7ff; color:#0f172a; }

                .intigo-tech { background:#fff; border:1px solid #e2e8f0; border-radius:14px; padding:0; margin:0 0 16px 0; }
                .intigo-tech > summary { cursor:pointer; list-style:none; padding:14px 18px; font-weight:600; color:#0f172a; display:flex; justify-content:space-between; align-items:center; }
                .intigo-tech > summary::-webkit-details-marker { display:none; }
                .intigo-tech[open] > summary { border-bottom:1px solid #f1f5f9; }
                .intigo-tech-body { padding:14px 18px 18px 18px; color:#475569; font-size:13px; }
                .intigo-tech-body code { background:#f1f5f9; padding:2px 6px; border-radius:5px; font-size:12px; }

                .intigo-save-bar { position:sticky; bottom:0; background:linear-gradient(180deg, rgba(255,255,255,0), #fff 40%); padding:18px 0 4px 0; display:flex; gap:10px; align-items:center; }
                .intigo-save-bar .button-primary { padding:6px 22px !important; }
            </style>

            <div class="intigo-settings">
                <?php if (!$health['ok']): ?>
                    <div class="intigo-alert intigo-alert--error">
                        <span class="intigo-alert-icon"><span class="dashicons dashicons-warning"></span></span>
                        <span class="intigo-alert-body"><strong>API not reachable.</strong> <?php echo esc_html($health['message']); ?></span>
                    </div>
                <?php endif; ?>

                <form method="post" action="options.php">
                    <?php settings_fields('intigo_parcels_group'); ?>

                    <section class="intigo-section">
                        <div class="intigo-section-head">
                            <h2 class="intigo-section-title">Connection</h2>
                            <p class="intigo-section-sub">Where this plugin sends data and the credentials it uses.</p>
                        </div>
                        <div class="intigo-section-body">
                            <div class="intigo-field">
                                <div>
                                    <div class="intigo-field-label">Environment</div>
                                    <div class="intigo-field-hint">Sandbox is safe for testing. Production sends real shipments.</div>
                                </div>
                                <div class="intigo-field-input">
                                    <div class="intigo-segmented" role="radiogroup" aria-label="Environment">
                                        <label><input type="radio" name="<?php echo esc_attr($opt); ?>[environment_mode]" value="sandbox" <?php checked($env_mode, 'sandbox'); ?>> Sandbox</label>
                                        <label><input type="radio" name="<?php echo esc_attr($opt); ?>[environment_mode]" value="production" <?php checked($env_mode, 'production'); ?>> Production</label>
                                    </div>
                                </div>
                            </div>
                            <div class="intigo-field">
                                <div>
                                    <div class="intigo-field-label">API Key</div>
                                    <div class="intigo-field-hint">Used for every call. Keep this key secret.</div>
                                </div>
                                <div class="intigo-field-input">
                                    <span class="intigo-key-wrap">
                                        <input id="intigo-api-key" type="password" class="regular-text" name="<?php echo esc_attr($opt); ?>[api_key]" value="<?php echo esc_attr($api_key); ?>" autocomplete="off" placeholder="Paste your Intigo API key">
                                        <button type="button" class="intigo-key-toggle" aria-label="Show or hide API key" onclick="(function(b){var i=document.getElementById('intigo-api-key');if(!i)return;i.type=i.type==='password'?'text':'password';b.textContent=i.type==='password'?'Show':'Hide';})(this)">Show</button>
                                    </span>
                                </div>
                            </div>
                            <div class="intigo-field">
                                <div>
                                    <div class="intigo-field-label">Fallback adapter</div>
                                    <div class="intigo-field-hint">If the primary API fails, retry through the legacy bridge.</div>
                                </div>
                                <div class="intigo-field-input">
                                    <label class="intigo-switch">
                                        <input type="hidden" name="<?php echo esc_attr($opt); ?>[fallback_enabled]" value="no">
                                        <input type="checkbox" name="<?php echo esc_attr($opt); ?>[fallback_enabled]" value="yes" <?php checked($fallback_on, true); ?>>
                                        <span class="intigo-switch-track"><span class="intigo-switch-thumb"></span></span>
                                        <span class="intigo-switch-label"><?php echo $fallback_on ? 'Enabled' : 'Disabled'; ?></span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </section>

                    <section class="intigo-section">
                        <div class="intigo-section-head">
                            <h2 class="intigo-section-title">Order processing</h2>
                            <p class="intigo-section-sub">How WooCommerce orders are pushed to Intigo.</p>
                        </div>
                        <div class="intigo-section-body">
                            <div class="intigo-mode-cards">
                                <label class="intigo-mode-card">
                                    <input type="radio" name="<?php echo esc_attr($opt); ?>[auto_create_on_paid]" value="yes" <?php checked($auto_mode, true); ?>>
                                    <div>
                                        <span class="intigo-mode-title">Automatic</span>
                                        <span class="intigo-mode-desc">Push orders to Intigo automatically as soon as WooCommerce marks them as <em>Processing</em>. No action needed from your team.</span>
                                    </div>
                                </label>
                                <label class="intigo-mode-card">
                                    <input type="radio" name="<?php echo esc_attr($opt); ?>[auto_create_on_paid]" value="no" <?php checked($auto_mode, false); ?>>
                                    <div>
                                        <span class="intigo-mode-title">Manual</span>
                                        <span class="intigo-mode-desc">Review each order in <em>Manage Orders</em> and click <strong>Send to Intigo</strong> when you're ready.</span>
                                    </div>
                                </label>
                            </div>
                            <p class="intigo-field-hint" style="margin-top:10px;">You can change this at any time.</p>
                        </div>
                    </section>

                    <section class="intigo-section">
                        <div class="intigo-section-head">
                            <h2 class="intigo-section-title">Checkout experience</h2>
                            <p class="intigo-section-sub">Controls what Intigo Delivery customers see and must complete at checkout.</p>
                        </div>
                        <div class="intigo-section-body">
                            <div class="intigo-field">
                                <div>
                                    <div class="intigo-field-label">Address confirmation modal</div>
                                    <div class="intigo-field-hint">When enabled, customers who pick Intigo Delivery must confirm their recipient details and choose their Intigo city &amp; district before placing the order. Turn this off if you'd rather collect the address with the standard WooCommerce fields — the Intigo zone is then resolved automatically from that address when the parcel is pushed.</div>
                                </div>
                                <div class="intigo-field-input">
                                    <label class="intigo-switch">
                                        <input type="hidden" name="<?php echo esc_attr($opt); ?>[checkout_modal_enabled]" value="no">
                                        <input type="checkbox" name="<?php echo esc_attr($opt); ?>[checkout_modal_enabled]" value="yes" <?php checked($modal_on, true); ?>>
                                        <span class="intigo-switch-track"><span class="intigo-switch-thumb"></span></span>
                                        <span class="intigo-switch-label"><?php echo $modal_on ? 'Enabled' : 'Disabled'; ?></span>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </section>

                    <section class="intigo-section">
                        <div class="intigo-section-head">
                            <h2 class="intigo-section-title">Defaults</h2>
                            <p class="intigo-section-sub">Fallback size when a product hasn't been assigned one yet.</p>
                        </div>
                        <div class="intigo-section-body">
                            <div class="intigo-field">
                                <div>
                                    <div class="intigo-field-label">Default package size</div>
                                    <div class="intigo-field-hint">Sellers assign each product to a size in <strong>Products → edit → Intigo Delivery</strong>. This default is used only when a product hasn't been assigned, and as the seed for a brand-new cart line.</div>
                                </div>
                                <div class="intigo-field-input">
                                    <div class="intigo-package-grid" role="radiogroup" aria-label="Default package size">
                                        <?php foreach (['S','M','L','XL'] as $size): ?>
                                            <label><input type="radio" name="<?php echo esc_attr($opt); ?>[default_package_size]" value="<?php echo esc_attr($size); ?>" <?php checked($pkg, $size); ?>><?php echo esc_html($size); ?></label>
                                        <?php endforeach; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>

                    <section class="intigo-section">
                        <div class="intigo-section-head">
                            <h2 class="intigo-section-title">Shipping pricing</h2>
                            <p class="intigo-section-sub">Cost shown at checkout when a customer picks <strong>Intigo Delivery</strong>, by package size.</p>
                        </div>
                        <div class="intigo-section-body">
                            <?php
                                $zone_status = $this->get_intigo_zone_status();
                                $with = $zone_status['with'];
                                $without = $zone_status['without'];
                                $attached_count = count($with);
                                $missing_count = count($without);
                                $add_url = wp_nonce_url(admin_url('admin-post.php?action=intigo_add_to_zones'), 'intigo_add_to_zones');
                                $wc_shipping_url = admin_url('admin.php?page=wc-settings&tab=shipping');
                            ?>
                            <style>
                                .intigo-zones-card { display:flex; gap:14px; align-items:flex-start; padding:14px 16px; border-radius:12px; margin-bottom:18px; border:1px solid; flex-wrap:wrap; }
                                .intigo-zones-card.is-ok { background:var(--intigo-success-soft); border-color:#a7f3d0; }
                                .intigo-zones-card.is-warn { background:var(--intigo-warn-soft); border-color:#fde68a; }
                                .intigo-zones-card .intigo-zones-icon { flex:0 0 auto; width:36px; height:36px; border-radius:10px; display:flex; align-items:center; justify-content:center; color:#fff; }
                                .intigo-zones-card.is-ok .intigo-zones-icon { background:var(--intigo-success); }
                                .intigo-zones-card.is-warn .intigo-zones-icon { background:#dba617; }
                                .intigo-zones-body { flex:1 1 280px; min-width:0; }
                                .intigo-zones-title { font-weight:700; color:var(--intigo-text); font-size:14px; margin:0 0 4px 0; }
                                .intigo-zones-sub { color:var(--intigo-text-soft); font-size:13px; margin:0 0 8px 0; line-height:1.5; }
                                .intigo-zones-list { display:flex; flex-wrap:wrap; gap:6px; margin-top:6px; }
                                .intigo-zones-chip { display:inline-flex; align-items:center; gap:6px; padding:3px 10px; border-radius:999px; font-size:12px; font-weight:600; background:#fff; border:1px solid var(--intigo-border); color:var(--intigo-text); }
                                .intigo-zones-chip.is-on { border-color:#a7f3d0; color:#047857; }
                                .intigo-zones-chip.is-off { border-color:#fde68a; color:#92400e; }
                                .intigo-zones-actions { display:flex; gap:8px; align-items:center; flex-wrap:wrap; flex:0 0 auto; }
                            </style>
                            <?php if (!$zone_status['ok']): ?>
                                <div class="intigo-zones-card is-warn">
                                    <span class="intigo-zones-icon"><span class="dashicons dashicons-warning"></span></span>
                                    <div class="intigo-zones-body">
                                        <p class="intigo-zones-title">WooCommerce shipping not detected</p>
                                        <p class="intigo-zones-sub">WooCommerce must be active for the Intigo shipping method to register.</p>
                                    </div>
                                </div>
                            <?php elseif ($missing_count === 0): ?>
                                <div class="intigo-zones-card is-ok">
                                    <span class="intigo-zones-icon"><span class="dashicons dashicons-yes"></span></span>
                                    <div class="intigo-zones-body">
                                        <p class="intigo-zones-title">Intigo Delivery is active on every shipping zone</p>
                                        <p class="intigo-zones-sub">Customers will see this option at checkout in all <?php echo esc_html($attached_count); ?> zone(s).</p>
                                        <div class="intigo-zones-list">
                                            <?php foreach ($with as $z): ?>
                                                <span class="intigo-zones-chip is-on"><span class="dashicons dashicons-yes" style="font-size:14px; width:14px; height:14px;"></span><?php echo esc_html($z['name']); ?></span>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                    <div class="intigo-zones-actions">
                                        <a class="button" href="<?php echo esc_url($wc_shipping_url); ?>">Manage zones</a>
                                    </div>
                                </div>
                            <?php else: ?>
                                <div class="intigo-zones-card is-warn">
                                    <span class="intigo-zones-icon"><span class="dashicons dashicons-info-outline"></span></span>
                                    <div class="intigo-zones-body">
                                        <p class="intigo-zones-title">
                                            <?php if ($attached_count === 0): ?>
                                                Intigo Delivery is not attached to any shipping zone yet
                                            <?php else: ?>
                                                Intigo Delivery is missing from <?php echo esc_html($missing_count); ?> zone(s)
                                            <?php endif; ?>
                                        </p>
                                        <p class="intigo-zones-sub">WooCommerce needs the method on a zone before customers see it at checkout. Click the button to add it everywhere — or do it manually in <strong>WooCommerce &rarr; Settings &rarr; Shipping</strong>.</p>
                                        <div class="intigo-zones-list">
                                            <?php foreach ($with as $z): ?>
                                                <span class="intigo-zones-chip is-on"><span class="dashicons dashicons-yes" style="font-size:14px; width:14px; height:14px;"></span><?php echo esc_html($z['name']); ?></span>
                                            <?php endforeach; ?>
                                            <?php foreach ($without as $z): ?>
                                                <span class="intigo-zones-chip is-off"><span class="dashicons dashicons-warning" style="font-size:14px; width:14px; height:14px;"></span><?php echo esc_html($z['name']); ?></span>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                    <div class="intigo-zones-actions">
                                        <a class="button button-primary" href="<?php echo esc_url($add_url); ?>">Add to all zones</a>
                                        <a class="button" href="<?php echo esc_url($wc_shipping_url); ?>">Manage zones</a>
                                    </div>
                                </div>
                            <?php endif; ?>

                            <style>
                                .intigo-price-grid { display:grid; grid-template-columns: repeat(2, 1fr); gap:12px; max-width:640px; }
                                @media (min-width: 720px) { .intigo-price-grid { grid-template-columns: repeat(4, 1fr); } }
                                .intigo-price-card { display:flex; flex-direction:column; gap:6px; padding:14px; border:1px solid #e2e8f0; border-radius:12px; background:#fff; }
                                .intigo-price-card .intigo-price-code { display:inline-flex; align-items:center; justify-content:center; width:30px; height:30px; border-radius:8px; background:#f1f5f9; color:#0f172a; font-weight:700; font-size:13px; }
                                .intigo-price-card .intigo-price-label { font-size:12px; color:#64748b; }
                                .intigo-price-card .intigo-price-input-wrap { position:relative; }
                                .intigo-price-card input[type=number] { width:100%; min-height:38px; padding:0 14px 0 38px; border:1px solid #c7d2dc; border-radius:8px; font-size:14px; font-weight:600; color:#0f172a; background:#fbfdff; }
                                .intigo-price-card input[type=number]:focus { border-color:#2271b1; box-shadow:0 0 0 3px rgba(34,113,177,.15); outline:none; background:#fff; }
                                .intigo-price-card .intigo-price-currency { position:absolute; left:12px; top:50%; transform:translateY(-50%); color:#64748b; font-weight:600; font-size:13px; pointer-events:none; }
                            </style>
                            <div class="intigo-price-grid">
                                <?php
                                $price_rows = [
                                    ['code' => 'S',  'name' => 'Small',       'key' => 'size_price_s',  'val' => $price_s],
                                    ['code' => 'M',  'name' => 'Medium',      'key' => 'size_price_m',  'val' => $price_m],
                                    ['code' => 'L',  'name' => 'Large',       'key' => 'size_price_l',  'val' => $price_l],
                                    ['code' => 'XL', 'name' => 'Extra large', 'key' => 'size_price_xl', 'val' => $price_xl],
                                ];
                                foreach ($price_rows as $row): ?>
                                    <div class="intigo-price-card">
                                        <div style="display:flex; align-items:center; gap:10px;">
                                            <span class="intigo-price-code"><?php echo esc_html($row['code']); ?></span>
                                            <div>
                                                <div style="font-weight:600; color:#0f172a; font-size:13.5px;"><?php echo esc_html($row['name']); ?></div>
                                                <div class="intigo-price-label">Per parcel</div>
                                            </div>
                                        </div>
                                        <div class="intigo-price-input-wrap">
                                            <span class="intigo-price-currency"><?php echo esc_html($currency_symbol !== '' ? $currency_symbol : 'DT'); ?></span>
                                            <input type="number" min="0" step="0.001" name="<?php echo esc_attr($opt); ?>[<?php echo esc_attr($row['key']); ?>]" value="<?php echo esc_attr($row['val']); ?>">
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                            <p class="intigo-field-hint" style="margin-top:12px;">Prices use your store currency. Make sure WooCommerce shipping zones include <em>Intigo Delivery</em> under <strong>WooCommerce &rarr; Settings &rarr; Shipping</strong>.</p>
                        </div>
                    </section>

                    <details class="intigo-tech">
                        <summary>
                            <span>Technical details</span>
                            <span style="color:#94a3b8; font-weight:500; font-size:12px;">Endpoints &amp; reference URLs</span>
                        </summary>
                        <div class="intigo-tech-body">
                            <p style="margin-top:0;"><strong>API base URL</strong> (auto-selected from environment):</p>
                            <ul style="margin:6px 0 14px 18px;">
                                <li>Sandbox: <code>https://dev-api.intigo.net/api</code></li>
                                <li>Production: <code>https://api.intigo.net/api</code></li>
                            </ul>
                            <p><strong>Lookup endpoints</strong>:</p>
                            <ul style="margin:6px 0 0 18px;">
                                <li><code>/api/v3/regions/cities</code></li>
                                <li><code>/api/v3/regions/cities/{city_id}/districts</code></li>
                                <li><code>/api/v3/regions/districts/{district_id}/neighborhoods</code></li>
                            </ul>
                        </div>
                    </details>

                    <div class="intigo-save-bar">
                        <?php submit_button('Save changes', 'primary', 'submit', false); ?>
                        <span style="color:#64748b; font-size:13px;">Changes apply immediately to new orders.</span>
                    </div>
                </form>
            </div>
        </div>
        <?php
    }

    public function render_dashboard() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized');
        }
        if (!$this->is_intigo_logged_in()) {
            $this->render_login_interface('Please login to Intigo to manage system interactions.');
            return;
        }
        $orders = function_exists('wc_get_orders') ? wc_get_orders(['limit' => 20, 'orderby' => 'date', 'order' => 'DESC']) : [];
        $stats_orders = function_exists('wc_get_orders') ? wc_get_orders(['limit' => 200, 'orderby' => 'date', 'order' => 'DESC']) : $orders;
        $metrics = $this->compute_dashboard_metrics($stats_orders);
        $total_orders_for_chart = max(1, intval($metrics['total_orders']));
        $product_posts = function_exists('wp_count_posts') ? wp_count_posts('product') : null;
        $metrics['total_products'] = ($product_posts && isset($product_posts->publish)) ? intval($product_posts->publish) : 0;
        $logs = array_slice($this->get_logs(), 0, 8);
        ?>
        <div class="wrap">
            <?php $this->render_responsive_styles(); ?>
            <?php $this->render_interface_nav('intigo-dashboard'); ?>
            <?php $this->render_snackbar(); ?>
            <?php $this->render_page_header('Dashboard', 'Operational overview of your Intigo integration &mdash; orders, parcels and recent activity at a glance.', 'Overview'); ?>
            <div style="display:flex; flex-wrap:wrap; gap:8px; margin:0 0 16px 0;">
                <a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=intigo-manage-orders')); ?>"><span class="dashicons dashicons-cart" style="margin:3px 6px 0 -2px; font-size:16px; width:16px; height:16px;"></span>Manage orders</a>
                <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=intigo-logs')); ?>"><span class="dashicons dashicons-list-view" style="margin:3px 6px 0 -2px; font-size:16px; width:16px; height:16px;"></span>View logs</a>
                <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=intigo-parcels-settings')); ?>"><span class="dashicons dashicons-admin-generic" style="margin:3px 6px 0 -2px; font-size:16px; width:16px; height:16px;"></span>Settings</a>
            </div>
            <div class="intigo-kpis">
                <div class="intigo-kpi"><div class="intigo-kpi-label">Total orders</div><div class="intigo-kpi-value"><?php echo esc_html($metrics['total_orders']); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label">Orders in Intigo</div><div class="intigo-kpi-value"><?php echo esc_html($metrics['with_parcel']); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label">Orders not in Intigo</div><div class="intigo-kpi-value"><?php echo esc_html(max(0, intval($metrics['total_orders']) - intval($metrics['with_parcel']))); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label">Need verification</div><div class="intigo-kpi-value"><?php echo esc_html($metrics['need_confirmation']); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label">Missing data</div><div class="intigo-kpi-value"><?php echo esc_html($metrics['missing_data']); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label">Total products</div><div class="intigo-kpi-value"><?php echo esc_html($metrics['total_products']); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label">Total sales</div><div class="intigo-kpi-value"><?php echo wp_kses_post(wc_price($metrics['total_sales'])); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label">Average order</div><div class="intigo-kpi-value"><?php echo wp_kses_post(wc_price($metrics['avg_order_value'])); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label">Intigo coverage</div><div class="intigo-kpi-value"><?php echo esc_html($metrics['coverage_rate']); ?>%</div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label">Ready for shipment</div><div class="intigo-kpi-value"><?php echo esc_html($metrics['ready_for_shipment']); ?></div></div>
            </div>
            <div class="intigo-charts">
                <div class="intigo-chart-card">
                    <h3 class="intigo-chart-title">Order Progress</h3>
                    <div class="intigo-bar-row"><div class="intigo-bar-meta"><span>Orders in Intigo</span><strong><?php echo esc_html($metrics['with_parcel']); ?></strong></div><div class="intigo-bar-track"><div class="intigo-bar-fill intigo-fill-blue" style="width:<?php echo esc_attr(round(($metrics['with_parcel'] / $total_orders_for_chart) * 100, 1)); ?>%;"></div></div></div>
                    <div class="intigo-bar-row"><div class="intigo-bar-meta"><span>Ready for shipment</span><strong><?php echo esc_html($metrics['ready_for_shipment']); ?></strong></div><div class="intigo-bar-track"><div class="intigo-bar-fill intigo-fill-green" style="width:<?php echo esc_attr(round(($metrics['ready_for_shipment'] / $total_orders_for_chart) * 100, 1)); ?>%;"></div></div></div>
                    <div class="intigo-bar-row"><div class="intigo-bar-meta"><span>Bordereau generated</span><strong><?php echo esc_html($metrics['with_bordereau']); ?></strong></div><div class="intigo-bar-track"><div class="intigo-bar-fill intigo-fill-green" style="width:<?php echo esc_attr(round(($metrics['with_bordereau'] / $total_orders_for_chart) * 100, 1)); ?>%;"></div></div></div>
                </div>
                <div class="intigo-chart-card">
                    <h3 class="intigo-chart-title">Recent plugin activity</h3>
                    <?php if (empty($logs)): ?>
                        <div class="intigo-empty" style="padding:18px 0;">
                            <div class="intigo-empty-icon"><span class="dashicons dashicons-clock"></span></div>
                            <div class="intigo-empty-title">No activity yet</div>
                            <div style="font-size:12.5px;">Actions will appear here once you start using Intigo.</div>
                        </div>
                    <?php else: ?>
                        <ul style="list-style:none; margin:0; padding:0; display:flex; flex-direction:column; gap:8px;">
                            <?php foreach ($logs as $log):
                                $action = (string) ($log['action'] ?? '');
                                $is_error = stripos($action, 'fail') !== false || stripos($action, 'error') !== false;
                                $is_success = stripos($action, 'success') !== false || stripos($action, 'created') !== false;
                                $dot_color = '#94a3b8';
                                if ($is_error) { $dot_color = '#dc2626'; }
                                elseif ($is_success) { $dot_color = '#16a34a'; }
                                ?>
                                <li style="display:flex; gap:10px; align-items:flex-start; padding:8px 10px; background:#fbfdff; border:1px solid #f1f5f9; border-radius:8px;">
                                    <span style="display:inline-block; width:8px; height:8px; border-radius:50%; background:<?php echo esc_attr($dot_color); ?>; margin-top:6px; flex:0 0 auto;"></span>
                                    <div style="flex:1; min-width:0;">
                                        <div style="font-size:13px; color:#0f172a; font-weight:500;"><?php echo esc_html($action); ?></div>
                                        <div style="font-size:11.5px; color:#64748b; margin-top:2px;"><?php echo esc_html((string) ($log['time'] ?? '')); ?> &middot; <?php echo esc_html((string) ($log['actor'] ?? 'system')); ?></div>
                                    </div>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
    }

    public function render_panel() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized');
        }
        if (!$this->is_intigo_logged_in()) {
            $this->render_login_interface('Please login to Intigo to manage system interactions.');
            return;
        }
        $per_page = 10;
        $current_page = isset($_GET['paged']) ? max(1, intval($_GET['paged'])) : 1;
        $orders = [];
        $total_pages = 1;
        $total_items = 0;
        if (function_exists('wc_get_orders')) {
            $total_ids = wc_get_orders([
                'limit' => -1,
                'return' => 'ids',
            ]);
            $total_items = is_array($total_ids) ? count($total_ids) : 0;
            $total_pages = max(1, intval(ceil($total_items / $per_page)));
            $orders = wc_get_orders([
                'limit' => $per_page,
                'offset' => ($current_page - 1) * $per_page,
                'orderby' => 'date',
                'order' => 'DESC',
            ]);
            if (!is_array($orders)) {
                $orders = [];
            }
        }
        $this->mark_orders_as_seen($orders);
        $metrics_source = function_exists('wc_get_orders') ? wc_get_orders(['limit' => 200, 'orderby' => 'date', 'order' => 'DESC']) : $orders;
        $metrics = $this->compute_dashboard_metrics($metrics_source);
        $total_orders_for_chart = max(1, intval($metrics['total_orders']));
        ?>
        <div class="wrap">
            <?php $this->render_responsive_styles(); ?>
            <?php $this->render_interface_nav('intigo-manage-orders'); ?>
            <?php $this->render_snackbar(); ?>
            <?php
                $logout_url = wp_nonce_url(admin_url('admin-post.php?action=intigo_logout'), 'intigo_logout');
                $extra_pills = '<span class="intigo-pill-status intigo-pill-neutral"><span class="dashicons dashicons-admin-users" style="font-size:13px; width:13px; height:13px;"></span>'
                    . esc_html($this->get_intigo_login_label())
                    . '</span>'
                    . '<a class="button button-small" href="' . esc_url($logout_url) . '">Logout</a>';
                $this->render_page_header('Manage Orders', 'Review WooCommerce orders, complete Intigo metadata and run shipment actions.', 'Operations', $extra_pills);
            ?>
            <?php $this->render_processing_mode_banner(); ?>

            <style>
                .intigo-actions .button { margin: 0 6px 6px 0; border-radius:8px; }
                .intigo-meta-edit-link { text-decoration:none; vertical-align:middle; }
                .intigo-meta-edit-link .dashicons { font-size:16px; width:16px; height:16px; }
                .intigo-modal-backdrop { position:fixed; inset:0; background:rgba(15,23,42,.45); backdrop-filter:blur(2px); display:none; align-items:center; justify-content:center; z-index:9999; }
                .intigo-modal { width:min(620px, 94vw); background:#fff; border-radius:14px; border:1px solid var(--intigo-border); box-shadow:0 20px 50px rgba(15,23,42,.22); }
                .intigo-modal-header { padding:14px 16px; border-bottom:1px solid var(--intigo-border-soft); display:flex; justify-content:space-between; align-items:center; background:#f8fbff; border-radius:14px 14px 0 0; }
                .intigo-modal-body { padding:16px; }
                .intigo-modal-open { overflow:hidden; }
                .intigo-form-row { margin-bottom:12px; }
                .intigo-form-row label { display:block; margin-bottom:6px; font-weight:600; color:var(--intigo-text); }
                .intigo-form-row input, .intigo-form-row select { width:100%; border:1px solid #c7d2dc; border-radius:9px; min-height:38px; padding:0 10px; background:#fff; }
                .intigo-form-row input:focus, .intigo-form-row select:focus { border-color:var(--intigo-primary); box-shadow:0 0 0 3px rgba(34,113,177,.15); outline:none; }
                .intigo-location-results { border:1px solid #c7d2dc !important; border-radius:10px !important; background:#fbfdff; padding:4px; min-height:148px; }
                .intigo-location-results option { padding:7px 8px; border-radius:6px; margin:1px 0; }
                .intigo-location-results option:checked { background:#e8f2fb linear-gradient(0deg,#e8f2fb,#e8f2fb); color:#0b3c5d; }
            </style>

            <div class="intigo-kpis">
                <div class="intigo-kpi"><div class="intigo-kpi-label">Total orders</div><div class="intigo-kpi-value"><?php echo esc_html($metrics['total_orders']); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label">Orders in Intigo</div><div class="intigo-kpi-value"><?php echo esc_html($metrics['with_parcel']); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label">Need verification</div><div class="intigo-kpi-value"><?php echo esc_html($metrics['need_confirmation']); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label">Missing data</div><div class="intigo-kpi-value"><?php echo esc_html($metrics['missing_data']); ?></div></div>
            </div>
            <div class="intigo-charts">
                <div class="intigo-chart-card">
                    <h3 class="intigo-chart-title">Order Progress</h3>
                    <div class="intigo-bar-row">
                        <div class="intigo-bar-meta"><span>Orders in Intigo</span><strong><?php echo esc_html($metrics['with_parcel']); ?></strong></div>
                        <div class="intigo-bar-track"><div class="intigo-bar-fill intigo-fill-blue" style="width:<?php echo esc_attr(round(($metrics['with_parcel'] / $total_orders_for_chart) * 100, 1)); ?>%;"></div></div>
                    </div>
                    <div class="intigo-bar-row">
                        <div class="intigo-bar-meta"><span>Ready for shipment</span><strong><?php echo esc_html($metrics['ready_for_shipment']); ?></strong></div>
                        <div class="intigo-bar-track"><div class="intigo-bar-fill intigo-fill-green" style="width:<?php echo esc_attr(round(($metrics['ready_for_shipment'] / $total_orders_for_chart) * 100, 1)); ?>%;"></div></div>
                    </div>
                    <div class="intigo-bar-row">
                        <div class="intigo-bar-meta"><span>Bordereau generated</span><strong><?php echo esc_html($metrics['with_bordereau']); ?></strong></div>
                        <div class="intigo-bar-track"><div class="intigo-bar-fill intigo-fill-green" style="width:<?php echo esc_attr(round(($metrics['with_bordereau'] / $total_orders_for_chart) * 100, 1)); ?>%;"></div></div>
                    </div>
                </div>
                <div class="intigo-chart-card">
                    <h3 class="intigo-chart-title">Verification Funnel</h3>
                    <div class="intigo-bar-row">
                        <div class="intigo-bar-meta"><span>Verified</span><strong><?php echo esc_html($metrics['verified']); ?></strong></div>
                        <div class="intigo-bar-track"><div class="intigo-bar-fill intigo-fill-green" style="width:<?php echo esc_attr(round(($metrics['verified'] / $total_orders_for_chart) * 100, 1)); ?>%;"></div></div>
                    </div>
                    <div class="intigo-bar-row">
                        <div class="intigo-bar-meta"><span>Need confirmation</span><strong><?php echo esc_html($metrics['need_confirmation']); ?></strong></div>
                        <div class="intigo-bar-track"><div class="intigo-bar-fill intigo-fill-yellow" style="width:<?php echo esc_attr(round(($metrics['need_confirmation'] / $total_orders_for_chart) * 100, 1)); ?>%;"></div></div>
                    </div>
                    <div class="intigo-bar-row">
                        <div class="intigo-bar-meta"><span>Missing data</span><strong><?php echo esc_html($metrics['missing_data']); ?></strong></div>
                        <div class="intigo-bar-track"><div class="intigo-bar-fill intigo-fill-gray" style="width:<?php echo esc_attr(round(($metrics['missing_data'] / $total_orders_for_chart) * 100, 1)); ?>%;"></div></div>
                    </div>
                </div>
            </div>

            <div class="intigo-card">
            <h2 style="margin-top:0;">Orders</h2>
            <div class="intigo-table-wrap">
            <table class="widefat striped">
                <thead>
                    <tr>
                        <th>Order</th>
                        <th>Status</th>
                        <th>Total</th>
                        <th>Destination</th>
                        <th>Package</th>
                        <th>Parcel NID</th>
                        <th>Intigo Metadata</th>
                        <th>Actions</th>
                        <th style="min-width:240px;">Notes</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($orders as $order): ?>
                    <?php
                    $order_id = $order->get_id();
                    $nid = (string) $order->get_meta('_intigo_parcel_nid');
                    $create_url = wp_nonce_url(admin_url('admin-post.php?action=intigo_order_action&op=create&order_id=' . $order_id), 'intigo_order_action_' . $order_id . '_create');
                    $bordereau_url = wp_nonce_url(admin_url('admin-post.php?action=intigo_order_action&op=bordereau&order_id=' . $order_id), 'intigo_order_action_' . $order_id . '_bordereau');
                    $sync_url = wp_nonce_url(admin_url('admin-post.php?action=intigo_order_action&op=sync_update&order_id=' . $order_id), 'intigo_order_action_' . $order_id . '_sync_update');
                    $cancel_url = wp_nonce_url(admin_url('admin-post.php?action=intigo_order_action&op=cancel&order_id=' . $order_id), 'intigo_order_action_' . $order_id . '_cancel');
                    $relance_url = wp_nonce_url(admin_url('admin-post.php?action=intigo_order_action&op=relance&order_id=' . $order_id), 'intigo_order_action_' . $order_id . '_relance');
                    $delay_url = wp_nonce_url(admin_url('admin-post.php?action=intigo_order_action&op=report_delay&order_id=' . $order_id), 'intigo_order_action_' . $order_id . '_report_delay');
                    $download_url = wp_nonce_url(admin_url('admin-post.php?action=intigo_download_bordereau&order_id=' . $order_id), 'intigo_download_bordereau_' . $order_id);
                    $stored_bordereau_url = (string) $order->get_meta('_intigo_bordereau_url');
                    $print_url = $stored_bordereau_url !== '' ? $stored_bordereau_url : '';
                    $city_id = (string) $order->get_meta('_intigo_city_id');
                    $district_id = (string) $order->get_meta('_intigo_district_id');
                    $neighborhood_id = (string) $order->get_meta('_intigo_neighborhood_id');
                    if ($city_id !== '' && $district_id === '') {
                        $district_candidate = trim((string) $order->get_shipping_state());
                        if ($district_candidate === '') {
                            $district_candidate = trim((string) $order->get_billing_state());
                        }
                        $resolved_district_id = $this->resolve_district_id_with_order_context($order, intval($city_id), $district_candidate);
                        if ($resolved_district_id > 0) {
                            $district_id = (string) $resolved_district_id;
                            $order->update_meta_data('_intigo_district_id', $resolved_district_id);
                            $order->save();
                        }
                    }
                    $pkg = (string) $order->get_meta('_intigo_package_size');
                    $api_target = (string) $order->get_meta('_intigo_api_target_used');
                    $last_status = (string) $order->get_meta('_intigo_last_status');
                    $last_sync = (string) $order->get_meta('_intigo_last_sync_at');
                    $last_error = (string) $order->get_meta('_intigo_last_error');
                    $last_attempt_at = (string) $order->get_meta('_intigo_last_attempt_at');
                    $ops_status = $this->compute_automatic_ops_status($city_id, $district_id, $pkg, $nid, $stored_bordereau_url);
                    $order->update_meta_data(self::META_OPS_STATUS, $ops_status);
                    $order->save();
                    $tags = $this->build_order_tags($city_id, $district_id, $pkg, $nid, $ops_status);
                    $order_edit_url = admin_url('admin.php?page=wc-orders&action=edit&id=' . $order_id);
                    $missing_required_meta = ($city_id === '' || $district_id === '' || $pkg === '');
                    $has_parcel_in_intigo = ($nid !== '');
                    $can_send = ($ops_status === 'verified');
                    $can_generate_bordereau = $has_parcel_in_intigo;
                    $phone_prefill = trim((string) $order->get_billing_phone());
                    if ($phone_prefill === '' && method_exists($order, 'get_shipping_phone')) {
                        $phone_prefill = trim((string) $order->get_shipping_phone());
                    }
                    if ($phone_prefill === '') {
                        $phone_prefill = trim((string) get_post_meta($order_id, '_billing_phone', true));
                    }
                    if ($phone_prefill === '') {
                        $phone_prefill = trim((string) get_post_meta($order_id, '_shipping_phone', true));
                    }
                    $district_query_prefill = trim((string) $order->get_shipping_state());
                    if ($district_query_prefill === '') {
                        $district_query_prefill = trim((string) $order->get_billing_state());
                    }
                    ?>
                    <tr>
                        <td>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=wc-orders&action=edit&id=' . $order_id)); ?>">#<?php echo esc_html($order_id); ?></a>
                            <?php if ($this->is_order_new($order_id)): ?>
                                <span class="intigo-pill intigo-pill-info">NEW</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo esc_html($order->get_status()); ?></td>
                        <td><?php echo wp_kses_post($order->get_formatted_order_total()); ?></td>
                        <td>
                            <small>City ID: <?php echo esc_html($city_id !== '' ? $city_id : '—'); ?></small><br>
                            <small>District ID: <?php echo esc_html($district_id !== '' ? $district_id : '—'); ?></small><br>
                            <small>Neighborhood ID: <?php echo esc_html($neighborhood_id !== '' ? $neighborhood_id : '—'); ?></small>
                            <?php if ($missing_required_meta): ?>
                                <a class="intigo-meta-edit-link" href="<?php echo esc_url($order_edit_url); ?>" title="Edit Intigo metadata">
                                    <span class="dashicons dashicons-edit"></span>
                                </a>
                            <?php endif; ?>
                        </td>
                        <td><?php echo esc_html($pkg !== '' ? strtoupper($pkg) : '—'); ?></td>
                        <td><?php echo $nid !== '' ? esc_html($nid) : '<span style="color:#777;">—</span>'; ?></td>
                        <td>
                            <div><small>API: <?php echo esc_html($api_target !== '' ? $api_target : '—'); ?></small></div>
                            <div><small>Last status: <?php echo esc_html($last_status !== '' ? $last_status : '—'); ?></small></div>
                            <div><small>Last sync: <?php echo esc_html($last_sync !== '' ? $last_sync : '—'); ?></small></div>
                            <div style="margin-top:4px; display:flex; gap:4px; flex-wrap:wrap;">
                                <?php if ($nid !== ''): ?>
                                    <span class="intigo-pill intigo-pill-ok">Parcel Created</span>
                                <?php else: ?>
                                    <span class="intigo-pill intigo-pill-warn">Not Sent</span>
                                <?php endif; ?>
                                <?php foreach ($tags as $tag): ?>
                                    <span class="intigo-pill <?php echo esc_attr($tag['class']); ?>"><?php echo esc_html($tag['label']); ?></span>
                                <?php endforeach; ?>
                            </div>
                        </td>
                        <td>
                            <div class="intigo-actions">
                                <?php if ($can_send): ?>
                                    <a class="button button-small" href="<?php echo esc_url($create_url); ?>">Send to Intigo</a>
                                <?php else: ?>
                                    <button class="button button-small" disabled title="Complete required metadata first">Send to Intigo</button>
                                <?php endif; ?>
                                <?php if ($has_parcel_in_intigo): ?>
                                    <button
                                        type="button"
                                        class="button button-small"
                                        disabled
                                        title="This parcel is already in Intigo. Please edit it on the Intigo website."
                                    >Edit</button>
                                <?php else: ?>
                                    <button
                                        type="button"
                                        class="button button-small intigo-open-meta-modal"
                                        data-order-id="<?php echo esc_attr($order_id); ?>"
                                        data-city-id="<?php echo esc_attr($city_id); ?>"
                                        data-district-id="<?php echo esc_attr($district_id); ?>"
                                        data-neighborhood-id="<?php echo esc_attr($neighborhood_id); ?>"
                                        data-phone="<?php echo esc_attr($phone_prefill); ?>"
                                        data-city-query="<?php echo esc_attr((string) $order->get_shipping_city()); ?>"
                                        data-district-query="<?php echo esc_attr($district_query_prefill); ?>"
                                        data-location-query="<?php echo esc_attr(trim((string) $order->get_shipping_address_1() . ' ' . (string) $order->get_shipping_city() . ' ' . (string) $order->get_shipping_state())); ?>"
                                        data-package-size="<?php echo esc_attr($pkg !== '' ? strtoupper($pkg) : 'S'); ?>"
                                    >Edit</button>
                                <?php endif; ?>
                                <?php if ($can_generate_bordereau): ?>
                                    <a class="button button-small" href="<?php echo esc_url($bordereau_url); ?>">Generate Bordereau</a>
                                <?php else: ?>
                                    <button class="button button-small" disabled title="Requires Intigo parcel ID first">Generate Bordereau</button>
                                <?php endif; ?>
                            <button
                                type="button"
                                class="button button-small intigo-open-actions-modal"
                                data-order-id="<?php echo esc_attr($order_id); ?>"
                                data-sync-url="<?php echo esc_url($sync_url); ?>"
                                data-relance-url="<?php echo esc_url($relance_url); ?>"
                                data-delay-url="<?php echo esc_url($delay_url); ?>"
                                data-cancel-url="<?php echo esc_url($cancel_url); ?>"
                                data-has-nid="<?php echo esc_attr($nid !== '' ? '1' : '0'); ?>"
                            >More Actions</button>
                            <?php if ($stored_bordereau_url !== ''): ?>
                                <a class="button button-small button-primary" href="<?php echo esc_url($download_url); ?>">Download</a>
                                <a class="button button-small" target="_blank" rel="noopener noreferrer" href="<?php echo esc_url($print_url); ?>">Print</a>
                            <?php endif; ?>
                            </div>
                        </td>
                        <td class="intigo-notes-cell" style="vertical-align:top; max-width:320px;">
                            <?php if ($last_error !== '' && $nid === ''): ?>
                                <div style="padding:8px 10px; background:#fef2f2; border:1px solid #fecaca; border-radius:8px; color:#991b1b; font-size:12px;">
                                    <div style="display:flex; align-items:center; gap:6px; font-weight:700; margin-bottom:4px;">
                                        <span style="display:inline-flex; width:18px; height:18px; border-radius:50%; background:#dc2626; color:#fff; align-items:center; justify-content:center; font-size:11px; flex:0 0 auto;">!</span>
                                        Auto-push failed
                                    </div>
                                    <div style="color:#7f1d1d; word-break:break-word;"><?php echo esc_html($last_error); ?></div>
                                    <?php if ($last_attempt_at !== ''): ?>
                                        <div style="color:#a16f6f; font-size:11px; margin-top:4px;"><?php echo esc_html($last_attempt_at); ?></div>
                                    <?php endif; ?>
                                </div>
                            <?php elseif ($nid !== ''): ?>
                                <div style="padding:8px 10px; background:#ecfdf5; border:1px solid #a7f3d0; border-radius:8px; color:#065f46; font-size:12px;">
                                    <div style="display:flex; align-items:center; gap:6px; font-weight:700; margin-bottom:2px;">
                                        <span style="display:inline-flex; width:18px; height:18px; border-radius:50%; background:#16a34a; color:#fff; align-items:center; justify-content:center; font-size:11px; flex:0 0 auto;">✓</span>
                                        Sent to Intigo
                                    </div>
                                    <?php if ($last_attempt_at !== ''): ?>
                                        <div style="color:#047857; font-size:11px;">at <?php echo esc_html($last_attempt_at); ?></div>
                                    <?php endif; ?>
                                </div>
                            <?php else: ?>
                                <span style="color:#94a3b8; font-size:12px;">—</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>
            <?php if ($total_pages > 1): ?>
                <?php
                $base_url = admin_url('admin.php?page=intigo-manage-orders');
                $from = (($current_page - 1) * $per_page) + 1;
                $to = min($total_items, $current_page * $per_page);
                ?>
                <div style="display:flex; align-items:center; justify-content:space-between; gap:10px; margin-top:12px; flex-wrap:wrap;">
                    <small style="color:#50575e;">Showing <?php echo esc_html($from); ?>-<?php echo esc_html($to); ?> of <?php echo esc_html($total_items); ?> orders</small>
                    <div style="display:flex; gap:6px; align-items:center;">
                        <?php if ($current_page > 1): ?>
                            <a class="button button-small" href="<?php echo esc_url(add_query_arg('paged', $current_page - 1, $base_url)); ?>">Previous</a>
                        <?php else: ?>
                            <button class="button button-small" disabled>Previous</button>
                        <?php endif; ?>
                        <span style="min-width:90px; text-align:center;">Page <?php echo esc_html($current_page); ?> / <?php echo esc_html($total_pages); ?></span>
                        <?php if ($current_page < $total_pages): ?>
                            <a class="button button-small" href="<?php echo esc_url(add_query_arg('paged', $current_page + 1, $base_url)); ?>">Next</a>
                        <?php else: ?>
                            <button class="button button-small" disabled>Next</button>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
            </div>

        </div>
        <div id="intigo-meta-modal-backdrop" class="intigo-modal-backdrop" aria-hidden="true">
            <div class="intigo-modal" role="dialog" aria-modal="true" aria-labelledby="intigoMetaModalTitle">
                <div class="intigo-modal-header">
                    <strong id="intigoMetaModalTitle">Edit Intigo Metadata</strong>
                    <button type="button" class="button-link" id="intigo-meta-modal-close">Close</button>
                </div>
                <div class="intigo-modal-body">
                    <form method="get" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                        <input type="hidden" name="action" value="intigo_order_action">
                        <input type="hidden" name="op" value="save_metadata">
                        <input type="hidden" name="order_id" id="intigo_meta_order_id" value="">
                        <input type="hidden" name="intigo_district_query" id="intigo_meta_district_query" value="">
                        <input type="hidden" id="intigo_meta_lookup_nonce" value="<?php echo esc_attr(wp_create_nonce('intigo_lookup_nonce')); ?>">
                        <?php wp_nonce_field('intigo_order_action_meta_edit', '_wpnonce'); ?>
                        <div class="intigo-form-row">
                            <label for="intigo_meta_location_query">Search address/location first</label>
                            <input type="text" id="intigo_meta_location_query" placeholder="Type address/city and results update as you type" style="width:100%;">
                            <select id="intigo_meta_location_results" class="intigo-location-results" size="6" style="width:100%; margin-top:6px; display:none;"></select>
                        </div>
                        <div class="intigo-form-row">
                            <label for="intigo_meta_city_id">City ID *</label>
                            <select id="intigo_meta_city_id" name="intigo_city_id" required>
                                <option value="">Select city</option>
                            </select>
                        </div>
                        <div class="intigo-form-row">
                            <label for="intigo_meta_district_id">District ID *</label>
                            <select id="intigo_meta_district_id" name="intigo_district_id" required>
                                <option value="">Select district</option>
                            </select>
                        </div>
                        <div class="intigo-form-row">
                            <label for="intigo_meta_neighborhood_id">Neighborhood ID (optional)</label>
                            <select id="intigo_meta_neighborhood_id" name="intigo_neighborhood_id">
                                <option value="">Select neighborhood</option>
                            </select>
                        </div>
                        <div class="intigo-form-row">
                            <label for="intigo_meta_phone">Phone *</label>
                            <input type="text" id="intigo_meta_phone" name="intigo_phone" placeholder="e.g. 20123456" required>
                        </div>
                        <div class="intigo-form-row">
                            <label for="intigo_meta_package_size">Package Size *</label>
                            <select id="intigo_meta_package_size" name="intigo_package_size" required>
                                <option value="S">S</option>
                                <option value="M">M</option>
                                <option value="L">L</option>
                                <option value="XL">XL</option>
                            </select>
                        </div>
                        <button type="submit" class="button button-primary">Save Metadata</button>
                    </form>
                </div>
            </div>
        </div>
        <div id="intigo-actions-modal-backdrop" class="intigo-modal-backdrop" aria-hidden="true">
            <div class="intigo-modal" role="dialog" aria-modal="true" aria-labelledby="intigoActionsModalTitle">
                <div class="intigo-modal-header">
                    <strong id="intigoActionsModalTitle">Order Actions</strong>
                    <button type="button" class="button-link" id="intigo-actions-modal-close">Close</button>
                </div>
                <div class="intigo-modal-body">
                    <p style="margin-top:0;">Select an action, then click Run.</p>
                    <div class="intigo-form-row">
                        <label for="intigo_modal_action_select">Action</label>
                        <select id="intigo_modal_action_select" class="intigo-action-select">
                            <option value="">Select action...</option>
                        </select>
                    </div>
                    <button type="button" class="button button-primary" id="intigo_modal_action_run">Run</button>
                </div>
            </div>
        </div>
        <script>
        (function() {
            const backdrop = document.getElementById('intigo-meta-modal-backdrop');
            const closeBtn = document.getElementById('intigo-meta-modal-close');
            const orderInput = document.getElementById('intigo_meta_order_id');
            const cityInput = document.getElementById('intigo_meta_city_id');
            const districtInput = document.getElementById('intigo_meta_district_id');
            const neighborhoodInput = document.getElementById('intigo_meta_neighborhood_id');
            const phoneInput = document.getElementById('intigo_meta_phone');
            const packageInput = document.getElementById('intigo_meta_package_size');
            const districtQueryInput = document.getElementById('intigo_meta_district_query');
            const locationQueryInput = document.getElementById('intigo_meta_location_query');
            const locationResultsInput = document.getElementById('intigo_meta_location_results');
            const lookupNonceInput = document.getElementById('intigo_meta_lookup_nonce');
            const openButtons = document.querySelectorAll('.intigo-open-meta-modal');
            const openActionsButtons = document.querySelectorAll('.intigo-open-actions-modal');
            const actionsBackdrop = document.getElementById('intigo-actions-modal-backdrop');
            const actionsCloseBtn = document.getElementById('intigo-actions-modal-close');
            const actionsSelect = document.getElementById('intigo_modal_action_select');
            const actionsRunBtn = document.getElementById('intigo_modal_action_run');
            if (!backdrop || !closeBtn || !openButtons.length) return;
            if (actionsBackdrop && actionsBackdrop.parentNode !== document.body) {
                document.body.appendChild(actionsBackdrop);
            }
            const ajaxUrl = "<?php echo esc_js(admin_url('admin-ajax.php')); ?>";
            const lookupNonce = lookupNonceInput ? lookupNonceInput.value : '';
            let pendingSelection = { cityId: '', districtId: '', neighborhoodId: '', cityQuery: '', districtQuery: '', locationQuery: '' };

            function addOption(select, value, label, selected) {
                const opt = document.createElement('option');
                opt.value = value;
                opt.textContent = label;
                if (selected) opt.selected = true;
                select.appendChild(opt);
            }

            function setLoading(select, text) {
                select.innerHTML = '';
                addOption(select, '', text, true);
            }

            function searchLocations(query) {
                if (!locationResultsInput) return;
                const q = String(query || '').trim();
                if (q.length < 1) {
                    locationResultsInput.style.display = 'none';
                    locationResultsInput.innerHTML = '';
                    return;
                }
                locationResultsInput.style.display = 'block';
                locationResultsInput.innerHTML = '';
                addOption(locationResultsInput, '', 'Searching...', true);
                fetch(ajaxUrl + '?action=intigo_search_locations&q=' + encodeURIComponent(q) + '&_wpnonce=' + encodeURIComponent(lookupNonce), { credentials: 'same-origin' })
                    .then(r => r.json())
                    .then(data => {
                        locationResultsInput.innerHTML = '';
                        if (!data || !data.success || !Array.isArray(data.data) || data.data.length === 0) {
                            addOption(locationResultsInput, '', 'No matching locations', true);
                            return;
                        }
                        data.data.forEach(function(item, idx) {
                            const opt = document.createElement('option');
                            opt.value = String(idx + 1);
                            opt.textContent = item.label || '';
                            opt.dataset.cityId = String(item.city_id || '');
                            opt.dataset.districtId = String(item.district_id || '');
                            opt.dataset.neighborhoodId = String(item.neighborhood_id || '');
                            locationResultsInput.appendChild(opt);
                        });
                    })
                    .catch(function() {
                        locationResultsInput.innerHTML = '';
                        addOption(locationResultsInput, '', 'Lookup failed', true);
                    });
            }

            function debounce(fn, delay) {
                let t = null;
                return function() {
                    const args = arguments;
                    clearTimeout(t);
                    t = setTimeout(function() { fn.apply(null, args); }, delay);
                };
            }

            function loadCities(selectedCityId) {
                setLoading(cityInput, 'Loading cities...');
                let url = ajaxUrl + '?action=intigo_get_cities&_wpnonce=' + encodeURIComponent(lookupNonce);
                if (pendingSelection.cityQuery) {
                    url += '&q=' + encodeURIComponent(pendingSelection.cityQuery);
                }
                fetch(url, { credentials: 'same-origin' })
                    .then(r => r.json())
                    .then(data => {
                        cityInput.innerHTML = '';
                        addOption(cityInput, '', 'Select city', false);
                        if (!data || !data.success || !Array.isArray(data.data)) {
                            const msg = (data && data.data && data.data.message) ? data.data.message : 'Lookup failed';
                            addOption(cityInput, '', msg, true);
                            return;
                        }
                        data.data.forEach(c => addOption(cityInput, c.id, c.name, String(c.id) === String(selectedCityId)));
                        if (!selectedCityId && pendingSelection.cityQuery) {
                            const q = String(pendingSelection.cityQuery).trim().toLowerCase();
                            for (let i = 0; i < cityInput.options.length; i++) {
                                const opt = cityInput.options[i];
                                if (!opt || !opt.value) continue;
                                const label = String(opt.textContent || '').trim().toLowerCase();
                                if (label === q || label.indexOf(q) !== -1 || q.indexOf(label) !== -1) {
                                    cityInput.value = opt.value;
                                    selectedCityId = opt.value;
                                    pendingSelection.cityId = opt.value;
                                    break;
                                }
                            }
                        }
                        if (selectedCityId) {
                            loadDistricts(selectedCityId, pendingSelection.districtId);
                        } else {
                            districtInput.innerHTML = '';
                            addOption(districtInput, '', 'Select district', false);
                            neighborhoodInput.innerHTML = '';
                            addOption(neighborhoodInput, '', 'Select neighborhood', false);
                        }
                    })
                    .catch(() => {
                        cityInput.innerHTML = '';
                        addOption(cityInput, '', 'Lookup failed: network/AJAX error', true);
                    });
            }

            function loadDistricts(cityId, selectedDistrictId) {
                if (!cityId) {
                    districtInput.innerHTML = '';
                    addOption(districtInput, '', 'Select district', false);
                    neighborhoodInput.innerHTML = '';
                    addOption(neighborhoodInput, '', 'Select neighborhood', false);
                    return;
                }
                setLoading(districtInput, 'Loading districts...');
                let url = ajaxUrl + '?action=intigo_get_districts&city_id=' + encodeURIComponent(cityId) + '&_wpnonce=' + encodeURIComponent(lookupNonce);
                if (pendingSelection.districtQuery) {
                    url += '&q=' + encodeURIComponent(pendingSelection.districtQuery);
                }
                fetch(url, { credentials: 'same-origin' })
                    .then(r => r.json())
                    .then(data => {
                        districtInput.innerHTML = '';
                        addOption(districtInput, '', 'Select district', false);
                        if (!data || !data.success || !Array.isArray(data.data)) {
                            const msg = (data && data.data && data.data.message) ? data.data.message : 'Lookup failed';
                            addOption(districtInput, '', msg, true);
                            return;
                        }
                        data.data.forEach(d => addOption(districtInput, d.id, d.name, String(d.id) === String(selectedDistrictId)));
                        if (!selectedDistrictId && pendingSelection.districtQuery) {
                            const q = String(pendingSelection.districtQuery).trim().toLowerCase();
                            for (let i = 0; i < districtInput.options.length; i++) {
                                const opt = districtInput.options[i];
                                if (!opt || !opt.value) continue;
                                const label = String(opt.textContent || '').trim().toLowerCase();
                                if (label === q || label.indexOf(q) !== -1 || q.indexOf(label) !== -1) {
                                    districtInput.value = opt.value;
                                    selectedDistrictId = opt.value;
                                    pendingSelection.districtId = opt.value;
                                    break;
                                }
                            }
                        }
                        if (selectedDistrictId) {
                            loadNeighborhoods(selectedDistrictId, pendingSelection.neighborhoodId);
                        } else {
                            neighborhoodInput.innerHTML = '';
                            addOption(neighborhoodInput, '', 'Select neighborhood', false);
                        }
                    })
                    .catch(() => {
                        districtInput.innerHTML = '';
                        addOption(districtInput, '', 'Lookup failed: network/AJAX error', true);
                    });
            }

            function loadNeighborhoods(districtId, selectedNeighborhoodId) {
                if (!districtId) {
                    neighborhoodInput.innerHTML = '';
                    addOption(neighborhoodInput, '', 'Select neighborhood', false);
                    return;
                }
                setLoading(neighborhoodInput, 'Loading neighborhoods...');
                fetch(ajaxUrl + '?action=intigo_get_neighborhoods&district_id=' + encodeURIComponent(districtId) + '&_wpnonce=' + encodeURIComponent(lookupNonce), { credentials: 'same-origin' })
                    .then(r => r.json())
                    .then(data => {
                        neighborhoodInput.innerHTML = '';
                        addOption(neighborhoodInput, '', 'Select neighborhood', false);
                        if (!data || !data.success || !Array.isArray(data.data)) {
                            const msg = (data && data.data && data.data.message) ? data.data.message : 'Lookup failed';
                            addOption(neighborhoodInput, '', msg, true);
                            return;
                        }
                        data.data.forEach(n => addOption(neighborhoodInput, n.id, n.name, String(n.id) === String(selectedNeighborhoodId)));
                    })
                    .catch(() => {
                        neighborhoodInput.innerHTML = '';
                        addOption(neighborhoodInput, '', 'Lookup failed: network/AJAX error', true);
                    });
            }

            function openModal(btn) {
                orderInput.value = btn.getAttribute('data-order-id') || '';
                pendingSelection = {
                    cityId: btn.getAttribute('data-city-id') || '',
                    districtId: btn.getAttribute('data-district-id') || '',
                    neighborhoodId: btn.getAttribute('data-neighborhood-id') || '',
                    cityQuery: btn.getAttribute('data-city-query') || '',
                    districtQuery: btn.getAttribute('data-district-query') || '',
                    locationQuery: '',
                };
                // If IDs already exist, prioritize exact ID preload over text-based filtering.
                if (pendingSelection.cityId) {
                    pendingSelection.cityQuery = '';
                }
                if (pendingSelection.districtId) {
                    pendingSelection.districtQuery = '';
                }
                if (locationQueryInput) {
                    locationQueryInput.value = '';
                }
                if (locationResultsInput) {
                    locationResultsInput.innerHTML = '';
                    locationResultsInput.style.display = 'none';
                }
                if (phoneInput) {
                    phoneInput.value = btn.getAttribute('data-phone') || '';
                }
                if (districtQueryInput) {
                    districtQueryInput.value = pendingSelection.districtQuery || '';
                }
                if (!pendingSelection.districtId && pendingSelection.districtQuery) {
                    districtInput.innerHTML = '';
                    addOption(districtInput, '', 'Select district', false);
                    addOption(districtInput, '', pendingSelection.districtQuery + ' (from WooCommerce)', true);
                }
                packageInput.value = btn.getAttribute('data-package-size') || 'S';
                loadCities(pendingSelection.cityId);
                backdrop.style.display = 'flex';
                document.body.classList.add('intigo-modal-open');
            }
            function closeModal() {
                backdrop.style.display = 'none';
                document.body.classList.remove('intigo-modal-open');
            }
            openButtons.forEach((btn) => btn.addEventListener('click', () => openModal(btn)));
            cityInput.addEventListener('change', function() {
                pendingSelection.districtId = '';
                pendingSelection.neighborhoodId = '';
                loadDistricts(cityInput.value, '');
            });
            districtInput.addEventListener('change', function() {
                pendingSelection.neighborhoodId = '';
                if (districtQueryInput && districtInput.selectedIndex >= 0) {
                    districtQueryInput.value = String(districtInput.options[districtInput.selectedIndex].textContent || '').trim();
                }
                loadNeighborhoods(districtInput.value, '');
            });
            if (locationQueryInput) {
                const handleLocationTyping = debounce(function() {
                    const raw = String(locationQueryInput.value || '').trim();
                    pendingSelection.cityQuery = raw;
                    pendingSelection.districtQuery = raw;
                    pendingSelection.cityId = '';
                    pendingSelection.districtId = '';
                    pendingSelection.neighborhoodId = '';
                    searchLocations(raw);
                }, 250);
                locationQueryInput.addEventListener('input', handleLocationTyping);
            }
            if (locationResultsInput) {
                locationResultsInput.addEventListener('change', function() {
                    const opt = locationResultsInput.options[locationResultsInput.selectedIndex];
                    if (!opt) return;
                    const cityId = String(opt.dataset.cityId || '');
                    const districtId = String(opt.dataset.districtId || '');
                    const neighborhoodId = String(opt.dataset.neighborhoodId || '');
                    pendingSelection.cityId = cityId;
                    pendingSelection.districtId = districtId;
                    pendingSelection.neighborhoodId = neighborhoodId;
                    pendingSelection.cityQuery = String(locationQueryInput ? locationQueryInput.value || '' : '').trim();
                    pendingSelection.districtQuery = pendingSelection.cityQuery;
                    loadCities(cityId);
                });
            }
            function addActionOption(value, label) {
                const opt = document.createElement('option');
                opt.value = value;
                opt.textContent = label;
                actionsSelect.appendChild(opt);
            }
            function openActionsModal(btn) {
                if (!actionsBackdrop || !actionsSelect) return;
                actionsSelect.innerHTML = '';
                addActionOption('', 'Select action...');
                addActionOption(btn.getAttribute('data-sync-url') || '', 'Synchronize with Intigo');
                if ((btn.getAttribute('data-has-nid') || '') === '1') {
                    addActionOption(btn.getAttribute('data-relance-url') || '', 'Request Relance');
                    addActionOption(btn.getAttribute('data-delay-url') || '', 'Report Delay');
                    addActionOption(btn.getAttribute('data-cancel-url') || '', 'Cancel Parcel');
                }
                actionsBackdrop.style.display = 'flex';
                document.body.classList.add('intigo-modal-open');
            }
            function closeActionsModal() {
                if (!actionsBackdrop) return;
                actionsBackdrop.style.display = 'none';
                document.body.classList.remove('intigo-modal-open');
            }
            openActionsButtons.forEach((btn) => btn.addEventListener('click', () => openActionsModal(btn)));
            if (actionsRunBtn) {
                actionsRunBtn.addEventListener('click', function() {
                    if (!actionsSelect || !actionsSelect.value) return;
                    window.location.href = actionsSelect.value;
                });
            }
            if (actionsCloseBtn) actionsCloseBtn.addEventListener('click', closeActionsModal);
            closeBtn.addEventListener('click', closeModal);
            backdrop.addEventListener('click', function(e) {
                if (e.target === backdrop) closeModal();
            });
            if (actionsBackdrop) {
                actionsBackdrop.addEventListener('click', function(e) {
                    if (e.target === actionsBackdrop) closeActionsModal();
                });
            }
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && backdrop.style.display === 'flex') closeModal();
                if (e.key === 'Escape' && actionsBackdrop && actionsBackdrop.style.display === 'flex') closeActionsModal();
            });
        })();
        </script>
        <?php
    }

    public function render_logs() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized');
        }
        $logs = $this->get_logs();
        $total = count($logs);
        $per_page = self::LOGS_PER_PAGE;
        $total_pages = max(1, (int) ceil($total / $per_page));
        $current_page = isset($_GET['lpaged']) ? max(1, intval($_GET['lpaged'])) : 1;
        if ($current_page > $total_pages) { $current_page = $total_pages; }
        $offset = ($current_page - 1) * $per_page;
        $page_logs = $total > 0 ? array_slice($logs, $offset, $per_page) : [];
        $base_url = admin_url('admin.php?page=intigo-logs');
        $range_from = $total === 0 ? 0 : $offset + 1;
        $range_to = min($offset + $per_page, $total);
        ?>
        <div class="wrap">
            <?php $this->render_responsive_styles(); ?>
            <?php $this->render_interface_nav('intigo-logs'); ?>
            <?php $this->render_snackbar(); ?>
            <?php $this->render_page_header('Activity Log', 'Latest ' . esc_html(self::MAX_LOGS) . ' plugin actions and messages &mdash; useful for debugging and audits.', 'History'); ?>
            <?php if (empty($logs)): ?>
                <div class="intigo-card">
                    <div class="intigo-empty">
                        <div class="intigo-empty-icon"><span class="dashicons dashicons-list-view"></span></div>
                        <div class="intigo-empty-title">No activity yet</div>
                        <div>Plugin actions and API calls will appear here once you start using Intigo.</div>
                    </div>
                </div>
            <?php else: ?>
                <div class="intigo-logs-meta" style="display:flex; justify-content:space-between; align-items:center; flex-wrap:wrap; gap:8px; margin: 0 0 12px 0; color:var(--intigo-muted); font-size:12.5px;">
                    <span>Showing <strong style="color:var(--intigo-text);"><?php echo esc_html($range_from); ?>&ndash;<?php echo esc_html($range_to); ?></strong> of <strong style="color:var(--intigo-text);"><?php echo esc_html($total); ?></strong> entries (max <?php echo esc_html(self::MAX_LOGS); ?> retained).</span>
                    <span>Page <strong style="color:var(--intigo-text);"><?php echo esc_html($current_page); ?></strong> of <strong style="color:var(--intigo-text);"><?php echo esc_html($total_pages); ?></strong></span>
                </div>
                <div class="intigo-table-wrap">
                    <table class="widefat striped">
                        <thead>
                            <tr>
                                <th style="width:170px;">Time</th>
                                <th style="width:160px;">Actor</th>
                                <th style="width:200px;">Action</th>
                                <th>Context</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($page_logs as $log):
                                $action = (string) ($log['action'] ?? '');
                                $is_error = stripos($action, 'fail') !== false || stripos($action, 'error') !== false;
                                $is_success = stripos($action, 'success') !== false || stripos($action, 'created') !== false;
                                $pill_class = 'intigo-pill-muted';
                                if ($is_error) { $pill_class = 'intigo-pill-warn'; }
                                elseif ($is_success) { $pill_class = 'intigo-pill-ok'; }
                                ?>
                                <tr>
                                    <td><code style="background:#f1f5f9; color:#475569; padding:2px 6px; border-radius:5px; font-size:11.5px;"><?php echo esc_html((string) ($log['time'] ?? '')); ?></code></td>
                                    <td><?php echo esc_html((string) ($log['actor'] ?? 'system')); ?></td>
                                    <td><span class="intigo-pill <?php echo esc_attr($pill_class); ?>"><?php echo esc_html($action); ?></span></td>
                                    <td><small style="color:#64748b;"><?php echo esc_html((string) ($log['context'] ?? '')); ?></small></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php if ($total_pages > 1): ?>
                    <nav class="intigo-pagination" aria-label="Logs pagination">
                        <?php
                            $prev_disabled = $current_page <= 1;
                            $next_disabled = $current_page >= $total_pages;
                            $prev_url = add_query_arg('lpaged', max(1, $current_page - 1), $base_url);
                            $next_url = add_query_arg('lpaged', min($total_pages, $current_page + 1), $base_url);
                            $first_url = add_query_arg('lpaged', 1, $base_url);
                            $last_url = add_query_arg('lpaged', $total_pages, $base_url);

                            $window = 2;
                            $start = max(1, $current_page - $window);
                            $end = min($total_pages, $current_page + $window);
                            if ($start > 1) { echo '<a class="intigo-page-btn" href="' . esc_url($first_url) . '">1</a>'; if ($start > 2) { echo '<span class="intigo-page-ellipsis">&hellip;</span>'; } }
                        ?>
                        <a class="intigo-page-btn intigo-page-nav <?php echo $prev_disabled ? 'is-disabled' : ''; ?>" <?php echo $prev_disabled ? '' : 'href="' . esc_url($prev_url) . '"'; ?> aria-label="Previous page"><span class="dashicons dashicons-arrow-left-alt2"></span> Previous</a>
                        <?php for ($i = $start; $i <= $end; $i++):
                            $active = $i === $current_page ? 'is-active' : '';
                            $url = add_query_arg('lpaged', $i, $base_url);
                            ?>
                            <a class="intigo-page-btn <?php echo esc_attr($active); ?>" href="<?php echo esc_url($url); ?>"><?php echo esc_html($i); ?></a>
                        <?php endfor; ?>
                        <a class="intigo-page-btn intigo-page-nav <?php echo $next_disabled ? 'is-disabled' : ''; ?>" <?php echo $next_disabled ? '' : 'href="' . esc_url($next_url) . '"'; ?> aria-label="Next page">Next <span class="dashicons dashicons-arrow-right-alt2"></span></a>
                        <?php if ($end < $total_pages): if ($end < $total_pages - 1) { echo '<span class="intigo-page-ellipsis">&hellip;</span>'; } ?>
                            <a class="intigo-page-btn" href="<?php echo esc_url($last_url); ?>"><?php echo esc_html($total_pages); ?></a>
                        <?php endif; ?>
                    </nav>
                <?php endif; ?>
            <?php endif; ?>
        </div>
        <?php
    }

    public function render_docs() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized');
        }
        ?>
        <div class="wrap">
            <?php $this->render_responsive_styles(); ?>
            <?php $this->render_interface_nav('intigo-docs'); ?>
            <?php $this->render_snackbar(); ?>
            <?php $this->render_page_header('Documentation', 'How the Intigo plugin works, best practices, tag meanings, and troubleshooting tips.', 'Help center'); ?>
            <style>
                .intigo-docs-grid { display:grid; grid-template-columns: repeat(2, 1fr); gap:14px; }
                @media (max-width: 900px) { .intigo-docs-grid { grid-template-columns: 1fr; } }
                .intigo-doc-card { background:#fff; border:1px solid var(--intigo-border); border-radius: var(--intigo-radius-lg); padding:20px; box-shadow: var(--intigo-shadow-sm); position:relative; }
                .intigo-doc-card .intigo-doc-icon { width:40px; height:40px; border-radius:10px; background:var(--intigo-primary-soft); color:var(--intigo-primary); display:flex; align-items:center; justify-content:center; margin-bottom:12px; }
                .intigo-doc-card .intigo-doc-icon .dashicons { font-size:20px; width:20px; height:20px; }
                .intigo-doc-card h2 { margin:0 0 8px 0; font-size:15px; font-weight:600; color:var(--intigo-text); }
                .intigo-doc-card p, .intigo-doc-card li { color:var(--intigo-text-soft); font-size:13.5px; line-height:1.6; }
                .intigo-doc-card ol, .intigo-doc-card ul { margin:8px 0 0 18px; padding:0; }
                .intigo-doc-card li { margin-bottom:6px; }
                .intigo-doc-card .intigo-doc-tag { display:inline-block; padding:2px 8px; background:#f1f5f9; color:#0f172a; border-radius:6px; font-size:12px; font-weight:600; margin-right:6px; }
                .intigo-doc-card.intigo-doc-help { background: linear-gradient(180deg, #f0f7ff 0%, #fff 100%); border-color:#bfdbfe; }
                .intigo-doc-locale { padding:14px 16px; background:#fff; border:1px solid var(--intigo-border); border-radius: var(--intigo-radius); margin-top:10px; }
                .intigo-doc-locale .intigo-doc-locale-flag { display:inline-block; padding:2px 8px; border-radius:6px; background:#0f172a; color:#fff; font-size:11px; font-weight:700; letter-spacing:.04em; margin-right:8px; }
            </style>
            <div class="intigo-docs-grid">
                <div class="intigo-doc-card">
                    <div class="intigo-doc-icon"><span class="dashicons dashicons-flag"></span></div>
                    <h2>Getting started</h2>
                    <ol>
                        <li>Open <strong>Intigo &rarr; Settings</strong>.</li>
                        <li>Paste your <strong>API key</strong>.</li>
                        <li>Pick <strong>Sandbox</strong> for testing or <strong>Production</strong> for live operations.</li>
                        <li>Save and confirm the <em>API connected</em> pill at the top.</li>
                    </ol>
                    <p style="margin-top:12px;"><strong>Order flow:</strong> WooCommerce orders appear in <strong>Manage Orders</strong>. Complete metadata (city, district, neighborhood, package), send to Intigo, then generate and download the bordereau.</p>
                </div>

                <div class="intigo-doc-card">
                    <div class="intigo-doc-icon"><span class="dashicons dashicons-yes-alt"></span></div>
                    <h2>Best practices</h2>
                    <ul>
                        <li>Validate end-to-end in <strong>Sandbox</strong> before switching to Production.</li>
                        <li>Generate the bordereau only after a parcel NID is assigned.</li>
                        <li>Review the <strong>Activity Log</strong> regularly for failures.</li>
                        <li>Keep city/district metadata complete to avoid missing-data status.</li>
                    </ul>
                </div>

                <div class="intigo-doc-card" style="grid-column: 1 / -1; background: linear-gradient(180deg, #f0f7ff 0%, #fff 100%); border-color:#bfdbfe;">
                    <div class="intigo-doc-icon"><span class="dashicons dashicons-update-alt"></span></div>
                    <h2>Automatic Send to Intigo</h2>
                    <p>When <strong>Order Processing Mode</strong> is set to <strong>Automatic</strong>, every WooCommerce order placed with the Intigo Delivery shipping method is pushed to Intigo's parcel API automatically &mdash; no admin click required.</p>

                    <h3 style="margin:14px 0 6px 0; font-size:13.5px; color:#0f172a;">How it works end-to-end</h3>
                    <ol>
                        <li>Customer at checkout picks <strong>Intigo Delivery (Small / Medium / Large / Extra large)</strong> &mdash; the size determines the shipping cost.</li>
                        <li>A modal pops up titled <em>Confirm your delivery details</em>, pre-filled from the customer's WooCommerce billing.</li>
                        <li>Customer confirms recipient, phone, country, address, and picks <strong>Intigo city &rarr; district &rarr; neighborhood</strong> from cascading dropdowns served by Intigo's region API.</li>
                        <li>Customer clicks <strong>Save delivery info</strong>; the modal closes; the cart total reflects the chosen size.</li>
                        <li>Customer clicks <strong>Place Order</strong>. Server-side validation enforces that all required Intigo fields are filled &mdash; otherwise the order is rejected with a clear inline error.</li>
                        <li>Once the order status reaches <em>Processing</em> (immediate for COD; after payment confirmation for cards), the plugin pushes the parcel to <code>/v3/parcels/</code> on the active environment URL.</li>
                        <li>On success, the parcel <strong>NID</strong> is stored on the order, an order note is added (<em>"Intigo parcel created: NID-XXXX"</em>), and the Manage Orders <strong>Notes</strong> column shows a green <strong>Sent to Intigo ✓</strong>.</li>
                        <li>On failure, the API error is stored on the order and shown in the Manage Orders <strong>Notes</strong> column in red, plus added as an order note for the audit trail.</li>
                    </ol>

                    <h3 style="margin:14px 0 6px 0; font-size:13.5px; color:#0f172a;">Trigger events (idempotent &mdash; will not double-push)</h3>
                    <ul>
                        <li><code>woocommerce_store_api_checkout_order_processed</code> &mdash; Blocks-checkout primary path.</li>
                        <li><code>woocommerce_order_status_processing</code> &mdash; classic + COD primary path.</li>
                        <li><code>woocommerce_order_status_completed</code> &mdash; safety net.</li>
                        <li><code>woocommerce_payment_complete</code> &mdash; fires for any gateway when payment is confirmed.</li>
                        <li><code>woocommerce_thankyou</code> &mdash; final fallback when the customer reaches the order-received page.</li>
                    </ul>
                    <p style="margin-top:8px;">Each event funnels through <code>Intigo_Order_Service::maybe_auto_create_from_order_event($order_id)</code>, which checks the Automatic toggle, confirms the order uses Intigo Delivery, skips orders in failed/cancelled/draft state, skips if a NID is already assigned (or the idempotency meta is set), and otherwise calls <code>create_single_for_order($order)</code>.</p>

                    <h3 style="margin:14px 0 6px 0; font-size:13.5px; color:#0f172a;">Phone normalization</h3>
                    <p>Intigo's API rejects phones containing non-digit characters. The plugin auto-strips them before sending: <code>+216 25 24 92 15</code> &rarr; <code>21625249215</code>, <code>0021625249215</code> &rarr; <code>21625249215</code>. Whatever the customer types is normalized to digits-only.</p>

                    <h3 style="margin:14px 0 6px 0; font-size:13.5px; color:#0f172a;">If the auto-push fails</h3>
                    <ul>
                        <li>Open <strong>Manage Orders</strong> &mdash; the failing order shows the API error in the <strong>Notes</strong> column on the right.</li>
                        <li>Or open the order in WC and read the <strong>Order notes</strong> sidebar for the full request/response.</li>
                        <li>Click <strong>Send to Intigo</strong> from Manage Orders to retry once you've fixed the underlying issue.</li>
                    </ul>

                    <h3 style="margin:14px 0 6px 0; font-size:13.5px; color:#0f172a;">Switching back to Manual mode</h3>
                    <p>Set <strong>Settings &rarr; Order processing</strong> to <em>Manual</em>. New orders will sit in Manage Orders with all metadata pre-filled, and the seller clicks <strong>Send to Intigo</strong> when ready.</p>
                </div>

                <div class="intigo-doc-card" style="grid-column: 1 / -1;">
                    <div class="intigo-doc-icon"><span class="dashicons dashicons-tag"></span></div>
                    <h2>Tag meanings (Manage Orders)</h2>
                    <ul style="list-style:none; margin-left:0; display:grid; grid-template-columns: repeat(2, 1fr); gap:10px 24px;">
                        <li><span class="intigo-doc-tag">NEW</span> Newly created order, not yet reviewed.</li>
                        <li><span class="intigo-doc-tag">Not Sent</span> No Intigo parcel created yet for this order.</li>
                        <li><span class="intigo-doc-tag">Parcel Created</span> Parcel exists in Intigo with a NID.</li>
                        <li><span class="intigo-doc-tag">Missing Data</span> Required metadata is incomplete.</li>
                        <li><span class="intigo-doc-tag">Need Verification</span> Metadata exists but needs review.</li>
                        <li><span class="intigo-doc-tag">Verified</span> Metadata complete &mdash; ready for Intigo actions.</li>
                        <li><span class="intigo-doc-tag">Ready for Shipment</span> Parcel created and verified.</li>
                        <li><span class="intigo-doc-tag">Bordereau Generated</span> Bordereau URL is available.</li>
                    </ul>
                </div>

                <div class="intigo-doc-card">
                    <div class="intigo-doc-icon"><span class="dashicons dashicons-sos"></span></div>
                    <h2>Troubleshooting</h2>
                    <ul>
                        <li><strong>Cannot load cities/districts:</strong> verify API key and environment in Settings.</li>
                        <li><strong>"Send to Intigo" disabled:</strong> required metadata is missing &mdash; use the <em>Edit</em> button.</li>
                        <li><strong>Bordereau action disabled:</strong> the parcel must exist in Intigo first.</li>
                        <li><strong>Login or health failures:</strong> verify API key and connectivity.</li>
                    </ul>
                </div>

                <div class="intigo-doc-card intigo-doc-help">
                    <div class="intigo-doc-icon"><span class="dashicons dashicons-email-alt"></span></div>
                    <h2>Need help?</h2>
                    <p>Reach the Intigo team for support, account changes, or API key requests.</p>
                    <p style="margin-top:10px;"><a class="button button-primary" href="mailto:hello@intigo.tn">Email hello@intigo.tn</a></p>
                </div>

                <div class="intigo-doc-card" style="grid-column: 1 / -1;">
                    <div class="intigo-doc-icon"><span class="dashicons dashicons-translation"></span></div>
                    <h2>Quick guide (FR / AR)</h2>
                    <div class="intigo-doc-locale">
                        <span class="intigo-doc-locale-flag">FR</span>
                        Commencez par ajouter votre cle API dans les Parametres, choisissez Sandbox ou Production, puis enregistrez. Les commandes WooCommerce apparaitront dans Manage Orders pour completer les metadonnees et traiter l'expedition. En cas d'erreur, contactez <a href="mailto:hello@intigo.tn">hello@intigo.tn</a>.
                    </div>
                    <div class="intigo-doc-locale" dir="rtl" style="text-align:right;">
                        <span class="intigo-doc-locale-flag">AR</span>
                        ابدأ بإضافة مفتاح API من صفحة الإعدادات ثم اختر وضع الاختبار أو الإنتاج. بعد إنشاء الطلبات في WooCommerce ستظهر تلقائياً في Manage Orders لإكمال البيانات ثم الشحن. في حال وجود أخطاء تواصل مع <a href="mailto:hello@intigo.tn">hello@intigo.tn</a>.
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    public function register_order_meta_box() {
        add_meta_box(
            'intigo_shipment_meta',
            'Intigo Shipment',
            [$this, 'render_order_meta_box'],
            'shop_order',
            'side',
            'default'
        );
    }

    public function register_order_meta_box_hpos($screen_id = '') {
        // HPOS order editor screen id is typically woocommerce_page_wc-orders.
        $target = $screen_id ?: 'woocommerce_page_wc-orders';
        add_meta_box(
            'intigo_shipment_meta',
            'Intigo Shipment',
            [$this, 'render_order_meta_box_hpos'],
            $target,
            'side',
            'default'
        );
    }

    public function render_order_meta_box($post) {
        $order_id = $post->ID;
        $this->render_order_meta_box_fields($order_id);
    }

    public function render_order_meta_box_hpos($object_or_order) {
        $order_id = 0;
        if (is_object($object_or_order) && method_exists($object_or_order, 'get_id')) {
            $order_id = intval($object_or_order->get_id());
        } elseif (is_object($object_or_order) && isset($object_or_order->ID)) {
            $order_id = intval($object_or_order->ID);
        }
        if ($order_id <= 0 && isset($_GET['id'])) {
            $order_id = intval($_GET['id']);
        }
        if ($order_id <= 0) {
            echo '<p>Unable to resolve order ID for Intigo Shipment.</p>';
            return;
        }
        $this->render_order_meta_box_fields($order_id);
    }

    private function render_order_meta_box_fields($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }
        $city_id = $order->get_meta('_intigo_city_id');
        $district_id = $order->get_meta('_intigo_district_id');
        $neighborhood_id = $order->get_meta('_intigo_neighborhood_id');
        $package_size = (string) $order->get_meta('_intigo_package_size');
        if ($package_size === '') {
            $package_size = 'S';
        }

        wp_nonce_field('intigo_order_meta_nonce', 'intigo_order_meta_nonce_field');
        ?>
        <style>
            .intigo-shipment-grid { display: grid; grid-template-columns: 1fr; gap: 12px; background:#fff; border:1px solid #d8e2ea; border-radius:12px; padding:12px; }
            .intigo-field label { font-weight: 600; display: block; margin-bottom: 4px; }
            .intigo-field small { display: block; color: #646970; margin-top: 4px; }
            .intigo-field input, .intigo-field select { border:1px solid #c7d2dc; border-radius:9px; min-height:38px; padding:0 10px; background:#fff; }
            .intigo-field input:focus, .intigo-field select:focus { border-color:#2271b1; box-shadow:0 0 0 3px rgba(34,113,177,.15); outline:none; }
            .intigo-location-results { border:1px solid #c7d2dc !important; border-radius:10px !important; background:#fbfdff; padding:4px; min-height:148px; }
            .intigo-location-results option { padding:7px 8px; border-radius:6px; margin:1px 0; }
            .intigo-location-results option:checked { background:#e8f2fb linear-gradient(0deg,#e8f2fb,#e8f2fb); color:#0b3c5d; }
            .intigo-helper {
                border: 1px solid #d8e2ea;
                background: #f8fbff;
                padding: 10px;
                border-radius: 8px;
                margin-bottom: 10px;
                font-size: 12px;
                color: #334155;
            }
        </style>
        <div class="intigo-helper">
            Step 1: Select City. Step 2: Select District. Step 3: Optional Neighborhood. Step 4: Choose package size.
        </div>
        <div class="intigo-shipment-grid">
        <p class="intigo-field">
            <label for="intigo_location_search"><strong>Search address/location first</strong></label><br>
            <input type="text" id="intigo_location_search" placeholder="Type address/city and results update as you type" style="width:100%;">
            <select id="intigo_location_results" class="intigo-location-results" size="6" style="width:100%; margin-top:6px; display:none;"></select>
        </p>
        <p class="intigo-field">
            <label for="intigo_city_select"><strong>City</strong></label><br>
            <select id="intigo_city_select" name="intigo_city_id" style="width:100%;">
                <option value="">Select city</option>
            </select>
        </p>
        <p class="intigo-field">
            <label for="intigo_district_select"><strong>District</strong></label><br>
            <select id="intigo_district_select" name="intigo_district_id" style="width:100%;">
                <option value="">Select district</option>
            </select>
        </p>
        <p class="intigo-field">
            <label for="intigo_neighborhood_select"><strong>Neighborhood (optional)</strong></label><br>
            <select id="intigo_neighborhood_select" name="intigo_neighborhood_id" style="width:100%;">
                <option value="">Select neighborhood</option>
            </select>
        </p>
        <p class="intigo-field">
            <label for="intigo_package_size"><strong>Package Size</strong></label><br>
            <select id="intigo_package_size" name="intigo_package_size" style="width:100%;">
                <option value="S" <?php selected(strtoupper((string) $package_size), 'S'); ?>>S</option>
                <option value="M" <?php selected(strtoupper((string) $package_size), 'M'); ?>>M</option>
                <option value="L" <?php selected(strtoupper((string) $package_size), 'L'); ?>>L</option>
                <option value="XL" <?php selected(strtoupper((string) $package_size), 'XL'); ?>>XL</option>
            </select>
            <small>Mapped automatically for API payload.</small>
        </p>
        </div>
        <?php
        $bordereau_url = (string) $order->get_meta('_intigo_bordereau_url');
        $parcel_nid = (string) $order->get_meta('_intigo_parcel_nid');
        if ($bordereau_url !== ''):
            $download_url = wp_nonce_url(
                admin_url('admin-post.php?action=intigo_download_bordereau&order_id=' . intval($order_id)),
                'intigo_download_bordereau_' . intval($order_id)
            );
            ?>
            <p style="margin-top:10px;">
                <a class="button button-primary" href="<?php echo esc_url($download_url); ?>">Download Bordereau</a>
            </p>
            <?php if ($parcel_nid !== ''): ?>
                <p class="description">Parcel NID: <strong><?php echo esc_html($parcel_nid); ?></strong></p>
            <?php endif; ?>
        <?php else: ?>
            <p class="description" style="margin-top:10px;">Generate bordereau from Order Actions first, then download it here.</p>
        <?php endif; ?>

        <script>
        (function() {
            const ajaxUrl = "<?php echo esc_js(admin_url('admin-ajax.php')); ?>";
            const citySelect = document.getElementById('intigo_city_select');
            const districtSelect = document.getElementById('intigo_district_select');
            const neighborhoodSelect = document.getElementById('intigo_neighborhood_select');
            const locationSearchInput = document.getElementById('intigo_location_search');
            const locationResultsInput = document.getElementById('intigo_location_results');
            const currentCityId = "<?php echo esc_js((string) $city_id); ?>";
            const currentDistrictId = "<?php echo esc_js((string) $district_id); ?>";
            const currentNeighborhoodId = "<?php echo esc_js((string) $neighborhood_id); ?>";
            const nonce = "<?php echo esc_js(wp_create_nonce('intigo_lookup_nonce')); ?>";
            const shippingCityInput = document.getElementById('_shipping_city');
            const shippingStateInput = document.getElementById('_shipping_state');
            const shippingAddressInput = document.getElementById('_shipping_address_1');
            let locationQuery = '';
            if (shippingAddressInput && String(shippingAddressInput.value || '').trim()) {
                locationQuery = String(shippingAddressInput.value || '').trim();
            } else if (shippingCityInput && String(shippingCityInput.value || '').trim()) {
                locationQuery = String(shippingCityInput.value || '').trim();
            } else if (shippingStateInput && String(shippingStateInput.value || '').trim()) {
                locationQuery = String(shippingStateInput.value || '').trim();
            }
            let cityQuery = locationQuery;
            let districtQuery = locationQuery;
            let selectedCityId = currentCityId;
            let selectedDistrictId = currentDistrictId;
            let selectedNeighborhoodId = currentNeighborhoodId;
            if (locationSearchInput) {
                locationSearchInput.value = locationQuery;
            }

            function addOption(select, value, label, selected) {
                const opt = document.createElement('option');
                opt.value = value;
                opt.textContent = label;
                if (selected) opt.selected = true;
                select.appendChild(opt);
            }

            function debounce(fn, delay) {
                let t = null;
                return function() {
                    const args = arguments;
                    clearTimeout(t);
                    t = setTimeout(function() { fn.apply(null, args); }, delay);
                };
            }

            function searchLocations(query) {
                if (!locationResultsInput) return;
                const q = String(query || '').trim();
                if (q.length < 1) {
                    locationResultsInput.style.display = 'none';
                    locationResultsInput.innerHTML = '';
                    return;
                }
                locationResultsInput.style.display = 'block';
                locationResultsInput.innerHTML = '';
                addOption(locationResultsInput, '', 'Searching...', true);
                fetch(ajaxUrl + '?action=intigo_search_locations&q=' + encodeURIComponent(q) + '&_wpnonce=' + encodeURIComponent(nonce), { credentials: 'same-origin' })
                    .then(r => r.json())
                    .then(data => {
                        locationResultsInput.innerHTML = '';
                        if (!data || !data.success || !Array.isArray(data.data) || data.data.length === 0) {
                            addOption(locationResultsInput, '', 'No matching locations', true);
                            return;
                        }
                        data.data.forEach(function(item, idx) {
                            const opt = document.createElement('option');
                            opt.value = String(idx + 1);
                            opt.textContent = item.label || '';
                            opt.dataset.cityId = String(item.city_id || '');
                            opt.dataset.districtId = String(item.district_id || '');
                            opt.dataset.neighborhoodId = String(item.neighborhood_id || '');
                            locationResultsInput.appendChild(opt);
                        });
                    })
                    .catch(function() {
                        locationResultsInput.innerHTML = '';
                        addOption(locationResultsInput, '', 'Lookup failed', true);
                    });
            }

            function loadCities() {
                let url = ajaxUrl + '?action=intigo_get_cities&_wpnonce=' + encodeURIComponent(nonce);
                if (cityQuery) {
                    url += '&q=' + encodeURIComponent(cityQuery);
                }
                fetch(url, { credentials: 'same-origin' })
                    .then(r => r.json())
                    .then(data => {
                        if (!data || !data.success || !Array.isArray(data.data)) {
                            citySelect.innerHTML = '';
                            addOption(citySelect, '', 'Lookup failed: check API URL/key', true);
                            return;
                        }
                        citySelect.innerHTML = '';
                        addOption(citySelect, '', 'Select city', false);
                        if (data.data.length === 0) {
                            addOption(citySelect, '', 'No cities returned by API', true);
                            return;
                        }
                        data.data.forEach(c => addOption(citySelect, c.id, c.name, String(c.id) === String(selectedCityId)));
                        if (citySelect.value) {
                            loadDistricts(citySelect.value);
                        }
                    })
                    .catch(() => {
                        citySelect.innerHTML = '';
                        addOption(citySelect, '', 'Lookup failed: network/AJAX error', true);
                    });
            }

            function loadDistricts(cityId) {
                districtSelect.innerHTML = '';
                addOption(districtSelect, '', 'Loading districts...', false);
                let url = ajaxUrl + '?action=intigo_get_districts&city_id=' + encodeURIComponent(cityId) + '&_wpnonce=' + encodeURIComponent(nonce);
                if (districtQuery) {
                    url += '&q=' + encodeURIComponent(districtQuery);
                }
                fetch(url, { credentials: 'same-origin' })
                    .then(r => r.json())
                    .then(data => {
                        districtSelect.innerHTML = '';
                        addOption(districtSelect, '', 'Select district', false);
                        if (!data || !data.success || !Array.isArray(data.data)) {
                            districtSelect.innerHTML = '';
                            addOption(districtSelect, '', 'Lookup failed: check API URL/key', true);
                            return;
                        }
                        if (data.data.length === 0) {
                            districtSelect.innerHTML = '';
                            addOption(districtSelect, '', 'No districts for selected city', true);
                            neighborhoodSelect.innerHTML = '';
                            addOption(neighborhoodSelect, '', 'Select neighborhood', false);
                            return;
                        }
                        data.data.forEach(d => addOption(districtSelect, d.id, d.name, String(d.id) === String(selectedDistrictId)));
                        if (districtSelect.value) {
                            loadNeighborhoods(districtSelect.value);
                        }
                    })
                    .catch(() => {
                        districtSelect.innerHTML = '';
                        addOption(districtSelect, '', 'Lookup failed: network/AJAX error', true);
                    });
            }

            function loadNeighborhoods(districtId) {
                neighborhoodSelect.innerHTML = '';
                addOption(neighborhoodSelect, '', 'Loading neighborhoods...', false);
                fetch(ajaxUrl + '?action=intigo_get_neighborhoods&district_id=' + encodeURIComponent(districtId) + '&_wpnonce=' + encodeURIComponent(nonce), { credentials: 'same-origin' })
                    .then(r => r.json())
                    .then(data => {
                        neighborhoodSelect.innerHTML = '';
                        addOption(neighborhoodSelect, '', 'Select neighborhood', false);
                        if (!data || !data.success || !Array.isArray(data.data)) {
                            addOption(neighborhoodSelect, '', 'Lookup failed: check API URL/key', true);
                            return;
                        }
                        if (data.data.length === 0) {
                            addOption(neighborhoodSelect, '', 'No neighborhoods for selected district', true);
                            return;
                        }
                        data.data.forEach(n => addOption(neighborhoodSelect, n.id, n.name, String(n.id) === String(selectedNeighborhoodId)));
                    })
                    .catch(() => {
                        neighborhoodSelect.innerHTML = '';
                        addOption(neighborhoodSelect, '', 'Lookup failed: network/AJAX error', true);
                    });
            }

            citySelect.addEventListener('change', function() {
                if (!citySelect.value) {
                    districtSelect.innerHTML = '';
                    addOption(districtSelect, '', 'Select district', false);
                    neighborhoodSelect.innerHTML = '';
                    addOption(neighborhoodSelect, '', 'Select neighborhood', false);
                    return;
                }
                loadDistricts(citySelect.value);
            });

            districtSelect.addEventListener('change', function() {
                if (!districtSelect.value) {
                    neighborhoodSelect.innerHTML = '';
                    addOption(neighborhoodSelect, '', 'Select neighborhood', false);
                    return;
                }
                loadNeighborhoods(districtSelect.value);
            });
            if (locationSearchInput) {
                const handleLocationTyping = debounce(function() {
                    const raw = String(locationSearchInput.value || '').trim();
                    cityQuery = raw;
                    districtQuery = raw;
                    selectedCityId = '';
                    selectedDistrictId = '';
                    selectedNeighborhoodId = '';
                    searchLocations(raw);
                }, 250);
                locationSearchInput.addEventListener('input', handleLocationTyping);
            }
            if (locationResultsInput) {
                locationResultsInput.addEventListener('change', function() {
                    const opt = locationResultsInput.options[locationResultsInput.selectedIndex];
                    if (!opt) return;
                    selectedCityId = String(opt.dataset.cityId || '');
                    selectedDistrictId = String(opt.dataset.districtId || '');
                    selectedNeighborhoodId = String(opt.dataset.neighborhoodId || '');
                    loadCities();
                });
            }

            loadCities();
        })();
        </script>
        <?php
    }

    public function save_order_meta_box($post_id, $post) {
        if (!isset($_POST['intigo_order_meta_nonce_field']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['intigo_order_meta_nonce_field'])), 'intigo_order_meta_nonce')) {
            return;
        }
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        if (!$post || $post->post_type !== 'shop_order') {
            return;
        }
        if (!current_user_can('edit_post', $post_id) && !current_user_can('edit_shop_orders') && !current_user_can('manage_woocommerce')) {
            return;
        }
        $this->persist_intigo_order_meta_from_post($post_id);
    }

    public function save_order_meta_box_from_order_id($order_id) {
        $order_id = intval($order_id);
        if ($order_id <= 0) {
            return;
        }
        if (!isset($_POST['intigo_order_meta_nonce_field']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['intigo_order_meta_nonce_field'])), 'intigo_order_meta_nonce')) {
            return;
        }
        if (!current_user_can('edit_post', $order_id) && !current_user_can('edit_shop_orders') && !current_user_can('manage_woocommerce')) {
            return;
        }
        $this->persist_intigo_order_meta_from_post($order_id);
    }

    private function persist_intigo_order_meta_from_post($order_id) {
        $city_id = isset($_POST['intigo_city_id']) ? intval($_POST['intigo_city_id']) : 0;
        $district_id = isset($_POST['intigo_district_id']) ? intval($_POST['intigo_district_id']) : 0;
        $neighborhood_id = isset($_POST['intigo_neighborhood_id']) ? intval($_POST['intigo_neighborhood_id']) : 0;
        $package_size = isset($_POST['intigo_package_size']) ? strtoupper(sanitize_text_field(wp_unslash($_POST['intigo_package_size']))) : 'S';
        if ($city_id > 0 && $district_id <= 0) {
            $district_name = isset($_POST['intigo_district_query']) ? sanitize_text_field(wp_unslash($_POST['intigo_district_query'])) : '';
            if ($district_name === '') {
                $district_name = isset($_POST['_shipping_state']) ? sanitize_text_field(wp_unslash($_POST['_shipping_state'])) : '';
            }
            if ($district_name === '') {
                $district_name = isset($_POST['_billing_state']) ? sanitize_text_field(wp_unslash($_POST['_billing_state'])) : '';
            }
            $order = wc_get_order($order_id);
            $resolved = $this->resolve_district_id_with_order_context($order, $city_id, $district_name);
            if ($resolved > 0) {
                $district_id = $resolved;
            }
        }

        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }
        if ($city_id > 0) {
            $order->update_meta_data('_intigo_city_id', $city_id);
        } else {
            $order->delete_meta_data('_intigo_city_id');
        }
        if ($district_id > 0) {
            $order->update_meta_data('_intigo_district_id', $district_id);
        } else {
            $order->delete_meta_data('_intigo_district_id');
        }
        if ($neighborhood_id > 0) {
            $order->update_meta_data('_intigo_neighborhood_id', $neighborhood_id);
        } else {
            $order->delete_meta_data('_intigo_neighborhood_id');
        }
        $order->delete_meta_data('_intigo_district_name');
        $order->update_meta_data('_intigo_package_size', in_array($package_size, ['S', 'M', 'L', 'XL'], true) ? $package_size : 'S');
        $order->save();
    }

    private function resolve_district_id_with_order_context($order, $city_id, $district_query = '') {
        $city_id = intval($city_id);
        if ($city_id <= 0) {
            return 0;
        }
        $district_query = trim((string) $district_query);
        if ($district_query === '' && is_object($order)) {
            $district_query = trim((string) $order->get_shipping_state());
            if ($district_query === '') {
                $district_query = trim((string) $order->get_billing_state());
            }
        }
        if ($district_query !== '') {
            return intval($this->resolve_district_id_from_regions_api($city_id, $district_query));
        }
        return 0;
    }

    private function resolve_district_id_from_regions_api($city_id, $district_name) {
        $city_id = intval($city_id);
        $district_name = trim((string) $district_name);
        if ($city_id <= 0 || $district_name === '') {
            return 0;
        }
        $settings = $this->api_client->get_settings();
        $base = rtrim((string) ($settings['primary_base_url'] ?? ''), '/');
        if ($base === '') {
            return 0;
        }
        $url = $base . '/v3/regions/cities/' . rawurlencode((string) $city_id) . '/districts';
        $result = $this->fetch_lookup_items($url, $settings);
        if (!$result['ok'] || empty($result['items'])) {
            return 0;
        }
        $needle = strtolower($district_name);
        foreach ($result['items'] as $item) {
            if (!is_array($item) || empty($item['id']) || empty($item['name'])) {
                continue;
            }
            $name = strtolower((string) $item['name']);
            if ($name === $needle || strpos($name, $needle) !== false || strpos($needle, $name) !== false) {
                return intval($item['id']);
            }
        }
        return 0;
    }

    public function render_hpos_inline_fields($order) {
        if (!is_object($order) || !method_exists($order, 'get_id')) {
            return;
        }
        $order_id = intval($order->get_id());
        if ($order_id <= 0) {
            return;
        }
        echo '<div class="order_data_column" style="width:100%; clear:both; margin-top:12px; border-top:1px solid #ddd; padding-top:12px;">';
        echo '<h4>Intigo Shipment</h4>';
        $this->render_order_meta_box_fields($order_id);
        echo '</div>';
    }

    public function ajax_get_cities() {
        check_ajax_referer('intigo_lookup_nonce');
        $settings = $this->api_client->get_settings();
        $query = isset($_GET['q']) ? sanitize_text_field(wp_unslash($_GET['q'])) : '';

        $base = rtrim((string) ($settings['primary_base_url'] ?? ''), '/');
        $template = $base . '/v3/regions/cities';
        if ($base === '' || strpos($template, 'http') !== 0) {
            wp_send_json_error(['message' => 'primary_base_url is not configured'], 400);
        }

        $url = str_replace('{city}', '', $template);
        $result = $this->fetch_lookup_items($url, $settings);
        if (!$result['ok']) {
            $this->add_log('lookup_cities_failed', $result['error']);
            wp_send_json_error(['message' => $result['error']], 502);
        }
        $items = $result['items'];
        if ($query !== '') {
            $needle = strtolower($query);
            $items = array_values(array_filter($items, function($item) use ($needle) {
                return is_array($item) && isset($item['name']) && strpos(strtolower((string) $item['name']), $needle) !== false;
            }));
        }
        $this->add_log('lookup_cities_ok', 'count=' . count($items));
        wp_send_json_success($items);
    }

    public function ajax_get_districts() {
        check_ajax_referer('intigo_lookup_nonce');
        $city_id = isset($_GET['city_id']) ? intval($_GET['city_id']) : 0;
        $query = isset($_GET['q']) ? sanitize_text_field(wp_unslash($_GET['q'])) : '';
        if ($city_id <= 0) {
            wp_send_json_error(['message' => 'city_id is required'], 400);
        }

        $settings = $this->api_client->get_settings();

        $base = rtrim((string) ($settings['primary_base_url'] ?? ''), '/');
        $template = $base . '/v3/regions/cities/{city_id}/districts';
        if ($base === '' || strpos($template, 'http') !== 0) {
            wp_send_json_error(['message' => 'primary_base_url is not configured'], 400);
        }

        $url = str_replace('{district}', '', $template);
        $url = str_replace('{city_id}', rawurlencode((string) $city_id), $url);
        $result = $this->fetch_lookup_items($url, $settings);
        if (!$result['ok']) {
            $this->add_log('lookup_districts_failed', 'city_id=' . $city_id . '; ' . $result['error']);
            wp_send_json_error(['message' => $result['error']], 502);
        }
        $items = $result['items'];
        if ($query !== '') {
            $needle = strtolower($query);
            $items = array_values(array_filter($items, function($item) use ($needle) {
                return is_array($item) && isset($item['name']) && strpos(strtolower((string) $item['name']), $needle) !== false;
            }));
        }
        $this->add_log('lookup_districts_ok', 'city_id=' . $city_id . '; count=' . count($items));
        wp_send_json_success($items);
    }

    public function ajax_get_neighborhoods() {
        check_ajax_referer('intigo_lookup_nonce');
        $district_id = isset($_GET['district_id']) ? intval($_GET['district_id']) : 0;
        if ($district_id <= 0) {
            wp_send_json_error(['message' => 'district_id is required'], 400);
        }

        $settings = $this->api_client->get_settings();
        $base = rtrim((string) ($settings['primary_base_url'] ?? ''), '/');
        $template = $base . '/v3/regions/districts/{district_id}/neighborhoods';
        if ($base === '' || strpos($template, 'http') !== 0) {
            wp_send_json_error(['message' => 'primary_base_url is not configured'], 400);
        }

        $url = str_replace('{district_id}', rawurlencode((string) $district_id), $template);
        $result = $this->fetch_lookup_items($url, $settings);
        if (!$result['ok']) {
            $this->add_log('lookup_neighborhoods_failed', 'district_id=' . $district_id . '; ' . $result['error']);
            wp_send_json_error(['message' => $result['error']], 502);
        }
        $this->add_log('lookup_neighborhoods_ok', 'district_id=' . $district_id . '; count=' . count($result['items']));
        wp_send_json_success($result['items']);
    }

    public function ajax_search_locations() {
        check_ajax_referer('intigo_lookup_nonce');
        $query = isset($_GET['q']) ? sanitize_text_field(wp_unslash($_GET['q'])) : '';
        if ($query === '') {
            wp_send_json_success([]);
        }
        $settings = $this->api_client->get_settings();
        $location_result = $this->fetch_location_query_items($query);
        if (!$location_result['ok']) {
            wp_send_json_error(['message' => $location_result['error']], 502);
        }
        $items = $this->normalize_location_suggestions($location_result['items'], $settings);
        $this->add_log('lookup_locations_ok', 'q=' . $query . '; count=' . count($items));
        wp_send_json_success($items);
    }

    private function fetch_lookup_items($url, $settings) {
        $args = [
            'timeout' => 20,
            'headers' => [
                'Content-Type' => 'application/json',
                'X-API-KEY' => isset($settings['api_key']) ? $settings['api_key'] : '',
            ],
        ];
        $res = wp_remote_get($url, $args);
        if (is_wp_error($res)) {
            return ['ok' => false, 'error' => $res->get_error_message(), 'items' => []];
        }
        $code = wp_remote_retrieve_response_code($res);
        if (($code === 301 || $code === 302 || $code === 307 || $code === 308 || $code === 404) && substr($url, -1) !== '/') {
            $retry = wp_remote_get($url . '/', $args);
            if (!is_wp_error($retry)) {
                $retry_code = wp_remote_retrieve_response_code($retry);
                if ($retry_code >= 200 && $retry_code < 300) {
                    $res = $retry;
                    $code = $retry_code;
                }
            }
        }
        if ($code < 200 || $code >= 300) {
            $body = wp_remote_retrieve_body($res);
            return ['ok' => false, 'error' => 'HTTP ' . $code . ' ' . $body, 'items' => []];
        }
        $body = wp_remote_retrieve_body($res);
        $json = json_decode($body, true);
        if (!is_array($json)) {
            return ['ok' => false, 'error' => 'Invalid JSON response from lookup API', 'items' => []];
        }

        $rows = [];
        if (isset($json['data']) && is_array($json['data'])) {
            $rows = $json['data'];
        } elseif (isset($json['results']) && is_array($json['results'])) {
            $rows = $json['results'];
        } elseif (isset($json['cities']) && is_array($json['cities'])) {
            $rows = $json['cities'];
        } elseif (isset($json['districts']) && is_array($json['districts'])) {
            $rows = $json['districts'];
        } elseif (isset($json['neighborhoods']) && is_array($json['neighborhoods'])) {
            $rows = $json['neighborhoods'];
        } elseif (array_keys($json) === range(0, count($json) - 1)) {
            $rows = $json;
        }

        $out = [];
        foreach ($rows as $r) {
            if (!is_array($r) || !isset($r['id'])) {
                continue;
            }
            $name = '';
            if (isset($r['name'])) {
                $name = (string) $r['name'];
            } elseif (isset($r['city_name'])) {
                $name = (string) $r['city_name'];
            } elseif (isset($r['district_name'])) {
                $name = (string) $r['district_name'];
            } elseif (isset($r['neighborhood_name'])) {
                $name = (string) $r['neighborhood_name'];
            } elseif (isset($r['label'])) {
                $name = (string) $r['label'];
            } elseif (isset($r['title'])) {
                $name = (string) $r['title'];
            }
            if ($name === '') {
                continue;
            }
            $out[] = [
                'id' => intval($r['id']),
                'name' => $name,
            ];
        }
        return ['ok' => true, 'error' => '', 'items' => $out];
    }

    private function fetch_location_query_items($query) {
        $query = trim((string) $query);
        if ($query === '') {
            return ['ok' => false, 'error' => 'empty_query', 'items' => []];
        }
        $url = 'https://intishop.dannous.shop/parcels/api/public/locations/?q=' . rawurlencode($query);
        $res = wp_remote_get($url, [
            'timeout' => 20,
            'headers' => [
                'Content-Type' => 'application/json',
            ],
        ]);
        if (is_wp_error($res)) {
            return ['ok' => false, 'error' => $res->get_error_message(), 'items' => []];
        }
        $code = wp_remote_retrieve_response_code($res);
        if ($code < 200 || $code >= 300) {
            return ['ok' => false, 'error' => 'HTTP ' . $code, 'items' => []];
        }
        $body = wp_remote_retrieve_body($res);
        $json = json_decode($body, true);
        if (!is_array($json)) {
            return ['ok' => false, 'error' => 'Invalid JSON response from location query API', 'items' => []];
        }
        if (isset($json['results']) && is_array($json['results'])) {
            return ['ok' => true, 'error' => '', 'items' => $json['results']];
        }
        if (isset($json['data']) && is_array($json['data'])) {
            return ['ok' => true, 'error' => '', 'items' => $json['data']];
        }
        if (array_keys($json) === range(0, count($json) - 1)) {
            return ['ok' => true, 'error' => '', 'items' => $json];
        }
        return ['ok' => true, 'error' => '', 'items' => []];
    }

    private function normalize_location_suggestions($rows, $settings = []) {
        $out = [];
        $city_map = $this->build_city_name_id_map($settings);
        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }
            $city_id = 0;
            if (isset($row['city_id'])) {
                $city_id = intval($row['city_id']);
            } elseif (isset($row['city']) && is_array($row['city']) && isset($row['city']['id'])) {
                $city_id = intval($row['city']['id']);
            } elseif (isset($row['city']) && !is_array($row['city']) && is_numeric($row['city'])) {
                $city_id = intval($row['city']);
            }

            $district_id = 0;
            if (isset($row['district_id'])) {
                $district_id = intval($row['district_id']);
            } elseif (isset($row['district']) && is_array($row['district']) && isset($row['district']['id'])) {
                $district_id = intval($row['district']['id']);
            } elseif (isset($row['district']) && !is_array($row['district']) && is_numeric($row['district'])) {
                $district_id = intval($row['district']);
            }

            $neighborhood_id = 0;
            if (isset($row['neighborhood_id'])) {
                $neighborhood_id = intval($row['neighborhood_id']);
            } elseif (isset($row['neighborhood']) && is_array($row['neighborhood']) && isset($row['neighborhood']['id'])) {
                $neighborhood_id = intval($row['neighborhood']['id']);
            } elseif (isset($row['neighborhood']) && !is_array($row['neighborhood']) && is_numeric($row['neighborhood'])) {
                $neighborhood_id = intval($row['neighborhood']);
            }

            $city_name = '';
            if (isset($row['city_name'])) {
                $city_name = (string) $row['city_name'];
            } elseif (isset($row['city']) && is_array($row['city']) && isset($row['city']['name'])) {
                $city_name = (string) $row['city']['name'];
            } elseif (isset($row['name'])) {
                $city_name = $this->extract_city_name_from_label((string) $row['name']);
            }
            if ($city_id <= 0 && $city_name !== '') {
                $city_name_key = strtolower(trim($city_name));
                if (isset($city_map[$city_name_key])) {
                    $city_id = intval($city_map[$city_name_key]);
                }
            }

            $district_name = '';
            if (isset($row['district_name'])) {
                $district_name = (string) $row['district_name'];
            } elseif (isset($row['district']) && is_array($row['district']) && isset($row['district']['name'])) {
                $district_name = (string) $row['district']['name'];
            }

            $neighborhood_name = '';
            if (isset($row['neighborhood_name'])) {
                $neighborhood_name = (string) $row['neighborhood_name'];
            } elseif (isset($row['neighborhood']) && is_array($row['neighborhood']) && isset($row['neighborhood']['name'])) {
                $neighborhood_name = (string) $row['neighborhood']['name'];
            }

            if ($city_id <= 0) {
                continue;
            }
            $parts = [];
            if ($city_name !== '') {
                $parts[] = $city_name;
            }
            if ($district_name !== '') {
                $parts[] = $district_name;
            }
            if ($neighborhood_name !== '') {
                $parts[] = $neighborhood_name;
            }
            $label = implode(' / ', $parts);
            if ($label === '') {
                $label = 'City #' . $city_id;
            }
            $out[] = [
                'label' => $label,
                'city_id' => $city_id,
                'district_id' => $district_id,
                'neighborhood_id' => $neighborhood_id,
            ];
            if (count($out) >= 20) {
                break;
            }
        }
        return $out;
    }

    private function build_city_name_id_map($settings) {
        $map = [];
        $base = rtrim((string) ($settings['primary_base_url'] ?? ''), '/');
        if ($base === '') {
            return $map;
        }
        $url = $base . '/v3/regions/cities';
        $result = $this->fetch_lookup_items($url, $settings);
        if (!$result['ok'] || empty($result['items'])) {
            return $map;
        }
        foreach ($result['items'] as $item) {
            if (!is_array($item) || !isset($item['id']) || !isset($item['name'])) {
                continue;
            }
            $key = strtolower(trim((string) $item['name']));
            if ($key === '') {
                continue;
            }
            $map[$key] = intval($item['id']);
        }
        return $map;
    }

    private function extract_city_name_from_label($label) {
        $label = trim((string) $label);
        if ($label === '') {
            return '';
        }
        if (preg_match('/\(([^)]+)\)\s*$/', $label, $m)) {
            return trim((string) $m[1]);
        }
        return '';
    }

    private function normalize_cities_from_location_items($rows) {
        $out = [];
        $seen = [];
        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }
            $city_id = 0;
            if (isset($row['city_id'])) {
                $city_id = intval($row['city_id']);
            } elseif (isset($row['city']) && is_array($row['city']) && isset($row['city']['id'])) {
                $city_id = intval($row['city']['id']);
            } elseif (isset($row['city']) && !is_array($row['city']) && is_numeric($row['city'])) {
                $city_id = intval($row['city']);
            }
            if ($city_id <= 0 || isset($seen[$city_id])) {
                continue;
            }
            $name = '';
            if (isset($row['city_name'])) {
                $name = (string) $row['city_name'];
            } elseif (isset($row['city']) && is_array($row['city']) && isset($row['city']['name'])) {
                $name = (string) $row['city']['name'];
            } elseif (isset($row['name'])) {
                $name = (string) $row['name'];
            }
            if ($name === '') {
                continue;
            }
            $seen[$city_id] = true;
            $out[] = ['id' => $city_id, 'name' => $name];
        }
        return $out;
    }

    private function normalize_districts_from_location_items($rows, $city_id = 0) {
        $out = [];
        $seen = [];
        $city_id = intval($city_id);
        foreach ($rows as $row) {
            if (!is_array($row)) {
                continue;
            }
            $row_city_id = 0;
            if (isset($row['city_id'])) {
                $row_city_id = intval($row['city_id']);
            } elseif (isset($row['city']) && is_array($row['city']) && isset($row['city']['id'])) {
                $row_city_id = intval($row['city']['id']);
            } elseif (isset($row['city']) && !is_array($row['city']) && is_numeric($row['city'])) {
                $row_city_id = intval($row['city']);
            }
            if ($city_id > 0 && $row_city_id > 0 && $row_city_id !== $city_id) {
                continue;
            }
            $district_id = 0;
            if (isset($row['district_id'])) {
                $district_id = intval($row['district_id']);
            } elseif (isset($row['district']) && is_array($row['district']) && isset($row['district']['id'])) {
                $district_id = intval($row['district']['id']);
            } elseif (isset($row['district']) && !is_array($row['district']) && is_numeric($row['district'])) {
                $district_id = intval($row['district']);
            }
            if ($district_id <= 0 || isset($seen[$district_id])) {
                continue;
            }
            $name = '';
            if (isset($row['district_name'])) {
                $name = (string) $row['district_name'];
            } elseif (isset($row['district']) && is_array($row['district']) && isset($row['district']['name'])) {
                $name = (string) $row['district']['name'];
            } elseif (isset($row['name'])) {
                $name = (string) $row['name'];
            }
            if ($name === '') {
                continue;
            }
            $seen[$district_id] = true;
            $out[] = ['id' => $district_id, 'name' => $name];
        }
        return $out;
    }

    public function handle_download_bordereau() {
        if (!$this->is_intigo_logged_in()) {
            $this->add_log('download_bordereau_blocked', 'not_logged_in');
            $this->redirect_with_notice('intigo-dashboard', 'Please login to Intigo first.', 'warning');
            exit;
        }
        if (!current_user_can('edit_shop_orders') && !current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized');
        }
        $order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;
        if ($order_id <= 0) {
            wp_die('Invalid order id');
        }
        check_admin_referer('intigo_download_bordereau_' . $order_id);

        $order = wc_get_order($order_id);
        if (!$order) {
            wp_die('Order not found');
        }

        $url = (string) $order->get_meta('_intigo_bordereau_url');
        if ($url === '') {
            wp_die('No bordereau URL found for this order');
        }
        $this->add_log('download_bordereau_requested', 'order_id=' . $order_id);

        $res = wp_remote_get($url, ['timeout' => 60]);
        if (is_wp_error($res)) {
            wp_die('Download failed: ' . esc_html($res->get_error_message()));
        }

        $code = wp_remote_retrieve_response_code($res);
        if ($code < 200 || $code >= 300) {
            wp_die('Download failed: HTTP ' . intval($code));
        }

        $body = wp_remote_retrieve_body($res);
        if ($body === '') {
            wp_die('Download failed: empty response');
        }

        $filename_nid = (string) $order->get_meta('_intigo_parcel_nid');
        if ($filename_nid === '') {
            $filename_nid = 'order-' . $order_id;
        }
        $filename = 'bordereau-' . sanitize_file_name($filename_nid) . '.html';

        nocache_headers();
        header('Content-Type: text/html; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        echo $body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        exit;
    }

    public function handle_intigo_order_action() {
        if (!$this->is_intigo_logged_in()) {
            $this->add_log('order_action_blocked', 'not_logged_in');
            $this->redirect_with_notice('intigo-dashboard', 'Please login to Intigo first.', 'warning');
            exit;
        }
        if (!current_user_can('edit_shop_orders') && !current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized');
        }
        $order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;
        $op = isset($_GET['op']) ? sanitize_text_field(wp_unslash($_GET['op'])) : '';
        if ($order_id <= 0 || $op === '') {
            wp_die('Invalid request');
        }
        if ($op === 'save_metadata') {
            check_admin_referer('intigo_order_action_meta_edit');
        } else {
            check_admin_referer('intigo_order_action_' . $order_id . '_' . $op);
        }
        $order = wc_get_order($order_id);
        if (!$order) {
            wp_die('Order not found');
        }

        $notice = 'Action completed';
        $notice_type = 'success';
        if ($op === 'create') {
            $this->order_service->create_single_for_order($order);
            $notice = 'Order #' . $order_id . ': sent to Intigo.';
            $this->add_log('order_create_parcel', 'order_id=' . $order_id);
        } elseif ($op === 'bordereau') {
            $this->order_service->generate_bordereau_for_order($order);
            $notice = 'Order #' . $order_id . ': bordereau generated. Download/Print is now available when URL is returned.';
            $this->add_log('order_generate_bordereau', 'order_id=' . $order_id);
        } elseif ($op === 'sync_update') {
            $nid = (string) $order->get_meta('_intigo_parcel_nid');
            if ($nid === '') {
                $notice = 'Sync skipped: create parcel in Intigo first.';
                $notice_type = 'warning';
            } else {
                $sync_res = $this->order_service->update_parcel_for_order($order);
                if (!empty($sync_res['ok'])) {
                    $notice = 'Order #' . $order_id . ': synchronized with Intigo.';
                    $this->add_log('order_sync_update', 'order_id=' . $order_id);
                } else {
                    if (!empty($sync_res['locked'])) {
                        $notice = 'Order #' . $order_id . ': parcel is locked in Intigo (already delivered or return). Sync is skipped.';
                        $notice_type = 'warning';
                        $this->add_log('order_sync_update_locked', 'order_id=' . $order_id . '; error=' . ($sync_res['message'] ?? 'locked'));
                    } else {
                        $notice = 'Sync failed for order #' . $order_id . ': ' . ($sync_res['message'] ?? 'unknown error');
                        $notice_type = 'error';
                        $this->add_log('order_sync_update_failed', 'order_id=' . $order_id . '; error=' . ($sync_res['message'] ?? 'unknown'));
                    }
                }
            }
        } elseif ($op === 'cancel') {
            $nid = (string) $order->get_meta('_intigo_parcel_nid');
            if ($nid === '') {
                $notice = 'Cancel skipped: no Intigo parcel ID found.';
                $notice_type = 'warning';
            } else {
                $res = $this->api_client->cancel_parcel($nid);
                if (!empty($res['ok'])) {
                    $notice = 'Order #' . $order_id . ': parcel cancelled successfully.';
                    $this->add_log('order_cancel', 'order_id=' . $order_id . '; nid=' . $nid);
                } else {
                    $notice = 'Cancel failed for order #' . $order_id . '.';
                    $notice_type = 'error';
                    $this->add_log('order_cancel_failed', 'order_id=' . $order_id . '; nid=' . $nid);
                }
            }
        } elseif ($op === 'relance') {
            $nid = (string) $order->get_meta('_intigo_parcel_nid');
            if ($nid === '') {
                $notice = 'Relance skipped: no Intigo parcel ID found.';
                $notice_type = 'warning';
            } else {
                $res = $this->api_client->relance_parcel($nid, false);
                if (!empty($res['ok'])) {
                    $notice = 'Order #' . $order_id . ': relance requested.';
                    $this->add_log('order_relance', 'order_id=' . $order_id . '; nid=' . $nid);
                } else {
                    $notice = 'Relance failed for order #' . $order_id . '.';
                    $notice_type = 'error';
                    $this->add_log('order_relance_failed', 'order_id=' . $order_id . '; nid=' . $nid);
                }
            }
        } elseif ($op === 'report_delay') {
            $nid = (string) $order->get_meta('_intigo_parcel_nid');
            if ($nid === '') {
                $notice = 'Report delay skipped: no Intigo parcel ID found.';
                $notice_type = 'warning';
            } else {
                $res = $this->api_client->report_delay($nid, 'Reported from WooCommerce Intigo plugin');
                if (!empty($res['ok'])) {
                    $notice = 'Order #' . $order_id . ': delay reported successfully.';
                    $this->add_log('order_report_delay', 'order_id=' . $order_id . '; nid=' . $nid);
                } else {
                    $notice = 'Report delay failed for order #' . $order_id . '.';
                    $notice_type = 'error';
                    $this->add_log('order_report_delay_failed', 'order_id=' . $order_id . '; nid=' . $nid);
                }
            }
        } elseif ($op === 'save_metadata') {
            $city_id = isset($_GET['intigo_city_id']) ? intval($_GET['intigo_city_id']) : 0;
            $district_id = isset($_GET['intigo_district_id']) ? intval($_GET['intigo_district_id']) : 0;
            $neighborhood_id = isset($_GET['intigo_neighborhood_id']) ? intval($_GET['intigo_neighborhood_id']) : 0;
            $phone = isset($_GET['intigo_phone']) ? sanitize_text_field(wp_unslash($_GET['intigo_phone'])) : '';
            $district_query = isset($_GET['intigo_district_query']) ? sanitize_text_field(wp_unslash($_GET['intigo_district_query'])) : '';
            $package_size = isset($_GET['intigo_package_size']) ? strtoupper(sanitize_text_field(wp_unslash($_GET['intigo_package_size']))) : 'S';
            if ($city_id > 0 && $district_id <= 0) {
                if ($district_query === '' && is_object($order)) {
                    $district_query = trim((string) $order->get_shipping_state());
                    if ($district_query === '') {
                        $district_query = trim((string) $order->get_billing_state());
                    }
                }
                $resolved = $this->resolve_district_id_with_order_context($order, $city_id, $district_query);
                if ($resolved > 0) {
                    $district_id = $resolved;
                }
            }
            if ($city_id <= 0 || $district_id <= 0 || $phone === '') {
                $notice = 'Metadata save failed: city_id, district_id and phone are required.';
                $notice_type = 'error';
                $this->add_log('order_metadata_save_failed', 'order_id=' . $order_id . '; missing city_id/district_id/phone');
            } else {
                if (!in_array($package_size, ['S', 'M', 'L', 'XL'], true)) {
                    $package_size = 'S';
                }
                if (is_object($order)) {
                    $order->update_meta_data('_intigo_city_id', $city_id);
                    $order->update_meta_data('_intigo_district_id', $district_id);
                    if ($neighborhood_id > 0) {
                        $order->update_meta_data('_intigo_neighborhood_id', $neighborhood_id);
                    } else {
                        $order->delete_meta_data('_intigo_neighborhood_id');
                    }
                    $order->update_meta_data('_intigo_package_size', $package_size);
                    if (method_exists($order, 'set_billing_phone')) {
                        $order->set_billing_phone($phone);
                    }
                    $order->save();
                }
                $notice = 'Order #' . $order_id . ': Intigo metadata updated.';
                $this->add_log('order_metadata_saved', 'order_id=' . $order_id . '; city=' . $city_id . '; district=' . $district_id . '; phone=updated');
            }
        }

        $this->redirect_with_notice('intigo-manage-orders', $notice, $notice_type);
        exit;
    }

    public function handle_intigo_login() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized');
        }
        check_admin_referer('intigo_login');
        $label = isset($_POST['intigo_login_label']) ? sanitize_text_field(wp_unslash($_POST['intigo_login_label'])) : '';
        $api_key = isset($_POST['intigo_login_api_key']) ? sanitize_text_field(wp_unslash($_POST['intigo_login_api_key'])) : '';
        if ($api_key === '') {
            $this->add_log('login_failed', 'missing_api_key');
            $this->redirect_with_notice('intigo-dashboard', 'API key is required to login.', 'error');
            exit;
        }

        $settings = $this->api_client->get_settings();
        $settings['api_key'] = $api_key;
        update_option(Intigo_API_Client::OPTION_KEY, $settings);
        $health = $this->check_health();
        if (!$health['ok']) {
            $this->add_log('login_failed', $health['message']);
            $this->redirect_with_notice('intigo-dashboard', 'Login failed: ' . $health['message'], 'error');
            exit;
        }

        update_option(self::OPTION_AUTH, [
            'logged_in' => 'yes',
            'label' => $label !== '' ? $label : wp_get_current_user()->display_name,
            'user_id' => get_current_user_id(),
            'logged_at' => current_time('mysql'),
        ]);
        $this->add_log('login_success', 'user_id=' . get_current_user_id());
        $this->redirect_with_notice('intigo-dashboard', 'Logged in to Intigo successfully.', 'success');
        exit;
    }

    public function handle_intigo_logout() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized');
        }
        check_admin_referer('intigo_logout');
        delete_option(self::OPTION_AUTH);
        $this->add_log('logout', 'user_id=' . get_current_user_id());
        $this->redirect_with_notice('intigo-dashboard', 'Logged out from Intigo.', 'info');
        exit;
    }

    private function render_login_interface($message = '') {
        $notice = $this->get_notice_message();
        ?>
        <div class="wrap">
            <?php $this->render_snackbar(); ?>
            <style>
                .intigo-login-shell { display:flex; justify-content:center; padding:32px 16px; }
                .intigo-login-card { width:100%; max-width:480px; background:#fff; border:1px solid #e2e8f0; border-radius:18px; box-shadow:0 18px 48px rgba(15,23,42,.08); overflow:hidden; }
                .intigo-login-header { padding:28px 28px 20px 28px; text-align:center; background:linear-gradient(180deg, #f0f7ff 0%, #fff 100%); border-bottom:1px solid #f1f5f9; }
                .intigo-login-mark { width:56px; height:56px; margin:0 auto 12px auto; border-radius:14px; background:#2271b1; color:#fff; display:flex; align-items:center; justify-content:center; box-shadow:0 6px 16px rgba(34,113,177,.30); }
                .intigo-login-mark .dashicons { font-size:30px; width:30px; height:30px; }
                .intigo-login-title { margin:0; font-size:20px; font-weight:700; color:#0f172a; }
                .intigo-login-sub { margin:6px 0 0 0; color:#475569; font-size:13px; }
                .intigo-login-body { padding:24px 28px 28px 28px; }
                .intigo-login-row { margin-bottom:14px; }
                .intigo-login-row label { display:block; font-size:13px; font-weight:600; color:#0f172a; margin-bottom:6px; }
                .intigo-login-row input { width:100%; min-height:40px; padding:0 12px; border:1px solid #c7d2dc; border-radius:10px; font-size:14px; background:#fbfdff; }
                .intigo-login-row input:focus { border-color:#2271b1; box-shadow:0 0 0 3px rgba(34,113,177,.15); outline:none; background:#fff; }
                .intigo-login-row .intigo-login-hint { color:#64748b; font-size:12px; margin-top:6px; }
                .intigo-login-submit { width:100%; padding:12px 16px; background:#2271b1; color:#fff; border:0; border-radius:10px; font-size:14px; font-weight:600; cursor:pointer; transition:background .15s ease; }
                .intigo-login-submit:hover { background:#1d63a0; }
                .intigo-login-notice { margin:0 28px 20px 28px; padding:10px 12px; border-radius:10px; background:#fff7e6; border:1px solid #fde68a; color:#92400e; font-size:13px; }
                .intigo-login-foot { padding:14px 28px; background:#f8fafc; color:#64748b; font-size:12px; text-align:center; border-top:1px solid #f1f5f9; }
                .intigo-login-foot a { color:#2271b1; text-decoration:none; }
                .intigo-login-foot a:hover { text-decoration:underline; }
            </style>
            <div class="intigo-login-shell">
                <div class="intigo-login-card">
                    <div class="intigo-login-header">
                        <div class="intigo-login-mark"><span class="dashicons dashicons-location-alt"></span></div>
                        <h1 class="intigo-login-title">Sign in to Intigo</h1>
                        <p class="intigo-login-sub">Connect this WooCommerce store so you can create parcels, bordereaux and sync orders.</p>
                    </div>
                    <?php if ($message !== ''): ?>
                        <div class="intigo-login-notice"><?php echo esc_html($message); ?></div>
                    <?php endif; ?>
                    <div class="intigo-login-body">
                        <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                            <input type="hidden" name="action" value="intigo_login">
                            <?php wp_nonce_field('intigo_login'); ?>
                            <div class="intigo-login-row">
                                <label for="intigo_login_label">Display name</label>
                                <input id="intigo_login_label" name="intigo_login_label" type="text" placeholder="e.g. Operations Team" autocomplete="off">
                                <div class="intigo-login-hint">Shown in audit logs and notices. Optional.</div>
                            </div>
                            <div class="intigo-login-row">
                                <label for="intigo_login_api_key">Intigo API key</label>
                                <input id="intigo_login_api_key" name="intigo_login_api_key" type="password" required placeholder="Paste your API key" autocomplete="off">
                                <div class="intigo-login-hint">Find this in your Intigo partner dashboard. Keep it secret.</div>
                            </div>
                            <button type="submit" class="intigo-login-submit">Sign in</button>
                        </form>
                    </div>
                    <div class="intigo-login-foot">
                        Need a key? Contact your Intigo partner manager.
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    private function is_intigo_logged_in() {
        $auth = get_option(self::OPTION_AUTH, []);
        return is_array($auth) && (($auth['logged_in'] ?? 'no') === 'yes');
    }

    private function get_intigo_login_label() {
        $auth = get_option(self::OPTION_AUTH, []);
        if (is_array($auth) && !empty($auth['label'])) {
            return (string) $auth['label'];
        }
        $u = wp_get_current_user();
        return $u && !empty($u->display_name) ? (string) $u->display_name : 'User';
    }

    private function render_processing_mode_banner() {
        $settings = $this->api_client->get_settings();
        $is_auto = ($settings['auto_create_on_paid'] ?? 'no') === 'yes';
        $settings_url = admin_url('admin.php?page=intigo-parcels-settings');
        if ($is_auto) {
            echo '<div class="intigo-alert intigo-alert--info">'
                . '<span class="intigo-alert-icon"><span class="dashicons dashicons-update-alt"></span></span>'
                . '<span class="intigo-alert-body"><strong>Mode: Automatic.</strong> Orders are pushed to Intigo automatically when WooCommerce marks them as <em>Processing</em>.</span>'
                . '<span class="intigo-alert-actions"><a class="button button-small" href="' . esc_url($settings_url) . '">Change mode</a></span>'
                . '</div>';
            return;
        }
        echo '<div class="intigo-alert intigo-alert--warn">'
            . '<span class="intigo-alert-icon"><span class="dashicons dashicons-visibility"></span></span>'
            . '<span class="intigo-alert-body"><strong>Mode: Manual.</strong> Review each order below and click <strong>Send to Intigo</strong> when you are ready to ship.</span>'
            . '<span class="intigo-alert-actions"><a class="button button-small" href="' . esc_url($settings_url) . '">Change mode</a></span>'
            . '</div>';
    }

    private function render_environment_badge() {
        $settings = $this->api_client->get_settings();
        $mode = ($settings['environment_mode'] ?? 'sandbox') === 'production' ? 'production' : 'sandbox';
        if ($mode === 'sandbox') {
            echo '<div class="intigo-alert intigo-alert--warn">'
                . '<span class="intigo-alert-icon"><span class="dashicons dashicons-warning"></span></span>'
                . '<span class="intigo-alert-body"><strong>Testing mode.</strong> Sandbox environment is active &mdash; no live shipments are produced.</span>'
                . '</div>';
            return;
        }
        echo '<div class="intigo-alert intigo-alert--success">'
            . '<span class="intigo-alert-icon"><span class="dashicons dashicons-yes"></span></span>'
            . '<span class="intigo-alert-body"><strong>Production mode.</strong> Live environment &mdash; real shipments may be created.</span>'
            . '</div>';
    }

    private function render_page_header($title, $subtitle = '', $eyebrow = '', $extra_pills = '') {
        $settings = $this->api_client->get_settings();
        $env = ($settings['environment_mode'] ?? 'sandbox') === 'production' ? 'production' : 'sandbox';
        $health = $this->check_health();
        $health_class = $health['ok'] ? 'intigo-pill-ok' : 'intigo-pill-err';
        $health_label = $health['ok'] ? 'API connected' : 'API issue';
        $env_class = $env === 'production' ? 'intigo-pill-info' : 'intigo-pill-warn';
        $env_label = $env === 'production' ? 'Production' : 'Sandbox';
        ?>
        <div class="intigo-hero">
            <div class="intigo-hero-text">
                <?php if ($eyebrow !== ''): ?>
                    <span class="intigo-hero-eyebrow"><?php echo esc_html($eyebrow); ?></span>
                <?php endif; ?>
                <h1><?php echo esc_html($title); ?></h1>
                <?php if ($subtitle !== ''): ?>
                    <p><?php echo wp_kses_post($subtitle); ?></p>
                <?php endif; ?>
            </div>
            <div class="intigo-hero-meta">
                <span class="intigo-pill-status <?php echo esc_attr($health_class); ?>" title="<?php echo esc_attr($health['message']); ?>">
                    <span class="intigo-dot"></span><?php echo esc_html($health_label); ?>
                </span>
                <span class="intigo-pill-status <?php echo esc_attr($env_class); ?>">
                    <span class="intigo-dot"></span><?php echo esc_html($env_label); ?>
                </span>
                <span class="intigo-pill-status intigo-pill-version" title="<?php esc_attr_e('Installed plugin version', 'intigo-parcels'); ?>">
                    <span class="dashicons dashicons-tag" style="font-size:14px; width:14px; height:14px;"></span>v<?php echo esc_html(defined('INTIGO_PARCELS_VERSION') ? INTIGO_PARCELS_VERSION : ''); ?>
                </span>
                <?php if ($extra_pills !== ''): ?>
                    <?php echo $extra_pills; ?>
                <?php endif; ?>
            </div>
        </div>
        <?php
    }

    private function get_notice_message() {
        return isset($_GET['intigo_notice']) ? sanitize_text_field(wp_unslash($_GET['intigo_notice'])) : '';
    }

    private function get_notice_type() {
        $type = isset($_GET['intigo_notice_type']) ? sanitize_text_field(wp_unslash($_GET['intigo_notice_type'])) : 'info';
        return in_array($type, ['success', 'error', 'warning', 'info'], true) ? $type : 'info';
    }

    private function redirect_with_notice($page, $message, $type = 'info') {
        wp_safe_redirect(add_query_arg([
            'page' => $page,
            'intigo_notice' => rawurlencode((string) $message),
            'intigo_notice_type' => rawurlencode((string) $type),
        ], admin_url('admin.php')));
    }

    private function render_snackbar() {
        $message = $this->get_notice_message();
        if ($message === '') {
            return;
        }
        $type = $this->get_notice_type();
        $rail_color = '#2271b1';
        $icon = 'dashicons-info-outline';
        $title = 'Notice';
        if ($type === 'success') {
            $rail_color = '#16a34a';
            $icon = 'dashicons-yes-alt';
            $title = 'Success';
        } elseif ($type === 'error') {
            $rail_color = '#dc2626';
            $icon = 'dashicons-warning';
            $title = 'Error';
        } elseif ($type === 'warning') {
            $rail_color = '#d97706';
            $icon = 'dashicons-warning';
            $title = 'Heads up';
        }
        ?>
        <style>
            #intigo-snackbar { position:fixed; right:24px; bottom:24px; z-index:100100; min-width:300px; max-width:440px; background:#0f172a; color:#fff; padding:0; border-radius:14px; box-shadow:0 18px 48px rgba(15,23,42,.35); overflow:hidden; transform:translateY(16px); opacity:0; transition: transform .3s cubic-bezier(.2,.9,.3,1.2), opacity .25s ease; }
            #intigo-snackbar.is-visible { transform:translateY(0); opacity:1; }
            #intigo-snackbar .intigo-sn-rail { position:absolute; left:0; top:0; bottom:0; width:4px; background:<?php echo esc_attr($rail_color); ?>; }
            #intigo-snackbar .intigo-sn-inner { display:flex; gap:12px; padding:14px 16px 14px 20px; align-items:flex-start; }
            #intigo-snackbar .intigo-sn-icon { flex:0 0 auto; width:28px; height:28px; border-radius:50%; background:<?php echo esc_attr($rail_color); ?>; display:flex; align-items:center; justify-content:center; color:#fff; }
            #intigo-snackbar .intigo-sn-icon .dashicons { font-size:16px; width:16px; height:16px; }
            #intigo-snackbar .intigo-sn-text { flex:1 1 auto; min-width:0; }
            #intigo-snackbar .intigo-sn-title { display:block; font-weight:600; font-size:13px; margin-bottom:2px; color:#fff; }
            #intigo-snackbar .intigo-sn-msg { display:block; font-size:13px; color:#cbd5e1; line-height:1.45; }
            #intigo-snackbar .intigo-sn-close { flex:0 0 auto; background:transparent; border:0; color:#94a3b8; cursor:pointer; padding:4px; line-height:0; border-radius:6px; }
            #intigo-snackbar .intigo-sn-close:hover { color:#fff; background:rgba(255,255,255,.06); }
            #intigo-snackbar .intigo-sn-progress { height:2px; background:rgba(255,255,255,.08); position:relative; }
            #intigo-snackbar .intigo-sn-progress::after { content:''; position:absolute; left:0; top:0; bottom:0; width:100%; background:<?php echo esc_attr($rail_color); ?>; transform-origin:left; animation: intigoSnTick 4.5s linear forwards; }
            @keyframes intigoSnTick { from { transform:scaleX(1); } to { transform:scaleX(0); } }
            @media (max-width: 600px) { #intigo-snackbar { right:12px; left:12px; bottom:12px; max-width:none; } }
        </style>
        <div id="intigo-snackbar" role="status" aria-live="polite">
            <span class="intigo-sn-rail"></span>
            <div class="intigo-sn-inner">
                <span class="intigo-sn-icon"><span class="dashicons <?php echo esc_attr($icon); ?>"></span></span>
                <div class="intigo-sn-text">
                    <span class="intigo-sn-title"><?php echo esc_html($title); ?></span>
                    <span class="intigo-sn-msg"><?php echo esc_html($message); ?></span>
                </div>
                <button type="button" class="intigo-sn-close" aria-label="Dismiss"><span class="dashicons dashicons-no-alt"></span></button>
            </div>
            <div class="intigo-sn-progress"></div>
        </div>
        <script>
        (function() {
            const sb = document.getElementById('intigo-snackbar');
            if (!sb) return;
            requestAnimationFrame(() => sb.classList.add('is-visible'));
            const close = () => {
                sb.classList.remove('is-visible');
                setTimeout(() => { if (sb.parentNode) sb.parentNode.removeChild(sb); }, 320);
            };
            const btn = sb.querySelector('.intigo-sn-close');
            if (btn) btn.addEventListener('click', close);
            setTimeout(close, 4500);
        })();
        </script>
        <?php
    }

    private function render_interface_nav($current_page) {
        $items = [
            'intigo-dashboard' => ['label' => 'Dashboard', 'icon' => 'dashicons-chart-area'],
            'intigo-manage-orders' => ['label' => 'Manage Orders', 'icon' => 'dashicons-cart'],
            'intigo-logs' => ['label' => 'Logs', 'icon' => 'dashicons-list-view'],
            'intigo-docs' => ['label' => 'Documentation', 'icon' => 'dashicons-book-alt'],
            'intigo-parcels-settings' => ['label' => 'Settings', 'icon' => 'dashicons-admin-generic'],
        ];
        $new_count = $this->get_new_orders_count();
        ?>
        <style>
            .intigo-nav { display:flex; gap:2px; flex-wrap:wrap; margin:6px 0 18px 0; padding:0; border-bottom:1px solid #e2e8f0; }
            .intigo-nav a { display:inline-flex; align-items:center; gap:8px; padding:10px 14px; border-radius:8px 8px 0 0; color:#475569; font-weight:600; font-size:13px; text-decoration:none; border:1px solid transparent; border-bottom:0; position:relative; bottom:-1px; transition:color .15s ease, background .15s ease; }
            .intigo-nav a:hover { color:#0f172a; background:#f8fafc; }
            .intigo-nav a.is-active { color:#0f172a; background:#fff; border-color:#e2e8f0; }
            .intigo-nav a.is-active::after { content:''; position:absolute; left:14px; right:14px; bottom:1px; height:2px; background:#2271b1; border-radius:2px; }
            .intigo-nav a .dashicons { width:16px; height:16px; font-size:16px; }
            .intigo-nav-badge { display:inline-flex; align-items:center; justify-content:center; min-width:20px; height:20px; padding:0 6px; background:#2271b1; color:#fff; border-radius:999px; font-size:11px; font-weight:700; }
            @media (max-width: 600px) { .intigo-nav a { padding:8px 10px; font-size:12px; } }
        </style>
        <nav class="intigo-nav" aria-label="Intigo sections">
            <?php foreach ($items as $slug => $item):
                $is_active = $slug === $current_page;
                $url = admin_url('admin.php?page=' . $slug);
                ?>
                <a class="<?php echo $is_active ? 'is-active' : ''; ?>" href="<?php echo esc_url($url); ?>">
                    <span class="dashicons <?php echo esc_attr($item['icon']); ?>"></span>
                    <?php echo esc_html($item['label']); ?>
                    <?php if ($slug === 'intigo-manage-orders' && $new_count > 0): ?>
                        <span class="intigo-nav-badge" title="<?php echo esc_attr($new_count . ' new orders'); ?>"><?php echo esc_html($new_count); ?></span>
                    <?php endif; ?>
                </a>
            <?php endforeach; ?>
        </nav>
        <?php
    }

    private function render_responsive_styles() {
        ?>
        <style>
            :root {
                --intigo-primary: #2271b1;
                --intigo-primary-hover: #1d63a0;
                --intigo-primary-soft: #eff6ff;
                --intigo-success: #047857;
                --intigo-success-soft: #ecfdf5;
                --intigo-warn: #92400e;
                --intigo-warn-soft: #fff7e6;
                --intigo-danger: #b91c1c;
                --intigo-danger-soft: #fef2f2;
                --intigo-info: #1d4ed8;
                --intigo-info-soft: #eff6ff;
                --intigo-text: #0f172a;
                --intigo-text-soft: #475569;
                --intigo-muted: #64748b;
                --intigo-border: #e2e8f0;
                --intigo-border-soft: #f1f5f9;
                --intigo-bg: #f8fafc;
                --intigo-card-bg: #ffffff;
                --intigo-radius-sm: 8px;
                --intigo-radius: 12px;
                --intigo-radius-lg: 16px;
                --intigo-shadow-sm: 0 1px 2px rgba(15,23,42,.04);
                --intigo-shadow: 0 4px 14px rgba(15,23,42,.06);
                --intigo-shadow-lg: 0 18px 48px rgba(15,23,42,.10);
            }

            /* Vertical rhythm — give every top-level block room to breathe */
            .wrap .intigo-hero,
            .wrap .intigo-alert,
            .wrap .intigo-card,
            .wrap .intigo-kpis,
            .wrap .intigo-charts,
            .wrap .intigo-table-wrap,
            .wrap .intigo-section,
            .wrap .intigo-tech,
            .wrap .intigo-docs-grid,
            .wrap .intigo-logs-meta,
            .wrap .intigo-pagination,
            .wrap .intigo-save-bar { margin-bottom: 20px; }
            .wrap .intigo-hero + .intigo-alert,
            .wrap .intigo-alert + .intigo-alert { margin-top:0; }

            /* Page header (hero) */
            .wrap .intigo-hero { display:flex; justify-content:space-between; align-items:flex-start; gap:16px; margin: 6px 0 20px 0; padding:18px 22px; background: linear-gradient(180deg, #ffffff 0%, #fbfdff 100%); border:1px solid var(--intigo-border); border-radius: var(--intigo-radius-lg); box-shadow: var(--intigo-shadow-sm); flex-wrap:wrap; }
            .wrap .intigo-hero-text { min-width:0; flex:1 1 320px; }
            .wrap .intigo-hero-eyebrow { display:inline-block; font-size:11px; font-weight:700; letter-spacing:.06em; color:var(--intigo-primary); text-transform:uppercase; margin:0 0 4px 0; }
            .wrap .intigo-hero h1 { margin:0; padding:0; font-size:22px; font-weight:700; color:var(--intigo-text); line-height:1.25; }
            .wrap .intigo-hero p { margin:6px 0 0 0; color:var(--intigo-muted); font-size:13.5px; max-width:680px; }
            .wrap .intigo-hero-meta { display:flex; flex-wrap:wrap; gap:8px; align-items:center; }

            /* Pills */
            .intigo-pill-status { display:inline-flex; align-items:center; gap:8px; padding:6px 12px; border-radius:999px; font-size:12.5px; font-weight:600; border:1px solid transparent; line-height:1; white-space:nowrap; }
            .intigo-pill-status .intigo-dot { width:7px; height:7px; border-radius:50%; background:currentColor; box-shadow:0 0 0 4px rgba(0,0,0,.05); }
            .intigo-pill-ok { background:var(--intigo-success-soft); color:var(--intigo-success); border-color:#a7f3d0; }
            .intigo-pill-err { background:var(--intigo-danger-soft); color:var(--intigo-danger); border-color:#fecaca; }
            .intigo-pill-warn { background:var(--intigo-warn-soft); color:var(--intigo-warn); border-color:#fde68a; }
            .intigo-pill-info { background:var(--intigo-info-soft); color:var(--intigo-info); border-color:#bfdbfe; }
            .intigo-pill-version { background:#f1f5f9; color:#475569; border-color:#e2e8f0; font-variant-numeric:tabular-nums; }
            .intigo-pill-neutral { background:#f1f5f9; color:var(--intigo-text-soft); border-color:var(--intigo-border); }

            /* Inline alerts */
            .intigo-alert { display:flex; gap:12px; align-items:flex-start; padding:12px 14px; border-radius: var(--intigo-radius); border:1px solid var(--intigo-border); background:#fff; margin:10px 0; }
            .intigo-alert .intigo-alert-icon { flex:0 0 auto; width:22px; height:22px; border-radius:50%; display:flex; align-items:center; justify-content:center; color:#fff; margin-top:1px; }
            .intigo-alert .intigo-alert-icon .dashicons { font-size:14px; width:14px; height:14px; }
            .intigo-alert .intigo-alert-body { min-width:0; flex:1 1 auto; color:var(--intigo-text); font-size:13.5px; line-height:1.5; }
            .intigo-alert .intigo-alert-body strong { color:var(--intigo-text); }
            .intigo-alert .intigo-alert-actions { flex:0 0 auto; }
            .intigo-alert--info { border-color:#bfdbfe; background:var(--intigo-info-soft); }
            .intigo-alert--info .intigo-alert-icon { background:var(--intigo-info); }
            .intigo-alert--success { border-color:#a7f3d0; background:var(--intigo-success-soft); }
            .intigo-alert--success .intigo-alert-icon { background:var(--intigo-success); }
            .intigo-alert--warn { border-color:#fde68a; background:var(--intigo-warn-soft); }
            .intigo-alert--warn .intigo-alert-icon { background:#dba617; }
            .intigo-alert--error { border-color:#fecaca; background:var(--intigo-danger-soft); }
            .intigo-alert--error .intigo-alert-icon { background:var(--intigo-danger); }

            /* Cards */
            .wrap .intigo-card,
            .wrap .intigo-chart-card { box-sizing: border-box; }
            .wrap .intigo-card { width: 100%; max-width: none; background:var(--intigo-card-bg); border:1px solid var(--intigo-border); border-radius: var(--intigo-radius-lg); padding:18px 20px; box-shadow: var(--intigo-shadow-sm); }
            .wrap .intigo-card table.widefat { width: 100% !important; min-width: 100%; }
            .wrap .intigo-card-title { margin:0 0 4px 0; font-size:15px; font-weight:600; color:var(--intigo-text); }
            .wrap .intigo-card-sub { margin:0 0 14px 0; color:var(--intigo-muted); font-size:13px; }

            /* KPIs */
            .wrap .intigo-kpis { display: grid; grid-template-columns: repeat(4, minmax(160px, 1fr)); gap: 10px; }
            .wrap .intigo-kpi { background: linear-gradient(180deg, #fff, #fbfdff); border:1px solid var(--intigo-border); border-radius: var(--intigo-radius); padding:14px 16px; transition: box-shadow .15s ease, transform .15s ease; }
            .wrap .intigo-kpi:hover { box-shadow: var(--intigo-shadow); transform: translateY(-1px); }
            .wrap .intigo-kpi-label { font-size:12px; color:var(--intigo-muted); margin-bottom:6px; font-weight:500; letter-spacing:.02em; }
            .wrap .intigo-kpi-value { font-size:22px; font-weight:700; color:var(--intigo-text); line-height:1.1; }

            /* Charts */
            .wrap .intigo-charts { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; }
            .wrap .intigo-chart-card { background:#fff; border:1px solid var(--intigo-border); border-radius: var(--intigo-radius); padding:16px; box-shadow: var(--intigo-shadow-sm); }
            .wrap .intigo-chart-title { margin:0 0 12px 0; font-size:13px; font-weight:600; color:var(--intigo-text); }
            .wrap .intigo-bar-row { margin-bottom:10px; }
            .wrap .intigo-bar-meta { display:flex; justify-content:space-between; font-size:12.5px; color:var(--intigo-text-soft); margin-bottom:5px; }
            .wrap .intigo-bar-track { width:100%; height:8px; border-radius:999px; background:#eef2f6; overflow:hidden; }
            .wrap .intigo-bar-fill { height:100%; border-radius:999px; transition: width .4s ease; }
            .wrap .intigo-fill-blue { background: linear-gradient(90deg, #2271b1, #4f9bd8); }
            .wrap .intigo-fill-green { background: linear-gradient(90deg, #16a34a, #4ade80); }
            .wrap .intigo-fill-yellow { background: linear-gradient(90deg, #dba617, #facc15); }
            .wrap .intigo-fill-gray { background: linear-gradient(90deg, #94a3b8, #cbd5e1); }

            /* Tables */
            .wrap .widefat { width: 100%; display: block; overflow-x: auto; -webkit-overflow-scrolling: touch; border:0 !important; background:transparent; }
            .wrap .intigo-table-wrap { background:#fff; border:1px solid var(--intigo-border); border-radius: var(--intigo-radius); overflow:hidden; }
            .wrap .intigo-table-wrap .widefat thead th { background:#f8fafc; font-weight:600; color:var(--intigo-text); border-bottom:1px solid var(--intigo-border); padding:12px 14px; }
            .wrap .intigo-table-wrap .widefat tbody td { padding:12px 14px; border-bottom:1px solid var(--intigo-border-soft); color:var(--intigo-text-soft); }
            .wrap .intigo-table-wrap .widefat tbody tr:last-child td { border-bottom:0; }
            .wrap .intigo-table-wrap .widefat tbody tr:hover td { background:#fbfdff; }

            /* Buttons (subtle polish that respects WP defaults) */
            .wrap .button { border-radius:8px; font-weight:500; }
            .wrap .button-primary { background:var(--intigo-primary); border-color:var(--intigo-primary); }
            .wrap .button-primary:hover, .wrap .button-primary:focus { background:var(--intigo-primary-hover); border-color:var(--intigo-primary-hover); }

            /* Pagination */
            .wrap .intigo-pagination { display:flex; flex-wrap:wrap; gap:6px; align-items:center; padding:8px 0; }
            .wrap .intigo-page-btn { display:inline-flex; align-items:center; gap:4px; min-width:36px; height:34px; padding:0 12px; border-radius:8px; border:1px solid var(--intigo-border); background:#fff; color:var(--intigo-text-soft); font-size:13px; font-weight:600; text-decoration:none; transition: background .15s ease, color .15s ease, border-color .15s ease, box-shadow .15s ease; justify-content:center; }
            .wrap .intigo-page-btn:hover { background:#f8fafc; color:var(--intigo-text); border-color:#cbd5e1; }
            .wrap .intigo-page-btn.is-active { background:var(--intigo-primary); color:#fff; border-color:var(--intigo-primary); box-shadow: 0 4px 10px rgba(34,113,177,.18); }
            .wrap .intigo-page-btn.is-active:hover { background:var(--intigo-primary-hover); color:#fff; }
            .wrap .intigo-page-btn.is-disabled { opacity:.45; pointer-events:none; }
            .wrap .intigo-page-btn .dashicons { font-size:16px; width:16px; height:16px; }
            .wrap .intigo-page-ellipsis { padding:0 4px; color:var(--intigo-muted); font-weight:600; }

            /* Empty state */
            .wrap .intigo-empty { padding:36px 20px; text-align:center; color:var(--intigo-muted); }
            .wrap .intigo-empty-icon { width:48px; height:48px; margin:0 auto 10px auto; border-radius:50%; background:#f1f5f9; display:flex; align-items:center; justify-content:center; color:var(--intigo-text-soft); }
            .wrap .intigo-empty-icon .dashicons { font-size:24px; width:24px; height:24px; }
            .wrap .intigo-empty-title { font-size:14px; font-weight:600; color:var(--intigo-text); margin-bottom:4px; }

            /* Modal carryover */
            .intigo-modal { max-height: 90vh; overflow: auto; }

            /* Pills used in tables */
            .intigo-pill { display:inline-block; padding:3px 10px; border-radius:999px; font-size:11px; font-weight:600; line-height:1.4; }
            .intigo-pill-ok { background:#dcfce7; color:#166534; }
            .intigo-pill-warn { background:#fef3c7; color:#92400e; }
            .intigo-pill-info { background:#dbeafe; color:#1e3a8a; }
            .intigo-pill-muted { background:#f1f5f9; color:#374151; }

            @media (max-width: 1200px) {
                .wrap .intigo-kpis { grid-template-columns: repeat(3, minmax(160px, 1fr)); }
            }
            @media (max-width: 900px) {
                .wrap .intigo-kpis { grid-template-columns: repeat(2, minmax(140px, 1fr)); }
                .wrap .intigo-charts { grid-template-columns: 1fr; }
                .wrap .intigo-hero { padding:16px 18px; }
            }
            @media (max-width: 600px) {
                .wrap .intigo-kpis { grid-template-columns: 1fr; }
                .wrap .button { width: 100%; text-align: center; margin-bottom: 6px; }
                .wrap .widefat thead th, .wrap .widefat tbody td { font-size: 12px; }
                .intigo-modal { width: 94vw; }
                .intigo-modal-header { flex-wrap: wrap; gap: 8px; }
                .wrap .intigo-hero h1 { font-size:18px; }
            }
        </style>
        <?php
    }

    private function is_order_new($order_id) {
        $order = wc_get_order($order_id);
        if (!$order) {
            return false;
        }
        return (string) $order->get_meta('_intigo_seen_at') === '';
    }

    private function get_new_orders_count() {
        if (!function_exists('wc_get_orders')) {
            return 0;
        }
        $orders = wc_get_orders(['limit' => 50, 'orderby' => 'date', 'order' => 'DESC']);
        $count = 0;
        foreach ($orders as $order) {
            if (!$order || !method_exists($order, 'get_id')) {
                continue;
            }
            if ((string) $order->get_meta('_intigo_seen_at') === '') {
                $count++;
            }
        }
        return $count;
    }

    private function mark_orders_as_seen($orders) {
        foreach ($orders as $order) {
            if (!$order || !method_exists($order, 'get_id')) {
                continue;
            }
            if ((string) $order->get_meta('_intigo_seen_at') === '') {
                $order->update_meta_data('_intigo_seen_at', current_time('mysql'));
                $order->save();
            }
        }
    }

    public function render_manage_orders_shortcode() {
        if (!is_user_logged_in()) {
            return '<p>Please login to access Intigo manage orders.</p>';
        }
        if (!current_user_can('manage_woocommerce')) {
            return '<p>You do not have permission to access Intigo manage orders.</p>';
        }
        $url = admin_url('admin.php?page=intigo-manage-orders');
        return '<p><a class="button" href="' . esc_url($url) . '">Open Intigo Manage Orders</a></p>';
    }

    private function compute_automatic_ops_status($city_id, $district_id, $package_size, $nid, $bordereau_url) {
        if ((string) $city_id === '' || (string) $district_id === '' || (string) $package_size === '') {
            return 'missing_data';
        }
        if ((string) $nid === '' && (string) $bordereau_url === '') {
            return 'verified';
        }
        if ((string) $nid !== '' && (string) $bordereau_url === '') {
            return 'need_confirmation';
        }
        return 'ready_for_shipment';
    }

    private function build_order_tags($city_id, $district_id, $package_size, $nid, $ops_status) {
        $tags = [];
        $ops_status_label = '';
        $ops_status_class = 'intigo-pill-muted';
        if ($ops_status === 'verified') {
            $ops_status_label = 'Verified';
            $ops_status_class = 'intigo-pill-ok';
        } elseif ($ops_status === 'ready_for_shipment') {
            $ops_status_label = 'Ready For Shipment';
            $ops_status_class = 'intigo-pill-info';
        } elseif ($ops_status === 'missing_data') {
            $ops_status_label = 'Missing Data';
            $ops_status_class = 'intigo-pill-warn';
        } elseif ($ops_status === 'need_confirmation') {
            $ops_status_label = 'Need Confirmation';
            $ops_status_class = 'intigo-pill-muted';
        }
        if ($ops_status_label !== '') {
            $tags[] = ['label' => $ops_status_label, 'class' => $ops_status_class];
        }
        return $tags;
    }

    private function get_intigo_zone_status() {
        if (!class_exists('WC_Shipping_Zones')) {
            return ['ok' => false, 'reason' => 'WooCommerce shipping not available.', 'with' => [], 'without' => []];
        }
        $with = [];
        $without = [];
        $entries = [];
        foreach (WC_Shipping_Zones::get_zones() as $zd) {
            $entries[] = ['id' => intval($zd['zone_id']), 'name' => (string) $zd['zone_name']];
        }
        $entries[] = ['id' => 0, 'name' => __('Locations not covered by your other zones', 'intigo-parcels')];
        foreach ($entries as $entry) {
            $zone = WC_Shipping_Zones::get_zone($entry['id']);
            if (!$zone) {
                continue;
            }
            $found = false;
            foreach ($zone->get_shipping_methods(false) as $method) {
                if (isset($method->id) && $method->id === 'intigo_delivery') {
                    $found = true;
                    break;
                }
            }
            if ($found) {
                $with[] = $entry;
            } else {
                $without[] = $entry;
            }
        }
        return ['ok' => true, 'with' => $with, 'without' => $without];
    }

    public function handle_add_to_zones() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized');
        }
        check_admin_referer('intigo_add_to_zones');
        if (!class_exists('WC_Shipping_Zones')) {
            $this->redirect_with_notice('intigo-parcels-settings', 'WooCommerce is not active.', 'error');
            exit;
        }
        $added = 0;
        $skipped = 0;
        $entries = [];
        foreach (WC_Shipping_Zones::get_zones() as $zd) {
            $entries[] = intval($zd['zone_id']);
        }
        $entries[] = 0;
        foreach ($entries as $zone_id) {
            $zone = WC_Shipping_Zones::get_zone($zone_id);
            if (!$zone) {
                continue;
            }
            $already = false;
            foreach ($zone->get_shipping_methods(false) as $method) {
                if (isset($method->id) && $method->id === 'intigo_delivery') {
                    $already = true;
                    break;
                }
            }
            if ($already) {
                $skipped++;
                continue;
            }
            $zone->add_shipping_method('intigo_delivery');
            $added++;
        }
        $this->add_log('shipping_zones_attached', 'added=' . $added . '; skipped=' . $skipped);
        $msg = $added > 0
            ? sprintf('Added Intigo Delivery to %d zone(s). %d already had it.', $added, $skipped)
            : 'Intigo Delivery is already on every zone.';
        $type = $added > 0 ? 'success' : 'info';
        $this->redirect_with_notice('intigo-parcels-settings', $msg, $type);
        exit;
    }

    private function check_health() {
        $settings = $this->api_client->get_settings();
        $base = rtrim((string) ($settings['primary_base_url'] ?? ''), '/');
        if ($base === '') {
            return ['ok' => false, 'message' => 'Primary Base URL is not configured'];
        }
        $health_url = preg_replace('#/api$#', '', $base) . '/health';
        $res = wp_remote_get($health_url, ['timeout' => 10]);
        if (is_wp_error($res)) {
            return ['ok' => false, 'message' => 'Health check failed: ' . $res->get_error_message()];
        }
        $code = wp_remote_retrieve_response_code($res);
        if ($code >= 200 && $code < 300) {
            return ['ok' => true, 'message' => 'Connected (' . $health_url . ')'];
        }
        return ['ok' => false, 'message' => 'Health check HTTP ' . $code . ' (' . $health_url . ')'];
    }

    private function compute_dashboard_metrics($orders) {
        $metrics = [
            'total_orders' => count($orders),
            'with_parcel' => 0,
            'with_bordereau' => 0,
            'missing_data' => 0,
            'verified' => 0,
            'need_confirmation' => 0,
            'ready_for_shipment' => 0,
            'total_sales' => 0.0,
            'avg_order_value' => 0.0,
            'coverage_rate' => 0.0,
            'ready_rate' => 0.0,
            'bordereau_rate' => 0.0,
        ];
        foreach ($orders as $metrics_order) {
            $metrics['total_sales'] += floatval($metrics_order->get_total());
            $m_nid = (string) $metrics_order->get_meta('_intigo_parcel_nid');
            $m_bordereau = (string) $metrics_order->get_meta('_intigo_bordereau_url');
            $m_city = (string) $metrics_order->get_meta('_intigo_city_id');
            $m_district = (string) $metrics_order->get_meta('_intigo_district_id');
            $m_package = (string) $metrics_order->get_meta('_intigo_package_size');
            if ($m_nid !== '') {
                $metrics['with_parcel']++;
            }
            if ($m_bordereau !== '') {
                $metrics['with_bordereau']++;
            }
            $m_status = $this->compute_automatic_ops_status($m_city, $m_district, $m_package, $m_nid, $m_bordereau);
            if (isset($metrics[$m_status])) {
                $metrics[$m_status]++;
            }
        }
        if ($metrics['total_orders'] > 0) {
            $metrics['avg_order_value'] = round($metrics['total_sales'] / $metrics['total_orders'], 2);
            $metrics['coverage_rate'] = round(($metrics['with_parcel'] / $metrics['total_orders']) * 100, 1);
            $metrics['ready_rate'] = round(($metrics['ready_for_shipment'] / $metrics['total_orders']) * 100, 1);
            $metrics['bordereau_rate'] = round(($metrics['with_bordereau'] / $metrics['total_orders']) * 100, 1);
        }
        return $metrics;
    }

    private function add_log($action, $context = '') {
        $logs = get_option(self::OPTION_LOGS, []);
        if (!is_array($logs)) {
            $logs = [];
        }
        $user = wp_get_current_user();
        $actor = ($user && !empty($user->user_login)) ? $user->user_login : 'system';
        array_unshift($logs, [
            'time' => current_time('mysql'),
            'actor' => $actor,
            'action' => sanitize_text_field((string) $action),
            'context' => sanitize_text_field((string) $context),
        ]);
        if (count($logs) > self::MAX_LOGS) {
            $logs = array_slice($logs, 0, self::MAX_LOGS);
        }
        update_option(self::OPTION_LOGS, $logs, false);
    }

    private function get_logs() {
        $logs = get_option(self::OPTION_LOGS, []);
        if (!is_array($logs)) {
            return [];
        }
        if (count($logs) > self::MAX_LOGS) {
            $logs = array_slice($logs, 0, self::MAX_LOGS);
            update_option(self::OPTION_LOGS, $logs, false);
        }
        return $logs;
    }
}

