<?php
/**
 * Intigo size in the WooCommerce Products list — column, Quick Edit, Bulk Edit, filter.
 *
 * Additive admin UX on top of the per-product "Intigo Delivery" box (Intigo_Product).
 * Same single source of truth: the `_intigo_product_size` product meta consumed by
 * Intigo_Size_Resolver. No schema changes, no checkout/pricing/resolver changes.
 *
 *   • Column "Intigo Size" — shows the assigned size, or "Default · X" when unassigned.
 *   • Quick Edit          — change one product's size inline.
 *   • Bulk Edit           — set many products at once ("— No change —" leaves them alone).
 *   • Filter              — narrow the list by size or "Unassigned".
 *
 * @since 0.2.3
 */

if (!defined('ABSPATH')) {
    exit;
}

class Intigo_Product_List {
    const COLUMN = 'intigo_size';
    const QUICK_FIELD = 'intigo_quick_size';
    const BULK_FIELD  = 'intigo_bulk_size';
    const BULK_NOCHANGE = '__no_change__';
    const NONCE_ACTION = 'intigo_inline_size';
    const NONCE_FIELD  = 'intigo_inline_size_nonce';

    /** @var Intigo_API_Client */
    private $api;

    public function __construct(Intigo_API_Client $api) {
        $this->api = $api;
    }

    public function register_hooks() {
        add_filter('manage_product_posts_columns', [$this, 'add_column']);
        add_action('manage_product_posts_custom_column', [$this, 'render_column'], 10, 2);
        add_action('quick_edit_custom_box', [$this, 'render_quick_edit'], 10, 2);
        add_action('bulk_edit_custom_box', [$this, 'render_bulk_edit'], 10, 2);
        add_action('save_post_product', [$this, 'save_inline'], 10, 2);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);
        add_action('restrict_manage_posts', [$this, 'render_filter']);
        add_action('pre_get_posts', [$this, 'apply_filter']);
    }

    // ---------------------------------------------------------------
    //  Column
    // ---------------------------------------------------------------

    public function add_column($columns) {
        // Insert after the price column when present, otherwise before the date column.
        $out = [];
        $inserted = false;
        foreach ($columns as $key => $label) {
            $out[$key] = $label;
            if ($key === 'price') {
                $out[self::COLUMN] = __('Intigo Size', 'intigo-parcels');
                $inserted = true;
            }
        }
        if (!$inserted) {
            $date = isset($out['date']) ? $out['date'] : null;
            if ($date !== null) {
                unset($out['date']);
            }
            $out[self::COLUMN] = __('Intigo Size', 'intigo-parcels');
            if ($date !== null) {
                $out['date'] = $date;
            }
        }
        return $out;
    }

    public function render_column($column, $post_id) {
        if ($column !== self::COLUMN) {
            return;
        }
        $assigned = $this->read_assigned($post_id);
        // Hidden value drives the Quick Edit JS pre-fill.
        echo '<span class="intigo-size-value" data-size="' . esc_attr($assigned) . '" style="display:none"></span>';
        if ($assigned !== '') {
            echo '<span class="intigo-size-chip" title="' . esc_attr__('Intigo package size used to ship this product.', 'intigo-parcels') . '">' . esc_html($assigned) . '</span>';
        } else {
            $default = $this->plugin_default();
            echo '<span class="intigo-size-chip is-default" title="' . esc_attr__('No size assigned — falls back to the plugin default.', 'intigo-parcels') . '">'
                . esc_html__('Default', 'intigo-parcels') . ' · ' . esc_html($default) . '</span>';
        }
    }

    // ---------------------------------------------------------------
    //  Quick Edit / Bulk Edit fields
    // ---------------------------------------------------------------

    public function render_quick_edit($column_name, $post_type) {
        if ($post_type !== 'product' || $column_name !== self::COLUMN) {
            return;
        }
        wp_nonce_field(self::NONCE_ACTION, self::NONCE_FIELD);
        ?>
        <fieldset class="inline-edit-col-right">
            <div class="inline-edit-col">
                <label class="inline-edit-group">
                    <span class="title"><?php esc_html_e('Intigo size', 'intigo-parcels'); ?></span>
                    <select name="<?php echo esc_attr(self::QUICK_FIELD); ?>">
                        <option value=""><?php esc_html_e('— Use default —', 'intigo-parcels'); ?></option>
                        <?php foreach ($this->size_options() as $code => $label): ?>
                            <option value="<?php echo esc_attr($code); ?>"><?php echo esc_html($label); ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
            </div>
        </fieldset>
        <?php
    }

    public function render_bulk_edit($column_name, $post_type) {
        if ($post_type !== 'product' || $column_name !== self::COLUMN) {
            return;
        }
        wp_nonce_field(self::NONCE_ACTION, self::NONCE_FIELD);
        ?>
        <fieldset class="inline-edit-col-right">
            <div class="inline-edit-col">
                <label class="inline-edit-group">
                    <span class="title"><?php esc_html_e('Intigo size', 'intigo-parcels'); ?></span>
                    <select name="<?php echo esc_attr(self::BULK_FIELD); ?>">
                        <option value="<?php echo esc_attr(self::BULK_NOCHANGE); ?>"><?php esc_html_e('— No change —', 'intigo-parcels'); ?></option>
                        <option value=""><?php esc_html_e('Use default', 'intigo-parcels'); ?></option>
                        <?php foreach ($this->size_options() as $code => $label): ?>
                            <option value="<?php echo esc_attr($code); ?>"><?php echo esc_html($label); ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
            </div>
        </fieldset>
        <?php
    }

    // ---------------------------------------------------------------
    //  Save (handles both Quick Edit and Bulk Edit)
    // ---------------------------------------------------------------

    public function save_inline($post_id, $post) {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        // Quick Edit: our field + our nonce must be present and valid.
        $is_quick = isset($_POST[self::QUICK_FIELD]);
        // Bulk Edit: WordPress submits the bulk form with `bulk_edit` set and our
        // field carried in the request for each looped post.
        $is_bulk  = isset($_REQUEST[self::BULK_FIELD]) && isset($_REQUEST['bulk_edit']);

        if (!$is_quick && !$is_bulk) {
            return;
        }
        if (
            !isset($_REQUEST[self::NONCE_FIELD]) ||
            !wp_verify_nonce(sanitize_text_field(wp_unslash($_REQUEST[self::NONCE_FIELD])), self::NONCE_ACTION)
        ) {
            return;
        }

        if ($is_quick) {
            $raw = strtoupper(sanitize_text_field(wp_unslash($_POST[self::QUICK_FIELD])));
            $this->apply_size($post_id, $raw);
            return;
        }

        // Bulk Edit
        $raw = sanitize_text_field(wp_unslash($_REQUEST[self::BULK_FIELD]));
        if ($raw === self::BULK_NOCHANGE) {
            return; // leave this product untouched
        }
        $this->apply_size($post_id, strtoupper($raw));
    }

    /** Persist (S/M/L/XL) or clear the meta when "use default" (empty). */
    private function apply_size($post_id, $raw) {
        $product = function_exists('wc_get_product') ? wc_get_product($post_id) : null;
        if (!$product) {
            return;
        }
        if (in_array($raw, Intigo_Size_Resolver::ALLOWED_SIZES, true)) {
            $product->update_meta_data(Intigo_Size_Resolver::PRODUCT_META, $raw);
        } else {
            $product->delete_meta_data(Intigo_Size_Resolver::PRODUCT_META);
        }
        $product->save();
    }

    // ---------------------------------------------------------------
    //  Filter
    // ---------------------------------------------------------------

    public function render_filter($post_type) {
        if ($post_type !== 'product') {
            return;
        }
        $current = isset($_GET['intigo_size_filter']) ? sanitize_text_field(wp_unslash($_GET['intigo_size_filter'])) : '';
        ?>
        <select name="intigo_size_filter">
            <option value=""><?php esc_html_e('All Intigo sizes', 'intigo-parcels'); ?></option>
            <option value="__unassigned__" <?php selected($current, '__unassigned__'); ?>><?php esc_html_e('Unassigned', 'intigo-parcels'); ?></option>
            <?php foreach ($this->size_options() as $code => $label): ?>
                <option value="<?php echo esc_attr($code); ?>" <?php selected($current, $code); ?>><?php echo esc_html($label); ?> (<?php echo esc_html($code); ?>)</option>
            <?php endforeach; ?>
        </select>
        <?php
    }

    public function apply_filter($query) {
        if (!is_admin() || !$query->is_main_query()) {
            return;
        }
        if ($query->get('post_type') !== 'product') {
            return;
        }
        if (empty($_GET['intigo_size_filter'])) {
            return;
        }
        $val = sanitize_text_field(wp_unslash($_GET['intigo_size_filter']));
        $meta = Intigo_Size_Resolver::PRODUCT_META;
        if ($val === '__unassigned__') {
            $query->set('meta_query', [
                'relation' => 'OR',
                ['key' => $meta, 'compare' => 'NOT EXISTS'],
                ['key' => $meta, 'value' => '', 'compare' => '='],
            ]);
        } elseif (in_array(strtoupper($val), Intigo_Size_Resolver::ALLOWED_SIZES, true)) {
            $query->set('meta_query', [
                ['key' => $meta, 'value' => strtoupper($val), 'compare' => '='],
            ]);
        }
    }

    // ---------------------------------------------------------------
    //  Assets
    // ---------------------------------------------------------------

    /**
     * Enqueue the column styles and the Quick Edit pre-fill script.
     *
     * The pre-fill script is attached as a dependent of `inline-edit-post` so it
     * runs *after* WordPress defines the global `inlineEditPost` object. Printing
     * it inline in the footer is unreliable — admin core scripts load deferred, so
     * `inlineEditPost` is still undefined at footer-parse time.
     */
    public function enqueue_admin_assets($hook) {
        if ($hook !== 'edit.php') {
            return;
        }
        $screen = function_exists('get_current_screen') ? get_current_screen() : null;
        if (!$screen || $screen->post_type !== 'product') {
            return;
        }

        wp_register_style('intigo-product-list', false, [], INTIGO_PARCELS_VERSION);
        wp_enqueue_style('intigo-product-list');
        wp_add_inline_style('intigo-product-list',
            '.column-' . self::COLUMN . ' { width: 92px; }'
            . '.intigo-size-chip { display:inline-block; padding:2px 9px; border-radius:999px; font-weight:700; font-size:12px; line-height:1.6; background:#eff6ff; color:#1d4ed8; border:1px solid #bfdbfe; }'
            . '.intigo-size-chip.is-default { background:#f1f5f9; color:#64748b; border-color:#e2e8f0; font-weight:600; }'
        );

        // Empty-src handle that depends on inline-edit-post (and jQuery), so our
        // inline override is printed and executed after inlineEditPost exists.
        wp_register_script('intigo-product-list', false, ['jquery', 'inline-edit-post'], INTIGO_PARCELS_VERSION, true);
        wp_enqueue_script('intigo-product-list');
        wp_add_inline_script('intigo-product-list', $this->quick_edit_js());
    }

    private function quick_edit_js() {
        $field = self::QUICK_FIELD;
        return <<<JS
(function(\$){
    if (typeof inlineEditPost === 'undefined' || !inlineEditPost.edit) { return; }
    var _edit = inlineEditPost.edit;
    inlineEditPost.edit = function(id){
        _edit.apply(this, arguments);
        var postId = 0;
        if (typeof id === 'object') { postId = parseInt(this.getId(id), 10); }
        if (!postId) { return; }
        var size = \$('#post-' + postId).find('.intigo-size-value').data('size');
        size = (size === undefined || size === null) ? '' : String(size);
        \$('#edit-' + postId).find('select[name="{$field}"]').val(size);
    };
})(jQuery);
JS;
    }

    // ---------------------------------------------------------------
    //  Helpers
    // ---------------------------------------------------------------

    /** @return array<string,string> code => human label */
    private function size_options() {
        return [
            'S'  => __('Small', 'intigo-parcels'),
            'M'  => __('Medium', 'intigo-parcels'),
            'L'  => __('Large', 'intigo-parcels'),
            'XL' => __('Extra large', 'intigo-parcels'),
        ];
    }

    private function read_assigned($post_id) {
        $product = function_exists('wc_get_product') ? wc_get_product($post_id) : null;
        if (!$product) {
            return '';
        }
        $raw = strtoupper(trim((string) $product->get_meta(Intigo_Size_Resolver::PRODUCT_META, true)));
        return in_array($raw, Intigo_Size_Resolver::ALLOWED_SIZES, true) ? $raw : '';
    }

    private function plugin_default() {
        $settings = $this->api->get_settings();
        $raw = strtoupper(trim((string) ($settings['default_package_size'] ?? 'S')));
        return in_array($raw, Intigo_Size_Resolver::ALLOWED_SIZES, true) ? $raw : 'S';
    }
}
