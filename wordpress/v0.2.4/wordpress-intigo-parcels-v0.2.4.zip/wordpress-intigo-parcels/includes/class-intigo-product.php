<?php
/**
 * Per-product Intigo configuration — currently a single field: the package size.
 *
 * Renders a small box on the product edit screen that lets the seller assign
 * the product to one of Intigo's fixed S/M/L/XL buckets. Saves to the
 * `_intigo_product_size` meta consumed by Intigo_Size_Resolver.
 *
 * Intigo's size grid (cm/kg per bucket) is defined by Intigo, not by the seller —
 * this UI deliberately doesn't expose any way to redefine what each bucket means;
 * it only lets the seller pick which bucket a given product belongs to.
 *
 * @since 0.2.1
 */

if (!defined('ABSPATH')) {
    exit;
}

class Intigo_Product {
    /** @var Intigo_Size_Resolver */
    private $resolver;

    public function __construct(Intigo_Size_Resolver $resolver) {
        $this->resolver = $resolver;
    }

    public function register_hooks() {
        add_action('add_meta_boxes', [$this, 'register_meta_box']);
        add_action('save_post_product', [$this, 'save_meta_box'], 10, 2);
    }

    public function register_meta_box() {
        add_meta_box(
            'intigo_product_box',
            __('Intigo Delivery', 'intigo-parcels'),
            [$this, 'render_meta_box'],
            'product',
            'side',
            'default'
        );
    }

    public function render_meta_box($post) {
        if (!($post instanceof WP_Post)) {
            return;
        }
        $product = function_exists('wc_get_product') ? wc_get_product($post->ID) : null;
        $current = $product ? (string) $product->get_meta(Intigo_Size_Resolver::PRODUCT_META, true) : '';
        $current = strtoupper(trim($current));

        wp_nonce_field('intigo_product_size_nonce', 'intigo_product_size_nonce_field');

        $sizes = [
            ''   => __('— Use default —', 'intigo-parcels'),
            'S'  => __('Small', 'intigo-parcels'),
            'M'  => __('Medium', 'intigo-parcels'),
            'L'  => __('Large', 'intigo-parcels'),
            'XL' => __('Extra large', 'intigo-parcels'),
        ];
        ?>
        <p style="margin-top:0;">
            <label for="intigo_product_size" style="display:block; font-weight:600; margin-bottom:4px;">
                <?php esc_html_e('Package size', 'intigo-parcels'); ?>
            </label>
            <select id="intigo_product_size" name="intigo_product_size" style="width:100%;">
                <?php foreach ($sizes as $value => $label): ?>
                    <option value="<?php echo esc_attr($value); ?>" <?php selected($current, $value); ?>>
                        <?php echo esc_html($label); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </p>
        <p style="margin:8px 0 0 0; color:#475569; font-size:12.5px; line-height:1.5;">
            <?php esc_html_e('Pick which Intigo size bucket this product belongs to. Intigo defines the cm/kg limits per bucket — this just tags the product.', 'intigo-parcels'); ?>
        </p>
        <p style="margin:8px 0 0 0; color:#94a3b8; font-size:12px; line-height:1.5;">
            <?php esc_html_e('Leave on "Use default" to fall back to the plugin-wide default in Intigo → Settings.', 'intigo-parcels'); ?>
        </p>
        <?php
    }

    public function save_meta_box($post_id, $post) {
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        if (
            !isset($_POST['intigo_product_size_nonce_field']) ||
            !wp_verify_nonce(
                sanitize_text_field(wp_unslash($_POST['intigo_product_size_nonce_field'])),
                'intigo_product_size_nonce'
            )
        ) {
            return;
        }
        $raw = isset($_POST['intigo_product_size'])
            ? strtoupper(sanitize_text_field(wp_unslash($_POST['intigo_product_size'])))
            : '';
        $product = function_exists('wc_get_product') ? wc_get_product($post_id) : null;
        if (!$product) {
            return;
        }
        if (in_array($raw, Intigo_Size_Resolver::ALLOWED_SIZES, true)) {
            $product->update_meta_data(Intigo_Size_Resolver::PRODUCT_META, $raw);
        } else {
            // Empty value means "use plugin default" — clear any prior assignment.
            $product->delete_meta_data(Intigo_Size_Resolver::PRODUCT_META);
        }
        $product->save();
    }
}
