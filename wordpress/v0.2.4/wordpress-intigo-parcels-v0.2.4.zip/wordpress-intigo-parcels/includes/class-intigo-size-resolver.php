<?php
/**
 * Intigo package-size resolver — single source of truth for "what size is this parcel?"
 *
 * Intigo's S/M/L/XL grid is a fixed contract defined by Intigo (logistics + pricing).
 * Sellers don't redefine what "Small" means — they assign each product to one of the
 * four buckets, and the customer never picks at checkout.
 *
 *   ┌──────────────────────────────────────────────────────────┐
 *   │ 1. Per-order admin override                               │
 *   │    Order meta `_intigo_package_size` set on the order     │
 *   │    edit screen for one-off cases.                         │
 *   ├──────────────────────────────────────────────────────────┤
 *   │ 2. Per-product seller assignment                          │
 *   │    Product meta `_intigo_product_size` (S | M | L | XL),  │
 *   │    set in the "Intigo Delivery" sidebar box on the        │
 *   │    product edit screen. This is the primary mechanism.    │
 *   ├──────────────────────────────────────────────────────────┤
 *   │ 3. Plugin-wide default                                    │
 *   │    Setting `default_package_size` (defaults to 'S') —     │
 *   │    used when a product hasn't been tagged yet.            │
 *   └──────────────────────────────────────────────────────────┘
 *
 * Cart aggregation: when a cart has multiple line items at different sizes, the
 * resolved size is the MAX by rank (S < M < L < XL) — the parcel needs to
 * physically contain the biggest item.
 *
 * @since 0.2.1
 */

if (!defined('ABSPATH')) {
    exit;
}

class Intigo_Size_Resolver {
    const ALLOWED_SIZES = ['S', 'M', 'L', 'XL'];
    const PRODUCT_META  = '_intigo_product_size';

    /** Rank used for cart aggregation — bigger rank wins. */
    const RANK = ['S' => 1, 'M' => 2, 'L' => 3, 'XL' => 4];

    /** @var Intigo_API_Client */
    private $api;

    public function __construct(Intigo_API_Client $api) {
        $this->api = $api;
    }

    // -------------------------------------------------------------------
    //  Public entry points
    // -------------------------------------------------------------------

    /**
     * Resolve the size for a single product (no cart aggregation).
     *
     * Layers consulted (in order): per-product assignment → plugin default.
     * Layer 1 (per-order override) is irrelevant here because there is no
     * order yet.
     */
    public function resolve_for_product($product): string {
        $override = $this->read_product_override($product);
        if ($override !== '') {
            return $override;
        }
        return $this->plugin_default();
    }

    /**
     * Resolve the size for the customer's cart (used at shipping-rate calc time).
     * Aggregates per-line-item sizes by max-rank.
     *
     * @param array $package WooCommerce shipping `$package` array — `contents` is a
     *                      keyed array of cart items, each holding 'data' (WC_Product) and 'quantity'.
     */
    public function resolve_for_cart_package(array $package): string {
        $sizes = [];
        $contents = isset($package['contents']) && is_array($package['contents']) ? $package['contents'] : [];
        foreach ($contents as $item) {
            $product = isset($item['data']) ? $item['data'] : null;
            if (!$product) {
                continue;
            }
            $size = $this->resolve_for_product($product);
            if ($size !== '') {
                $sizes[] = $size;
            }
        }
        if (empty($sizes)) {
            return $this->plugin_default();
        }
        return $this->max_by_rank($sizes);
    }

    /**
     * Resolve the size for an existing order.
     *
     * Layer 1 (per-order admin override) wins if present. Otherwise we walk the
     * order's line items and aggregate, the same way we do for the live cart.
     */
    public function resolve_for_order($order): string {
        if (!is_object($order)) {
            return $this->plugin_default();
        }
        $explicit = method_exists($order, 'get_meta')
            ? $this->normalize_size((string) $order->get_meta('_intigo_package_size'))
            : '';
        if ($explicit !== '') {
            return $explicit;
        }
        $sizes = [];
        if (method_exists($order, 'get_items')) {
            foreach ($order->get_items() as $item) {
                $product = method_exists($item, 'get_product') ? $item->get_product() : null;
                if ($product) {
                    $sizes[] = $this->resolve_for_product($product);
                }
            }
        }
        if (empty($sizes)) {
            return $this->plugin_default();
        }
        return $this->max_by_rank($sizes);
    }

    // -------------------------------------------------------------------
    //  Internals
    // -------------------------------------------------------------------

    private function read_product_override($product): string {
        if (!is_object($product) || !method_exists($product, 'get_meta')) {
            return '';
        }
        $raw = (string) $product->get_meta(self::PRODUCT_META, true);
        return $this->normalize_size($raw);
    }

    private function plugin_default(): string {
        $settings = $this->api->get_settings();
        $candidate = $this->normalize_size((string) ($settings['default_package_size'] ?? 'S'));
        return $candidate === '' ? 'S' : $candidate;
    }

    private function normalize_size(string $raw): string {
        $u = strtoupper(trim($raw));
        return in_array($u, self::ALLOWED_SIZES, true) ? $u : '';
    }

    /** @param string[] $sizes */
    private function max_by_rank(array $sizes): string {
        $best_rank = 0;
        $best_code = 'S';
        foreach ($sizes as $code) {
            $rank = self::RANK[$code] ?? 0;
            if ($rank > $best_rank) {
                $best_rank = $rank;
                $best_code = $code;
            }
        }
        return $best_code;
    }
}
