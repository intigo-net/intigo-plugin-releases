<?php

if (!defined('ABSPATH')) {
    exit;
}

class Intigo_Order_Service {
    private $api;

    public function __construct($api_client) {
        $this->api = $api_client;
    }

    public function register_hooks() {
        add_filter('woocommerce_order_actions', [$this, 'register_order_actions']);
        add_filter('bulk_actions-edit-shop_order', [$this, 'register_bulk_action']);
        add_filter('handle_bulk_actions-edit-shop_order', [$this, 'handle_bulk_action'], 10, 3);
        add_action('woocommerce_order_action_intigo_create_parcel', [$this, 'create_single_for_order']);
        add_action('woocommerce_order_action_intigo_generate_bordereau', [$this, 'generate_bordereau_for_order']);
        add_action('woocommerce_order_status_processing', [$this, 'maybe_auto_create_from_order_event']);
        add_action('woocommerce_order_status_completed', [$this, 'maybe_auto_create_from_order_event']);
        add_action('woocommerce_payment_complete', [$this, 'maybe_auto_create_from_order_event']);
        add_action('woocommerce_thankyou', [$this, 'maybe_auto_create_from_order_event']);
        add_action('woocommerce_process_shop_order_meta', [$this, 'maybe_sync_after_order_edit'], 30, 1);
    }

    public function register_order_actions($actions) {
        $actions['intigo_create_parcel'] = __('Intigo: Create Parcel', 'intigo-parcels');
        $actions['intigo_generate_bordereau'] = __('Intigo: Generate Bordereau', 'intigo-parcels');
        return $actions;
    }

    public function register_bulk_action($actions) {
        $actions['intigo_create_parcels_batch'] = __('Intigo: Create Parcels (Batch)', 'intigo-parcels');
        return $actions;
    }

    public function handle_bulk_action($redirect_to, $action, $post_ids) {
        if ($action !== 'intigo_create_parcels_batch') {
            return $redirect_to;
        }

        $batch = ['parcels' => []];
        foreach ($post_ids as $order_id) {
            $order = wc_get_order($order_id);
            if (!$order) {
                continue;
            }
            $payload = $this->order_to_payload($order);
            // Resolve the Intigo zone from the order's address when city/district
            // meta is missing — same fallback the single/auto/manual paths use.
            // Without this, modal-off stores would batch-push parcels with an
            // unresolved zone (city_id=0).
            $this->enrich_payload_with_location_ids($order, $payload);
            $batch['parcels'][] = $payload;
        }

        $res = $this->api->create_parcels_batch($batch);
        $created = !empty($res['data']['created']) ? intval($res['data']['created']) : 0;
        return add_query_arg(['intigo_batch_created' => $created], $redirect_to);
    }

    public function create_single_for_order($order) {
        if (!$order instanceof WC_Order) {
            return;
        }
        $this->hydrate_intigo_meta_from_request($order);
        $key = $this->idempotency_key($order, 'manual_create');
        if ($order->get_meta('_intigo_idem_' . md5($key)) !== '') {
            $order->add_order_note('Intigo create skipped: parcel already created for this order (idempotency). Use "Intigo: Force Create Parcel" to create another one.');
            return;
        }

        $payload = $this->order_to_payload($order);
        $this->enrich_payload_with_location_ids($order, $payload);
        $validation_error = $this->validate_payload($payload);
        if ($validation_error !== null) {
            $order->add_order_note('Intigo parcel creation failed: ' . $validation_error);
            return;
        }
        $res = $this->api->create_parcel($payload);

        if (!empty($res['ok']) && !empty($res['data']['nid'])) {
            $order->update_meta_data('_intigo_parcel_nid', sanitize_text_field($res['data']['nid']));
            $order->update_meta_data('_intigo_api_target_used', sanitize_text_field($res['adapter']));
            $order->update_meta_data('_intigo_idem_' . md5($key), 1);
            $order->delete_meta_data('_intigo_last_error');
            $order->update_meta_data('_intigo_last_attempt_at', current_time('mysql'));
            $order->save();
            $order->add_order_note('Intigo parcel created: ' . $res['data']['nid']);
        } else {
            $error_text = $this->format_api_error($res);
            $order->update_meta_data('_intigo_last_error', $error_text);
            $order->update_meta_data('_intigo_last_attempt_at', current_time('mysql'));
            $order->save();
            $order->add_order_note('Intigo parcel creation failed: ' . $error_text);
        }
    }

    public function force_create_for_order($order) {
        if (!$order instanceof WC_Order) {
            return;
        }
        // Ignore idempotency for explicit force action.
        $order->delete_meta_data('_intigo_idem_' . md5($this->idempotency_key($order, 'manual_create')));
        $order->save();
        $this->create_single_for_order($order);
    }

    public function update_parcel_for_order($order) {
        if (!$order instanceof WC_Order) {
            return ['ok' => false, 'message' => 'Invalid order instance'];
        }
        $this->hydrate_intigo_meta_from_request($order);

        $nid = $order->get_meta('_intigo_parcel_nid');
        if (empty($nid)) {
            $order->add_order_note('Intigo update failed: no parcel NID found. Create parcel first.');
            return ['ok' => false, 'message' => 'No parcel NID found'];
        }

        $payload = $this->order_to_payload($order);
        $this->enrich_payload_with_location_ids($order, $payload);
        $validation_error = $this->validate_payload($payload);
        if ($validation_error !== null) {
            $order->add_order_note('Intigo update failed: ' . $validation_error);
            return ['ok' => false, 'message' => $validation_error];
        }

        $res = $this->api->update_parcel($nid, $payload);
        if (!empty($res['ok'])) {
            $order->add_order_note('Intigo parcel updated successfully: ' . $nid);
            return ['ok' => true, 'message' => 'Updated via PATCH', 'response' => $res];
        }
        if ($this->is_parcel_locked_error($res)) {
            $msg = 'Parcel is locked in Intigo (already delivered or return). Updates are not allowed for this NID.';
            $order->update_meta_data('_intigo_sync_locked', 'yes');
            $order->save();
            $order->add_order_note('Intigo sync skipped: ' . $msg);
            return ['ok' => false, 'locked' => true, 'message' => $msg, 'response' => ['patch' => $res]];
        }

        // Fallback sync strategy for parcels that are no longer patchable.
        $fallback_errors = [];

        $phone_res = $this->api->change_phone($nid, $payload['phone1'] ?? '');
        if (empty($phone_res['ok'])) {
            $fallback_errors[] = 'phone=' . $this->format_api_error($phone_res);
        }

        $addr_payload = [
            'address' => $payload['destination_address'] ?? '',
            'city_id' => intval($payload['destination_city_id'] ?? 0),
            'district_id' => intval($payload['destination_district_id'] ?? 0),
        ];
        if (!empty($payload['destination_neighborhood_id'])) {
            $addr_payload['neighborhood_id'] = intval($payload['destination_neighborhood_id']);
        }
        $addr_res = $this->api->change_address($nid, $addr_payload);
        if (empty($addr_res['ok'])) {
            $fallback_errors[] = 'address=' . $this->format_api_error($addr_res);
        }

        $price_res = $this->api->change_price($nid, floatval($payload['price'] ?? 0));
        if (empty($price_res['ok'])) {
            $fallback_errors[] = 'price=' . $this->format_api_error($price_res);
        }

        if (count($fallback_errors) < 3) {
            $order->add_order_note('Intigo parcel synchronized partially using fallback actions: ' . $nid);
            return ['ok' => true, 'message' => 'Synchronized with fallback actions', 'response' => [
                'patch' => $res,
                'phone' => $phone_res,
                'address' => $addr_res,
                'price' => $price_res,
            ]];
        }

        $order->add_order_note('Intigo parcel update failed: ' . $this->format_api_error($res));
        $order->add_order_note('Intigo fallback sync failed: ' . implode(' | ', $fallback_errors));
        return ['ok' => false, 'message' => implode(' | ', $fallback_errors), 'response' => [
            'patch' => $res,
            'phone' => $phone_res,
            'address' => $addr_res,
            'price' => $price_res,
        ]];
    }

    public function generate_bordereau_for_order($order) {
        if (!$order instanceof WC_Order) {
            return;
        }

        $nid = $order->get_meta('_intigo_parcel_nid');
        if (empty($nid)) {
            $order->add_order_note('No Intigo parcel NID found for bordereau');
            return;
        }

        $res = $this->api->generate_bordereau([$nid]);
        if (!empty($res['ok']) && !empty($res['data']['url'])) {
            $order->update_meta_data('_intigo_bordereau_url', esc_url_raw($res['data']['url']));
            $order->save();
            $order->add_order_note('Intigo bordereau URL generated');
        } else {
            $order->add_order_note('Intigo bordereau generation failed: ' . $this->format_api_error($res));
        }
    }

    public function maybe_auto_create_from_order_event($order_id) {
        $settings = $this->api->get_settings();
        if (($settings['auto_create_on_paid'] ?? 'no') !== 'yes') {
            return;
        }

        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }

        // Only push when this is an Intigo Delivery order.
        $is_intigo = false;
        foreach ($order->get_items('shipping') as $item) {
            if (is_object($item) && method_exists($item, 'get_method_id') && $item->get_method_id() === 'intigo_delivery') {
                $is_intigo = true;
                break;
            }
        }
        if (!$is_intigo) {
            return;
        }

        // Skip orders that aren't in a "ready to ship" state.
        $status = $order->get_status();
        if (in_array($status, ['failed', 'cancelled', 'refunded', 'checkout-draft'], true)) {
            return;
        }

        // Idempotency — skip if we already pushed this order successfully.
        if ((string) $order->get_meta('_intigo_parcel_nid') !== '') {
            return;
        }
        $manual_key = $this->idempotency_key($order, 'manual_create');
        if ($order->get_meta('_intigo_idem_' . md5($manual_key)) !== '') {
            return;
        }

        $this->create_single_for_order($order);
    }

    private function order_to_payload($order) {
        $intigo_name = trim((string) $order->get_meta('_intigo_recipient_name'));
        if ($intigo_name !== '') {
            $recipient_name = $intigo_name;
        } else {
            $recipient_name = trim($order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name());
            if ($recipient_name === '') {
                $recipient_name = trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());
            }
        }

        $phone = trim((string) $order->get_meta('_intigo_phone'));
        if ($phone === '') {
            $phone = trim((string) $order->get_billing_phone());
        }
        if ($phone === '' && method_exists($order, 'get_shipping_phone')) {
            $phone = trim((string) $order->get_shipping_phone());
        }
        $phone = $this->normalize_phone($phone);

        $destination_address = trim((string) $order->get_meta('_intigo_address'));
        if ($destination_address === '') {
            $destination_address = trim($order->get_shipping_address_1() . ' ' . $order->get_shipping_address_2());
            if ($destination_address === '') {
                $destination_address = trim($order->get_billing_address_1() . ' ' . $order->get_billing_address_2());
            }
        }

        $raw_package_size = (string) $order->get_meta('_intigo_package_size');
        if ($raw_package_size === '' && class_exists('Intigo_Size_Resolver')) {
            // Walk the size resolver: per-product override → auto-from-dimensions → plugin default.
            // This keeps bulk-create / API-only flows correct even when no Intigo Delivery rate
            // was chosen at checkout (e.g. orders imported from elsewhere).
            $raw_package_size = (new Intigo_Size_Resolver($this->api))->resolve_for_order($order);
        }
        if ($raw_package_size === '') {
            $settings = $this->api->get_settings();
            $raw_package_size = (string) ($settings['default_package_size'] ?? 'S');
        }
        $package_size = $this->normalize_package_size($raw_package_size);

        $payload = [
            'recipient_name' => $recipient_name,
            'phone1' => $phone,
            'destination_address' => $destination_address,
            'destination_city_id' => intval($order->get_meta('_intigo_city_id')),
            'destination_district_id' => intval($order->get_meta('_intigo_district_id')),
            'price' => floatval($order->get_total()),
            'package_size' => $package_size,
            'description' => $this->build_description($order),
            'can_open' => false,
        ];
        $neighborhood_id = intval($order->get_meta('_intigo_neighborhood_id'));
        if ($neighborhood_id > 0) {
            $payload['destination_neighborhood_id'] = $neighborhood_id;
        }
        return $payload;
    }

    /**
     * Build the parcel description sent to Intigo: the order reference plus the
     * product names (with quantity when > 1). Falls back to just the order
     * reference when there are no line items. Capped to a safe length.
     */
    private function build_description($order) {
        $order_ref = 'WooCommerce Order #' . $order->get_id();
        $parts = [];
        if (method_exists($order, 'get_items')) {
            foreach ($order->get_items() as $item) {
                if (!is_object($item) || !method_exists($item, 'get_name')) {
                    continue;
                }
                $name = trim((string) $item->get_name());
                if ($name === '') {
                    continue;
                }
                $qty = method_exists($item, 'get_quantity') ? (int) $item->get_quantity() : 1;
                $parts[] = $qty > 1 ? ($name . ' x' . $qty) : $name;
            }
        }
        if (empty($parts)) {
            return $order_ref;
        }
        $desc = $order_ref . ' - ' . implode(', ', $parts);
        // Keep within a safe length for the Intigo API.
        $max = 250;
        if (function_exists('mb_strlen') && mb_strlen($desc) > $max) {
            $desc = rtrim(mb_substr($desc, 0, $max - 1)) . '…';
        } elseif (strlen($desc) > $max) {
            $desc = rtrim(substr($desc, 0, $max - 1)) . '...';
        }
        return $desc;
    }

    private function idempotency_key($order, $event) {
        return sprintf('wp:%d:%d:%s:v1', get_current_blog_id(), $order->get_id(), $event);
    }

    private function validate_payload($payload) {
        if (empty($payload['recipient_name'])) {
            return 'recipient_name is required (shipping first/last name missing)';
        }
        if (empty($payload['phone1'])) {
            return 'phone1 is required (billing phone missing)';
        }
        if (empty($payload['destination_address'])) {
            return 'destination_address is required (shipping address missing)';
        }
        if (empty($payload['destination_city_id'])) {
            return '_intigo_city_id order meta is required';
        }
        if (empty($payload['destination_district_id'])) {
            return '_intigo_district_id order meta is required';
        }
        return null;
    }

    private function format_api_error($res) {
        if (!is_array($res)) {
            return 'unknown error';
        }
        $parts = [];
        if (isset($res['adapter'])) {
            $parts[] = 'adapter=' . $res['adapter'];
        }
        if (isset($res['code'])) {
            $parts[] = 'http=' . $res['code'];
        }
        if (!empty($res['url'])) {
            $parts[] = 'url=' . $res['url'];
        }
        if (!empty($res['error'])) {
            $parts[] = 'error=' . $res['error'];
        } elseif (!empty($res['data'])) {
            $parts[] = 'response=' . wp_json_encode($res['data']);
        }
        if (!empty($res['legacy_attempt'])) {
            $la = $res['legacy_attempt'];
            $sub = [];
            if (!empty($la['code'])) { $sub[] = 'http=' . $la['code']; }
            if (!empty($la['url'])) { $sub[] = 'url=' . $la['url']; }
            if (!empty($la['error'])) { $sub[] = 'error=' . $la['error']; }
            elseif (!empty($la['data'])) { $sub[] = 'response=' . wp_json_encode($la['data']); }
            if ($sub) { $parts[] = 'legacy(' . implode(' ', $sub) . ')'; }
        }
        return empty($parts) ? 'unknown error' : implode(' | ', $parts);
    }

    private function is_parcel_locked_error($res) {
        if (!is_array($res)) {
            return false;
        }
        $status = 0;
        if (isset($res['code'])) {
            $status = intval($res['code']);
        } elseif (isset($res['status'])) {
            $status = intval($res['status']);
        }
        if ($status !== 400 && $status !== 409) {
            return false;
        }
        $detail = '';
        if (isset($res['data']) && is_array($res['data']) && isset($res['data']['detail'])) {
            $detail = strtolower((string) $res['data']['detail']);
        } elseif (isset($res['error'])) {
            $detail = strtolower((string) $res['error']);
        }
        if ($detail === '') {
            return false;
        }
        return (strpos($detail, 'deja livre') !== false)
            || (strpos($detail, 'déjà livré') !== false)
            || (strpos($detail, 'en retour') !== false)
            || (strpos($detail, 'ne peut plus être modifié') !== false)
            || (strpos($detail, 'ne peut plus etre modifie') !== false);
    }

    private function enrich_payload_with_location_ids($order, &$payload) {
        $dirty = false;
        // City auto-lookup from shipping/billing city if ID is missing.
        if (empty($payload['destination_city_id'])) {
            $city_name = trim((string) $order->get_shipping_city());
            if ($city_name === '') {
                $city_name = trim((string) $order->get_billing_city());
            }
            if ($city_name !== '') {
                $city_id = intval($this->api->resolve_city_id($city_name));
                if ($city_id > 0) {
                    $payload['destination_city_id'] = $city_id;
                    $order->update_meta_data('_intigo_city_id', $city_id);
                    $dirty = true;
                }
            }
        }

        // District auto-lookup from explicit meta name, shipping state, or billing state.
        if (empty($payload['destination_district_id'])) {
            $district_name = trim((string) $order->get_meta('_intigo_district_name'));
            if ($district_name === '') {
                $district_name = trim((string) $order->get_shipping_state());
            }
            if ($district_name === '') {
                $district_name = trim((string) $order->get_billing_state());
            }
            if ($district_name !== '') {
                $district_id = intval($this->api->resolve_district_id($district_name, intval($payload['destination_city_id'])));
                if ($district_id > 0) {
                    $payload['destination_district_id'] = $district_id;
                    $order->update_meta_data('_intigo_district_id', $district_id);
                    $dirty = true;
                }
            }
        }
        if ($dirty) {
            $order->save();
        }
    }

    private function normalize_phone($phone) {
        $digits = preg_replace('/\D+/', '', (string) $phone);
        if ($digits === null) {
            return '';
        }
        // Strip a leading "00" international prefix (e.g. 0021625249215 -> 21625249215).
        if (strpos($digits, '00') === 0) {
            $digits = substr($digits, 2);
        }
        return $digits;
    }

    private function normalize_package_size($raw) {
        $raw = trim((string) $raw);
        if ($raw === '') {
            return 1;
        }
        if (is_numeric($raw)) {
            return max(1, intval($raw));
        }
        $s = strtoupper($raw);
        $map = [
            'S' => 1,
            'SMALL' => 1,
            'M' => 2,
            'MEDIUM' => 2,
            'L' => 4,
            'LARGE' => 4,
            'XL' => 5,
            'EXTRALARGE' => 5,
        ];
        return $map[$s] ?? 1;
    }

    private function hydrate_intigo_meta_from_request($order) {
        if (!is_object($order) || !method_exists($order, 'get_id')) {
            return;
        }
        $order_id = intval($order->get_id());
        if ($order_id <= 0) {
            return;
        }

        // Only trust posted values when nonce is present and valid.
        if (
            !isset($_POST['intigo_order_meta_nonce_field']) ||
            !wp_verify_nonce(
                sanitize_text_field(wp_unslash($_POST['intigo_order_meta_nonce_field'])),
                'intigo_order_meta_nonce'
            )
        ) {
            return;
        }

        $city_id = isset($_POST['intigo_city_id']) ? intval($_POST['intigo_city_id']) : 0;
        $district_id = isset($_POST['intigo_district_id']) ? intval($_POST['intigo_district_id']) : 0;
        $neighborhood_id = isset($_POST['intigo_neighborhood_id']) ? intval($_POST['intigo_neighborhood_id']) : 0;
        $package_size = isset($_POST['intigo_package_size']) ? strtoupper(sanitize_text_field(wp_unslash($_POST['intigo_package_size']))) : '';

        $dirty = false;
        if ($city_id > 0) {
            $order->update_meta_data('_intigo_city_id', $city_id);
            $dirty = true;
        }
        if ($district_id > 0) {
            $order->update_meta_data('_intigo_district_id', $district_id);
            $dirty = true;
        }
        if ($neighborhood_id > 0) {
            $order->update_meta_data('_intigo_neighborhood_id', $neighborhood_id);
            $dirty = true;
        }
        $order->delete_meta_data('_intigo_district_name');
        if (in_array($package_size, ['S', 'M', 'L', 'XL'], true)) {
            $order->update_meta_data('_intigo_package_size', $package_size);
            $dirty = true;
        }
        if ($dirty) {
            $order->save();
        }
    }

    public function maybe_sync_after_order_edit($order_id) {
        $order_id = intval($order_id);
        if ($order_id <= 0) {
            return;
        }
        $order = wc_get_order($order_id);
        if (!$order instanceof WC_Order) {
            return;
        }
        $nid = (string) $order->get_meta('_intigo_parcel_nid');
        if ($nid === '') {
            return;
        }
        // Keep sync automatic when seller edits order in WooCommerce admin.
        $sync_res = $this->update_parcel_for_order($order);
        if (empty($sync_res['ok'])) {
            $order->add_order_note('Auto sync warning: ' . ($sync_res['message'] ?? 'unknown error'));
        }
    }
}

