<?php
/**
 * Plugin Name: Intigo Parcels for WooCommerce
 * Description: Sell on WooCommerce, ship via Intigo. Customer-facing checkout flow with Intigo zone selection, automatic or manual push of orders to Intigo, bordereau generation, and live status sync.
 * Version: 0.2.6
 * Author: Intigo
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * WC requires at least: 7.0
 * WC tested up to: 10.7
 */

if (!defined('ABSPATH')) {
    exit;
}

define('INTIGO_PARCELS_VERSION', '0.2.6');
define('INTIGO_PARCELS_FILE', __FILE__);
define('INTIGO_PARCELS_DIR', plugin_dir_path(__FILE__));

require_once INTIGO_PARCELS_DIR . 'includes/class-intigo-api-client.php';
require_once INTIGO_PARCELS_DIR . 'includes/class-intigo-size-resolver.php';
require_once INTIGO_PARCELS_DIR . 'includes/class-intigo-order-service.php';
require_once INTIGO_PARCELS_DIR . 'includes/class-intigo-admin.php';
require_once INTIGO_PARCELS_DIR . 'includes/class-intigo-sync.php';
require_once INTIGO_PARCELS_DIR . 'includes/class-intigo-shipping.php';
require_once INTIGO_PARCELS_DIR . 'includes/class-intigo-product.php';
require_once INTIGO_PARCELS_DIR . 'includes/class-intigo-product-list.php';

final class Intigo_Parcels_Plugin {
    private static $instance = null;
    private $api_client;
    private $size_resolver;
    private $order_service;
    private $admin;
    private $sync;
    private $shipping;
    private $product;
    private $product_list;

    public static function instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->api_client = new Intigo_API_Client();
        $this->size_resolver = new Intigo_Size_Resolver($this->api_client);
        $this->order_service = new Intigo_Order_Service($this->api_client);
        $this->admin = new Intigo_Admin($this->order_service);
        $this->sync = new Intigo_Sync($this->api_client);
        $this->shipping = new Intigo_Shipping($this->api_client, $this->size_resolver);
        $this->product = new Intigo_Product($this->size_resolver);
        $this->product_list = new Intigo_Product_List($this->api_client);

        add_action('plugins_loaded', [$this, 'bootstrap']);
        register_activation_hook(INTIGO_PARCELS_FILE, [$this, 'activate']);
    }

    public function bootstrap() {
        $this->admin->register();
        $this->order_service->register_hooks();
        $this->sync->register_hooks();
        $this->shipping->register_hooks();
        $this->product->register_hooks();
        $this->product_list->register_hooks();
    }

    public function activate() {
        if (!wp_next_scheduled('intigo_parcels_status_sync_cron')) {
            wp_schedule_event(time() + 300, 'hourly', 'intigo_parcels_status_sync_cron');
        }
    }
}

Intigo_Parcels_Plugin::instance();

