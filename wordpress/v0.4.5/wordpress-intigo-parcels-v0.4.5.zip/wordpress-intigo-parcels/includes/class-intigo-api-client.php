<?php

if (!defined('ABSPATH')) {
    exit;
}

class Intigo_API_Client {
    const OPTION_KEY = 'intigo_parcels_settings';
    const SANDBOX_BASE_URL = 'https://dev-api.intigo.net/api';
    const PRODUCTION_BASE_URL = 'https://api.intigo.net/api';
    const LOCATION_QUERY_BASE_URL = 'https://intishop.dannous.shop/parcels/api/public/locations/?q=';

    public function get_settings() {
        $defaults = [
            // Environment switch
            'environment_mode' => 'sandbox',
            'api_key' => '',
            'fallback_enabled' => 'yes',
            'auto_create_on_paid' => 'no',
            // Whether the checkout address-confirmation modal is shown to customers.
            // 'yes' (default) = customer must confirm recipient + pick Intigo
            // city/district before placing the order. 'no' = no modal, no forced
            // validation; the Intigo zone is resolved from the standard WooCommerce
            // address at push time instead.
            'checkout_modal_enabled' => 'yes',
            // Used by Intigo_Size_Resolver as the layer-3 fallback when a product
            // hasn't been assigned a size yet.
            'default_package_size' => 'S',
            // Checkout shipping pricing per package size (Tunisian dinar).
            // The customer sees ONE of these (whichever the resolver picked for
            // the cart); they never pick a size themselves.
            'size_price_s' => 1,
            'size_price_m' => 6,
            'size_price_l' => 7,
            'size_price_xl' => 8,
            // Index of the Intigo pickup address sent with every parcel ('' = the
            // first address with GPS on the Intigo account).
            'pickup_index' => '',
        ];
        $settings = wp_parse_args(get_option(self::OPTION_KEY, []), $defaults);
        $mode = ($settings['environment_mode'] ?? 'sandbox') === 'production' ? 'production' : 'sandbox';
        $active_primary = $mode === 'production' ? self::PRODUCTION_BASE_URL : self::SANDBOX_BASE_URL;
        $settings['environment_mode'] = $mode;
        $settings['primary_base_url'] = $active_primary;
        // Keep fallback pointing to active environment API unless changed internally in code.
        $settings['legacy_base_url'] = $active_primary;
        return $settings;
    }

    /**
     * Which Intigo account the plugin talks to now: 16 hex chars of a sha256 over
     * environment, API URL and API key. The key itself is never stored or logged.
     */
    public function account_fingerprint() {
        $settings = $this->get_settings();
        return substr(hash('sha256', $settings['environment_mode'] . '|' . $settings['primary_base_url'] . '|' . (string) $settings['api_key']), 0, 16);
    }

    /** Remember on the order which account created its parcel (call before $order->save()). */
    public function stamp_parcel_account($order) {
        $order->update_meta_data('_intigo_account_fp', $this->account_fingerprint());
        $order->update_meta_data('_intigo_account_env', $this->get_settings()['environment_mode']);
    }

    /**
     * True when the order's parcel was created with another Intigo account than the
     * one configured now. Parcels sent before 0.4.5 have no fingerprint: treated as current.
     */
    public function parcel_account_mismatch($order) {
        if (!$order instanceof WC_Order || (string) $order->get_meta('_intigo_parcel_nid') === '') {
            return false;
        }
        $fp = (string) $order->get_meta('_intigo_account_fp');
        return $fp !== '' && !hash_equals($fp, $this->account_fingerprint());
    }

    /** Merchant-facing reason shown for a parcel of another account. */
    public function parcel_account_mismatch_message($order) {
        $env = (string) $order->get_meta('_intigo_account_env');
        $env_label = $env === 'production' ? __('Production', 'intigo-parcels') : ($env === 'sandbox' ? __('Sandbox', 'intigo-parcels') : $env);
        /* translators: 1: Intigo parcel NID, 2: environment of the account that created it (Sandbox or Production). */
        return sprintf(__('This parcel (NID %1$s) was created with another Intigo account (%2$s). It does not exist on the account configured now.', 'intigo-parcels'), (string) $order->get_meta('_intigo_parcel_nid'), $env_label);
    }

    /**
     * Which integration sent this request: platform, plugin version and shop domain.
     * Single source of truth — both build_headers() and the `source` body object on
     * creation calls read from here, so the two can never disagree (Intigo lets the
     * body override the headers). A value that can't be resolved is omitted, never
     * fatal.
     */
    public function build_source() {
        $version = defined('INTIGO_PARCELS_VERSION') ? (string) INTIGO_PARCELS_VERSION : '';
        // Bare host, like PrestaShop and Shopify send — Intigo's example is "boutique.tn".
        $shop = '';
        if (function_exists('home_url')) {
            $home = (string) home_url();
            $host = function_exists('wp_parse_url') ? wp_parse_url($home, PHP_URL_HOST) : parse_url($home, PHP_URL_HOST);
            $shop = $host ? (string) $host : $home;
        }
        // Strip CR/LF so a value can never break the request headers.
        $version = substr(trim(str_replace(["\r", "\n"], '', $version)), 0, 20);
        $shop = substr(trim(str_replace(["\r", "\n"], '', $shop)), 0, 200);

        $source = ['platform' => 'woocommerce'];
        if ($version !== '') {
            $source['version'] = $version;
        }
        if ($shop !== '') {
            $source['shop_url'] = $shop;
        }
        return $source;
    }

    /**
     * Headers for every call to the Intigo API. The X-Intigo-Platform* / X-Intigo-Shop
     * headers let Intigo tell which integration sent the request.
     */
    public function build_headers($settings) {
        $source = $this->build_source();
        $headers = [
            'Content-Type' => 'application/json',
            'X-API-KEY' => isset($settings['api_key']) ? $settings['api_key'] : '',
            'X-Intigo-Platform' => $source['platform'],
        ];
        if (isset($source['version'])) {
            $headers['X-Intigo-Platform-Version'] = $source['version'];
        }
        if (isset($source['shop_url'])) {
            $headers['X-Intigo-Shop'] = $source['shop_url'];
        }
        return $headers;
    }

    /**
     * Add the top-level `source` object to a parcel-creation payload. Creation routes
     * only — Intigo accepts it on /v3/parcels/ and its batch / by-postal-code variants,
     * beside `parcels` on the batch forms. A payload that isn't an array is left alone.
     */
    public function with_source($payload) {
        if (!is_array($payload)) {
            return $payload;
        }
        $payload['source'] = $this->build_source();
        return $payload;
    }

    private function request($method, $path, $payload = null, $adapter = 'primary') {
        $settings = $this->get_settings();
        $base = $adapter === 'legacy' ? $settings['legacy_base_url'] : $settings['primary_base_url'];
        $url = rtrim($base, '/') . '/' . ltrim($path, '/');

        $args = [
            'method' => strtoupper($method),
            'timeout' => 20,
            'headers' => $this->build_headers($settings),
        ];
        if ($payload !== null) {
            $args['body'] = wp_json_encode($payload);
        }

        $res = wp_remote_request($url, $args);
        if (is_wp_error($res)) {
            return ['ok' => false, 'code' => 0, 'error' => $res->get_error_message(), 'adapter' => $adapter, 'url' => $url];
        }

        $code = wp_remote_retrieve_response_code($res);
        $body = wp_remote_retrieve_body($res);
        $json = json_decode($body, true);
        $data = is_array($json) ? $json : ['raw_body' => $body];

        if ($code >= 200 && $code < 300) {
            return ['ok' => true, 'code' => $code, 'data' => $data, 'adapter' => $adapter, 'url' => $url];
        }

        return ['ok' => false, 'code' => $code, 'data' => $data, 'adapter' => $adapter, 'url' => $url];
    }

    private function with_fallback($method, $primary_path, $payload = null, $legacy_path = null) {
        $settings = $this->get_settings();
        $primary = $this->request($method, $primary_path, $payload, 'primary');
        if ($primary['ok']) {
            return $primary;
        }

        if ($settings['fallback_enabled'] !== 'yes') {
            return $primary;
        }

        if ($primary['code'] === 401 || empty($legacy_path)) {
            return $primary;
        }

        // Skip the legacy fallback when it points at the same server as primary —
        // those endpoints belong to an unrelated legacy API and just produce noisy 404s.
        $primary_base = rtrim((string) ($settings['primary_base_url'] ?? ''), '/');
        $legacy_base = rtrim((string) ($settings['legacy_base_url'] ?? ''), '/');
        if ($primary_base !== '' && $primary_base === $legacy_base) {
            return $primary;
        }

        $legacy = $this->request($method, $legacy_path, $payload, 'legacy');
        if ($legacy['ok']) {
            return $legacy;
        }
        // Both failed — surface the primary error to the user (it's the real target),
        // but attach a summary of the legacy attempt for diagnostics.
        $primary['legacy_attempt'] = [
            'code' => $legacy['code'] ?? 0,
            'error' => $legacy['error'] ?? '',
            'data' => $legacy['data'] ?? null,
            'url' => $legacy['url'] ?? '',
        ];
        return $primary;
    }

    public function create_parcel($payload) {
        return $this->with_fallback('POST', '/v3/parcels/', $this->with_source($payload), '/expediteurs/api/parcel/create/');
    }

    /**
     * POST /v3/parcels/by-name: the destination is given by names (governorate required,
     * délégation / quartier optional) and Intigo finds the délégation in the address when
     * it is missing. Same `source` body object and headers as create_parcel(); no legacy route.
     */
    public function create_parcel_by_name($payload) {
        return $this->with_fallback('POST', '/v3/parcels/by-name', $this->with_source($payload), null);
    }

    public function create_parcels_batch($payload) {
        return $this->with_fallback('POST', '/v3/parcels/batch', $this->with_source($payload), '/expediteurs/api/parcels/batch/');
    }

    /** Seconds before the pickup-address list is refetched. */
    const PICKUP_CACHE_TTL = 600;

    /** @var array|null Request-scoped memo of get_pickup_addresses(). */
    private $pickup_memo = null;

    /**
     * The pickup addresses of the Intigo account (GET /v3/pickup-addresses/), sorted
     * by index, cached 10 minutes per API base URL and key. Only a successful answer
     * is cached; any failure returns ok=false (never an empty list that looks valid).
     *
     * @return array{ok: bool, items: array, error?: string, response?: array}
     *   items: [{index: int, street: string, district: string, city: string, has_gps: bool}]
     */
    public function get_pickup_addresses($force = false) {
        $settings = $this->get_settings();
        $key_value = (string) ($settings['api_key'] ?? '');
        if (trim($key_value) === '') {
            return ['ok' => false, 'items' => [], 'error' => __('No API key is configured.', 'intigo-parcels')];
        }
        $cache_key = $this->pickup_cache_key($settings);
        if (!$force) {
            if ($this->pickup_memo !== null && ($this->pickup_memo['key'] ?? '') === $cache_key) {
                return $this->pickup_memo['result'];
            }
            $cached = get_transient($cache_key);
            if (is_array($cached) && isset($cached['items']) && is_array($cached['items'])) {
                $result = ['ok' => true, 'items' => $cached['items']];
                $this->pickup_memo = ['key' => $cache_key, 'result' => $result];
                return $result;
            }
        }
        $res = $this->request('GET', '/v3/pickup-addresses/');
        if (empty($res['ok']) || !isset($res['data']['pickup_addresses']) || !is_array($res['data']['pickup_addresses'])) {
            $result = ['ok' => false, 'items' => [], 'response' => $res];
            $this->pickup_memo = ['key' => $cache_key, 'result' => $result];
            return $result;
        }
        $items = [];
        foreach ($res['data']['pickup_addresses'] as $row) {
            // An address without an index cannot be sent as pickup_index.
            if (!is_array($row) || !isset($row['index']) || !is_numeric($row['index']) || intval($row['index']) <= 0) {
                continue;
            }
            $items[] = [
                'index' => intval($row['index']),
                'street' => trim((string) ($row['street_address'] ?? '')),
                'district' => trim((string) ($row['district_name'] ?? '')),
                'city' => trim((string) ($row['city_name'] ?? '')),
                'has_gps' => !empty($row['has_gps']),
            ];
        }
        usort($items, function ($a, $b) {
            return $a['index'] <=> $b['index'];
        });
        set_transient($cache_key, ['items' => $items], self::PICKUP_CACHE_TTL);
        $result = ['ok' => true, 'items' => $items];
        $this->pickup_memo = ['key' => $cache_key, 'result' => $result];
        return $result;
    }

    /** Transient key of the pickup-address list: one per API base URL and key. */
    private function pickup_cache_key(array $settings) {
        $base = rtrim((string) ($settings['primary_base_url'] ?? ''), '/');
        return 'intigo_pu_' . md5($base . '|' . md5((string) ($settings['api_key'] ?? '')));
    }

    /** Forget the pickup-address list (after a create or an update), so the next read refetches it. */
    public function forget_pickup_addresses() {
        delete_transient($this->pickup_cache_key($this->get_settings()));
        $this->pickup_memo = null;
    }

    /**
     * Check the fields of a pickup-address form before anything is sent to Intigo.
     * $full: a new address (street, governorate, délégation and GPS required);
     * otherwise only the fields present are checked (Add GPS sends latitude + longitude).
     * GPS is always required as a pair: Intigo refuses parcels from an address without it.
     * Decimal commas are accepted ("36,84").
     *
     * @return array{ok: bool, errors: string[], data: array} data: the API body.
     */
    public static function validate_pickup_fields(array $in, $full = true) {
        $errors = [];
        $data = [];
        $street = trim(preg_replace('/\s+/u', ' ', (string) ($in['street_address'] ?? '')));
        if ($full || array_key_exists('street_address', $in)) {
            $len = function_exists('mb_strlen') ? mb_strlen($street) : strlen($street);
            if ($street === '') {
                $errors[] = __('Type the street address.', 'intigo-parcels');
            } elseif ($len > 255) {
                $errors[] = __('The street address is too long (255 characters at most).', 'intigo-parcels');
            } else {
                $data['street_address'] = $street;
            }
        }
        if ($full) {
            $city = intval($in['city_id'] ?? 0);
            $district = intval($in['district_id'] ?? 0);
            $neighborhood = intval($in['neighborhood_id'] ?? 0);
            if ($city <= 0) {
                $errors[] = __('Choose the governorate.', 'intigo-parcels');
            } else {
                $data['city_id'] = $city;
            }
            if ($district <= 0) {
                $errors[] = __('Choose the délégation.', 'intigo-parcels');
            } else {
                $data['district_id'] = $district;
            }
            if ($neighborhood > 0 && $district > 0) {
                $data['neighborhood_id'] = $neighborhood;
            }
        }
        if ($full || array_key_exists('latitude', $in) || array_key_exists('longitude', $in)) {
            $num = function ($v) {
                $v = str_replace(',', '.', trim((string) $v));
                return ($v !== '' && is_numeric($v)) ? (float) $v : null;
            };
            $lat = $num($in['latitude'] ?? '');
            $lng = $num($in['longitude'] ?? '');
            if ($lat === null || $lng === null) {
                $errors[] = __('Latitude and longitude are required: Intigo refuses parcels from a pickup address without GPS.', 'intigo-parcels');
            } elseif ($lat < 30 || $lat > 38 || $lng < 7 || $lng > 12) {
                $errors[] = ($lng >= 30 && $lng <= 38 && $lat >= 7 && $lat <= 12)
                    ? __('Latitude and longitude look swapped: in Tunisia, the latitude is between 30 and 38 and the longitude between 7 and 12.', 'intigo-parcels')
                    : __('These coordinates are outside Tunisia: the latitude must be between 30 and 38 and the longitude between 7 and 12.', 'intigo-parcels');
            } else {
                $data['latitude'] = round($lat, 7);
                $data['longitude'] = round($lng, 7);
            }
        }
        if (array_key_exists('is_primary', $in)) {
            $data['is_primary'] = !empty($in['is_primary']);
        }
        return ['ok' => empty($errors), 'errors' => $errors, 'data' => $data];
    }

    /**
     * Create a pickup address on the Intigo account (POST /v3/pickup-addresses/).
     * Intigo assigns the index; the first address of an account becomes its primary.
     * The fields are checked first (validate_pickup_fields): nothing is sent when they are wrong.
     *
     * @return array{ok: bool, index: int, message: string, response?: array}
     */
    public function create_pickup_address(array $data) {
        $check = self::validate_pickup_fields($data, true);
        if (!$check['ok']) {
            return ['ok' => false, 'index' => 0, 'message' => implode(' ', $check['errors'])];
        }
        $body = $check['data'];
        $body['is_primary'] = !empty($body['is_primary']);
        $res = $this->request('POST', '/v3/pickup-addresses/', $body);
        return $this->pickup_write_result($res);
    }

    /**
     * Partial update of a pickup address (PATCH /v3/pickup-addresses/{index}): only
     * the fields given change — e.g. ['latitude' => …, 'longitude' => …] for Add GPS.
     *
     * @return array{ok: bool, index: int, message: string, response?: array}
     */
    public function update_pickup_address($index, array $data) {
        $index = intval($index);
        if ($index <= 0) {
            return ['ok' => false, 'index' => 0, 'message' => __('This pickup address does not exist on your Intigo account.', 'intigo-parcels')];
        }
        $check = self::validate_pickup_fields($data, false);
        if (!$check['ok']) {
            return ['ok' => false, 'index' => $index, 'message' => implode(' ', $check['errors'])];
        }
        if (empty($check['data'])) {
            return ['ok' => false, 'index' => $index, 'message' => __('Nothing to change.', 'intigo-parcels')];
        }
        $res = $this->request('PATCH', '/v3/pickup-addresses/' . $index, $check['data']);
        return $this->pickup_write_result($res, $index);
    }

    private function pickup_write_result(array $res, $index = 0) {
        if (!empty($res['ok'])) {
            $this->forget_pickup_addresses();
            $row = isset($res['data']['pickup_address']) && is_array($res['data']['pickup_address']) ? $res['data']['pickup_address'] : [];
            return ['ok' => true, 'index' => isset($row['index']) ? intval($row['index']) : intval($index), 'message' => '', 'response' => $res];
        }
        return ['ok' => false, 'index' => intval($index), 'message' => $this->humanize_error($res, self::pickup_error_codes()), 'response' => $res];
    }

    /** Intigo's pickup-address error codes, in words. */
    private static function pickup_error_codes() {
        return [
            'INVALID_GPS' => __('Give both the latitude and the longitude.', 'intigo-parcels'),
            'INVALID_CITY' => __('This governorate is unknown to Intigo.', 'intigo-parcels'),
            'INVALID_DISTRICT' => __('This délégation is not in the chosen governorate.', 'intigo-parcels'),
            'INVALID_NEIGHBORHOOD' => __('This quartier is not in the chosen délégation.', 'intigo-parcels'),
            'NOT_FOUND' => __('This pickup address does not exist on your Intigo account.', 'intigo-parcels'),
        ];
    }

    /**
     * Merchant-readable version of an API failure. $codes: error codes of the
     * route (e.g. INVALID_DISTRICT) explained in words, the code kept for support.
     */
    public function humanize_error($res, array $codes = []) {
        if (!is_array($res)) {
            return __('Intigo did not answer. Please try again.', 'intigo-parcels');
        }
        $code = isset($res['code']) ? intval($res['code']) : 0;
        if ($code === 0) {
            $detail = !empty($res['error']) ? (string) $res['error'] : __('no response', 'intigo-parcels');
            /* translators: %s: network error message. */
            return sprintf(__('Could not reach Intigo: %s', 'intigo-parcels'), $detail);
        }
        if ($code === 401 || $code === 403) {
            /* translators: %d: HTTP status code. */
            return sprintf(__('Intigo refused the API key (HTTP %d). Check the API key in the Intigo settings.', 'intigo-parcels'), $code);
        }

        $messages = [];
        $data = $res['data'] ?? null;
        if (is_array($data)) {
            foreach (['detail', 'message', 'error', 'errors', 'non_field_errors'] as $k) {
                if (isset($data[$k])) {
                    $messages = array_merge($messages, self::flatten_error_messages($data[$k]));
                }
            }
            if (empty($messages)) {
                // DRF-style field errors: {"phone1": ["Ce champ est obligatoire."]}.
                foreach ($data as $field => $value) {
                    if ($field === 'raw_body' || $field === 'status' || $field === 'code') {
                        continue;
                    }
                    foreach (self::flatten_error_messages($value) as $m) {
                        $messages[] = is_string($field) ? $field . ': ' . $m : $m;
                    }
                }
            }
        }
        if (empty($messages) && !empty($res['error'])) {
            $messages[] = (string) $res['error'];
        }

        foreach ($messages as $i => $m) {
            $m = trim((string) $m);
            if (isset($codes[$m])) {
                $messages[$i] = $codes[$m] . ' (' . $m . ')';
            }
        }

        $text = trim(wp_strip_all_tags(implode('; ', array_unique($messages))));
        if ($text === '') {
            /* translators: %d: HTTP status code. */
            return sprintf(__('Intigo returned an error (HTTP %d).', 'intigo-parcels'), $code);
        }
        if (function_exists('mb_strlen') && mb_strlen($text) > 300) {
            $text = rtrim(mb_substr($text, 0, 299)) . '…';
        }
        /* translators: 1: HTTP status code, 2: error message returned by Intigo. */
        return sprintf(__('Intigo rejected the request (HTTP %1$d): %2$s', 'intigo-parcels'), $code, $text);
    }

    private static function flatten_error_messages($value) {
        if (is_string($value) || is_numeric($value)) {
            return [(string) $value];
        }
        if (!is_array($value)) {
            return [];
        }
        // FastAPI/pydantic validation item: {"loc": ["body", "phone1"], "msg": "Value error, ..."}.
        if (isset($value['msg']) && is_string($value['msg'])) {
            $msg = preg_replace('/^Value error,\s*/i', '', $value['msg']);
            $loc = isset($value['loc']) && is_array($value['loc']) ? end($value['loc']) : '';
            return [(is_string($loc) && $loc !== '' && $loc !== 'body') ? $loc . ': ' . $msg : $msg];
        }
        $out = [];
        foreach ($value as $v) {
            $out = array_merge($out, self::flatten_error_messages($v));
        }
        return $out;
    }

    /** "#3 — Rue X, Sahloul, Sousse" (street, délégation, governorate; empty parts skipped). */
    public static function pickup_label(array $item) {
        $parts = array_values(array_filter([
            trim(preg_replace('/\s+/', ' ', (string) ($item['street'] ?? ''))),
            (string) ($item['district'] ?? ''),
            (string) ($item['city'] ?? ''),
        ], 'strlen'));
        return '#' . intval($item['index'] ?? 0) . ($parts ? ' — ' . implode(', ', $parts) : '');
    }

    public function generate_bordereau($nids) {
        return $this->with_fallback('POST', '/v3/parcels/bordereau', ['nids' => $nids], null);
    }

    public function status_bulk($nids) {
        return $this->with_fallback('POST', '/v3/parcels/status', ['nids' => $nids], null);
    }

    public function update_parcel($nid, $payload) {
        $nid = rawurlencode((string) $nid);
        return $this->with_fallback('PATCH', '/v3/parcels/' . $nid, $payload, null);
    }

    public function cancel_parcel($nid) {
        $nid = rawurlencode((string) $nid);
        return $this->with_fallback('POST', '/v3/parcels/' . $nid . '/cancel', [], null);
    }

    public function relance_parcel($nid, $accept_fee = false) {
        $nid = rawurlencode((string) $nid);
        return $this->with_fallback('POST', '/v3/parcels/' . $nid . '/relance', ['accept_fee' => (bool) $accept_fee], null);
    }

    public function report_delay($nid, $reason = '') {
        $nid = rawurlencode((string) $nid);
        $payload = [];
        if (trim((string) $reason) !== '') {
            $payload['reason'] = (string) $reason;
        }
        return $this->with_fallback('POST', '/v3/parcels/' . $nid . '/report-delay', $payload, null);
    }

    public function change_phone($nid, $phone) {
        $nid = rawurlencode((string) $nid);
        return $this->with_fallback('POST', '/v3/parcels/' . $nid . '/change-phone', [
            'phone' => (string) $phone,
        ], null);
    }

    public function change_price($nid, $price) {
        $nid = rawurlencode((string) $nid);
        return $this->with_fallback('POST', '/v3/parcels/' . $nid . '/change-price', [
            'price' => floatval($price),
        ], null);
    }

    public function change_address($nid, $payload) {
        $nid = rawurlencode((string) $nid);
        return $this->with_fallback('POST', '/v3/parcels/' . $nid . '/change-address', $payload, null);
    }

    public function fetch_cities($query = '') {
        $settings = $this->get_settings();
        $base = rtrim((string) ($settings['primary_base_url'] ?? ''), '/');
        if ($base === '') {
            return ['ok' => false, 'error' => __('primary_base_url is not configured', 'intigo-parcels'), 'items' => []];
        }
        $url = $base . '/v3/regions/cities';
        $items = $this->fetch_lookup_items_array($url, $settings);
        return $this->filter_lookup_items($items, $query);
    }

    public function fetch_districts($city_id, $query = '') {
        $settings = $this->get_settings();
        $city_id = intval($city_id);
        if ($city_id <= 0) {
            return ['ok' => false, 'error' => __('city_id is required', 'intigo-parcels'), 'items' => []];
        }
        $base = rtrim((string) ($settings['primary_base_url'] ?? ''), '/');
        if ($base === '') {
            return ['ok' => false, 'error' => __('primary_base_url is not configured', 'intigo-parcels'), 'items' => []];
        }
        $url = $base . '/v3/regions/cities/' . rawurlencode((string) $city_id) . '/districts';
        $items = $this->fetch_lookup_items_array($url, $settings);
        return $this->filter_lookup_items($items, $query);
    }

    public function fetch_neighborhoods($district_id) {
        $settings = $this->get_settings();
        $district_id = intval($district_id);
        if ($district_id <= 0) {
            return ['ok' => false, 'error' => __('district_id is required', 'intigo-parcels'), 'items' => []];
        }
        $base = rtrim((string) ($settings['primary_base_url'] ?? ''), '/');
        if ($base === '') {
            return ['ok' => false, 'error' => __('primary_base_url is not configured', 'intigo-parcels'), 'items' => []];
        }
        $url = $base . '/v3/regions/districts/' . rawurlencode((string) $district_id) . '/neighborhoods';
        $items = $this->fetch_lookup_items_array($url, $settings);
        return $items;
    }

    private function fetch_lookup_items_array($url, $settings, $timeout = 20) {
        $args = [
            'timeout' => $timeout,
            'headers' => $this->build_headers($settings),
        ];
        $res = wp_remote_get($url, $args);
        if (is_wp_error($res)) {
            return ['ok' => false, 'error' => $res->get_error_message(), 'items' => []];
        }
        $code = wp_remote_retrieve_response_code($res);
        if (in_array($code, [301, 302, 307, 308, 404], true) && substr($url, -1) !== '/') {
            $retry = wp_remote_get($url . '/', $args);
            if (!is_wp_error($retry)) {
                $retry_code = wp_remote_retrieve_response_code($retry);
                if ($retry_code >= 200 && $retry_code < 300) {
                    $res = $retry;
                    $code = $retry_code;
                }
            }
        }
        if ($code < 200 || $code >= 300) {
            return ['ok' => false, 'error' => 'http=' . $code, 'items' => []];
        }
        $body = wp_remote_retrieve_body($res);
        $json = json_decode($body, true);
        $items = $this->extract_list($json);
        return ['ok' => true, 'items' => $items];
    }

    private function extract_list($json) {
        if (!is_array($json)) {
            return [];
        }
        $candidates = $json;
        if (isset($json['data']) && is_array($json['data'])) {
            $candidates = $json['data'];
        } elseif (isset($json['results']) && is_array($json['results'])) {
            $candidates = $json['results'];
        } elseif (isset($json['cities']) && is_array($json['cities'])) {
            $candidates = $json['cities'];
        } elseif (isset($json['districts']) && is_array($json['districts'])) {
            $candidates = $json['districts'];
        } elseif (isset($json['neighborhoods']) && is_array($json['neighborhoods'])) {
            $candidates = $json['neighborhoods'];
        }
        if (!is_array($candidates)) {
            return [];
        }
        $out = [];
        foreach ($candidates as $row) {
            if (!is_array($row)) {
                continue;
            }
            if (isset($row['id']) && isset($row['name'])) {
                $out[] = ['id' => intval($row['id']), 'name' => (string) $row['name']];
            }
        }
        return $out;
    }

    private function filter_lookup_items($result, $query) {
        if (empty($result['ok'])) {
            return $result;
        }
        $query = strtolower(trim((string) $query));
        if ($query === '') {
            return $result;
        }
        $result['items'] = array_values(array_filter($result['items'], function($item) use ($query) {
            return is_array($item) && isset($item['name']) && strpos(strtolower((string) $item['name']), $query) !== false;
        }));
        return $result;
    }

    /* ---------------- Cached regions + exact name lookups ---------------- */

    /** Seconds before a cached regions list is refetched. */
    const REGIONS_CACHE_TTL = 86400;

    /** Total timeout (seconds) for resolver-path calls: short, and failures fail closed. */
    const RESOLVER_TIMEOUT = 8;

    /** @var array Request-scoped memo of cached lists, keyed like the transients. */
    private $regions_memo = [];

    /**
     * Lowercase, accents removed, every non-alphanumeric run → one space.
     * "Béja " → "beja", "Mutuelle-Ville" → "mutuelle ville".
     */
    public static function normalize_name($name) {
        $s = (string) $name;
        if (function_exists('remove_accents')) {
            $s = remove_accents($s);
        } elseif (function_exists('iconv')) {
            $conv = @iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $s);
            if ($conv !== false) {
                $s = $conv;
            }
        }
        $s = strtolower($s);
        $s = preg_replace('/[^a-z0-9]+/', ' ', $s);
        return trim(preg_replace('/\s+/', ' ', (string) $s));
    }

    /** normalize_name() without any space: "El Menzah 6" → "elmenzah6". */
    public static function squash_name($name) {
        return str_replace(' ', '', self::normalize_name($name));
    }

    /** All cities, cached 24h per API base URL. ['ok'=>bool,'items'=>[{id,name}],'error'?]. */
    public function get_cities_cached() {
        return $this->cached_regions('cities', 0);
    }

    /**
     * The cached cities list WITHOUT any network call (null when not cached yet) —
     * for pages that must stay read-only while rendering.
     */
    public function peek_cities_cached() {
        $settings = $this->get_settings();
        $base = rtrim((string) ($settings['primary_base_url'] ?? ''), '/');
        $key = 'intigo_rg_' . md5($base . '|cities|0');
        if (isset($this->regions_memo[$key])) {
            return $this->regions_memo[$key]['items'];
        }
        $cached = get_transient($key);
        return is_array($cached) && !empty($cached['items']) && is_array($cached['items']) ? $cached['items'] : null;
    }

    /** Districts of one city, cached 24h. */
    public function get_districts_cached($city_id) {
        return $this->cached_regions('districts', intval($city_id));
    }

    /** Neighborhoods of one district, cached 24h. */
    public function get_neighborhoods_cached($district_id) {
        return $this->cached_regions('neighborhoods', intval($district_id));
    }

    /**
     * Only successful answers are cached — an API outage must not be remembered
     * as "this city has no districts" for a day.
     */
    private function cached_regions($kind, $parent_id) {
        $settings = $this->get_settings();
        $base = rtrim((string) ($settings['primary_base_url'] ?? ''), '/');
        $key = 'intigo_rg_' . md5($base . '|' . $kind . '|' . $parent_id);
        if (isset($this->regions_memo[$key])) {
            return $this->regions_memo[$key];
        }
        $cached = get_transient($key);
        if (is_array($cached) && isset($cached['items']) && is_array($cached['items'])) {
            return $this->regions_memo[$key] = ['ok' => true, 'items' => $cached['items']];
        }
        if ($kind !== 'cities' && $parent_id <= 0) {
            return ['ok' => false, 'error' => 'invalid id', 'items' => []];
        }
        if ($base === '') {
            return ['ok' => false, 'error' => 'primary_base_url is not configured', 'items' => []];
        }
        if ($kind === 'cities') {
            $url = $base . '/v3/regions/cities';
        } elseif ($kind === 'districts') {
            $url = $base . '/v3/regions/cities/' . rawurlencode((string) $parent_id) . '/districts';
        } else {
            $url = $base . '/v3/regions/districts/' . rawurlencode((string) $parent_id) . '/neighborhoods';
        }
        $res = $this->fetch_lookup_items_array($url, $settings, self::RESOLVER_TIMEOUT);
        if (empty($res['ok'])) {
            return $res;
        }
        set_transient($key, ['items' => $res['items']], self::REGIONS_CACHE_TTL);
        return $this->regions_memo[$key] = ['ok' => true, 'items' => $res['items']];
    }

    /** Exact (squashed) name match within a list; null when absent. */
    private static function find_by_name($items, $name) {
        $key = self::squash_name($name);
        if ($key === '' || !is_array($items)) {
            return null;
        }
        foreach ($items as $item) {
            if (is_array($item) && isset($item['name']) && self::squash_name($item['name']) === $key) {
                return $item;
            }
        }
        return null;
    }

    /** City id for an exact name ("Béja" = "beja"), 0 when unknown or the API is down. */
    public function city_id_by_name($name) {
        $res = $this->get_cities_cached();
        $hit = empty($res['ok']) ? null : self::find_by_name($res['items'], $name);
        return $hit ? intval($hit['id']) : 0;
    }

    /** District id for an exact name inside one city, 0 when not found. */
    public function district_id_by_name($city_id, $name) {
        if (intval($city_id) <= 0) {
            return 0;
        }
        $res = $this->get_districts_cached($city_id);
        $hit = empty($res['ok']) ? null : self::find_by_name($res['items'], $name);
        return $hit ? intval($hit['id']) : 0;
    }

    /** Neighborhood id for an exact name inside one district, 0 when not found. */
    public function neighborhood_id_by_name($district_id, $name) {
        if (intval($district_id) <= 0) {
            return 0;
        }
        $res = $this->get_neighborhoods_cached($district_id);
        $hit = empty($res['ok']) ? null : self::find_by_name($res['items'], $name);
        return $hit ? intval($hit['id']) : 0;
    }

    /** True only when $district_id is listed among $city_id's districts. */
    public function district_belongs_to_city($district_id, $city_id) {
        $district_id = intval($district_id);
        $city_id = intval($city_id);
        if ($district_id <= 0 || $city_id <= 0) {
            return false;
        }
        $res = $this->get_districts_cached($city_id);
        if (empty($res['ok'])) {
            return false;
        }
        foreach ($res['items'] as $d) {
            if (intval($d['id']) === $district_id) {
                return true;
            }
        }
        return false;
    }

    /**
     * Names of a zone given by ids, from the cached regions lists (no guessing).
     * An id that is not in its parent's list gets '' — which callers treat as
     * "these ids do not belong together".
     *
     * @return array{city_name: string, district_name: string, neighborhood_name: string}
     */
    public function zone_names($city_id, $district_id, $neighborhood_id = 0) {
        $out = ['city_name' => '', 'district_name' => '', 'neighborhood_name' => ''];
        $lists = [
            'city_name' => [intval($city_id), $this->get_cities_cached()],
            'district_name' => [intval($district_id), intval($city_id) > 0 ? $this->get_districts_cached($city_id) : null],
            'neighborhood_name' => [intval($neighborhood_id), intval($district_id) > 0 && intval($neighborhood_id) > 0 ? $this->get_neighborhoods_cached($district_id) : null],
        ];
        foreach ($lists as $key => $pair) {
            list($id, $res) = $pair;
            if ($id <= 0 || !is_array($res) || empty($res['ok'])) {
                continue;
            }
            foreach ($res['items'] as $item) {
                if (intval($item['id']) === $id) {
                    $out[$key] = (string) $item['name'];
                    break;
                }
            }
        }
        return $out;
    }

    /**
     * The public free-text location guesser. Its ranking is fuzzy (q=Tunis ranks
     * a Sfax street first), so callers must fence its rows — never take row 0.
     * Returns ['ok'=>bool,'items'=>[...]]: ok=false means unreachable, which is
     * NOT the same as "no results".
     */
    public function search_locations($query) {
        $query = trim((string) $query);
        if ($query === '') {
            return ['ok' => false, 'error' => 'empty query', 'items' => []];
        }
        $res = wp_remote_get(self::LOCATION_QUERY_BASE_URL . rawurlencode($query), [
            'timeout' => self::RESOLVER_TIMEOUT,
            'headers' => ['Content-Type' => 'application/json'],
        ]);
        if (is_wp_error($res)) {
            return ['ok' => false, 'error' => $res->get_error_message(), 'items' => []];
        }
        $code = wp_remote_retrieve_response_code($res);
        if ($code < 200 || $code >= 300) {
            return ['ok' => false, 'error' => 'http=' . $code, 'items' => []];
        }
        $json = json_decode(wp_remote_retrieve_body($res), true);
        if (!is_array($json) || !isset($json['results']) || !is_array($json['results'])) {
            return ['ok' => false, 'error' => 'invalid response', 'items' => []];
        }
        $items = [];
        foreach ($json['results'] as $r) {
            if (!is_array($r)) {
                continue;
            }
            $items[] = [
                'city_id' => isset($r['city_id']) ? intval($r['city_id']) : 0,
                'city_name' => isset($r['city_name']) ? (string) $r['city_name'] : '',
                'district_id' => isset($r['district_id']) ? intval($r['district_id']) : 0,
                'district_name' => isset($r['district_name']) ? (string) $r['district_name'] : '',
                'neighborhood_id' => isset($r['neighborhood_id']) ? intval($r['neighborhood_id']) : 0,
                'neighborhood_name' => isset($r['neighborhood_name']) ? (string) $r['neighborhood_name'] : '',
            ];
        }
        return ['ok' => true, 'items' => $items];
    }
}
