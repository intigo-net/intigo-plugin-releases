<?php

if (!defined('ABSPATH')) {
    exit;
}

class Intigo_Order_Service {
    private $api;

    public function __construct($api_client) {
        $this->api = $api_client;
    }

    public function register_hooks() {
        add_filter('woocommerce_order_actions', [$this, 'register_order_actions']);
        add_filter('bulk_actions-edit-shop_order', [$this, 'register_bulk_action']);
        add_filter('handle_bulk_actions-edit-shop_order', [$this, 'handle_bulk_action'], 10, 3);
        add_action('woocommerce_order_action_intigo_create_parcel', [$this, 'create_single_for_order']);
        add_action('woocommerce_order_action_intigo_generate_bordereau', [$this, 'generate_bordereau_for_order']);
        add_action('woocommerce_order_status_processing', [$this, 'maybe_auto_create_from_order_event']);
        add_action('woocommerce_process_shop_order_meta', [$this, 'maybe_sync_after_order_edit'], 30, 1);
    }

    public function register_order_actions($actions) {
        $actions['intigo_create_parcel'] = __('Intigo: Create Parcel', 'intigo-parcels');
        $actions['intigo_generate_bordereau'] = __('Intigo: Generate Bordereau', 'intigo-parcels');
        return $actions;
    }

    public function register_bulk_action($actions) {
        $actions['intigo_create_parcels_batch'] = __('Intigo: Create Parcels (Batch)', 'intigo-parcels');
        return $actions;
    }

    public function handle_bulk_action($redirect_to, $action, $post_ids) {
        if ($action !== 'intigo_create_parcels_batch') {
            return $redirect_to;
        }

        $batch = ['parcels' => []];
        foreach ($post_ids as $order_id) {
            $order = wc_get_order($order_id);
            if (!$order) {
                continue;
            }
            $payload = $this->order_to_payload($order);
            $batch['parcels'][] = $payload;
        }

        $res = $this->api->create_parcels_batch($batch);
        $created = !empty($res['data']['created']) ? intval($res['data']['created']) : 0;
        return add_query_arg(['intigo_batch_created' => $created], $redirect_to);
    }

    public function create_single_for_order($order) {
        if (!$order instanceof WC_Order) {
            return;
        }
        $this->hydrate_intigo_meta_from_request($order);
        $key = $this->idempotency_key($order, 'manual_create');
        if (get_post_meta($order->get_id(), '_intigo_idem_' . md5($key), true)) {
            $order->add_order_note('Intigo create skipped: parcel already created for this order (idempotency). Use "Intigo: Force Create Parcel" to create another one.');
            return;
        }

        $payload = $this->order_to_payload($order);
        $this->enrich_payload_with_location_ids($order, $payload);
        $validation_error = $this->validate_payload($payload);
        if ($validation_error !== null) {
            $order->add_order_note('Intigo parcel creation failed: ' . $validation_error);
            return;
        }
        $res = $this->api->create_parcel($payload);

        if (!empty($res['ok']) && !empty($res['data']['nid'])) {
            update_post_meta($order->get_id(), '_intigo_parcel_nid', sanitize_text_field($res['data']['nid']));
            update_post_meta($order->get_id(), '_intigo_api_target_used', sanitize_text_field($res['adapter']));
            update_post_meta($order->get_id(), '_intigo_idem_' . md5($key), 1);
            $order->add_order_note('Intigo parcel created: ' . $res['data']['nid']);
        } else {
            $order->add_order_note('Intigo parcel creation failed: ' . $this->format_api_error($res));
        }
    }

    public function force_create_for_order($order) {
        if (!$order instanceof WC_Order) {
            return;
        }
        // Ignore idempotency for explicit force action.
        delete_post_meta($order->get_id(), '_intigo_idem_' . md5($this->idempotency_key($order, 'manual_create')));
        $this->create_single_for_order($order);
    }

    public function update_parcel_for_order($order) {
        if (!$order instanceof WC_Order) {
            return ['ok' => false, 'message' => 'Invalid order instance'];
        }
        $this->hydrate_intigo_meta_from_request($order);

        $nid = get_post_meta($order->get_id(), '_intigo_parcel_nid', true);
        if (empty($nid)) {
            $order->add_order_note('Intigo update failed: no parcel NID found. Create parcel first.');
            return ['ok' => false, 'message' => 'No parcel NID found'];
        }

        $payload = $this->order_to_payload($order);
        $this->enrich_payload_with_location_ids($order, $payload);
        $validation_error = $this->validate_payload($payload);
        if ($validation_error !== null) {
            $order->add_order_note('Intigo update failed: ' . $validation_error);
            return ['ok' => false, 'message' => $validation_error];
        }

        $res = $this->api->update_parcel($nid, $payload);
        if (!empty($res['ok'])) {
            $order->add_order_note('Intigo parcel updated successfully: ' . $nid);
            return ['ok' => true, 'message' => 'Updated via PATCH', 'response' => $res];
        }

        // Fallback sync strategy for parcels that are no longer patchable.
        $fallback_errors = [];

        $phone_res = $this->api->change_phone($nid, $payload['phone1'] ?? '');
        if (empty($phone_res['ok'])) {
            $fallback_errors[] = 'phone=' . $this->format_api_error($phone_res);
        }

        $addr_payload = [
            'address' => $payload['destination_address'] ?? '',
            'city_id' => intval($payload['destination_city_id'] ?? 0),
            'district_id' => intval($payload['destination_district_id'] ?? 0),
        ];
        if (!empty($payload['destination_neighborhood_id'])) {
            $addr_payload['neighborhood_id'] = intval($payload['destination_neighborhood_id']);
        }
        $addr_res = $this->api->change_address($nid, $addr_payload);
        if (empty($addr_res['ok'])) {
            $fallback_errors[] = 'address=' . $this->format_api_error($addr_res);
        }

        $price_res = $this->api->change_price($nid, floatval($payload['price'] ?? 0));
        if (empty($price_res['ok'])) {
            $fallback_errors[] = 'price=' . $this->format_api_error($price_res);
        }

        if (count($fallback_errors) < 3) {
            $order->add_order_note('Intigo parcel synchronized partially using fallback actions: ' . $nid);
            return ['ok' => true, 'message' => 'Synchronized with fallback actions', 'response' => [
                'patch' => $res,
                'phone' => $phone_res,
                'address' => $addr_res,
                'price' => $price_res,
            ]];
        }

        $order->add_order_note('Intigo parcel update failed: ' . $this->format_api_error($res));
        $order->add_order_note('Intigo fallback sync failed: ' . implode(' | ', $fallback_errors));
        return ['ok' => false, 'message' => implode(' | ', $fallback_errors), 'response' => [
            'patch' => $res,
            'phone' => $phone_res,
            'address' => $addr_res,
            'price' => $price_res,
        ]];
    }

    public function generate_bordereau_for_order($order) {
        if (!$order instanceof WC_Order) {
            return;
        }

        $nid = get_post_meta($order->get_id(), '_intigo_parcel_nid', true);
        if (empty($nid)) {
            $order->add_order_note('No Intigo parcel NID found for bordereau');
            return;
        }

        $res = $this->api->generate_bordereau([$nid]);
        if (!empty($res['ok']) && !empty($res['data']['url'])) {
            update_post_meta($order->get_id(), '_intigo_bordereau_url', esc_url_raw($res['data']['url']));
            $order->add_order_note('Intigo bordereau URL generated');
        } else {
            $order->add_order_note('Intigo bordereau generation failed: ' . $this->format_api_error($res));
        }
    }

    public function maybe_auto_create_from_order_event($order_id) {
        $settings = $this->api->get_settings();
        if ($settings['auto_create_on_paid'] !== 'yes') {
            return;
        }

        $order = wc_get_order($order_id);
        if (!$order) {
            return;
        }

        $key = $this->idempotency_key($order, 'order_paid');
        if (get_post_meta($order_id, '_intigo_idem_' . md5($key), true)) {
            return;
        }

        $this->create_single_for_order($order);
    }

    private function order_to_payload($order) {
        $recipient_name = trim($order->get_shipping_first_name() . ' ' . $order->get_shipping_last_name());
        if ($recipient_name === '') {
            $recipient_name = trim($order->get_billing_first_name() . ' ' . $order->get_billing_last_name());
        }

        $phone = trim((string) $order->get_billing_phone());
        if ($phone === '' && method_exists($order, 'get_shipping_phone')) {
            $phone = trim((string) $order->get_shipping_phone());
        }
        if ($phone === '') {
            $phone = trim((string) get_post_meta($order->get_id(), '_shipping_phone', true));
        }
        if ($phone === '') {
            $phone = trim((string) get_post_meta($order->get_id(), '_billing_phone', true));
        }

        $destination_address = trim($order->get_shipping_address_1() . ' ' . $order->get_shipping_address_2());
        if ($destination_address === '') {
            $destination_address = trim($order->get_billing_address_1() . ' ' . $order->get_billing_address_2());
        }

        $raw_package_size = get_post_meta($order->get_id(), '_intigo_package_size', true);
        if ($raw_package_size === '') {
            $settings = $this->api->get_settings();
            $raw_package_size = (string) ($settings['default_package_size'] ?? 'S');
        }
        $package_size = $this->normalize_package_size($raw_package_size);

        $payload = [
            'recipient_name' => $recipient_name,
            'phone1' => $phone,
            'destination_address' => $destination_address,
            'destination_city_id' => intval(get_post_meta($order->get_id(), '_intigo_city_id', true)),
            'destination_district_id' => intval(get_post_meta($order->get_id(), '_intigo_district_id', true)),
            'price' => floatval($order->get_total()),
            'package_size' => $package_size,
            'description' => 'WooCommerce Order #' . $order->get_id(),
            'can_open' => false,
        ];
        $neighborhood_id = intval(get_post_meta($order->get_id(), '_intigo_neighborhood_id', true));
        if ($neighborhood_id > 0) {
            $payload['destination_neighborhood_id'] = $neighborhood_id;
        }
        return $payload;
    }

    private function idempotency_key($order, $event) {
        return sprintf('wp:%d:%d:%s:v1', get_current_blog_id(), $order->get_id(), $event);
    }

    private function validate_payload($payload) {
        if (empty($payload['recipient_name'])) {
            return 'recipient_name is required (shipping first/last name missing)';
        }
        if (empty($payload['phone1'])) {
            return 'phone1 is required (billing phone missing)';
        }
        if (empty($payload['destination_address'])) {
            return 'destination_address is required (shipping address missing)';
        }
        if (empty($payload['destination_city_id'])) {
            return '_intigo_city_id order meta is required';
        }
        if (empty($payload['destination_district_id'])) {
            return '_intigo_district_id order meta is required';
        }
        return null;
    }

    private function format_api_error($res) {
        if (!is_array($res)) {
            return 'unknown error';
        }
        $parts = [];
        if (isset($res['adapter'])) {
            $parts[] = 'adapter=' . $res['adapter'];
        }
        if (isset($res['code'])) {
            $parts[] = 'http=' . $res['code'];
        }
        if (!empty($res['error'])) {
            $parts[] = 'error=' . $res['error'];
        } elseif (!empty($res['data'])) {
            $parts[] = 'response=' . wp_json_encode($res['data']);
        }
        return empty($parts) ? 'unknown error' : implode(' | ', $parts);
    }

    private function enrich_payload_with_location_ids($order, &$payload) {
        // City auto-lookup from shipping/billing city if ID is missing.
        if (empty($payload['destination_city_id'])) {
            $city_name = trim((string) $order->get_shipping_city());
            if ($city_name === '') {
                $city_name = trim((string) $order->get_billing_city());
            }
            if ($city_name !== '') {
                $city_id = intval($this->api->resolve_city_id($city_name));
                if ($city_id > 0) {
                    $payload['destination_city_id'] = $city_id;
                    update_post_meta($order->get_id(), '_intigo_city_id', $city_id);
                }
            }
        }

        // District auto-lookup from explicit meta name, shipping state, or billing state.
        if (empty($payload['destination_district_id'])) {
            $district_name = trim((string) get_post_meta($order->get_id(), '_intigo_district_name', true));
            if ($district_name === '') {
                $district_name = trim((string) $order->get_shipping_state());
            }
            if ($district_name === '') {
                $district_name = trim((string) $order->get_billing_state());
            }
            if ($district_name !== '') {
                $district_id = intval($this->api->resolve_district_id($district_name, intval($payload['destination_city_id'])));
                if ($district_id > 0) {
                    $payload['destination_district_id'] = $district_id;
                    update_post_meta($order->get_id(), '_intigo_district_id', $district_id);
                }
            }
        }
    }

    private function normalize_package_size($raw) {
        $raw = trim((string) $raw);
        if ($raw === '') {
            return 1;
        }
        if (is_numeric($raw)) {
            return max(1, intval($raw));
        }
        $s = strtoupper($raw);
        $map = [
            'S' => 1,
            'SMALL' => 1,
            'M' => 2,
            'MEDIUM' => 2,
            'L' => 4,
            'LARGE' => 4,
            'XL' => 5,
            'EXTRALARGE' => 5,
        ];
        return $map[$s] ?? 1;
    }

    private function hydrate_intigo_meta_from_request($order) {
        if (!is_object($order) || !method_exists($order, 'get_id')) {
            return;
        }
        $order_id = intval($order->get_id());
        if ($order_id <= 0) {
            return;
        }

        // Only trust posted values when nonce is present and valid.
        if (
            !isset($_POST['intigo_order_meta_nonce_field']) ||
            !wp_verify_nonce(
                sanitize_text_field(wp_unslash($_POST['intigo_order_meta_nonce_field'])),
                'intigo_order_meta_nonce'
            )
        ) {
            return;
        }

        $city_id = isset($_POST['intigo_city_id']) ? intval($_POST['intigo_city_id']) : 0;
        $district_id = isset($_POST['intigo_district_id']) ? intval($_POST['intigo_district_id']) : 0;
        $neighborhood_id = isset($_POST['intigo_neighborhood_id']) ? intval($_POST['intigo_neighborhood_id']) : 0;
        $package_size = isset($_POST['intigo_package_size']) ? strtoupper(sanitize_text_field(wp_unslash($_POST['intigo_package_size']))) : '';

        if ($city_id > 0) {
            update_post_meta($order_id, '_intigo_city_id', $city_id);
        }
        if ($district_id > 0) {
            update_post_meta($order_id, '_intigo_district_id', $district_id);
        }
        if ($neighborhood_id > 0) {
            update_post_meta($order_id, '_intigo_neighborhood_id', $neighborhood_id);
        }
        delete_post_meta($order_id, '_intigo_district_name');
        if (in_array($package_size, ['S', 'M', 'L', 'XL'], true)) {
            update_post_meta($order_id, '_intigo_package_size', $package_size);
        }
    }

    public function maybe_sync_after_order_edit($order_id) {
        $order_id = intval($order_id);
        if ($order_id <= 0) {
            return;
        }
        $order = wc_get_order($order_id);
        if (!$order instanceof WC_Order) {
            return;
        }
        $nid = (string) get_post_meta($order_id, '_intigo_parcel_nid', true);
        if ($nid === '') {
            return;
        }
        // Keep sync automatic when seller edits order in WooCommerce admin.
        $sync_res = $this->update_parcel_for_order($order);
        if (empty($sync_res['ok'])) {
            $order->add_order_note('Auto sync warning: ' . ($sync_res['message'] ?? 'unknown error'));
        }
    }
}

