<?php

if (!defined('ABSPATH')) {
    exit;
}

class Intigo_Admin {
    private $order_service;
    private $api_client;
    const META_OPS_STATUS = '_intigo_ops_status';
    const OPTION_AUTH = 'intigo_parcels_auth';
    const OPTION_LOGS = 'intigo_parcels_logs';
    const MAX_LOGS = 1000;

    public function __construct($order_service) {
        $this->order_service = $order_service;
        $this->api_client = new Intigo_API_Client();
    }

    public function register() {
        add_action('admin_menu', [$this, 'add_menu']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('add_meta_boxes', [$this, 'register_order_meta_box']);
        add_action('add_meta_boxes_woocommerce_page_wc-orders', [$this, 'register_order_meta_box_hpos']);
        add_action('woocommerce_admin_order_data_after_order_details', [$this, 'render_hpos_inline_fields'], 20, 1);
        add_action('save_post_shop_order', [$this, 'save_order_meta_box'], 10, 2);
        add_action('woocommerce_process_shop_order_meta', [$this, 'save_order_meta_box_from_order_id'], 10, 1);
        add_action('wp_ajax_intigo_get_cities', [$this, 'ajax_get_cities']);
        add_action('wp_ajax_intigo_get_districts', [$this, 'ajax_get_districts']);
        add_action('wp_ajax_intigo_get_neighborhoods', [$this, 'ajax_get_neighborhoods']);
        add_action('admin_post_intigo_download_bordereau', [$this, 'handle_download_bordereau']);
        add_action('admin_post_intigo_order_action', [$this, 'handle_intigo_order_action']);
        add_action('admin_post_intigo_login', [$this, 'handle_intigo_login']);
        add_action('admin_post_intigo_logout', [$this, 'handle_intigo_logout']);
        add_shortcode('intigo_manage_orders', [$this, 'render_manage_orders_shortcode']);
    }

    public function add_menu() {
        $new_orders_count = $this->get_new_orders_count();
        $manage_orders_label = 'Manage Orders';
        if ($new_orders_count > 0) {
            $manage_orders_label .= ' <span class="awaiting-mod count-' . intval($new_orders_count) . '"><span class="pending-count">' . intval($new_orders_count) . '</span></span>';
        }
        add_menu_page(
            'Intigo Dashboard',
            'Intigo',
            'manage_woocommerce',
            'intigo-dashboard',
            [$this, 'render_dashboard'],
            'dashicons-location-alt',
            56
        );
        add_submenu_page(
            'intigo-dashboard',
            'Dashboard',
            'Dashboard',
            'manage_woocommerce',
            'intigo-dashboard',
            [$this, 'render_dashboard']
        );
        add_submenu_page(
            'intigo-dashboard',
            'Manage Orders',
            $manage_orders_label,
            'manage_woocommerce',
            'intigo-manage-orders',
            [$this, 'render_panel']
        );
        add_submenu_page(
            'intigo-dashboard',
            'Logs',
            'Logs',
            'manage_woocommerce',
            'intigo-logs',
            [$this, 'render_logs']
        );

        add_submenu_page(
            'intigo-dashboard',
            'Documentation',
            'Documentation',
            'manage_woocommerce',
            'intigo-docs',
            [$this, 'render_docs']
        );

        add_submenu_page(
            'intigo-dashboard',
            'Intigo Settings',
            'Settings',
            'manage_woocommerce',
            'intigo-parcels-settings',
            [$this, 'render_settings']
        );
    }

    public function register_settings() {
        register_setting('intigo_parcels_group', Intigo_API_Client::OPTION_KEY);
    }

    public function render_settings() {
        $settings = get_option(Intigo_API_Client::OPTION_KEY, []);
        $health = $this->check_health();
        ?>
        <div class="wrap">
            <h1>Intigo Parcels Settings</h1>
            <?php $this->render_responsive_styles(); ?>
            <?php $this->render_interface_nav('intigo-parcels-settings'); ?>
            <?php $this->render_snackbar(); ?>
            <?php $this->render_environment_badge(); ?>
            <div style="margin:12px 0; padding:10px 12px; border-left:4px solid <?php echo esc_attr($health['ok'] ? '#46b450' : '#d63638'); ?>; background:#fff;">
                <strong>API Health:</strong>
                <?php echo esc_html($health['message']); ?>
            </div>
            <form method="post" action="options.php">
                <?php settings_fields('intigo_parcels_group'); ?>
                <table class="form-table">
                    <tr>
                        <th scope="row">Environment Mode</th>
                        <td>
                            <select name="<?php echo esc_attr(Intigo_API_Client::OPTION_KEY); ?>[environment_mode]">
                                <option value="sandbox" <?php selected(($settings['environment_mode'] ?? 'sandbox'), 'sandbox'); ?>>Sandbox (Testing)</option>
                                <option value="production" <?php selected(($settings['environment_mode'] ?? 'sandbox'), 'production'); ?>>Production (Live)</option>
                            </select>
                            <p class="description">Sandbox is recommended for testing; Production sends real shipments.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Sandbox API (fixed)</th>
                        <td><code>https://dev-api.intigo.net/api</code></td>
                    </tr>
                    <tr>
                        <th scope="row">Production API (fixed)</th>
                        <td><code>https://api.intigo.net/api</code></td>
                    </tr>
                    <tr>
                        <th scope="row">API Key</th>
                        <td>
                            <input type="password" class="regular-text" name="<?php echo esc_attr(Intigo_API_Client::OPTION_KEY); ?>[api_key]" value="<?php echo esc_attr($settings['api_key'] ?? ''); ?>">
                            <p class="description">Used for all Intigo API calls. Keep this key secret.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Enable Fallback</th>
                        <td>
                            <select name="<?php echo esc_attr(Intigo_API_Client::OPTION_KEY); ?>[fallback_enabled]">
                                <option value="yes" <?php selected(($settings['fallback_enabled'] ?? 'yes'), 'yes'); ?>>Yes</option>
                                <option value="no" <?php selected(($settings['fallback_enabled'] ?? 'yes'), 'no'); ?>>No</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Lookup Endpoints</th>
                        <td>
                            <code>/api/v3/regions/cities</code><br>
                            <code>/api/v3/regions/cities/{city_id}/districts</code><br>
                            <code>/api/v3/regions/districts/{district_id}/neighborhoods</code>
                            <p class="description">These are fixed and follow the selected environment mode.</p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Auto create on paid order</th>
                        <td>
                            <select name="<?php echo esc_attr(Intigo_API_Client::OPTION_KEY); ?>[auto_create_on_paid]">
                                <option value="yes" <?php selected(($settings['auto_create_on_paid'] ?? 'no'), 'yes'); ?>>Yes</option>
                                <option value="no" <?php selected(($settings['auto_create_on_paid'] ?? 'no'), 'no'); ?>>No</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">Default Package Size</th>
                        <td>
                            <select name="<?php echo esc_attr(Intigo_API_Client::OPTION_KEY); ?>[default_package_size]">
                                <option value="S" <?php selected(($settings['default_package_size'] ?? 'S'), 'S'); ?>>S</option>
                                <option value="M" <?php selected(($settings['default_package_size'] ?? 'S'), 'M'); ?>>M</option>
                                <option value="L" <?php selected(($settings['default_package_size'] ?? 'S'), 'L'); ?>>L</option>
                                <option value="XL" <?php selected(($settings['default_package_size'] ?? 'S'), 'XL'); ?>>XL</option>
                            </select>
                            <p class="description">Used when order metadata has no package size.</p>
                        </td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }

    public function render_dashboard() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized');
        }
        if (!$this->is_intigo_logged_in()) {
            $this->render_login_interface('Please login to Intigo to manage system interactions.');
            return;
        }
        $orders = function_exists('wc_get_orders') ? wc_get_orders(['limit' => 20, 'orderby' => 'date', 'order' => 'DESC']) : [];
        $stats_orders = function_exists('wc_get_orders') ? wc_get_orders(['limit' => 200, 'orderby' => 'date', 'order' => 'DESC']) : $orders;
        $metrics = $this->compute_dashboard_metrics($stats_orders);
        $total_orders_for_chart = max(1, intval($metrics['total_orders']));
        $product_posts = function_exists('wp_count_posts') ? wp_count_posts('product') : null;
        $metrics['total_products'] = ($product_posts && isset($product_posts->publish)) ? intval($product_posts->publish) : 0;
        $logs = array_slice($this->get_logs(), 0, 8);
        ?>
        <div class="wrap">
            <h1>Intigo Dashboard</h1>
            <?php $this->render_responsive_styles(); ?>
            <?php $this->render_interface_nav('intigo-dashboard'); ?>
            <?php $this->render_snackbar(); ?>
            <p style="color:#50575e;">Start here for current Intigo operations overview.</p>
            <?php $this->render_environment_badge(); ?>
            <p>
                <a class="button button-primary" href="<?php echo esc_url(admin_url('admin.php?page=intigo-manage-orders')); ?>">Go to Manage Orders</a>
                <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=intigo-logs')); ?>">View Logs</a>
                <a class="button" href="<?php echo esc_url(admin_url('admin.php?page=intigo-parcels-settings')); ?>">Settings</a>
            </p>
            <style>
                .intigo-kpis { display:grid; grid-template-columns: repeat(4, minmax(160px, 1fr)); gap:10px; margin-top:12px; }
                .intigo-kpi { background:#f6f7f7; border:1px solid #dcdcde; border-radius:6px; padding:10px; }
                .intigo-kpi-label { font-size:12px; color:#646970; margin-bottom:4px; }
                .intigo-kpi-value { font-size:18px; font-weight:600; color:#1d2327; }
                .intigo-charts { display:grid; grid-template-columns: 1fr 1fr; gap:12px; margin-top:12px; }
                .intigo-chart-card { background:#fff; border:1px solid #dcdcde; border-radius:8px; padding:12px; }
                .intigo-chart-title { margin:0 0 10px 0; font-size:13px; color:#1d2327; }
                .intigo-bar-row { margin-bottom:8px; }
                .intigo-bar-meta { display:flex; justify-content:space-between; font-size:12px; color:#50575e; margin-bottom:4px; }
                .intigo-bar-track { width:100%; height:8px; border-radius:999px; background:#f0f0f1; overflow:hidden; }
                .intigo-bar-fill { height:100%; border-radius:999px; }
                .intigo-fill-blue { background:#2271b1; }
                .intigo-fill-green { background:#46b450; }
                .intigo-fill-yellow { background:#dba617; }
                .intigo-fill-gray { background:#8c8f94; }
                .intigo-action-select-wrap { display:flex; gap:6px; align-items:center; flex-wrap:wrap; margin-top:4px; }
                .intigo-action-select { min-width: 210px; }
            </style>
            <div class="intigo-kpis">
                <div class="intigo-kpi"><div class="intigo-kpi-label">Total orders</div><div class="intigo-kpi-value"><?php echo esc_html($metrics['total_orders']); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label">Orders in Intigo</div><div class="intigo-kpi-value"><?php echo esc_html($metrics['with_parcel']); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label">Orders not in Intigo</div><div class="intigo-kpi-value"><?php echo esc_html(max(0, intval($metrics['total_orders']) - intval($metrics['with_parcel']))); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label">Need verification</div><div class="intigo-kpi-value"><?php echo esc_html($metrics['need_confirmation']); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label">Missing data</div><div class="intigo-kpi-value"><?php echo esc_html($metrics['missing_data']); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label">Total products</div><div class="intigo-kpi-value"><?php echo esc_html($metrics['total_products']); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label">Total sales</div><div class="intigo-kpi-value"><?php echo wp_kses_post(wc_price($metrics['total_sales'])); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label">Average order</div><div class="intigo-kpi-value"><?php echo wp_kses_post(wc_price($metrics['avg_order_value'])); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label">Intigo coverage</div><div class="intigo-kpi-value"><?php echo esc_html($metrics['coverage_rate']); ?>%</div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label">Ready for shipment</div><div class="intigo-kpi-value"><?php echo esc_html($metrics['ready_for_shipment']); ?></div></div>
            </div>
            <div class="intigo-charts">
                <div class="intigo-chart-card">
                    <h3 class="intigo-chart-title">Order Progress</h3>
                    <div class="intigo-bar-row"><div class="intigo-bar-meta"><span>Orders in Intigo</span><strong><?php echo esc_html($metrics['with_parcel']); ?></strong></div><div class="intigo-bar-track"><div class="intigo-bar-fill intigo-fill-blue" style="width:<?php echo esc_attr(round(($metrics['with_parcel'] / $total_orders_for_chart) * 100, 1)); ?>%;"></div></div></div>
                    <div class="intigo-bar-row"><div class="intigo-bar-meta"><span>Ready for shipment</span><strong><?php echo esc_html($metrics['ready_for_shipment']); ?></strong></div><div class="intigo-bar-track"><div class="intigo-bar-fill intigo-fill-green" style="width:<?php echo esc_attr(round(($metrics['ready_for_shipment'] / $total_orders_for_chart) * 100, 1)); ?>%;"></div></div></div>
                    <div class="intigo-bar-row"><div class="intigo-bar-meta"><span>Bordereau generated</span><strong><?php echo esc_html($metrics['with_bordereau']); ?></strong></div><div class="intigo-bar-track"><div class="intigo-bar-fill intigo-fill-green" style="width:<?php echo esc_attr(round(($metrics['with_bordereau'] / $total_orders_for_chart) * 100, 1)); ?>%;"></div></div></div>
                </div>
                <div class="intigo-chart-card">
                    <h3 class="intigo-chart-title">Recent plugin activity</h3>
                    <?php if (empty($logs)): ?>
                        <p>No logs yet.</p>
                    <?php else: ?>
                        <ul>
                            <?php foreach ($logs as $log): ?>
                                <li><code><?php echo esc_html((string) ($log['time'] ?? '')); ?></code> - <?php echo esc_html((string) ($log['action'] ?? '')); ?> <small style="color:#646970;">(<?php echo esc_html((string) ($log['actor'] ?? 'system')); ?>)</small></li>
                            <?php endforeach; ?>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
    }

    public function render_panel() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized');
        }
        if (!$this->is_intigo_logged_in()) {
            $this->render_login_interface('Please login to Intigo to manage system interactions.');
            return;
        }
        $orders = function_exists('wc_get_orders') ? wc_get_orders(['limit' => 20, 'orderby' => 'date', 'order' => 'DESC']) : [];
        $this->mark_orders_as_seen($orders);
        $metrics = $this->compute_dashboard_metrics($orders);
        $total_orders_for_chart = max(1, intval($metrics['total_orders']));
        ?>
        <div class="wrap">
            <h1>Intigo - Manage Orders</h1>
            <?php $this->render_responsive_styles(); ?>
            <?php $this->render_interface_nav('intigo-manage-orders'); ?>
            <p style="color:#50575e;">Manage WooCommerce orders and execute Intigo actions.</p>
            <?php $this->render_environment_badge(); ?>
            <div style="margin:8px 0 14px 0;">
                <span style="display:inline-block; padding:4px 10px; background:#dcfce7; color:#166534; border-radius:999px; font-size:12px; font-weight:600;">
                    Logged in as <?php echo esc_html($this->get_intigo_login_label()); ?>
                </span>
                <a class="button button-small" style="margin-left:8px;" href="<?php echo esc_url(wp_nonce_url(admin_url('admin-post.php?action=intigo_logout'), 'intigo_logout')); ?>">Logout</a>
            </div>
            <?php $this->render_snackbar(); ?>

            <style>
                .intigo-card { background:#fff; border:1px solid #dcdcde; border-radius:8px; padding:14px; margin-top:16px; }
                .intigo-kpis { display:grid; grid-template-columns: repeat(4, minmax(140px, 1fr)); gap:10px; margin-top:12px; }
                .intigo-kpi { background:#f6f7f7; border:1px solid #dcdcde; border-radius:6px; padding:10px; }
                .intigo-kpi-label { font-size:12px; color:#646970; margin-bottom:4px; }
                .intigo-kpi-value { font-size:18px; font-weight:600; color:#1d2327; }
                .intigo-pill { display:inline-block; padding:2px 8px; border-radius:999px; font-size:11px; font-weight:600; }
                .intigo-pill-ok { background:#dcfce7; color:#166534; }
                .intigo-pill-warn { background:#fef3c7; color:#92400e; }
                .intigo-pill-info { background:#dbeafe; color:#1e3a8a; }
                .intigo-pill-muted { background:#f3f4f6; color:#374151; }
                .intigo-actions .button { margin: 0 4px 4px 0; }
                .intigo-meta-edit-link { text-decoration:none; vertical-align:middle; }
                .intigo-meta-edit-link .dashicons { font-size:16px; width:16px; height:16px; }
                .intigo-modal-backdrop { position:fixed; inset:0; background:rgba(0,0,0,.35); display:none; align-items:center; justify-content:center; z-index:9999; }
                .intigo-modal { width:min(520px, 92vw); background:#fff; border-radius:10px; border:1px solid #dcdcde; box-shadow:0 10px 30px rgba(0,0,0,.18); }
                .intigo-modal-header { padding:12px 14px; border-bottom:1px solid #ececec; display:flex; justify-content:space-between; align-items:center; }
                .intigo-modal-body { padding:14px; }
                .intigo-form-row { margin-bottom:10px; }
                .intigo-form-row label { display:block; margin-bottom:4px; font-weight:600; }
                .intigo-form-row input, .intigo-form-row select { width:100%; }
                .intigo-modal-open { overflow:hidden; }
                .intigo-charts { display:grid; grid-template-columns: 1fr 1fr; gap:12px; margin-top:12px; }
                .intigo-chart-card { background:#fff; border:1px solid #dcdcde; border-radius:8px; padding:12px; }
                .intigo-chart-title { margin:0 0 10px 0; font-size:13px; color:#1d2327; }
                .intigo-bar-row { margin-bottom:8px; }
                .intigo-bar-meta { display:flex; justify-content:space-between; font-size:12px; color:#50575e; margin-bottom:4px; }
                .intigo-bar-track { width:100%; height:8px; border-radius:999px; background:#f0f0f1; overflow:hidden; }
                .intigo-bar-fill { height:100%; border-radius:999px; }
                .intigo-fill-blue { background:#2271b1; }
                .intigo-fill-green { background:#46b450; }
                .intigo-fill-yellow { background:#dba617; }
                .intigo-fill-gray { background:#8c8f94; }
            </style>

            <div class="intigo-kpis">
                <div class="intigo-kpi"><div class="intigo-kpi-label">Total orders</div><div class="intigo-kpi-value"><?php echo esc_html($metrics['total_orders']); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label">Orders in Intigo</div><div class="intigo-kpi-value"><?php echo esc_html($metrics['with_parcel']); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label">Need verification</div><div class="intigo-kpi-value"><?php echo esc_html($metrics['need_confirmation']); ?></div></div>
                <div class="intigo-kpi"><div class="intigo-kpi-label">Missing data</div><div class="intigo-kpi-value"><?php echo esc_html($metrics['missing_data']); ?></div></div>
            </div>
            <div class="intigo-charts">
                <div class="intigo-chart-card">
                    <h3 class="intigo-chart-title">Order Progress</h3>
                    <div class="intigo-bar-row">
                        <div class="intigo-bar-meta"><span>Orders in Intigo</span><strong><?php echo esc_html($metrics['with_parcel']); ?></strong></div>
                        <div class="intigo-bar-track"><div class="intigo-bar-fill intigo-fill-blue" style="width:<?php echo esc_attr(round(($metrics['with_parcel'] / $total_orders_for_chart) * 100, 1)); ?>%;"></div></div>
                    </div>
                    <div class="intigo-bar-row">
                        <div class="intigo-bar-meta"><span>Ready for shipment</span><strong><?php echo esc_html($metrics['ready_for_shipment']); ?></strong></div>
                        <div class="intigo-bar-track"><div class="intigo-bar-fill intigo-fill-green" style="width:<?php echo esc_attr(round(($metrics['ready_for_shipment'] / $total_orders_for_chart) * 100, 1)); ?>%;"></div></div>
                    </div>
                    <div class="intigo-bar-row">
                        <div class="intigo-bar-meta"><span>Bordereau generated</span><strong><?php echo esc_html($metrics['with_bordereau']); ?></strong></div>
                        <div class="intigo-bar-track"><div class="intigo-bar-fill intigo-fill-green" style="width:<?php echo esc_attr(round(($metrics['with_bordereau'] / $total_orders_for_chart) * 100, 1)); ?>%;"></div></div>
                    </div>
                </div>
                <div class="intigo-chart-card">
                    <h3 class="intigo-chart-title">Verification Funnel</h3>
                    <div class="intigo-bar-row">
                        <div class="intigo-bar-meta"><span>Verified</span><strong><?php echo esc_html($metrics['verified']); ?></strong></div>
                        <div class="intigo-bar-track"><div class="intigo-bar-fill intigo-fill-green" style="width:<?php echo esc_attr(round(($metrics['verified'] / $total_orders_for_chart) * 100, 1)); ?>%;"></div></div>
                    </div>
                    <div class="intigo-bar-row">
                        <div class="intigo-bar-meta"><span>Need confirmation</span><strong><?php echo esc_html($metrics['need_confirmation']); ?></strong></div>
                        <div class="intigo-bar-track"><div class="intigo-bar-fill intigo-fill-yellow" style="width:<?php echo esc_attr(round(($metrics['need_confirmation'] / $total_orders_for_chart) * 100, 1)); ?>%;"></div></div>
                    </div>
                    <div class="intigo-bar-row">
                        <div class="intigo-bar-meta"><span>Missing data</span><strong><?php echo esc_html($metrics['missing_data']); ?></strong></div>
                        <div class="intigo-bar-track"><div class="intigo-bar-fill intigo-fill-gray" style="width:<?php echo esc_attr(round(($metrics['missing_data'] / $total_orders_for_chart) * 100, 1)); ?>%;"></div></div>
                    </div>
                </div>
            </div>

            <div class="intigo-card">
            <h2 style="margin-top:0;">Orders</h2>
            <table class="widefat striped">
                <thead>
                    <tr>
                        <th>Order</th>
                        <th>Status</th>
                        <th>Total</th>
                        <th>Destination</th>
                        <th>Package</th>
                        <th>Parcel NID</th>
                        <th>Intigo Metadata</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($orders as $order): ?>
                    <?php
                    $order_id = $order->get_id();
                    $nid = (string) get_post_meta($order_id, '_intigo_parcel_nid', true);
                    $create_url = wp_nonce_url(admin_url('admin-post.php?action=intigo_order_action&op=create&order_id=' . $order_id), 'intigo_order_action_' . $order_id . '_create');
                    $bordereau_url = wp_nonce_url(admin_url('admin-post.php?action=intigo_order_action&op=bordereau&order_id=' . $order_id), 'intigo_order_action_' . $order_id . '_bordereau');
                    $sync_url = wp_nonce_url(admin_url('admin-post.php?action=intigo_order_action&op=sync_update&order_id=' . $order_id), 'intigo_order_action_' . $order_id . '_sync_update');
                    $cancel_url = wp_nonce_url(admin_url('admin-post.php?action=intigo_order_action&op=cancel&order_id=' . $order_id), 'intigo_order_action_' . $order_id . '_cancel');
                    $relance_url = wp_nonce_url(admin_url('admin-post.php?action=intigo_order_action&op=relance&order_id=' . $order_id), 'intigo_order_action_' . $order_id . '_relance');
                    $delay_url = wp_nonce_url(admin_url('admin-post.php?action=intigo_order_action&op=report_delay&order_id=' . $order_id), 'intigo_order_action_' . $order_id . '_report_delay');
                    $download_url = wp_nonce_url(admin_url('admin-post.php?action=intigo_download_bordereau&order_id=' . $order_id), 'intigo_download_bordereau_' . $order_id);
                    $stored_bordereau_url = (string) get_post_meta($order_id, '_intigo_bordereau_url', true);
                    $print_url = $stored_bordereau_url !== '' ? $stored_bordereau_url : '';
                    $city_id = (string) get_post_meta($order_id, '_intigo_city_id', true);
                    $district_id = (string) get_post_meta($order_id, '_intigo_district_id', true);
                    $neighborhood_id = (string) get_post_meta($order_id, '_intigo_neighborhood_id', true);
                    $pkg = (string) get_post_meta($order_id, '_intigo_package_size', true);
                    $api_target = (string) get_post_meta($order_id, '_intigo_api_target_used', true);
                    $last_status = (string) get_post_meta($order_id, '_intigo_last_status', true);
                    $last_sync = (string) get_post_meta($order_id, '_intigo_last_sync_at', true);
                    $ops_status = $this->compute_automatic_ops_status($city_id, $district_id, $pkg, $nid, $stored_bordereau_url);
                    update_post_meta($order_id, self::META_OPS_STATUS, $ops_status);
                    $tags = $this->build_order_tags($city_id, $district_id, $pkg, $nid, $ops_status);
                    $order_edit_url = admin_url('admin.php?page=wc-orders&action=edit&id=' . $order_id);
                    $missing_required_meta = ($city_id === '' || $district_id === '' || $pkg === '');
                    $has_parcel_in_intigo = ($nid !== '');
                    $can_send = ($ops_status === 'verified');
                    $can_generate_bordereau = $has_parcel_in_intigo;
                    ?>
                    <tr>
                        <td>
                            <a href="<?php echo esc_url(admin_url('admin.php?page=wc-orders&action=edit&id=' . $order_id)); ?>">#<?php echo esc_html($order_id); ?></a>
                            <?php if ($this->is_order_new($order_id)): ?>
                                <span class="intigo-pill intigo-pill-info">NEW</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo esc_html($order->get_status()); ?></td>
                        <td><?php echo wp_kses_post($order->get_formatted_order_total()); ?></td>
                        <td>
                            <small>City ID: <?php echo esc_html($city_id !== '' ? $city_id : '—'); ?></small><br>
                            <small>District ID: <?php echo esc_html($district_id !== '' ? $district_id : '—'); ?></small><br>
                            <small>Neighborhood ID: <?php echo esc_html($neighborhood_id !== '' ? $neighborhood_id : '—'); ?></small>
                            <?php if ($missing_required_meta): ?>
                                <a class="intigo-meta-edit-link" href="<?php echo esc_url($order_edit_url); ?>" title="Edit Intigo metadata">
                                    <span class="dashicons dashicons-edit"></span>
                                </a>
                            <?php endif; ?>
                        </td>
                        <td><?php echo esc_html($pkg !== '' ? strtoupper($pkg) : '—'); ?></td>
                        <td><?php echo $nid !== '' ? esc_html($nid) : '<span style="color:#777;">—</span>'; ?></td>
                        <td>
                            <div><small>API: <?php echo esc_html($api_target !== '' ? $api_target : '—'); ?></small></div>
                            <div><small>Last status: <?php echo esc_html($last_status !== '' ? $last_status : '—'); ?></small></div>
                            <div><small>Last sync: <?php echo esc_html($last_sync !== '' ? $last_sync : '—'); ?></small></div>
                            <div style="margin-top:4px; display:flex; gap:4px; flex-wrap:wrap;">
                                <?php if ($nid !== ''): ?>
                                    <span class="intigo-pill intigo-pill-ok">Parcel Created</span>
                                <?php else: ?>
                                    <span class="intigo-pill intigo-pill-warn">Not Sent</span>
                                <?php endif; ?>
                                <?php foreach ($tags as $tag): ?>
                                    <span class="intigo-pill <?php echo esc_attr($tag['class']); ?>"><?php echo esc_html($tag['label']); ?></span>
                                <?php endforeach; ?>
                            </div>
                        </td>
                        <td>
                            <div class="intigo-actions">
                                <?php if ($can_send): ?>
                                    <a class="button button-small" href="<?php echo esc_url($create_url); ?>">Send to Intigo</a>
                                <?php else: ?>
                                    <button class="button button-small" disabled title="Complete required metadata first">Send to Intigo</button>
                                <?php endif; ?>
                                <button
                                    type="button"
                                    class="button button-small intigo-open-meta-modal"
                                    data-order-id="<?php echo esc_attr($order_id); ?>"
                                    data-city-id="<?php echo esc_attr($city_id); ?>"
                                    data-district-id="<?php echo esc_attr($district_id); ?>"
                                    data-neighborhood-id="<?php echo esc_attr($neighborhood_id); ?>"
                                    data-package-size="<?php echo esc_attr($pkg !== '' ? strtoupper($pkg) : 'S'); ?>"
                                >Edit</button>
                                <?php if ($can_generate_bordereau): ?>
                                    <a class="button button-small" href="<?php echo esc_url($bordereau_url); ?>">Generate Bordereau</a>
                                <?php else: ?>
                                    <button class="button button-small" disabled title="Requires Intigo parcel ID first">Generate Bordereau</button>
                                <?php endif; ?>
                            <button
                                type="button"
                                class="button button-small intigo-open-actions-modal"
                                data-order-id="<?php echo esc_attr($order_id); ?>"
                                data-sync-url="<?php echo esc_url($sync_url); ?>"
                                data-relance-url="<?php echo esc_url($relance_url); ?>"
                                data-delay-url="<?php echo esc_url($delay_url); ?>"
                                data-cancel-url="<?php echo esc_url($cancel_url); ?>"
                                data-has-nid="<?php echo esc_attr($nid !== '' ? '1' : '0'); ?>"
                            >More Actions</button>
                            <?php if ($stored_bordereau_url !== ''): ?>
                                <a class="button button-small button-primary" href="<?php echo esc_url($download_url); ?>">Download</a>
                                <a class="button button-small" target="_blank" rel="noopener noreferrer" href="<?php echo esc_url($print_url); ?>">Print</a>
                            <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
            </div>

        </div>
        <div id="intigo-meta-modal-backdrop" class="intigo-modal-backdrop" aria-hidden="true">
            <div class="intigo-modal" role="dialog" aria-modal="true" aria-labelledby="intigoMetaModalTitle">
                <div class="intigo-modal-header">
                    <strong id="intigoMetaModalTitle">Edit Intigo Metadata</strong>
                    <button type="button" class="button-link" id="intigo-meta-modal-close">Close</button>
                </div>
                <div class="intigo-modal-body">
                    <form method="get" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                        <input type="hidden" name="action" value="intigo_order_action">
                        <input type="hidden" name="op" value="save_metadata">
                        <input type="hidden" name="order_id" id="intigo_meta_order_id" value="">
                        <input type="hidden" id="intigo_meta_lookup_nonce" value="<?php echo esc_attr(wp_create_nonce('intigo_lookup_nonce')); ?>">
                        <?php wp_nonce_field('intigo_order_action_meta_edit', '_wpnonce'); ?>
                        <div class="intigo-form-row">
                            <label for="intigo_meta_city_id">City ID *</label>
                            <select id="intigo_meta_city_id" name="intigo_city_id" required>
                                <option value="">Select city</option>
                            </select>
                        </div>
                        <div class="intigo-form-row">
                            <label for="intigo_meta_district_id">District ID *</label>
                            <select id="intigo_meta_district_id" name="intigo_district_id" required>
                                <option value="">Select district</option>
                            </select>
                        </div>
                        <div class="intigo-form-row">
                            <label for="intigo_meta_neighborhood_id">Neighborhood ID (optional)</label>
                            <select id="intigo_meta_neighborhood_id" name="intigo_neighborhood_id">
                                <option value="">Select neighborhood</option>
                            </select>
                        </div>
                        <div class="intigo-form-row">
                            <label for="intigo_meta_package_size">Package Size *</label>
                            <select id="intigo_meta_package_size" name="intigo_package_size" required>
                                <option value="S">S</option>
                                <option value="M">M</option>
                                <option value="L">L</option>
                                <option value="XL">XL</option>
                            </select>
                        </div>
                        <button type="submit" class="button button-primary">Save Metadata</button>
                    </form>
                </div>
            </div>
        </div>
        <div id="intigo-actions-modal-backdrop" class="intigo-modal-backdrop" aria-hidden="true">
            <div class="intigo-modal" role="dialog" aria-modal="true" aria-labelledby="intigoActionsModalTitle">
                <div class="intigo-modal-header">
                    <strong id="intigoActionsModalTitle">Order Actions</strong>
                    <button type="button" class="button-link" id="intigo-actions-modal-close">Close</button>
                </div>
                <div class="intigo-modal-body">
                    <p style="margin-top:0;">Select an action, then click Run.</p>
                    <div class="intigo-form-row">
                        <label for="intigo_modal_action_select">Action</label>
                        <select id="intigo_modal_action_select" class="intigo-action-select">
                            <option value="">Select action...</option>
                        </select>
                    </div>
                    <button type="button" class="button button-primary" id="intigo_modal_action_run">Run</button>
                </div>
            </div>
        </div>
        <script>
        (function() {
            const backdrop = document.getElementById('intigo-meta-modal-backdrop');
            const closeBtn = document.getElementById('intigo-meta-modal-close');
            const orderInput = document.getElementById('intigo_meta_order_id');
            const cityInput = document.getElementById('intigo_meta_city_id');
            const districtInput = document.getElementById('intigo_meta_district_id');
            const neighborhoodInput = document.getElementById('intigo_meta_neighborhood_id');
            const packageInput = document.getElementById('intigo_meta_package_size');
            const lookupNonceInput = document.getElementById('intigo_meta_lookup_nonce');
            const openButtons = document.querySelectorAll('.intigo-open-meta-modal');
            const openActionsButtons = document.querySelectorAll('.intigo-open-actions-modal');
            const actionsBackdrop = document.getElementById('intigo-actions-modal-backdrop');
            const actionsCloseBtn = document.getElementById('intigo-actions-modal-close');
            const actionsSelect = document.getElementById('intigo_modal_action_select');
            const actionsRunBtn = document.getElementById('intigo_modal_action_run');
            if (!backdrop || !closeBtn || !openButtons.length) return;
            if (actionsBackdrop && actionsBackdrop.parentNode !== document.body) {
                document.body.appendChild(actionsBackdrop);
            }
            const ajaxUrl = "<?php echo esc_js(admin_url('admin-ajax.php')); ?>";
            const lookupNonce = lookupNonceInput ? lookupNonceInput.value : '';
            let pendingSelection = { cityId: '', districtId: '', neighborhoodId: '' };

            function addOption(select, value, label, selected) {
                const opt = document.createElement('option');
                opt.value = value;
                opt.textContent = label;
                if (selected) opt.selected = true;
                select.appendChild(opt);
            }

            function setLoading(select, text) {
                select.innerHTML = '';
                addOption(select, '', text, true);
            }

            function loadCities(selectedCityId) {
                setLoading(cityInput, 'Loading cities...');
                fetch(ajaxUrl + '?action=intigo_get_cities&_wpnonce=' + encodeURIComponent(lookupNonce), { credentials: 'same-origin' })
                    .then(r => r.json())
                    .then(data => {
                        cityInput.innerHTML = '';
                        addOption(cityInput, '', 'Select city', false);
                        if (!data || !data.success || !Array.isArray(data.data)) {
                            const msg = (data && data.data && data.data.message) ? data.data.message : 'Lookup failed';
                            addOption(cityInput, '', msg, true);
                            return;
                        }
                        data.data.forEach(c => addOption(cityInput, c.id, c.name, String(c.id) === String(selectedCityId)));
                        if (selectedCityId) {
                            loadDistricts(selectedCityId, pendingSelection.districtId);
                        } else {
                            districtInput.innerHTML = '';
                            addOption(districtInput, '', 'Select district', false);
                            neighborhoodInput.innerHTML = '';
                            addOption(neighborhoodInput, '', 'Select neighborhood', false);
                        }
                    })
                    .catch(() => {
                        cityInput.innerHTML = '';
                        addOption(cityInput, '', 'Lookup failed: network/AJAX error', true);
                    });
            }

            function loadDistricts(cityId, selectedDistrictId) {
                if (!cityId) {
                    districtInput.innerHTML = '';
                    addOption(districtInput, '', 'Select district', false);
                    neighborhoodInput.innerHTML = '';
                    addOption(neighborhoodInput, '', 'Select neighborhood', false);
                    return;
                }
                setLoading(districtInput, 'Loading districts...');
                fetch(ajaxUrl + '?action=intigo_get_districts&city_id=' + encodeURIComponent(cityId) + '&_wpnonce=' + encodeURIComponent(lookupNonce), { credentials: 'same-origin' })
                    .then(r => r.json())
                    .then(data => {
                        districtInput.innerHTML = '';
                        addOption(districtInput, '', 'Select district', false);
                        if (!data || !data.success || !Array.isArray(data.data)) {
                            const msg = (data && data.data && data.data.message) ? data.data.message : 'Lookup failed';
                            addOption(districtInput, '', msg, true);
                            return;
                        }
                        data.data.forEach(d => addOption(districtInput, d.id, d.name, String(d.id) === String(selectedDistrictId)));
                        if (selectedDistrictId) {
                            loadNeighborhoods(selectedDistrictId, pendingSelection.neighborhoodId);
                        } else {
                            neighborhoodInput.innerHTML = '';
                            addOption(neighborhoodInput, '', 'Select neighborhood', false);
                        }
                    })
                    .catch(() => {
                        districtInput.innerHTML = '';
                        addOption(districtInput, '', 'Lookup failed: network/AJAX error', true);
                    });
            }

            function loadNeighborhoods(districtId, selectedNeighborhoodId) {
                if (!districtId) {
                    neighborhoodInput.innerHTML = '';
                    addOption(neighborhoodInput, '', 'Select neighborhood', false);
                    return;
                }
                setLoading(neighborhoodInput, 'Loading neighborhoods...');
                fetch(ajaxUrl + '?action=intigo_get_neighborhoods&district_id=' + encodeURIComponent(districtId) + '&_wpnonce=' + encodeURIComponent(lookupNonce), { credentials: 'same-origin' })
                    .then(r => r.json())
                    .then(data => {
                        neighborhoodInput.innerHTML = '';
                        addOption(neighborhoodInput, '', 'Select neighborhood', false);
                        if (!data || !data.success || !Array.isArray(data.data)) {
                            const msg = (data && data.data && data.data.message) ? data.data.message : 'Lookup failed';
                            addOption(neighborhoodInput, '', msg, true);
                            return;
                        }
                        data.data.forEach(n => addOption(neighborhoodInput, n.id, n.name, String(n.id) === String(selectedNeighborhoodId)));
                    })
                    .catch(() => {
                        neighborhoodInput.innerHTML = '';
                        addOption(neighborhoodInput, '', 'Lookup failed: network/AJAX error', true);
                    });
            }

            function openModal(btn) {
                orderInput.value = btn.getAttribute('data-order-id') || '';
                pendingSelection = {
                    cityId: btn.getAttribute('data-city-id') || '',
                    districtId: btn.getAttribute('data-district-id') || '',
                    neighborhoodId: btn.getAttribute('data-neighborhood-id') || '',
                };
                packageInput.value = btn.getAttribute('data-package-size') || 'S';
                loadCities(pendingSelection.cityId);
                backdrop.style.display = 'flex';
                document.body.classList.add('intigo-modal-open');
            }
            function closeModal() {
                backdrop.style.display = 'none';
                document.body.classList.remove('intigo-modal-open');
            }
            openButtons.forEach((btn) => btn.addEventListener('click', () => openModal(btn)));
            cityInput.addEventListener('change', function() {
                pendingSelection.districtId = '';
                pendingSelection.neighborhoodId = '';
                loadDistricts(cityInput.value, '');
            });
            districtInput.addEventListener('change', function() {
                pendingSelection.neighborhoodId = '';
                loadNeighborhoods(districtInput.value, '');
            });
            function addActionOption(value, label) {
                const opt = document.createElement('option');
                opt.value = value;
                opt.textContent = label;
                actionsSelect.appendChild(opt);
            }
            function openActionsModal(btn) {
                if (!actionsBackdrop || !actionsSelect) return;
                actionsSelect.innerHTML = '';
                addActionOption('', 'Select action...');
                addActionOption(btn.getAttribute('data-sync-url') || '', 'Synchronize with Intigo');
                if ((btn.getAttribute('data-has-nid') || '') === '1') {
                    addActionOption(btn.getAttribute('data-relance-url') || '', 'Request Relance');
                    addActionOption(btn.getAttribute('data-delay-url') || '', 'Report Delay');
                    addActionOption(btn.getAttribute('data-cancel-url') || '', 'Cancel Parcel');
                }
                actionsBackdrop.style.display = 'flex';
                document.body.classList.add('intigo-modal-open');
            }
            function closeActionsModal() {
                if (!actionsBackdrop) return;
                actionsBackdrop.style.display = 'none';
                document.body.classList.remove('intigo-modal-open');
            }
            openActionsButtons.forEach((btn) => btn.addEventListener('click', () => openActionsModal(btn)));
            if (actionsRunBtn) {
                actionsRunBtn.addEventListener('click', function() {
                    if (!actionsSelect || !actionsSelect.value) return;
                    window.location.href = actionsSelect.value;
                });
            }
            if (actionsCloseBtn) actionsCloseBtn.addEventListener('click', closeActionsModal);
            closeBtn.addEventListener('click', closeModal);
            backdrop.addEventListener('click', function(e) {
                if (e.target === backdrop) closeModal();
            });
            if (actionsBackdrop) {
                actionsBackdrop.addEventListener('click', function(e) {
                    if (e.target === actionsBackdrop) closeActionsModal();
                });
            }
            document.addEventListener('keydown', function(e) {
                if (e.key === 'Escape' && backdrop.style.display === 'flex') closeModal();
                if (e.key === 'Escape' && actionsBackdrop && actionsBackdrop.style.display === 'flex') closeActionsModal();
            });
        })();
        </script>
        <?php
    }

    public function render_logs() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized');
        }
        $logs = $this->get_logs();
        ?>
        <div class="wrap">
            <h1>Intigo Logs</h1>
            <?php $this->render_responsive_styles(); ?>
            <?php $this->render_interface_nav('intigo-logs'); ?>
            <?php $this->render_snackbar(); ?>
            <p style="color:#50575e;">Latest <?php echo esc_html(self::MAX_LOGS); ?> plugin actions and messages.</p>
            <?php $this->render_environment_badge(); ?>
            <table class="widefat striped">
                <thead>
                    <tr>
                        <th>Time</th>
                        <th>Actor</th>
                        <th>Action</th>
                        <th>Context</th>
                    </tr>
                </thead>
                <tbody>
                <?php if (empty($logs)): ?>
                    <tr><td colspan="4">No logs available.</td></tr>
                <?php else: ?>
                    <?php foreach ($logs as $log): ?>
                        <tr>
                            <td><code><?php echo esc_html((string) ($log['time'] ?? '')); ?></code></td>
                            <td><?php echo esc_html((string) ($log['actor'] ?? 'system')); ?></td>
                            <td><?php echo esc_html((string) ($log['action'] ?? '')); ?></td>
                            <td><small><?php echo esc_html((string) ($log['context'] ?? '')); ?></small></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    public function render_docs() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized');
        }
        ?>
        <div class="wrap">
            <h1>Intigo Documentation</h1>
            <?php $this->render_responsive_styles(); ?>
            <?php $this->render_interface_nav('intigo-docs'); ?>
            <?php $this->render_snackbar(); ?>
            <?php $this->render_environment_badge(); ?>
            <div style="display:grid; grid-template-columns:1fr; gap:12px; margin-top:10px;">
                <div style="background:#fff; border:1px solid #dcdcde; border-radius:8px; padding:16px;">
                    <h2 style="margin-top:0;">Getting Started</h2>
                    <ol>
                        <li>Go to <strong>Intigo -> Settings</strong>.</li>
                        <li>Add your <strong>API Key</strong>.</li>
                        <li>Select <strong>Sandbox</strong> for testing or <strong>Production</strong> for live operations.</li>
                        <li>Save settings and verify the API Health status.</li>
                    </ol>
                    <p><strong>Order flow:</strong> once orders are created in WooCommerce, they appear automatically in <strong>Intigo -> Manage Orders</strong>. From there, complete metadata (city/district/neighborhood/package), send to Intigo, then generate and download bordereau.</p>
                </div>

                <div style="background:#fff; border:1px solid #dcdcde; border-radius:8px; padding:16px;">
                    <h2 style="margin-top:0;">Operational Best Practices</h2>
                    <ul>
                        <li>Use <strong>Sandbox</strong> first for validation before switching to Production.</li>
                        <li>Do not generate bordereau until parcel creation succeeds and Intigo Parcel ID is available.</li>
                        <li>Review <strong>Logs</strong> page regularly for failed lookups or API errors.</li>
                        <li>Ensure city/district metadata is complete to avoid missing-data status.</li>
                    </ul>
                </div>

                <div style="background:#fff; border:1px solid #dcdcde; border-radius:8px; padding:16px;">
                    <h2 style="margin-top:0;">Troubleshooting</h2>
                    <ul>
                        <li><strong>Cannot load cities/districts:</strong> check API key and environment mode in Settings.</li>
                        <li><strong>Send to Intigo is disabled:</strong> required metadata is missing; use Edit in Manage Orders.</li>
                        <li><strong>Bordereau action disabled:</strong> parcel must exist first in Intigo.</li>
                        <li><strong>Login/Health failures:</strong> verify API key and endpoint availability.</li>
                    </ul>
                    <p style="margin-bottom:0;"><strong>Need help?</strong> If errors persist, contact support at <a href="mailto:hello@intigo.tn">hello@intigo.tn</a>.</p>
                </div>

                <div style="background:#fff; border:1px solid #dcdcde; border-radius:8px; padding:16px;">
                    <h2 style="margin-top:0;">Quick Guide (FR / AR)</h2>
                    <p><strong>Francais:</strong> Commencez par ajouter votre cle API dans les Parametres, choisissez Sandbox ou Production, puis enregistrez. Les commandes WooCommerce apparaitront dans Manage Orders pour completer les metadonnees et traiter l'expedition. En cas d'erreur, contactez <a href="mailto:hello@intigo.tn">hello@intigo.tn</a>.</p>
                    <p style="margin-bottom:0;"><strong>العربية:</strong> ابدأ بإضافة مفتاح API من صفحة الإعدادات ثم اختر وضع الاختبار أو الإنتاج. بعد إنشاء الطلبات في WooCommerce ستظهر تلقائياً في Manage Orders لإكمال البيانات ثم الشحن. في حال وجود أخطاء تواصل مع <a href="mailto:hello@intigo.tn">hello@intigo.tn</a>.</p>
                </div>
            </div>
        </div>
        <?php
    }

    public function register_order_meta_box() {
        add_meta_box(
            'intigo_shipment_meta',
            'Intigo Shipment',
            [$this, 'render_order_meta_box'],
            'shop_order',
            'side',
            'default'
        );
    }

    public function register_order_meta_box_hpos($screen_id = '') {
        // HPOS order editor screen id is typically woocommerce_page_wc-orders.
        $target = $screen_id ?: 'woocommerce_page_wc-orders';
        add_meta_box(
            'intigo_shipment_meta',
            'Intigo Shipment',
            [$this, 'render_order_meta_box_hpos'],
            $target,
            'side',
            'default'
        );
    }

    public function render_order_meta_box($post) {
        $order_id = $post->ID;
        $this->render_order_meta_box_fields($order_id);
    }

    public function render_order_meta_box_hpos($object_or_order) {
        $order_id = 0;
        if (is_object($object_or_order) && method_exists($object_or_order, 'get_id')) {
            $order_id = intval($object_or_order->get_id());
        } elseif (is_object($object_or_order) && isset($object_or_order->ID)) {
            $order_id = intval($object_or_order->ID);
        }
        if ($order_id <= 0 && isset($_GET['id'])) {
            $order_id = intval($_GET['id']);
        }
        if ($order_id <= 0) {
            echo '<p>Unable to resolve order ID for Intigo Shipment.</p>';
            return;
        }
        $this->render_order_meta_box_fields($order_id);
    }

    private function render_order_meta_box_fields($order_id) {
        $city_id = get_post_meta($order_id, '_intigo_city_id', true);
        $district_id = get_post_meta($order_id, '_intigo_district_id', true);
        $neighborhood_id = get_post_meta($order_id, '_intigo_neighborhood_id', true);
        $package_size = get_post_meta($order_id, '_intigo_package_size', true);
        if ($package_size === '') {
            $package_size = 'S';
        }

        wp_nonce_field('intigo_order_meta_nonce', 'intigo_order_meta_nonce_field');
        ?>
        <style>
            .intigo-shipment-grid { display: grid; grid-template-columns: 1fr; gap: 10px; }
            .intigo-field label { font-weight: 600; display: block; margin-bottom: 4px; }
            .intigo-field small { display: block; color: #646970; margin-top: 4px; }
            .intigo-helper {
                border: 1px solid #dcdcde;
                background: #f6f7f7;
                padding: 8px;
                border-radius: 4px;
                margin-bottom: 10px;
                font-size: 12px;
                color: #50575e;
            }
        </style>
        <div class="intigo-helper">
            Step 1: Select City. Step 2: Select District. Step 3: Optional Neighborhood. Step 4: Choose package size.
        </div>
        <div class="intigo-shipment-grid">
        <p class="intigo-field">
            <label for="intigo_city_select"><strong>City</strong></label><br>
            <select id="intigo_city_select" name="intigo_city_id" style="width:100%;">
                <option value="">Select city</option>
            </select>
        </p>
        <p class="intigo-field">
            <label for="intigo_district_select"><strong>District</strong></label><br>
            <select id="intigo_district_select" name="intigo_district_id" style="width:100%;">
                <option value="">Select district</option>
            </select>
        </p>
        <p class="intigo-field">
            <label for="intigo_neighborhood_select"><strong>Neighborhood (optional)</strong></label><br>
            <select id="intigo_neighborhood_select" name="intigo_neighborhood_id" style="width:100%;">
                <option value="">Select neighborhood</option>
            </select>
        </p>
        <p class="intigo-field">
            <label for="intigo_package_size"><strong>Package Size</strong></label><br>
            <select id="intigo_package_size" name="intigo_package_size" style="width:100%;">
                <option value="S" <?php selected(strtoupper((string) $package_size), 'S'); ?>>S</option>
                <option value="M" <?php selected(strtoupper((string) $package_size), 'M'); ?>>M</option>
                <option value="L" <?php selected(strtoupper((string) $package_size), 'L'); ?>>L</option>
                <option value="XL" <?php selected(strtoupper((string) $package_size), 'XL'); ?>>XL</option>
            </select>
            <small>Mapped automatically for API payload.</small>
        </p>
        </div>
        <?php
        $bordereau_url = (string) get_post_meta($order_id, '_intigo_bordereau_url', true);
        $parcel_nid = (string) get_post_meta($order_id, '_intigo_parcel_nid', true);
        if ($bordereau_url !== ''):
            $download_url = wp_nonce_url(
                admin_url('admin-post.php?action=intigo_download_bordereau&order_id=' . intval($order_id)),
                'intigo_download_bordereau_' . intval($order_id)
            );
            ?>
            <p style="margin-top:10px;">
                <a class="button button-primary" href="<?php echo esc_url($download_url); ?>">Download Bordereau</a>
            </p>
            <?php if ($parcel_nid !== ''): ?>
                <p class="description">Parcel NID: <strong><?php echo esc_html($parcel_nid); ?></strong></p>
            <?php endif; ?>
        <?php else: ?>
            <p class="description" style="margin-top:10px;">Generate bordereau from Order Actions first, then download it here.</p>
        <?php endif; ?>

        <script>
        (function() {
            const ajaxUrl = "<?php echo esc_js(admin_url('admin-ajax.php')); ?>";
            const citySelect = document.getElementById('intigo_city_select');
            const districtSelect = document.getElementById('intigo_district_select');
            const neighborhoodSelect = document.getElementById('intigo_neighborhood_select');
            const currentCityId = "<?php echo esc_js((string) $city_id); ?>";
            const currentDistrictId = "<?php echo esc_js((string) $district_id); ?>";
            const currentNeighborhoodId = "<?php echo esc_js((string) $neighborhood_id); ?>";
            const nonce = "<?php echo esc_js(wp_create_nonce('intigo_lookup_nonce')); ?>";

            function addOption(select, value, label, selected) {
                const opt = document.createElement('option');
                opt.value = value;
                opt.textContent = label;
                if (selected) opt.selected = true;
                select.appendChild(opt);
            }

            function loadCities() {
                fetch(ajaxUrl + '?action=intigo_get_cities&_wpnonce=' + encodeURIComponent(nonce), { credentials: 'same-origin' })
                    .then(r => r.json())
                    .then(data => {
                        if (!data || !data.success || !Array.isArray(data.data)) {
                            citySelect.innerHTML = '';
                            addOption(citySelect, '', 'Lookup failed: check API URL/key', true);
                            return;
                        }
                        citySelect.innerHTML = '';
                        addOption(citySelect, '', 'Select city', false);
                        if (data.data.length === 0) {
                            addOption(citySelect, '', 'No cities returned by API', true);
                            return;
                        }
                        data.data.forEach(c => addOption(citySelect, c.id, c.name, String(c.id) === String(currentCityId)));
                        if (citySelect.value) {
                            loadDistricts(citySelect.value);
                        }
                    })
                    .catch(() => {
                        citySelect.innerHTML = '';
                        addOption(citySelect, '', 'Lookup failed: network/AJAX error', true);
                    });
            }

            function loadDistricts(cityId) {
                districtSelect.innerHTML = '';
                addOption(districtSelect, '', 'Loading districts...', false);
                fetch(ajaxUrl + '?action=intigo_get_districts&city_id=' + encodeURIComponent(cityId) + '&_wpnonce=' + encodeURIComponent(nonce), { credentials: 'same-origin' })
                    .then(r => r.json())
                    .then(data => {
                        districtSelect.innerHTML = '';
                        addOption(districtSelect, '', 'Select district', false);
                        if (!data || !data.success || !Array.isArray(data.data)) {
                            districtSelect.innerHTML = '';
                            addOption(districtSelect, '', 'Lookup failed: check API URL/key', true);
                            return;
                        }
                        if (data.data.length === 0) {
                            districtSelect.innerHTML = '';
                            addOption(districtSelect, '', 'No districts for selected city', true);
                            neighborhoodSelect.innerHTML = '';
                            addOption(neighborhoodSelect, '', 'Select neighborhood', false);
                            return;
                        }
                        data.data.forEach(d => addOption(districtSelect, d.id, d.name, String(d.id) === String(currentDistrictId)));
                        if (districtSelect.value) {
                            loadNeighborhoods(districtSelect.value);
                        }
                    })
                    .catch(() => {
                        districtSelect.innerHTML = '';
                        addOption(districtSelect, '', 'Lookup failed: network/AJAX error', true);
                    });
            }

            function loadNeighborhoods(districtId) {
                neighborhoodSelect.innerHTML = '';
                addOption(neighborhoodSelect, '', 'Loading neighborhoods...', false);
                fetch(ajaxUrl + '?action=intigo_get_neighborhoods&district_id=' + encodeURIComponent(districtId) + '&_wpnonce=' + encodeURIComponent(nonce), { credentials: 'same-origin' })
                    .then(r => r.json())
                    .then(data => {
                        neighborhoodSelect.innerHTML = '';
                        addOption(neighborhoodSelect, '', 'Select neighborhood', false);
                        if (!data || !data.success || !Array.isArray(data.data)) {
                            addOption(neighborhoodSelect, '', 'Lookup failed: check API URL/key', true);
                            return;
                        }
                        if (data.data.length === 0) {
                            addOption(neighborhoodSelect, '', 'No neighborhoods for selected district', true);
                            return;
                        }
                        data.data.forEach(n => addOption(neighborhoodSelect, n.id, n.name, String(n.id) === String(currentNeighborhoodId)));
                    })
                    .catch(() => {
                        neighborhoodSelect.innerHTML = '';
                        addOption(neighborhoodSelect, '', 'Lookup failed: network/AJAX error', true);
                    });
            }

            citySelect.addEventListener('change', function() {
                if (!citySelect.value) {
                    districtSelect.innerHTML = '';
                    addOption(districtSelect, '', 'Select district', false);
                    neighborhoodSelect.innerHTML = '';
                    addOption(neighborhoodSelect, '', 'Select neighborhood', false);
                    return;
                }
                loadDistricts(citySelect.value);
            });

            districtSelect.addEventListener('change', function() {
                if (!districtSelect.value) {
                    neighborhoodSelect.innerHTML = '';
                    addOption(neighborhoodSelect, '', 'Select neighborhood', false);
                    return;
                }
                loadNeighborhoods(districtSelect.value);
            });

            loadCities();
        })();
        </script>
        <?php
    }

    public function save_order_meta_box($post_id, $post) {
        if (!isset($_POST['intigo_order_meta_nonce_field']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['intigo_order_meta_nonce_field'])), 'intigo_order_meta_nonce')) {
            return;
        }
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        if (!$post || $post->post_type !== 'shop_order') {
            return;
        }
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }

        $city_id = isset($_POST['intigo_city_id']) ? intval($_POST['intigo_city_id']) : 0;
        $district_id = isset($_POST['intigo_district_id']) ? intval($_POST['intigo_district_id']) : 0;
        $neighborhood_id = isset($_POST['intigo_neighborhood_id']) ? intval($_POST['intigo_neighborhood_id']) : 0;
        $package_size = isset($_POST['intigo_package_size']) ? strtoupper(sanitize_text_field(wp_unslash($_POST['intigo_package_size']))) : 'S';

        if ($city_id > 0) {
            update_post_meta($post_id, '_intigo_city_id', $city_id);
        } else {
            delete_post_meta($post_id, '_intigo_city_id');
        }
        if ($district_id > 0) {
            update_post_meta($post_id, '_intigo_district_id', $district_id);
        } else {
            delete_post_meta($post_id, '_intigo_district_id');
        }
        if ($neighborhood_id > 0) {
            update_post_meta($post_id, '_intigo_neighborhood_id', $neighborhood_id);
        } else {
            delete_post_meta($post_id, '_intigo_neighborhood_id');
        }
        delete_post_meta($post_id, '_intigo_district_name');
        update_post_meta($post_id, '_intigo_package_size', in_array($package_size, ['S', 'M', 'L', 'XL'], true) ? $package_size : 'S');
    }

    public function save_order_meta_box_from_order_id($order_id) {
        if (!$order_id) {
            return;
        }
        // Reuse same nonce + payload handling in classic saver.
        $post = get_post($order_id);
        if (!$post) {
            // Build lightweight fallback object expected by save_order_meta_box
            $post = (object) ['post_type' => 'shop_order'];
        }
        $this->save_order_meta_box($order_id, $post);
    }

    public function render_hpos_inline_fields($order) {
        if (!is_object($order) || !method_exists($order, 'get_id')) {
            return;
        }
        $order_id = intval($order->get_id());
        if ($order_id <= 0) {
            return;
        }
        echo '<div class="order_data_column" style="width:100%; clear:both; margin-top:12px; border-top:1px solid #ddd; padding-top:12px;">';
        echo '<h4>Intigo Shipment</h4>';
        $this->render_order_meta_box_fields($order_id);
        echo '</div>';
    }

    public function ajax_get_cities() {
        check_ajax_referer('intigo_lookup_nonce');
        $settings = $this->api_client->get_settings();
        $base = rtrim((string) ($settings['primary_base_url'] ?? ''), '/');
        $template = $base . '/v3/regions/cities';
        if ($base === '' || strpos($template, 'http') !== 0) {
            wp_send_json_error(['message' => 'primary_base_url is not configured'], 400);
        }

        $url = str_replace('{city}', '', $template);
        $result = $this->fetch_lookup_items($url, $settings);
        if (!$result['ok']) {
            $this->add_log('lookup_cities_failed', $result['error']);
            wp_send_json_error(['message' => $result['error']], 502);
        }
        $items = $result['items'];
        $this->add_log('lookup_cities_ok', 'count=' . count($items));
        wp_send_json_success($items);
    }

    public function ajax_get_districts() {
        check_ajax_referer('intigo_lookup_nonce');
        $city_id = isset($_GET['city_id']) ? intval($_GET['city_id']) : 0;
        if ($city_id <= 0) {
            wp_send_json_error(['message' => 'city_id is required'], 400);
        }

        $settings = $this->api_client->get_settings();
        $base = rtrim((string) ($settings['primary_base_url'] ?? ''), '/');
        $template = $base . '/v3/regions/cities/{city_id}/districts';
        if ($base === '' || strpos($template, 'http') !== 0) {
            wp_send_json_error(['message' => 'primary_base_url is not configured'], 400);
        }

        $url = str_replace('{district}', '', $template);
        $url = str_replace('{city_id}', rawurlencode((string) $city_id), $url);
        $result = $this->fetch_lookup_items($url, $settings);
        if (!$result['ok']) {
            $this->add_log('lookup_districts_failed', 'city_id=' . $city_id . '; ' . $result['error']);
            wp_send_json_error(['message' => $result['error']], 502);
        }
        $items = $result['items'];
        $this->add_log('lookup_districts_ok', 'city_id=' . $city_id . '; count=' . count($items));
        wp_send_json_success($items);
    }

    public function ajax_get_neighborhoods() {
        check_ajax_referer('intigo_lookup_nonce');
        $district_id = isset($_GET['district_id']) ? intval($_GET['district_id']) : 0;
        if ($district_id <= 0) {
            wp_send_json_error(['message' => 'district_id is required'], 400);
        }

        $settings = $this->api_client->get_settings();
        $base = rtrim((string) ($settings['primary_base_url'] ?? ''), '/');
        $template = $base . '/v3/regions/districts/{district_id}/neighborhoods';
        if ($base === '' || strpos($template, 'http') !== 0) {
            wp_send_json_error(['message' => 'primary_base_url is not configured'], 400);
        }

        $url = str_replace('{district_id}', rawurlencode((string) $district_id), $template);
        $result = $this->fetch_lookup_items($url, $settings);
        if (!$result['ok']) {
            $this->add_log('lookup_neighborhoods_failed', 'district_id=' . $district_id . '; ' . $result['error']);
            wp_send_json_error(['message' => $result['error']], 502);
        }
        $this->add_log('lookup_neighborhoods_ok', 'district_id=' . $district_id . '; count=' . count($result['items']));
        wp_send_json_success($result['items']);
    }

    private function fetch_lookup_items($url, $settings) {
        $args = [
            'timeout' => 20,
            'headers' => [
                'Content-Type' => 'application/json',
                'X-API-KEY' => isset($settings['api_key']) ? $settings['api_key'] : '',
            ],
        ];
        $res = wp_remote_get($url, $args);
        if (is_wp_error($res)) {
            return ['ok' => false, 'error' => $res->get_error_message(), 'items' => []];
        }
        $code = wp_remote_retrieve_response_code($res);
        if (($code === 301 || $code === 302 || $code === 307 || $code === 308 || $code === 404) && substr($url, -1) !== '/') {
            $retry = wp_remote_get($url . '/', $args);
            if (!is_wp_error($retry)) {
                $retry_code = wp_remote_retrieve_response_code($retry);
                if ($retry_code >= 200 && $retry_code < 300) {
                    $res = $retry;
                    $code = $retry_code;
                }
            }
        }
        if ($code < 200 || $code >= 300) {
            $body = wp_remote_retrieve_body($res);
            return ['ok' => false, 'error' => 'HTTP ' . $code . ' ' . $body, 'items' => []];
        }
        $body = wp_remote_retrieve_body($res);
        $json = json_decode($body, true);
        if (!is_array($json)) {
            return ['ok' => false, 'error' => 'Invalid JSON response from lookup API', 'items' => []];
        }

        $rows = [];
        if (isset($json['data']) && is_array($json['data'])) {
            $rows = $json['data'];
        } elseif (isset($json['results']) && is_array($json['results'])) {
            $rows = $json['results'];
        } elseif (isset($json['cities']) && is_array($json['cities'])) {
            $rows = $json['cities'];
        } elseif (isset($json['districts']) && is_array($json['districts'])) {
            $rows = $json['districts'];
        } elseif (isset($json['neighborhoods']) && is_array($json['neighborhoods'])) {
            $rows = $json['neighborhoods'];
        } elseif (array_keys($json) === range(0, count($json) - 1)) {
            $rows = $json;
        }

        $out = [];
        foreach ($rows as $r) {
            if (!is_array($r) || !isset($r['id'])) {
                continue;
            }
            $name = '';
            if (isset($r['name'])) {
                $name = (string) $r['name'];
            } elseif (isset($r['city_name'])) {
                $name = (string) $r['city_name'];
            } elseif (isset($r['district_name'])) {
                $name = (string) $r['district_name'];
            } elseif (isset($r['neighborhood_name'])) {
                $name = (string) $r['neighborhood_name'];
            } elseif (isset($r['label'])) {
                $name = (string) $r['label'];
            } elseif (isset($r['title'])) {
                $name = (string) $r['title'];
            }
            if ($name === '') {
                continue;
            }
            $out[] = [
                'id' => intval($r['id']),
                'name' => $name,
            ];
        }
        return ['ok' => true, 'error' => '', 'items' => $out];
    }

    public function handle_download_bordereau() {
        if (!$this->is_intigo_logged_in()) {
            $this->add_log('download_bordereau_blocked', 'not_logged_in');
            $this->redirect_with_notice('intigo-dashboard', 'Please login to Intigo first.', 'warning');
            exit;
        }
        if (!current_user_can('edit_shop_orders') && !current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized');
        }
        $order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;
        if ($order_id <= 0) {
            wp_die('Invalid order id');
        }
        check_admin_referer('intigo_download_bordereau_' . $order_id);

        $order = wc_get_order($order_id);
        if (!$order) {
            wp_die('Order not found');
        }

        $url = (string) get_post_meta($order_id, '_intigo_bordereau_url', true);
        if ($url === '') {
            wp_die('No bordereau URL found for this order');
        }
        $this->add_log('download_bordereau_requested', 'order_id=' . $order_id);

        $res = wp_remote_get($url, ['timeout' => 60]);
        if (is_wp_error($res)) {
            wp_die('Download failed: ' . esc_html($res->get_error_message()));
        }

        $code = wp_remote_retrieve_response_code($res);
        if ($code < 200 || $code >= 300) {
            wp_die('Download failed: HTTP ' . intval($code));
        }

        $body = wp_remote_retrieve_body($res);
        if ($body === '') {
            wp_die('Download failed: empty response');
        }

        $filename_nid = (string) get_post_meta($order_id, '_intigo_parcel_nid', true);
        if ($filename_nid === '') {
            $filename_nid = 'order-' . $order_id;
        }
        $filename = 'bordereau-' . sanitize_file_name($filename_nid) . '.html';

        nocache_headers();
        header('Content-Type: text/html; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        echo $body; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
        exit;
    }

    public function handle_intigo_order_action() {
        if (!$this->is_intigo_logged_in()) {
            $this->add_log('order_action_blocked', 'not_logged_in');
            $this->redirect_with_notice('intigo-dashboard', 'Please login to Intigo first.', 'warning');
            exit;
        }
        if (!current_user_can('edit_shop_orders') && !current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized');
        }
        $order_id = isset($_GET['order_id']) ? intval($_GET['order_id']) : 0;
        $op = isset($_GET['op']) ? sanitize_text_field(wp_unslash($_GET['op'])) : '';
        if ($order_id <= 0 || $op === '') {
            wp_die('Invalid request');
        }
        if ($op === 'save_metadata') {
            check_admin_referer('intigo_order_action_meta_edit');
        } else {
            check_admin_referer('intigo_order_action_' . $order_id . '_' . $op);
        }
        $order = wc_get_order($order_id);
        if (!$order) {
            wp_die('Order not found');
        }

        $notice = 'Action completed';
        $notice_type = 'success';
        if ($op === 'create') {
            $this->order_service->create_single_for_order($order);
            $notice = 'Order #' . $order_id . ': sent to Intigo.';
            $this->add_log('order_create_parcel', 'order_id=' . $order_id);
        } elseif ($op === 'bordereau') {
            $this->order_service->generate_bordereau_for_order($order);
            $notice = 'Order #' . $order_id . ': bordereau generated. Download/Print is now available when URL is returned.';
            $this->add_log('order_generate_bordereau', 'order_id=' . $order_id);
        } elseif ($op === 'sync_update') {
            $nid = (string) get_post_meta($order_id, '_intigo_parcel_nid', true);
            if ($nid === '') {
                $notice = 'Sync skipped: create parcel in Intigo first.';
                $notice_type = 'warning';
            } else {
                $sync_res = $this->order_service->update_parcel_for_order($order);
                if (!empty($sync_res['ok'])) {
                    $notice = 'Order #' . $order_id . ': synchronized with Intigo.';
                    $this->add_log('order_sync_update', 'order_id=' . $order_id);
                } else {
                    $notice = 'Sync failed for order #' . $order_id . ': ' . ($sync_res['message'] ?? 'unknown error');
                    $notice_type = 'error';
                    $this->add_log('order_sync_update_failed', 'order_id=' . $order_id . '; error=' . ($sync_res['message'] ?? 'unknown'));
                }
            }
        } elseif ($op === 'cancel') {
            $nid = (string) get_post_meta($order_id, '_intigo_parcel_nid', true);
            if ($nid === '') {
                $notice = 'Cancel skipped: no Intigo parcel ID found.';
                $notice_type = 'warning';
            } else {
                $res = $this->api_client->cancel_parcel($nid);
                if (!empty($res['ok'])) {
                    $notice = 'Order #' . $order_id . ': parcel cancelled successfully.';
                    $this->add_log('order_cancel', 'order_id=' . $order_id . '; nid=' . $nid);
                } else {
                    $notice = 'Cancel failed for order #' . $order_id . '.';
                    $notice_type = 'error';
                    $this->add_log('order_cancel_failed', 'order_id=' . $order_id . '; nid=' . $nid);
                }
            }
        } elseif ($op === 'relance') {
            $nid = (string) get_post_meta($order_id, '_intigo_parcel_nid', true);
            if ($nid === '') {
                $notice = 'Relance skipped: no Intigo parcel ID found.';
                $notice_type = 'warning';
            } else {
                $res = $this->api_client->relance_parcel($nid, false);
                if (!empty($res['ok'])) {
                    $notice = 'Order #' . $order_id . ': relance requested.';
                    $this->add_log('order_relance', 'order_id=' . $order_id . '; nid=' . $nid);
                } else {
                    $notice = 'Relance failed for order #' . $order_id . '.';
                    $notice_type = 'error';
                    $this->add_log('order_relance_failed', 'order_id=' . $order_id . '; nid=' . $nid);
                }
            }
        } elseif ($op === 'report_delay') {
            $nid = (string) get_post_meta($order_id, '_intigo_parcel_nid', true);
            if ($nid === '') {
                $notice = 'Report delay skipped: no Intigo parcel ID found.';
                $notice_type = 'warning';
            } else {
                $res = $this->api_client->report_delay($nid, 'Reported from WooCommerce Intigo plugin');
                if (!empty($res['ok'])) {
                    $notice = 'Order #' . $order_id . ': delay reported successfully.';
                    $this->add_log('order_report_delay', 'order_id=' . $order_id . '; nid=' . $nid);
                } else {
                    $notice = 'Report delay failed for order #' . $order_id . '.';
                    $notice_type = 'error';
                    $this->add_log('order_report_delay_failed', 'order_id=' . $order_id . '; nid=' . $nid);
                }
            }
        } elseif ($op === 'save_metadata') {
            $city_id = isset($_GET['intigo_city_id']) ? intval($_GET['intigo_city_id']) : 0;
            $district_id = isset($_GET['intigo_district_id']) ? intval($_GET['intigo_district_id']) : 0;
            $neighborhood_id = isset($_GET['intigo_neighborhood_id']) ? intval($_GET['intigo_neighborhood_id']) : 0;
            $package_size = isset($_GET['intigo_package_size']) ? strtoupper(sanitize_text_field(wp_unslash($_GET['intigo_package_size']))) : 'S';
            if ($city_id <= 0 || $district_id <= 0) {
                $notice = 'Metadata save failed: city_id and district_id are required.';
                $notice_type = 'error';
                $this->add_log('order_metadata_save_failed', 'order_id=' . $order_id . '; missing city_id/district_id');
            } else {
                update_post_meta($order_id, '_intigo_city_id', $city_id);
                update_post_meta($order_id, '_intigo_district_id', $district_id);
                if ($neighborhood_id > 0) {
                    update_post_meta($order_id, '_intigo_neighborhood_id', $neighborhood_id);
                } else {
                    delete_post_meta($order_id, '_intigo_neighborhood_id');
                }
                if (!in_array($package_size, ['S', 'M', 'L', 'XL'], true)) {
                    $package_size = 'S';
                }
                update_post_meta($order_id, '_intigo_package_size', $package_size);
                $notice = 'Order #' . $order_id . ': Intigo metadata updated.';
                $this->add_log('order_metadata_saved', 'order_id=' . $order_id . '; city=' . $city_id . '; district=' . $district_id);
            }
        }

        $this->redirect_with_notice('intigo-manage-orders', $notice, $notice_type);
        exit;
    }

    public function handle_intigo_login() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized');
        }
        check_admin_referer('intigo_login');
        $label = isset($_POST['intigo_login_label']) ? sanitize_text_field(wp_unslash($_POST['intigo_login_label'])) : '';
        $api_key = isset($_POST['intigo_login_api_key']) ? sanitize_text_field(wp_unslash($_POST['intigo_login_api_key'])) : '';
        if ($api_key === '') {
            $this->add_log('login_failed', 'missing_api_key');
            $this->redirect_with_notice('intigo-dashboard', 'API key is required to login.', 'error');
            exit;
        }

        $settings = $this->api_client->get_settings();
        $settings['api_key'] = $api_key;
        update_option(Intigo_API_Client::OPTION_KEY, $settings);
        $health = $this->check_health();
        if (!$health['ok']) {
            $this->add_log('login_failed', $health['message']);
            $this->redirect_with_notice('intigo-dashboard', 'Login failed: ' . $health['message'], 'error');
            exit;
        }

        update_option(self::OPTION_AUTH, [
            'logged_in' => 'yes',
            'label' => $label !== '' ? $label : wp_get_current_user()->display_name,
            'user_id' => get_current_user_id(),
            'logged_at' => current_time('mysql'),
        ]);
        $this->add_log('login_success', 'user_id=' . get_current_user_id());
        $this->redirect_with_notice('intigo-dashboard', 'Logged in to Intigo successfully.', 'success');
        exit;
    }

    public function handle_intigo_logout() {
        if (!current_user_can('manage_woocommerce')) {
            wp_die('Unauthorized');
        }
        check_admin_referer('intigo_logout');
        delete_option(self::OPTION_AUTH);
        $this->add_log('logout', 'user_id=' . get_current_user_id());
        $this->redirect_with_notice('intigo-dashboard', 'Logged out from Intigo.', 'info');
        exit;
    }

    private function render_login_interface($message = '') {
        $notice = $this->get_notice_message();
        ?>
        <div class="wrap">
            <h1>Intigo Login</h1>
            <p style="color:#50575e;">Login to enable Intigo system interactions (create parcel, bordereau, sync).</p>
            <?php $this->render_snackbar(); ?>
            <?php if ($message !== ''): ?>
                <div style="margin:12px 0; padding:10px 12px; border-left:4px solid #dba617; background:#fff;"><?php echo esc_html($message); ?></div>
            <?php endif; ?>
            <div style="background:#fff; border:1px solid #dcdcde; border-radius:8px; padding:16px; max-width:560px;">
                <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                    <input type="hidden" name="action" value="intigo_login">
                    <?php wp_nonce_field('intigo_login'); ?>
                    <table class="form-table" role="presentation">
                        <tr>
                            <th scope="row"><label for="intigo_login_label">Display Name</label></th>
                            <td><input id="intigo_login_label" name="intigo_login_label" class="regular-text" type="text" placeholder="Team Member"></td>
                        </tr>
                        <tr>
                            <th scope="row"><label for="intigo_login_api_key">Intigo API Key</label></th>
                            <td><input id="intigo_login_api_key" name="intigo_login_api_key" class="regular-text" type="password" required></td>
                        </tr>
                    </table>
                    <?php submit_button('Login to Intigo'); ?>
                </form>
            </div>
        </div>
        <?php
    }

    private function is_intigo_logged_in() {
        $auth = get_option(self::OPTION_AUTH, []);
        return is_array($auth) && (($auth['logged_in'] ?? 'no') === 'yes');
    }

    private function get_intigo_login_label() {
        $auth = get_option(self::OPTION_AUTH, []);
        if (is_array($auth) && !empty($auth['label'])) {
            return (string) $auth['label'];
        }
        $u = wp_get_current_user();
        return $u && !empty($u->display_name) ? (string) $u->display_name : 'User';
    }

    private function render_environment_badge() {
        $settings = $this->api_client->get_settings();
        $mode = ($settings['environment_mode'] ?? 'sandbox') === 'production' ? 'production' : 'sandbox';
        if ($mode === 'sandbox') {
            echo '<div style="margin:10px 0; padding:10px 12px; border-left:4px solid #dba617; background:#fff7e6;"><strong>Testing Mode:</strong> Sandbox environment is active. No live shipments should be used for real operations.</div>';
            return;
        }
        echo '<div style="margin:10px 0; padding:10px 12px; border-left:4px solid #46b450; background:#f6fff6;"><strong>Production Mode:</strong> Live environment is active. Real shipments may be created.</div>';
    }

    private function get_notice_message() {
        return isset($_GET['intigo_notice']) ? sanitize_text_field(wp_unslash($_GET['intigo_notice'])) : '';
    }

    private function get_notice_type() {
        $type = isset($_GET['intigo_notice_type']) ? sanitize_text_field(wp_unslash($_GET['intigo_notice_type'])) : 'info';
        return in_array($type, ['success', 'error', 'warning', 'info'], true) ? $type : 'info';
    }

    private function redirect_with_notice($page, $message, $type = 'info') {
        wp_safe_redirect(add_query_arg([
            'page' => $page,
            'intigo_notice' => rawurlencode((string) $message),
            'intigo_notice_type' => rawurlencode((string) $type),
        ], admin_url('admin.php')));
    }

    private function render_snackbar() {
        $message = $this->get_notice_message();
        if ($message === '') {
            return;
        }
        $type = $this->get_notice_type();
        $bg = '#2271b1';
        if ($type === 'success') {
            $bg = '#1f8f4f';
        } elseif ($type === 'error') {
            $bg = '#d63638';
        } elseif ($type === 'warning') {
            $bg = '#dba617';
        }
        ?>
        <div id="intigo-snackbar" style="position:fixed; right:20px; bottom:20px; z-index:100100; max-width:420px; background:<?php echo esc_attr($bg); ?>; color:#fff; padding:12px 14px; border-radius:8px; box-shadow:0 8px 20px rgba(0,0,0,.2);">
            <strong style="display:block; margin-bottom:4px; text-transform:capitalize;"><?php echo esc_html($type); ?></strong>
            <span><?php echo esc_html($message); ?></span>
        </div>
        <script>
        (function() {
            const sb = document.getElementById('intigo-snackbar');
            if (!sb) return;
            setTimeout(() => {
                sb.style.transition = 'opacity .25s ease';
                sb.style.opacity = '0';
                setTimeout(() => { if (sb.parentNode) sb.parentNode.removeChild(sb); }, 280);
            }, 4500);
        })();
        </script>
        <?php
    }

    private function render_interface_nav($current_page) {
        $items = [
            'intigo-dashboard' => 'Dashboard',
            'intigo-manage-orders' => 'Manage Orders',
            'intigo-logs' => 'Logs',
            'intigo-docs' => 'Documentation',
            'intigo-parcels-settings' => 'Settings',
        ];
        echo '<div style="margin:8px 0 12px 0; display:flex; gap:8px; flex-wrap:wrap;">';
        foreach ($items as $slug => $label) {
            $class = $slug === $current_page ? 'button button-primary' : 'button';
            $url = admin_url('admin.php?page=' . $slug);
            echo '<a class="' . esc_attr($class) . '" href="' . esc_url($url) . '">' . esc_html($label) . '</a>';
        }
        echo '</div>';
    }

    private function render_responsive_styles() {
        ?>
        <style>
            .wrap .widefat { width: 100%; }
            .wrap .intigo-card,
            .wrap .intigo-chart-card { box-sizing: border-box; }
            .wrap .intigo-card { width: 100%; max-width: none; }
            .wrap .intigo-card table.widefat { width: 100% !important; min-width: 100%; }
            .wrap .intigo-kpis { display: grid; grid-template-columns: repeat(4, minmax(160px, 1fr)); gap: 10px; }
            .wrap .intigo-charts { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
            .wrap .widefat { display: block; overflow-x: auto; -webkit-overflow-scrolling: touch; }
            .wrap .widefat thead th,
            .wrap .widefat tbody td { white-space: nowrap; }
            .intigo-modal { max-height: 90vh; overflow: auto; }

            @media (max-width: 1200px) {
                .wrap .intigo-kpis { grid-template-columns: repeat(3, minmax(160px, 1fr)); }
            }
            @media (max-width: 900px) {
                .wrap .intigo-kpis { grid-template-columns: repeat(2, minmax(140px, 1fr)); }
                .wrap .intigo-charts { grid-template-columns: 1fr; }
            }
            @media (max-width: 600px) {
                .wrap .intigo-kpis { grid-template-columns: 1fr; }
                .wrap .button { width: 100%; text-align: center; margin-bottom: 6px; }
                .wrap .widefat thead th,
                .wrap .widefat tbody td { font-size: 12px; }
                .intigo-modal { width: 94vw; }
                .intigo-modal-header { flex-wrap: wrap; gap: 8px; }
            }
        </style>
        <?php
    }

    private function is_order_new($order_id) {
        return (string) get_post_meta($order_id, '_intigo_seen_at', true) === '';
    }

    private function get_new_orders_count() {
        if (!function_exists('wc_get_orders')) {
            return 0;
        }
        $orders = wc_get_orders(['limit' => 50, 'orderby' => 'date', 'order' => 'DESC']);
        $count = 0;
        foreach ($orders as $order) {
            if (!$order || !method_exists($order, 'get_id')) {
                continue;
            }
            if ($this->is_order_new($order->get_id())) {
                $count++;
            }
        }
        return $count;
    }

    private function mark_orders_as_seen($orders) {
        foreach ($orders as $order) {
            if (!$order || !method_exists($order, 'get_id')) {
                continue;
            }
            $order_id = $order->get_id();
            if ($this->is_order_new($order_id)) {
                update_post_meta($order_id, '_intigo_seen_at', current_time('mysql'));
            }
        }
    }

    public function render_manage_orders_shortcode() {
        if (!is_user_logged_in()) {
            return '<p>Please login to access Intigo manage orders.</p>';
        }
        if (!current_user_can('manage_woocommerce')) {
            return '<p>You do not have permission to access Intigo manage orders.</p>';
        }
        $url = admin_url('admin.php?page=intigo-manage-orders');
        return '<p><a class="button" href="' . esc_url($url) . '">Open Intigo Manage Orders</a></p>';
    }

    private function compute_automatic_ops_status($city_id, $district_id, $package_size, $nid, $bordereau_url) {
        if ((string) $city_id === '' || (string) $district_id === '' || (string) $package_size === '') {
            return 'missing_data';
        }
        if ((string) $nid === '' && (string) $bordereau_url === '') {
            return 'verified';
        }
        if ((string) $nid !== '' && (string) $bordereau_url === '') {
            return 'need_confirmation';
        }
        return 'ready_for_shipment';
    }

    private function build_order_tags($city_id, $district_id, $package_size, $nid, $ops_status) {
        $tags = [];
        $ops_status_label = '';
        $ops_status_class = 'intigo-pill-muted';
        if ($ops_status === 'verified') {
            $ops_status_label = 'Verified';
            $ops_status_class = 'intigo-pill-ok';
        } elseif ($ops_status === 'ready_for_shipment') {
            $ops_status_label = 'Ready For Shipment';
            $ops_status_class = 'intigo-pill-info';
        } elseif ($ops_status === 'missing_data') {
            $ops_status_label = 'Missing Data';
            $ops_status_class = 'intigo-pill-warn';
        } elseif ($ops_status === 'need_confirmation') {
            $ops_status_label = 'Need Confirmation';
            $ops_status_class = 'intigo-pill-muted';
        }
        if ($ops_status_label !== '') {
            $tags[] = ['label' => $ops_status_label, 'class' => $ops_status_class];
        }
        return $tags;
    }

    private function check_health() {
        $settings = $this->api_client->get_settings();
        $base = rtrim((string) ($settings['primary_base_url'] ?? ''), '/');
        if ($base === '') {
            return ['ok' => false, 'message' => 'Primary Base URL is not configured'];
        }
        $health_url = preg_replace('#/api$#', '', $base) . '/health';
        $res = wp_remote_get($health_url, ['timeout' => 10]);
        if (is_wp_error($res)) {
            return ['ok' => false, 'message' => 'Health check failed: ' . $res->get_error_message()];
        }
        $code = wp_remote_retrieve_response_code($res);
        if ($code >= 200 && $code < 300) {
            return ['ok' => true, 'message' => 'Connected (' . $health_url . ')'];
        }
        return ['ok' => false, 'message' => 'Health check HTTP ' . $code . ' (' . $health_url . ')'];
    }

    private function compute_dashboard_metrics($orders) {
        $metrics = [
            'total_orders' => count($orders),
            'with_parcel' => 0,
            'with_bordereau' => 0,
            'missing_data' => 0,
            'verified' => 0,
            'need_confirmation' => 0,
            'ready_for_shipment' => 0,
            'total_sales' => 0.0,
            'avg_order_value' => 0.0,
            'coverage_rate' => 0.0,
            'ready_rate' => 0.0,
            'bordereau_rate' => 0.0,
        ];
        foreach ($orders as $metrics_order) {
            $metrics_order_id = $metrics_order->get_id();
            $metrics['total_sales'] += floatval($metrics_order->get_total());
            $m_nid = (string) get_post_meta($metrics_order_id, '_intigo_parcel_nid', true);
            $m_bordereau = (string) get_post_meta($metrics_order_id, '_intigo_bordereau_url', true);
            $m_city = (string) get_post_meta($metrics_order_id, '_intigo_city_id', true);
            $m_district = (string) get_post_meta($metrics_order_id, '_intigo_district_id', true);
            $m_package = (string) get_post_meta($metrics_order_id, '_intigo_package_size', true);
            if ($m_nid !== '') {
                $metrics['with_parcel']++;
            }
            if ($m_bordereau !== '') {
                $metrics['with_bordereau']++;
            }
            $m_status = $this->compute_automatic_ops_status($m_city, $m_district, $m_package, $m_nid, $m_bordereau);
            if (isset($metrics[$m_status])) {
                $metrics[$m_status]++;
            }
        }
        if ($metrics['total_orders'] > 0) {
            $metrics['avg_order_value'] = round($metrics['total_sales'] / $metrics['total_orders'], 2);
            $metrics['coverage_rate'] = round(($metrics['with_parcel'] / $metrics['total_orders']) * 100, 1);
            $metrics['ready_rate'] = round(($metrics['ready_for_shipment'] / $metrics['total_orders']) * 100, 1);
            $metrics['bordereau_rate'] = round(($metrics['with_bordereau'] / $metrics['total_orders']) * 100, 1);
        }
        return $metrics;
    }

    private function add_log($action, $context = '') {
        $logs = get_option(self::OPTION_LOGS, []);
        if (!is_array($logs)) {
            $logs = [];
        }
        $user = wp_get_current_user();
        $actor = ($user && !empty($user->user_login)) ? $user->user_login : 'system';
        array_unshift($logs, [
            'time' => current_time('mysql'),
            'actor' => $actor,
            'action' => sanitize_text_field((string) $action),
            'context' => sanitize_text_field((string) $context),
        ]);
        if (count($logs) > self::MAX_LOGS) {
            $logs = array_slice($logs, 0, self::MAX_LOGS);
        }
        update_option(self::OPTION_LOGS, $logs, false);
    }

    private function get_logs() {
        $logs = get_option(self::OPTION_LOGS, []);
        return is_array($logs) ? $logs : [];
    }
}

