<?php

if (!defined('ABSPATH')) {
    exit;
}

class Intigo_API_Client {
    const OPTION_KEY = 'intigo_parcels_settings';
    const SANDBOX_BASE_URL = 'https://dev-api.intigo.net/api';
    const PRODUCTION_BASE_URL = 'https://api.intigo.net/api';

    public function get_settings() {
        $defaults = [
            // Environment switch
            'environment_mode' => 'sandbox',
            'api_key' => '',
            'fallback_enabled' => 'yes',
            'auto_create_on_paid' => 'no',
            'default_package_size' => 'S',
        ];
        $settings = wp_parse_args(get_option(self::OPTION_KEY, []), $defaults);
        $mode = ($settings['environment_mode'] ?? 'sandbox') === 'production' ? 'production' : 'sandbox';
        $active_primary = $mode === 'production' ? self::PRODUCTION_BASE_URL : self::SANDBOX_BASE_URL;
        $settings['environment_mode'] = $mode;
        $settings['primary_base_url'] = $active_primary;
        // Keep fallback pointing to active environment API unless changed internally in code.
        $settings['legacy_base_url'] = $active_primary;
        return $settings;
    }

    private function request($method, $path, $payload = null, $adapter = 'primary') {
        $settings = $this->get_settings();
        $base = $adapter === 'legacy' ? $settings['legacy_base_url'] : $settings['primary_base_url'];
        $url = rtrim($base, '/') . '/' . ltrim($path, '/');

        $args = [
            'method' => strtoupper($method),
            'timeout' => 20,
            'headers' => [
                'Content-Type' => 'application/json',
                'X-API-KEY' => $settings['api_key'],
            ],
        ];
        if ($payload !== null) {
            $args['body'] = wp_json_encode($payload);
        }

        $res = wp_remote_request($url, $args);
        if (is_wp_error($res)) {
            return ['ok' => false, 'code' => 0, 'error' => $res->get_error_message(), 'adapter' => $adapter];
        }

        $code = wp_remote_retrieve_response_code($res);
        $body = wp_remote_retrieve_body($res);
        $json = json_decode($body, true);
        $data = is_array($json) ? $json : ['raw_body' => $body];

        if ($code >= 200 && $code < 300) {
            return ['ok' => true, 'code' => $code, 'data' => $data, 'adapter' => $adapter];
        }

        return ['ok' => false, 'code' => $code, 'data' => $data, 'adapter' => $adapter];
    }

    private function with_fallback($method, $primary_path, $payload = null, $legacy_path = null) {
        $settings = $this->get_settings();
        $primary = $this->request($method, $primary_path, $payload, 'primary');
        if ($primary['ok']) {
            return $primary;
        }

        if ($settings['fallback_enabled'] !== 'yes') {
            return $primary;
        }

        if ($primary['code'] === 401 || empty($legacy_path)) {
            return $primary;
        }

        return $this->request($method, $legacy_path, $payload, 'legacy');
    }

    public function create_parcel($payload) {
        return $this->with_fallback('POST', '/v3/parcels/', $payload, '/expediteurs/api/parcel/create/');
    }

    public function create_parcels_batch($payload) {
        return $this->with_fallback('POST', '/v3/parcels/batch', $payload, '/expediteurs/api/parcels/batch/');
    }

    public function generate_bordereau($nids) {
        return $this->with_fallback('POST', '/v3/parcels/bordereau', ['nids' => $nids], null);
    }

    public function status_bulk($nids) {
        return $this->with_fallback('POST', '/v3/parcels/status', ['nids' => $nids], null);
    }

    public function update_parcel($nid, $payload) {
        $nid = rawurlencode((string) $nid);
        return $this->with_fallback('PATCH', '/v3/parcels/' . $nid, $payload, null);
    }

    public function cancel_parcel($nid) {
        $nid = rawurlencode((string) $nid);
        return $this->with_fallback('POST', '/v3/parcels/' . $nid . '/cancel', [], null);
    }

    public function relance_parcel($nid, $accept_fee = false) {
        $nid = rawurlencode((string) $nid);
        return $this->with_fallback('POST', '/v3/parcels/' . $nid . '/relance', ['accept_fee' => (bool) $accept_fee], null);
    }

    public function report_delay($nid, $reason = '') {
        $nid = rawurlencode((string) $nid);
        $payload = [];
        if (trim((string) $reason) !== '') {
            $payload['reason'] = (string) $reason;
        }
        return $this->with_fallback('POST', '/v3/parcels/' . $nid . '/report-delay', $payload, null);
    }

    public function change_phone($nid, $phone) {
        $nid = rawurlencode((string) $nid);
        return $this->with_fallback('POST', '/v3/parcels/' . $nid . '/change-phone', [
            'phone' => (string) $phone,
        ], null);
    }

    public function change_price($nid, $price) {
        $nid = rawurlencode((string) $nid);
        return $this->with_fallback('POST', '/v3/parcels/' . $nid . '/change-price', [
            'price' => floatval($price),
        ], null);
    }

    public function change_address($nid, $payload) {
        $nid = rawurlencode((string) $nid);
        return $this->with_fallback('POST', '/v3/parcels/' . $nid . '/change-address', $payload, null);
    }

    public function resolve_city_id($city_name) {
        $settings = $this->get_settings();
        $city_name = trim((string) $city_name);
        if ($city_name === '') {
            return 0;
        }
        $template = isset($settings['city_lookup_url']) ? trim((string) $settings['city_lookup_url']) : '';
        if ($template === '') {
            // Auto-derive from primary base URL.
            $template = rtrim((string) $settings['primary_base_url'], '/') . '/v3/regions/cities';
        }
        $url = str_replace('{city}', rawurlencode($city_name), $template);
        $res = wp_remote_get($url, [
            'timeout' => 20,
            'headers' => [
                'Content-Type' => 'application/json',
                'X-API-KEY' => $settings['api_key'],
            ],
        ]);
        if (is_wp_error($res)) {
            return 0;
        }
        $code = wp_remote_retrieve_response_code($res);
        if ($code < 200 || $code >= 300) {
            return 0;
        }
        $body = wp_remote_retrieve_body($res);
        $json = json_decode($body, true);
        return $this->extract_first_id($json);
    }

    public function resolve_district_id($district_name, $city_id = 0) {
        $settings = $this->get_settings();
        $district_name = trim((string) $district_name);
        if ($district_name === '') {
            return 0;
        }
        $template = isset($settings['district_lookup_url']) ? trim((string) $settings['district_lookup_url']) : '';
        if ($template === '') {
            if (intval($city_id) <= 0) {
                return 0;
            }
            // Auto-derive from primary base URL.
            $template = rtrim((string) $settings['primary_base_url'], '/') . '/v3/regions/cities/{city_id}/districts';
        }
        $url = str_replace('{district}', rawurlencode($district_name), $template);
        $url = str_replace('{city_id}', rawurlencode((string) intval($city_id)), $url);
        $res = wp_remote_get($url, [
            'timeout' => 20,
            'headers' => [
                'Content-Type' => 'application/json',
                'X-API-KEY' => $settings['api_key'],
            ],
        ]);
        if (is_wp_error($res)) {
            return 0;
        }
        $code = wp_remote_retrieve_response_code($res);
        if ($code < 200 || $code >= 300) {
            return 0;
        }
        $body = wp_remote_retrieve_body($res);
        $json = json_decode($body, true);
        return $this->extract_first_id($json);
    }

    private function extract_first_id($json) {
        // Accept common response shapes:
        // {id:1}, {data:[{id:1}]}, [{id:1}], {results:[{id:1}]}, {cities:[{id:1}]}, {districts:[{id:1}]}
        if (is_array($json) && isset($json['id'])) {
            return intval($json['id']);
        }
        $candidates = [];
        if (is_array($json)) {
            if (isset($json['data']) && is_array($json['data'])) {
                $candidates = $json['data'];
            } elseif (isset($json['results']) && is_array($json['results'])) {
                $candidates = $json['results'];
            } elseif (isset($json['cities']) && is_array($json['cities'])) {
                $candidates = $json['cities'];
            } elseif (isset($json['districts']) && is_array($json['districts'])) {
                $candidates = $json['districts'];
            } elseif (array_keys($json) === range(0, count($json) - 1)) {
                $candidates = $json;
            }
        }
        if (!empty($candidates) && is_array($candidates[0]) && isset($candidates[0]['id'])) {
            return intval($candidates[0]['id']);
        }
        return 0;
    }
}

