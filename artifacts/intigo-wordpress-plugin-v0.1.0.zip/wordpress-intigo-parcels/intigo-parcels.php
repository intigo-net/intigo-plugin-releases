<?php
/**
 * Plugin Name: Intigo Parcels for WooCommerce
 * Description: Create Intigo parcels and generate bordereaux from WooCommerce orders.
 * Version: 0.1.0
 * Author: Intigo
 */

if (!defined('ABSPATH')) {
    exit;
}

define('INTIGO_PARCELS_VERSION', '0.1.0');
define('INTIGO_PARCELS_FILE', __FILE__);
define('INTIGO_PARCELS_DIR', plugin_dir_path(__FILE__));

require_once INTIGO_PARCELS_DIR . 'includes/class-intigo-api-client.php';
require_once INTIGO_PARCELS_DIR . 'includes/class-intigo-order-service.php';
require_once INTIGO_PARCELS_DIR . 'includes/class-intigo-admin.php';
require_once INTIGO_PARCELS_DIR . 'includes/class-intigo-sync.php';

final class Intigo_Parcels_Plugin {
    private static $instance = null;
    private $api_client;
    private $order_service;
    private $admin;
    private $sync;

    public static function instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->api_client = new Intigo_API_Client();
        $this->order_service = new Intigo_Order_Service($this->api_client);
        $this->admin = new Intigo_Admin($this->order_service);
        $this->sync = new Intigo_Sync($this->api_client);

        add_action('plugins_loaded', [$this, 'bootstrap']);
        register_activation_hook(INTIGO_PARCELS_FILE, [$this, 'activate']);
    }

    public function bootstrap() {
        $this->admin->register();
        $this->order_service->register_hooks();
        $this->sync->register_hooks();
    }

    public function activate() {
        if (!wp_next_scheduled('intigo_parcels_status_sync_cron')) {
            wp_schedule_event(time() + 300, 'hourly', 'intigo_parcels_status_sync_cron');
        }
    }
}

Intigo_Parcels_Plugin::instance();

