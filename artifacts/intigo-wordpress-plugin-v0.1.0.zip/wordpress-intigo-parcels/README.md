# WordPress Intigo Parcels Plugin

WooCommerce plugin for Intigo parcel operations.

## Features

- Single parcel creation from order action
- Batch parcel creation from admin list bulk action
- Bordereau URL generation from order action
- Hourly status sync (cron)
- Optional auto-create on order paid event
- Primary/fallback API routing

## Install

1. Zip `wordpress-intigo-parcels`.
2. Upload in `wp-admin -> Plugins -> Add New -> Upload Plugin`.
3. Activate plugin.
4. Configure in `Settings -> Intigo Parcels`.

